/*
 * 다람쌤 장기 한판 — 온라인 주소로 열기 (Cloudflare Worker)
 * ──────────────────────────────────────────────────────────
 * 화면 하나짜리 정적 앱이라 서버가 하는 일은 index.html 을 내려 주는 것뿐임.
 * 데이터베이스·비밀키·설정이 필요 없음.
 *
 *   - 주소: https://<워커주소>/
 *
 * ※ 이 파일은 build-janggi-worker.mjs 가 만든 자동 생성본임.
 *    화면(janggi/index.html)을 고친 뒤에는 빌드 스크립트를 다시 실행할 것.
 *
 * 올리는 법 (Cloudflare 대시보드에서 한 번만):
 *  1. Workers & Pages → Create → Worker 만들기 (이름 예: janggi)
 *  2. 이 파일(janggi-worker.js) 내용을 그대로 붙여넣고 Deploy
 *  3. 끝. 주소는 https://janggi.<계정이름>.workers.dev
 */

const APP_HTML = `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>다람쌤 장기 한판</title>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Gowun+Batang:wght@400;700&family=Noto+Sans+KR:wght@400;500;700;900&family=Noto+Serif+KR:wght@600;900&display=swap">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  :root {
    --ink:#17120d; --ink2:#241a12; --ink3:#33251a;
    --hanji:#f4e6c6;
    --board1:#f0d7a6; --board2:#dcb175; --board-edge:#7a4f22;
    --line:#6b4420;
    --han:#c0392b; --han-l:#ef6a5c;
    --cho:#137a4b; --cho-l:#37b97c;
    --gold:#dcb463; --gold-d:#8f6c22;
    --text:#f4e8d4; --muted:#bda98a;
    --panel:rgba(44,32,22,.86); --panel-b:rgba(220,180,99,.28);
    --danger:#e0604e; --ok:#57b98a;
    --wood-pc1:#f6e6c3; --wood-pc2:#dcbf8e;
  }
  html, body { height:100%; }
  /* 화면 글자 크기 기준. 이 값만 바꾸면 글자 전체가 함께 줄고 늘어남.
     장기판 위의 말은 판 너비에서 계산하므로 여기 영향을 받지 않음. */
  :root { font-size:14.4px; }
  body {
    font-family:'Noto Sans KR','Malgun Gothic','Apple SD Gothic Neo',sans-serif;
    color:var(--text); min-height:100%; overflow-x:hidden;
    background:
      radial-gradient(ellipse 120% 60% at 50% -8%, rgba(220,180,99,.16) 0%, rgba(23,18,13,0) 60%),
      linear-gradient(180deg, #221a12 0%, #17120d 60%, #0e0b07 100%);
    background-attachment:fixed;
  }
  #grain { position:fixed; inset:0; pointer-events:none; z-index:0; opacity:.5;
    background-image:repeating-linear-gradient(115deg, rgba(255,255,255,.018) 0 2px, rgba(0,0,0,0) 2px 6px); }
  #app { position:relative; z-index:1; max-width:1120px; margin:0 auto; padding-inline:16px; padding-block:12px 40px; }

  .screen { display:none; animation:fadein .28s ease; }
  .screen.active { display:block; }
  @keyframes fadein { from{opacity:0; transform:translateY(8px);} to{opacity:1; transform:none;} }
  @media (prefers-reduced-motion:reduce){ *{animation-duration:.01ms !important; transition-duration:.01ms !important;} }

  /* ===== 공통 타이포 ===== */
  h1.title {
    font-family:'Gowun Batang','Noto Serif KR',serif; text-wrap:balance;
    text-align:center; font-size:clamp(1.55rem,4.4vw,2.3rem); margin:14px 0 4px;
    color:var(--gold); letter-spacing:.04em; text-shadow:0 2px 14px rgba(220,180,99,.35);
  }
  .subtitle { text-align:center; color:var(--muted); font-size:.93rem; margin-bottom:20px; line-height:1.6; }
  .eyebrow { text-align:center; letter-spacing:.32em; font-size:.7rem; color:var(--gold-d); margin-bottom:2px; font-weight:700; }

  .btn {
    display:inline-block; border:none; cursor:pointer; font-family:inherit;
    background:linear-gradient(180deg,#f0cd7e,var(--gold) 45%,#b98f36);
    color:#3a2903; font-weight:800; font-size:1.02rem; padding:13px 22px;
    border-radius:12px; box-shadow:0 4px 0 #74551a, 0 6px 16px rgba(0,0,0,.4);
    transition:transform .08s, box-shadow .08s, filter .12s;
  }
  .btn:hover { filter:brightness(1.06); }
  .btn:active { transform:translateY(3px); box-shadow:0 1px 0 #74551a; }
  .btn.secondary { background:linear-gradient(180deg,#6b503a,#402e1f); color:#f7ead4; box-shadow:0 4px 0 #26190f, 0 6px 16px rgba(0,0,0,.4); }
  .btn.ghost { background:transparent; color:var(--muted); box-shadow:none; border:2px solid #4d3a26; font-weight:600; }
  .btn.ghost:hover { color:var(--gold); border-color:var(--gold-d); }
  .btn.danger { background:linear-gradient(180deg,#ec8375,#c0392b); color:#fff; box-shadow:0 4px 0 #781f16, 0 6px 16px rgba(0,0,0,.4); }
  .btn:disabled { filter:grayscale(.75) brightness(.62); cursor:not-allowed; transform:none; }
  .btn:focus-visible, .choice:focus-visible, .cell:focus-visible { outline:3px solid var(--gold); outline-offset:3px; }

  input.field {
    font-family:inherit; font-size:1rem; padding:11px 13px; border-radius:10px;
    border:2px solid #4d3a26; background:#1d150e; color:var(--text); outline:none; width:100%;
  }
  input.field:focus { border-color:var(--gold); }
  .card {
    background:linear-gradient(180deg,rgba(58,42,29,.72),rgba(32,23,16,.86));
    border:1px solid var(--panel-b); border-radius:16px; padding:20px;
    box-shadow:0 10px 28px rgba(0,0,0,.42);
  }
  .backrow { margin-bottom:12px; }
  .section-label { color:var(--gold); font-weight:800; margin:18px 0 6px; font-size:.95rem; letter-spacing:.02em; }
  .section-label.first { margin-top:0; }
  .hint-line { color:var(--muted); font-size:.82rem; line-height:1.6; margin-top:6px; }

  /* ===== 메인 메뉴 ===== */
  #hero { display:flex; align-items:center; justify-content:center; gap:16px; margin:6px 0 24px; flex-wrap:wrap; }
  #hero-pc { width:92px; height:92px; flex:0 0 auto; position:relative; }
  #hero-pc .hp {
    position:absolute; width:62px; height:62px;
    clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);
    background:linear-gradient(160deg,var(--wood-pc1),var(--wood-pc2));
    display:flex; align-items:center; justify-content:center;
    font-family:'Noto Serif KR',serif; font-weight:900; font-size:34px;
    box-shadow:0 6px 14px rgba(0,0,0,.55);
  }
  #hero-pc .hp.a { left:0; top:0; color:var(--cho); transform:rotate(-8deg); }
  #hero-pc .hp.b { right:0; bottom:0; color:var(--han); transform:rotate(7deg); }
  #hero-bubble {
    background:var(--hanji); color:#3a2a17; border-radius:14px; padding:11px 15px; font-size:.92rem;
    position:relative; max-width:340px; font-weight:600; line-height:1.6;
  }
  #hero-bubble::before {
    content:''; position:absolute; left:-8px; top:50%; transform:translateY(-50%);
    border:8px solid transparent; border-right-color:var(--hanji); border-left:0;
  }
  #hero-bubble b { color:#8a5a12; }
  .menu-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(230px,1fr)); gap:13px; max-width:780px; margin:0 auto; }
  .menu-btn {
    cursor:pointer; font-family:inherit; text-align:left;
    background:linear-gradient(160deg,rgba(74,54,36,.85),rgba(36,26,18,.92));
    border:1px solid rgba(220,180,99,.3); border-radius:16px; padding:18px;
    color:var(--text); transition:transform .12s, box-shadow .12s, border-color .12s;
    box-shadow:0 6px 18px rgba(0,0,0,.4);
  }
  .menu-btn:hover { transform:translateY(-3px); border-color:var(--gold); box-shadow:0 12px 26px rgba(0,0,0,.5); }
  .menu-btn .mi { font-size:1.8rem; display:block; margin-bottom:6px; }
  .menu-btn .mt { display:block; font-weight:800; font-size:1.1rem; color:var(--gold); }
  .menu-btn .md { display:block; font-size:.84rem; color:var(--muted); margin-top:4px; line-height:1.5; }
  .footer-note { text-align:center; color:#7a6851; font-size:.76rem; margin-top:30px; line-height:1.7; }

  /* ===== 선택 카드 ===== */
  .choice-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(190px,1fr)); gap:11px; margin:12px 0; }
  .choice-grid.tight { grid-template-columns:repeat(auto-fit,minmax(152px,1fr)); }
  .choice-grid.four { grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); }
  .choice {
    cursor:pointer; border-radius:13px; padding:14px; border:2px solid #4d3a26;
    background:rgba(30,22,15,.85); transition:.12s; font-family:inherit; color:var(--text); text-align:left;
  }
  .choice:hover { border-color:#7d6242; }
  .choice.sel { border-color:var(--gold); background:rgba(88,66,26,.5); box-shadow:0 0 14px rgba(220,180,99,.3); }
  .choice .ci { font-size:1.5rem; }
  .choice .ct { font-weight:800; margin-top:3px; font-size:1rem; }
  .choice .cd { font-size:.79rem; color:var(--muted); margin-top:4px; line-height:1.5; }
  .toggle-row { display:flex; align-items:center; gap:10px; margin-top:10px; color:var(--muted); font-size:.9rem; }
  .toggle-row input { width:18px; height:18px; accent-color:var(--gold); cursor:pointer; flex:0 0 auto; }
  .toggle-row label { cursor:pointer; }

  /* 마·상 배치판 — 실제 뒷줄을 놓고 눌러서 바꿈 */
  #setup-board { display:flex; flex-direction:column; gap:14px; margin-top:12px; }
  .sb-row { background:rgba(30,22,15,.7); border:1px solid #4d3a26; border-radius:13px; padding:12px 10px; }
  .sb-row.dim .sb-rank { opacity:.45; filter:grayscale(.55); }
  .sb-head { display:flex; justify-content:space-between; align-items:baseline; gap:8px;
    margin:0 4px 9px; flex-wrap:wrap; }
  .sb-who { font-weight:800; font-size:.9rem; }
  .sb-who .tag { font-family:'Noto Serif KR',serif; font-weight:900; margin-right:5px; }
  .sb-who .tag.han { color:var(--han-l); } .sb-who .tag.cho { color:var(--cho-l); }
  .sb-name { color:var(--gold); font-weight:800; font-size:.88rem; }
  .sb-rank { display:flex; align-items:center; justify-content:center; gap:2px;
    background:linear-gradient(185deg,var(--board1),var(--board2)); border-radius:8px;
    padding:8px 6px; border:2px solid var(--board-edge); }
  .sb-pc {
    flex:0 1 auto; width:clamp(24px,7.2vw,36px); aspect-ratio:1; min-width:0; padding:0; border:0;
    font-family:'Noto Serif KR',serif; font-weight:900; font-size:clamp(11px,3.3vw,17px);
    clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);
    background:linear-gradient(160deg,var(--wood-pc1),var(--wood-pc2));
    display:flex; align-items:center; justify-content:center; cursor:default;
  }
  .sb-pc.han { color:var(--han); } .sb-pc.cho { color:var(--cho); }
  .sb-pc.fixed { opacity:.5; }
  .sb-pc.wing { cursor:pointer; box-shadow:0 0 0 2px rgba(220,180,99,.75); transition:transform .1s; }
  .sb-pc.wing:hover { transform:translateY(-2px); }
  .sb-swap {
    flex:0 0 auto; width:clamp(18px,5vw,26px); height:clamp(18px,5vw,26px); padding:0;
    border:1px solid var(--gold-d); border-radius:50%; background:rgba(45,32,20,.9); color:var(--gold);
    font-size:clamp(9px,2.6vw,13px); font-weight:800; cursor:pointer; line-height:1;
    display:flex; align-items:center; justify-content:center; margin:0 1px;
  }
  .sb-swap:hover { background:var(--gold); color:#3a2903; }
  .sb-foot { text-align:center; color:var(--muted); font-size:.78rem; margin-top:7px; line-height:1.5; }

  /* ===== 게임 화면 ===== */
  #game-header { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; margin-bottom:10px; }
  #game-title { font-weight:800; color:var(--gold); font-size:1.02rem; }
  #game-status {
    text-align:center; font-weight:800; font-size:1rem; padding:9px 16px; border-radius:11px;
    background:rgba(44,32,22,.9); border:1px solid var(--panel-b); min-width:210px; flex:1 1 210px;
  }
  #game-status.check { color:var(--han-l); border-color:var(--han-l); animation:pulse 1.1s infinite; }
  #game-status.thinking { color:var(--gold); }
  @keyframes pulse { 0%,100%{box-shadow:0 0 0 rgba(239,106,92,0);} 50%{box-shadow:0 0 18px rgba(239,106,92,.55);} }

  #game-layout { display:flex; gap:18px; justify-content:center; align-items:flex-start; flex-wrap:wrap; }
  #board-wrap { width:min(94vw, 560px); flex:0 0 auto; }

  /* --- 장기판 --- */
  #board {
    position:relative; width:100%; aspect-ratio:924/1024;
    --u:56px; /* 한 칸 크기(px) — JS가 갱신 */
    background:
      linear-gradient(160deg, rgba(255,255,255,.14), rgba(0,0,0,0) 42%),
      linear-gradient(185deg, var(--board1) 0%, var(--board2) 100%);
    border:calc(var(--u)*.1) solid var(--board-edge);
    border-radius:6px;
    box-shadow:0 0 0 3px rgba(220,180,99,.35), 0 18px 44px rgba(0,0,0,.6),
               inset 0 0 40px rgba(122,79,34,.22);
    user-select:none; -webkit-tap-highlight-color:transparent; touch-action:manipulation;
    overflow:hidden;
  }
  #grid-svg { position:absolute; inset:0; width:100%; height:100%; pointer-events:none; z-index:1; }
  #layer-mark, #layer-pieces, #layer-cells { position:absolute; inset:0; }
  #layer-mark { z-index:2; pointer-events:none; }
  #layer-pieces { z-index:3; pointer-events:none; }
  #layer-cells { z-index:4; }

  .pt { position:absolute; transform:translate(-50%,-50%); }

  /* 말 */
  .pc {
    position:absolute; transform:translate(-50%,-50%);
    width:calc(var(--u)*var(--pz)); height:calc(var(--u)*var(--pz));
    clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);
    background:
      radial-gradient(circle at 34% 26%, rgba(255,255,255,.75), rgba(255,255,255,0) 55%),
      linear-gradient(160deg,var(--wood-pc1) 0%, var(--wood-pc2) 100%);
    display:flex; align-items:center; justify-content:center;
    font-family:'Noto Serif KR','Gowun Batang',serif; font-weight:900;
    font-size:calc(var(--u)*var(--pz)*.58); line-height:1;
    filter:drop-shadow(0 calc(var(--u)*.05) calc(var(--u)*.07) rgba(60,32,8,.55));
    transition:left .16s ease, top .16s ease;
  }
  .pc.ko { font-family:'Noto Sans KR',sans-serif; font-size:calc(var(--u)*var(--pz)*.50); }
  .pc.han { color:var(--han); }
  .pc.cho { color:var(--cho); }
  .pc::after {
    content:''; position:absolute; inset:calc(var(--u)*.055);
    clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);
    border:1px solid currentColor; opacity:.5;
  }
  .pc.sz1 { --pz:1.10; } /* 궁 */
  .pc.sz2 { --pz:0.98; } /* 차 포 마 상 */
  .pc.sz3 { --pz:0.85; } /* 사 졸 */
  .pc.sel { filter:drop-shadow(0 0 calc(var(--u)*.16) rgba(220,180,99,1)); }
  .pc.sel::after { opacity:1; border-width:2px; }
  .pc.captured-anim { animation:capfade .22s ease forwards; }
  @keyframes capfade { to { opacity:0; transform:translate(-50%,-50%) scale(.4) rotate(18deg); } }

  /* 표시 마커 */
  .mk { position:absolute; transform:translate(-50%,-50%); pointer-events:none; }
  .mk.dot { width:calc(var(--u)*.30); height:calc(var(--u)*.30); border-radius:50%;
    background:rgba(24,110,72,.62); box-shadow:0 0 calc(var(--u)*.12) rgba(24,110,72,.55); }
  .mk.cap { width:calc(var(--u)*1.02); height:calc(var(--u)*1.02); border-radius:50%;
    border:calc(var(--u)*.07) solid rgba(192,57,43,.72); background:transparent; }
  .mk.last { width:calc(var(--u)*.96); height:calc(var(--u)*.96); border-radius:5px;
    background:rgba(220,180,99,.28); box-shadow:inset 0 0 0 2px rgba(220,180,99,.75); }
  .mk.checkmk { width:calc(var(--u)*1.14); height:calc(var(--u)*1.14); border-radius:50%;
    border:calc(var(--u)*.07) solid var(--han); animation:pulse2 .9s infinite; }
  @keyframes pulse2 { 0%,100%{opacity:.45; transform:translate(-50%,-50%) scale(.94);} 50%{opacity:1; transform:translate(-50%,-50%) scale(1.06);} }
  .mk.hint { width:calc(var(--u)*1.1); height:calc(var(--u)*1.1); border-radius:50%;
    border:calc(var(--u)*.08) dashed var(--gold); animation:pulse2 .8s infinite; }

  /* 클릭 영역 */
  .cell { position:absolute; transform:translate(-50%,-50%);
    width:var(--u); height:var(--u); border:0; background:transparent; cursor:default; padding:0; }
  .cell.act { cursor:pointer; }

  /* ===== 사이드 패널 ===== */
  #side-panel { width:280px; display:flex; flex-direction:column; gap:10px; }
  @media (max-width:900px) { #side-panel { width:min(94vw,520px); } }
  .pl-card { background:var(--panel); border:1px solid var(--panel-b); border-radius:13px; padding:11px 13px; }
  .pl-card.turn { border-color:var(--gold); box-shadow:0 0 14px rgba(220,180,99,.3); }
  .pl-top { display:flex; align-items:center; justify-content:space-between; gap:8px; }
  .pl-name { font-weight:800; font-size:.98rem; display:flex; align-items:center; gap:7px; }
  .flag { font-family:'Noto Serif KR',serif; font-weight:900; font-size:1.02rem;
    width:26px; height:26px; display:inline-flex; align-items:center; justify-content:center;
    clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);
    background:linear-gradient(160deg,var(--wood-pc1),var(--wood-pc2)); flex:0 0 auto; }
  .flag.han { color:var(--han); } .flag.cho { color:var(--cho); }
  .pl-score { font-weight:800; color:var(--gold); font-variant-numeric:tabular-nums; font-size:1.02rem; }
  .pl-sub { font-size:.76rem; color:var(--muted); margin-top:2px; }
  .cap-row { min-height:22px; margin-top:6px; display:flex; flex-wrap:wrap; gap:3px; }
  .cap-row span {
    width:19px; height:19px; font-size:11px; font-weight:800;
    clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);
    background:linear-gradient(160deg,#cdb996,#b09b76);
    display:flex; align-items:center; justify-content:center; font-family:'Noto Serif KR',serif;
  }
  .cap-row span.han { color:#8f2a20; } .cap-row span.cho { color:#0d5335; }

  #game-actions { display:grid; grid-template-columns:repeat(2,1fr); gap:7px; }
  #game-actions .btn { font-size:.88rem; padding:10px 6px; text-align:center; border-radius:10px; }

  #movelog-box { background:var(--panel); border:1px solid var(--panel-b); border-radius:13px; padding:10px 12px; }
  #movelog-head { display:flex; justify-content:space-between; align-items:baseline; margin-bottom:6px; }
  #movelog-head b { color:var(--gold); font-size:.88rem; }
  #movelog-head span { font-size:.7rem; color:#8a765c; }
  #movelog { max-height:190px; overflow-y:auto; font-size:.82rem; line-height:1.85; font-variant-numeric:tabular-nums; }
  #movelog .ml { display:flex; gap:7px; align-items:baseline; }
  #movelog .ml .no { color:#8a765c; min-width:26px; text-align:right; }
  #movelog .ml .sd { font-weight:800; width:14px; font-family:'Noto Serif KR',serif; }
  #movelog .ml .sd.han { color:var(--han-l); } #movelog .ml .sd.cho { color:var(--cho-l); }
  #movelog .ml.new { color:var(--gold); }
  #movelog::-webkit-scrollbar { width:6px; }
  #movelog::-webkit-scrollbar-thumb { background:#5a442c; border-radius:3px; }
  #movelog .empty { color:#8a765c; font-size:.8rem; }

  /* ===== 규칙 화면 ===== */
  .rule-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:12px; margin-top:14px; }
  .rule-card { background:var(--panel); border:1px solid var(--panel-b); border-radius:14px; padding:15px 16px; }
  .rule-card h3 { color:var(--gold); font-size:1rem; display:flex; align-items:center; gap:8px; margin-bottom:7px; }
  .rule-card p { font-size:.86rem; line-height:1.75; color:#e0d2ba; }
  .rule-card p + p { margin-top:7px; }
  .rule-card b { color:var(--gold); }
  .tbl { width:100%; border-collapse:collapse; font-size:.85rem; margin-top:10px; }
  .tbl th, .tbl td { padding:7px 9px; border-bottom:1px solid rgba(220,180,99,.16); text-align:left; }
  .tbl th { color:var(--gold); font-size:.8rem; }
  .tbl td.n { text-align:right; font-variant-numeric:tabular-nums; }
  .tbl-wrap { overflow-x:auto; }

  /* ===== 묘수풀이 ===== */
  .puzzle-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); gap:11px; margin-top:14px; }
  .pz-card {
    cursor:pointer; border-radius:14px; padding:14px; border:2px solid #4d3a26;
    background:rgba(30,22,15,.85); transition:.12s; font-family:inherit; color:var(--text); text-align:left;
  }
  .pz-card:hover { border-color:var(--gold); transform:translateY(-2px); }
  .pz-card.done { border-color:var(--ok); background:rgba(28,62,46,.5); }
  .pz-card .pn { font-weight:800; color:var(--gold); font-size:1.02rem; }
  .pz-card.done .pn { color:var(--ok); }
  .pz-card .pd { font-size:.8rem; color:var(--muted); margin-top:4px; }
  .pz-card .pk { font-size:.78rem; font-weight:700; margin-top:7px; color:var(--ok); }
  .pz-group + .pz-group { margin-top:22px; }
  .pz-group-title { display:flex; justify-content:space-between; align-items:baseline; gap:10px;
    border-bottom:1px solid var(--panel-b); padding-bottom:6px; margin-top:18px; flex-wrap:wrap; }
  .pz-group-title b { color:var(--gold); font-size:1.02rem; font-family:'Gowun Batang',serif; }
  .pz-group-title span { color:var(--muted); font-size:.8rem; font-variant-numeric:tabular-nums; }
  #pz-progress { text-align:center; color:var(--muted); font-size:.9rem; margin-bottom:4px; }
  #pz-progress b { color:var(--gold); font-variant-numeric:tabular-nums; }
  #puzzle-card .pl-name { color:var(--gold); }

  /* ===== 전적 ===== */
  #stats-summary { display:flex; gap:12px; flex-wrap:wrap; justify-content:center; margin:16px 0; }
  .stat-tile { background:var(--panel); border:1px solid var(--panel-b); border-radius:13px; padding:14px 22px; text-align:center; min-width:104px; }
  .stat-tile .sv { font-size:1.9rem; font-weight:900; color:var(--gold); font-variant-numeric:tabular-nums; line-height:1.1; }
  .stat-tile .sl { font-size:.78rem; color:var(--muted); margin-top:3px; }

  /* ===== 모달 ===== */
  .modal-bg { display:none; position:fixed; inset:0; background:rgba(10,7,4,.78); z-index:50;
    align-items:center; justify-content:center; padding:16px; }
  .modal-bg.open { display:flex; }
  .modal {
    background:linear-gradient(180deg,#3d2d1e,#241a12); border:2px solid var(--gold);
    border-radius:18px; padding:26px 24px; max-width:430px; width:100%; text-align:center;
    box-shadow:0 0 44px rgba(220,180,99,.3); animation:pop .24s ease;
  }
  @keyframes pop { from{transform:scale(.88); opacity:0;} to{transform:scale(1); opacity:1;} }
  .modal h2 { color:var(--gold); margin-bottom:10px; font-size:1.42rem; font-family:'Gowun Batang',serif; }
  .modal p { color:#e3d5bc; margin-bottom:16px; line-height:1.7; font-size:.94rem; }
  .modal .btnrow { display:flex; gap:9px; justify-content:center; flex-wrap:wrap; }
  .modal .btnrow .btn { font-size:.95rem; padding:11px 18px; }
  #go-icon { font-size:3.2rem; margin-bottom:4px; }
  #go-score { font-size:.86rem; color:var(--muted); margin:-6px 0 14px; font-variant-numeric:tabular-nums; }

  #toast {
    position:fixed; left:50%; bottom:calc(26px + env(safe-area-inset-bottom, 0px));
    transform:translateX(-50%) translateY(80px);
    background:#32241a; color:var(--text); border:1px solid var(--gold); border-radius:11px;
    padding:11px 19px; font-weight:700; z-index:99; opacity:0; transition:.24s; pointer-events:none;
    max-width:90vw; text-align:center; font-size:.9rem;
  }
  #toast.show { opacity:1; transform:translateX(-50%) translateY(0); }
</style>
</head>
<body>
<div id="grain"></div>
<div id="app">

  <!-- ===================== 메인 메뉴 ===================== -->
  <section id="screen-menu" class="screen active">
    <div class="eyebrow">將 棋 · 韓 國 傳 統</div>
    <h1 class="title">다람쌤 장기 한판</h1>
    <div class="subtitle">초(楚)가 선수, 한(漢)은 1.5점 덤 · 대한장기협회 대국 방식</div>

    <div id="hero">
      <div id="hero-pc">
        <div class="hp a">楚</div>
        <div class="hp b">漢</div>
      </div>
      <div id="hero-bubble">
        어서 오세요. <b>진짜 장기 규칙</b> 그대로 두는 곳입니다.<br>
        마·상 배치를 고르고, 컴퓨터와 한판 두시지요. 車包馬象
      </div>
    </div>

    <div class="menu-grid">
      <button class="menu-btn" data-go="ai-setup">
        <span class="mi">🎯</span><span class="mt">컴퓨터와 대국</span>
        <span class="md">쉬움 · 보통 · 어려움 · 매우 어려움 중에서 고르기</span>
      </button>
      <button class="menu-btn" data-go="pvp-setup">
        <span class="mi">👥</span><span class="mt">둘이서 대국</span>
        <span class="md">한 화면에서 번갈아 두기 (부부 대결, 학급 대결)</span>
      </button>
      <button class="menu-btn" data-go="puzzles">
        <span class="mi">🧩</span><span class="mt">묘수풀이</span>
        <span class="md">차·포·마·상·졸로 끝내는 외통 문제 (정답을 엔진으로 검증함)</span>
      </button>
      <button class="menu-btn" data-go="rules">
        <span class="mi">📜</span><span class="mt">장기 규칙 보기</span>
        <span class="md">기물별 움직임 · 점수제 · 빅장 · 기보 읽는 법</span>
      </button>
      <button class="menu-btn" data-go="stats">
        <span class="mi">🏅</span><span class="mt">내 전적</span>
        <span class="md">난이도별 승 · 무 · 패 기록</span>
      </button>
    </div>
    <div class="footer-note">
      다람쌤 장기 한판 © 2026 · 궁 · 사 · 차 · 포 · 마 · 상 · 졸 전 기물 정식 규칙 구현<br>
      포 넘기 · 궁성 대각선 · 면포 · 외통 · 점수제 판정까지 그대로
    </div>
  </section>

  <!-- ===================== 컴퓨터 대국 설정 ===================== -->
  <section id="screen-ai-setup" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">컴퓨터와 대국</h1>
    <div class="subtitle">난이도와 진영, 마·상 배치를 정하세요</div>

    <div class="card" style="max-width:860px; margin:0 auto;">
      <div class="section-label first">난이도</div>
      <div class="choice-grid four" id="ai-levels">
        <button class="choice sel" type="button" data-level="easy"><span class="ci">🌱</span><div class="ct">쉬움</div><div class="cd">한 수 앞만 봅니다. 가끔 엉뚱한 수도 둡니다. 처음 배울 때.</div></button>
        <button class="choice" type="button" data-level="normal"><span class="ci">🌿</span><div class="ct">보통</div><div class="cd">두세 수 앞을 읽습니다. 기물을 그냥 주지는 않습니다.</div></button>
        <button class="choice" type="button" data-level="hard"><span class="ci">🌳</span><div class="ct">어려움</div><div class="cd">네 수 이상 + 교환 계산. 방심하면 차를 잃습니다.</div></button>
        <button class="choice" type="button" data-level="veryhard"><span class="ci">🔥</span><div class="ct">매우 어려움</div><div class="cd">4~5초쯤 생각합니다. 실수 없이 둡니다.</div></button>
        <button class="choice" type="button" data-level="master"><span class="ci">👑</span><div class="ct">최고 어려움</div><div class="cd">8~9초를 꽉 채워 끝까지 읽습니다. 한 수도 그냥 주지 않습니다.</div></button>
      </div>
      <div class="hint-line">위로 갈수록 생각 시간이 길어집니다. ‘최고 어려움’은 한 수에 10초 가까이 걸릴 수 있습니다.</div>

      <div class="section-label">내 진영</div>
      <div class="choice-grid tight" id="ai-sides">
        <button class="choice sel" type="button" data-side="han"><span class="ci" style="font-family:'Noto Serif KR',serif; color:var(--han-l);">漢</span><div class="ct">한 (빨강)</div><div class="cd">후수 · 1.5점 덤을 받음</div></button>
        <button class="choice" type="button" data-side="cho"><span class="ci" style="font-family:'Noto Serif KR',serif; color:var(--cho-l);">楚</span><div class="ct">초 (초록)</div><div class="cd">선수 · 내가 먼저 둠</div></button>
        <button class="choice" type="button" data-side="random"><span class="ci">🎲</span><div class="ct">아무거나</div><div class="cd">반반 확률로 정해짐</div></button>
      </div>

      <div class="section-label">마·상 배치 <span style="font-weight:400; color:var(--muted); font-size:.82rem;">(마·상을 누르거나 ↔ 를 눌러 자리를 맞바꿈)</span></div>
      <div id="setup-board">
        <div class="sb-row" id="sb-row-opp">
          <div class="sb-head"><span class="sb-who" id="sb-who-opp">상대 진영</span><span class="sb-name" id="sb-name-opp"></span></div>
          <div class="sb-rank" id="sb-rank-opp"></div>
          <div class="toggle-row" style="justify-content:center;"><input type="checkbox" id="opt-opp-random"><label for="opt-opp-random">상대가 알아서 고르게 하기 (상대 말을 누르면 저절로 꺼짐)</label></div>
        </div>
        <div class="sb-row" id="sb-row-me">
          <div class="sb-head"><span class="sb-who" id="sb-who-me">내 진영</span><span class="sb-name" id="sb-name-me"></span></div>
          <div class="sb-rank" id="sb-rank-me"></div>
          <div class="sb-foot">양귀마 · 원앙마 · 귀마(좌) · 귀마(우) 네 가지가 장기에서 놓을 수 있는 배치의 전부임<br>
            좌·우는 <b>그 진영이 앉은 자리에서 본 방향</b>이라, 마주 앉은 상대는 화면에서 반대쪽에 보임</div>
        </div>
      </div>

      <div class="section-label">표기와 규칙</div>
      <div class="toggle-row"><input type="checkbox" id="opt-korean"><label for="opt-korean">기물을 한글로 표시 (궁·사·차·포·마·상·졸)</label></div>
      <div class="toggle-row"><input type="checkbox" id="opt-bikjang"><label for="opt-bikjang">빅장(양 궁이 마주 봄)을 무승부로 처리 — 옛 규칙</label></div>
      <div class="toggle-row"><input type="checkbox" id="opt-sound" checked><label for="opt-sound">말 놓는 소리 켜기</label></div>

      <div style="text-align:center; margin-top:22px;"><button class="btn" id="ai-start-btn">대국 시작</button></div>
    </div>
  </section>

  <!-- ===================== 둘이서 대국 설정 ===================== -->
  <section id="screen-pvp-setup" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">둘이서 대국</h1>
    <div class="subtitle">한 화면에서 번갈아 둡니다 · 초(楚)가 먼저 둡니다</div>
    <div class="card" style="max-width:520px; margin:0 auto;">
      <div class="section-label first">초(楚) 쪽 이름</div>
      <input class="field" id="pvp-cho-name" maxlength="10" placeholder="초 (초록)">
      <div class="section-label">한(漢) 쪽 이름</div>
      <input class="field" id="pvp-han-name" maxlength="10" placeholder="한 (빨강)">
      <div class="section-label">화면 아래쪽에 둘 진영</div>
      <div class="choice-grid tight" id="pvp-bottom">
        <button class="choice sel" type="button" data-side="han"><span class="ci" style="font-family:'Noto Serif KR',serif; color:var(--han-l);">漢</span><div class="ct">한</div></button>
        <button class="choice" type="button" data-side="cho"><span class="ci" style="font-family:'Noto Serif KR',serif; color:var(--cho-l);">楚</span><div class="ct">초</div></button>
      </div>
      <div class="hint-line">마·상 배치는 ‘컴퓨터와 대국’ 설정 화면에서 양쪽 진영 모두 고를 수 있습니다. 아래쪽에 둘 진영이 그 화면의 ‘내 진영’ 배치를 씁니다.</div>
      <div style="text-align:center; margin-top:20px;"><button class="btn" id="pvp-start-btn">대국 시작</button></div>
    </div>
  </section>

  <!-- ===================== 게임 ===================== -->
  <section id="screen-game" class="screen">
    <div id="game-header">
      <span id="game-title">대국</span>
      <span id="game-status">초 차례</span>
      <button class="btn ghost" id="btn-quit" style="padding:8px 14px; font-size:.84rem;">메뉴로</button>
    </div>
    <div id="game-layout">
      <div id="board-wrap">
        <div id="board">
          <svg id="grid-svg" viewBox="0 0 924 1024" aria-hidden="true"></svg>
          <div id="layer-mark"></div>
          <div id="layer-pieces"></div>
          <div id="layer-cells"></div>
        </div>
      </div>
      <div id="side-panel">
        <div class="pl-card" id="pl-top">
          <div class="pl-top">
            <span class="pl-name"><span class="flag cho" id="f-top">楚</span><span id="n-top">상대</span></span>
            <span class="pl-score" id="s-top">72.0</span>
          </div>
          <div class="pl-sub" id="d-top">초 · 선수</div>
          <div class="cap-row" id="cap-top"></div>
        </div>
        <div class="pl-card" id="puzzle-card" hidden>
          <div class="pl-top"><span class="pl-name">🧩 <span id="pz-title">묘수풀이</span></span><span class="pl-score" id="pz-left"></span></div>
          <div class="pl-sub" id="pz-sub">초(楚)를 잡고 외통을 만드세요.</div>
        </div>
        <div class="pl-card turn" id="pl-bot">
          <div class="pl-top">
            <span class="pl-name"><span class="flag han" id="f-bot">漢</span><span id="n-bot">나</span></span>
            <span class="pl-score" id="s-bot">73.5</span>
          </div>
          <div class="pl-sub" id="d-bot">한 · 후수 · 덤 1.5</div>
          <div class="cap-row" id="cap-bot"></div>
        </div>
        <div id="game-actions">
          <button class="btn secondary" id="btn-undo">↩ 무르기</button>
          <button class="btn secondary" id="btn-pass">⏭ 한수쉼</button>
          <button class="btn secondary" id="btn-hint">💡 훈수</button>
          <button class="btn secondary" id="btn-flip">🔄 판 돌리기</button>
          <button class="btn danger" id="btn-resign">🏳 기권</button>
          <button class="btn" id="btn-restart">↻ 다시</button>
        </div>
        <div id="movelog-box">
          <div id="movelog-head"><b>기보</b><span id="movelog-coord">앞=세로줄, 뒤=가로줄</span></div>
          <div id="movelog"><div class="empty">아직 둔 수가 없습니다.</div></div>
        </div>
      </div>
    </div>
  </section>

  <!-- ===================== 규칙 ===================== -->
  <section id="screen-rules" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">장기 규칙</h1>
    <div class="subtitle">체스와 닮았지만 다릅니다 · 말은 칸이 아니라 <b>선이 만나는 점</b> 위에 놓입니다</div>

    <div class="rule-grid">
      <div class="rule-card">
        <h3><span class="flag han">漢</span> 궁 (將)</h3>
        <p>궁성(3×3) <b>안에서만</b> 움직입니다. 가로·세로로 한 칸, 그리고 <b>궁성에 그려진 대각선</b> 위에서는 대각으로 한 칸 갑니다.</p>
        <p>궁이 잡히면 지므로, 궁이 공격받으면 <b>장군</b>, 못 피하면 <b>외통</b>으로 끝납니다.</p>
      </div>
      <div class="rule-card">
        <h3><span class="flag han">士</span> 사</h3>
        <p>궁과 똑같이 움직입니다. 궁성 밖으로는 못 나갑니다. 궁 옆을 지키는 호위병입니다.</p>
      </div>
      <div class="rule-card">
        <h3><span class="flag han">車</span> 차</h3>
        <p>가로·세로로 <b>거리 제한 없이</b> 직진합니다(체스의 룩). 중간에 말이 있으면 막힙니다.</p>
        <p>게다가 <b>궁성 안 대각선</b>을 따라서도 직진할 수 있습니다. 장기에서 가장 센 말(13점)입니다.</p>
      </div>
      <div class="rule-card">
        <h3><span class="flag han">包</span> 포</h3>
        <p>같은 줄에 <b>넘어갈 말(다리)이 정확히 하나</b> 있어야 움직입니다. 다리를 넘어 그 뒤 빈 곳으로 가거나, 그곳의 적 말을 잡습니다.</p>
        <p>단, <b>포는 포를 다리로 쓸 수 없고 포를 잡을 수도 없습니다.</b> 궁성 대각선에서도 같은 방식으로 넘습니다.</p>
      </div>
      <div class="rule-card">
        <h3><span class="flag han">馬</span> 마</h3>
        <p>직진 한 칸 + 대각 한 칸(체스의 나이트와 같은 모양). 하지만 <b>첫 직진 칸에 말이 있으면 막혀서 못 갑니다.</b> 체스처럼 뛰어넘지 못합니다.</p>
      </div>
      <div class="rule-card">
        <h3><span class="flag han">象</span> 상</h3>
        <p>직진 한 칸 + 대각 두 칸. 지나는 <b>두 자리가 모두 비어 있어야</b> 갑니다. 멀리 뛰지만 길이 잘 막힙니다.</p>
      </div>
      <div class="rule-card">
        <h3><span class="flag han">兵</span> 졸 · 병</h3>
        <p>앞으로 한 칸, 또는 <b>옆으로 한 칸</b> 갑니다. <b>뒤로는 못 갑니다.</b> 상대 궁성 안 대각선 위에서는 앞 대각으로도 갑니다.</p>
      </div>
      <div class="rule-card">
        <h3>🕊 한수쉼과 빅장</h3>
        <p>장기에는 <b>한수쉼(패스)</b>이 있습니다. 둘 수가 마땅찮으면 그냥 쉴 수 있습니다. 단, 장군을 받은 상태에서는 쉴 수 없습니다.</p>
        <p><b>빅장</b>은 두 궁이 사이에 말 없이 마주 보는 자리입니다. 요즘 규칙에서는 그대로 두고, 옛 규칙에서는 무승부로 봅니다(설정에서 선택).</p>
      </div>
      <div class="rule-card">
        <h3>🏆 이기는 방법 · 점수제</h3>
        <p><b>외통</b>이면 바로 승리입니다. 수가 길어져 판가름이 안 나면 <b>남은 기물 점수</b>로 가립니다.</p>
        <p>초(楚)가 먼저 두므로, 한(漢)에게 <b>1.5점 덤</b>을 줍니다. 같은 자리가 세 번 반복되면 점수로 판정합니다.</p>
        <div class="tbl-wrap">
          <table class="tbl">
            <tr><th>기물</th><th class="n">점수</th><th>기물</th><th class="n">점수</th></tr>
            <tr><td>차 車</td><td class="n">13</td><td>상 象</td><td class="n">3</td></tr>
            <tr><td>포 包</td><td class="n">7</td><td>사 士</td><td class="n">3</td></tr>
            <tr><td>마 馬</td><td class="n">5</td><td>졸 卒</td><td class="n">2</td></tr>
            <tr><td>궁 將</td><td class="n">0</td><td>합계</td><td class="n">72</td></tr>
          </table>
        </div>
      </div>
      <div class="rule-card">
        <h3>🎴 마·상 배치</h3>
        <p>장기는 시작 전에 <b>마와 상의 자리를 바꿔 놓을 수</b> 있습니다. 양쪽이 각자 고릅니다.</p>
        <p><b>양귀마</b>는 두 마가 모두 바깥(차 옆), <b>원앙마</b>는 두 마가 모두 안쪽, <b>귀마</b>는 한쪽만 바깥입니다. 귀마가 가장 흔합니다.</p>
        <p>배치 이름의 <b>왼쪽·오른쪽은 그 진영이 앉은 자리에서 본 방향</b>입니다. 마주 앉은 두 사람이 똑같이 왼귀마를 놓으면, 판 위에서는 두 마가 서로 엇갈려 보입니다.</p>
      </div>
      <div class="rule-card">
        <h3>🔢 기보 좌표</h3>
        <p>기보는 두 자리 숫자로 적습니다. <b>앞자리는 세로줄</b>(화면 왼쪽부터 1~9), <b>뒷자리는 가로줄</b>(화면 위부터 1~9, 열째 줄은 0)입니다.</p>
        <p>예: <b>차 19→16</b> 은 왼쪽 끝 세로줄의 아홉째 가로줄에 있던 차가 여섯째 가로줄로 올라갔다는 뜻입니다.</p>
      </div>
      <div class="rule-card">
        <h3>♟ 체스와 다른 점</h3>
        <p>칸이 아닌 <b>점</b> 위에서 둡니다 · 마는 <b>못 뛰어넘습니다</b> · 포라는 새 기물이 있습니다 · 궁과 사는 <b>궁성에 갇혀</b> 있습니다 · 졸은 승진하지 않고 <b>옆으로</b> 갑니다 · <b>한수쉼</b>이 있어 스테일메이트가 없습니다.</p>
      </div>
    </div>
  </section>

  <!-- ===================== 묘수풀이 ===================== -->
  <section id="screen-puzzles" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">묘수풀이</h1>
    <div class="subtitle">초(楚)를 잡고 정해진 수 안에 <b>외통</b>을 만드세요 · 상대는 가장 끈질긴 수로 버팁니다<br>1수 문제는 어떤 기물로 끝내는지 적어 두었습니다</div>
    <div id="pz-progress"></div>
    <div id="puzzle-list"></div>
  </section>

  <!-- ===================== 전적 ===================== -->
  <section id="screen-stats" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">내 전적</h1>
    <div class="subtitle">이 기기(브라우저)에만 저장됩니다</div>
    <div id="stats-summary"></div>
    <div class="card" style="max-width:620px; margin:0 auto;">
      <div class="section-label first">난이도별 기록</div>
      <div class="tbl-wrap"><table class="tbl" id="stats-table"></table></div>
      <div style="text-align:center; margin-top:18px;"><button class="btn ghost" id="btn-reset-stats">기록 지우기</button></div>
    </div>
  </section>
</div>

<!-- ===================== 모달 ===================== -->
<div class="modal-bg" id="gameover-modal">
  <div class="modal">
    <div id="go-icon">🏆</div>
    <h2 id="go-title">대국 종료</h2>
    <p id="go-text"></p>
    <div id="go-score"></div>
    <div class="btnrow">
      <button class="btn" id="go-again">한판 더</button>
      <button class="btn secondary" id="go-setup">설정 바꾸기</button>
      <button class="btn ghost" id="go-menu">메뉴로</button>
    </div>
  </div>
</div>

<div class="modal-bg" id="confirm-modal">
  <div class="modal">
    <h2 id="cf-title">확인</h2>
    <p id="cf-text"></p>
    <div class="btnrow">
      <button class="btn danger" id="cf-yes">예</button>
      <button class="btn ghost" id="cf-no">아니요</button>
    </div>
  </div>
</div>

<div id="toast" role="status" aria-live="polite"></div>

<script>
'use strict';
/* ============================================================================
   1. 장기 엔진
   판: 가로 9줄 × 세로 10줄 = 90개의 점. 인덱스 = r*9 + c
   내부 좌표는 항상 고정: r=0 은 초(楚) 진영 맨 뒷줄, r=9 는 한(漢) 진영 맨 뒷줄.
   따라서 한(漢)의 졸은 위쪽(-1)으로, 초(楚)의 졸은 아래쪽(+1)으로 나아감.
   ============================================================================ */
const NC = 9, NR = 10, NSQ = 90;

/* 기물 코드: 종류(1~7) + 진영비트(한=0, 초=8) */
const T_K = 1, T_S = 2, T_R = 3, T_P = 4, T_H = 5, T_E = 6, T_J = 7;
const HAN = 0, CHO = 8;

const TYPE_KEY   = ['', 'K', 'S', 'R', 'P', 'H', 'E', 'J'];
/* 화면 표기 */
const GLYPH_HAN  = ['', '漢', '士', '車', '包', '馬', '象', '兵'];
const GLYPH_CHO  = ['', '楚', '士', '車', '包', '馬', '象', '卒'];
const KO_HAN     = ['', '궁', '사', '차', '포', '마', '상', '병'];
const KO_CHO     = ['', '궁', '사', '차', '포', '마', '상', '졸'];
/* 크기 등급 (1=궁, 2=차포마상, 3=사졸) */
const SZ         = [0, 1, 3, 2, 2, 2, 2, 3];
/* 탐색용 평가 점수 (점수제 ×10) */
const PV         = [0, 20000, 30, 130, 70, 50, 30, 20];
/* 점수제 실제 점수 */
const SCORE_VAL  = [0, 0, 3, 13, 7, 5, 3, 2];
const DUM = 1.5;                 /* 한(漢)이 받는 덤 */
const FULL_SCORE = 72;

const inB = (r, c) => r >= 0 && r < NR && c >= 0 && c < NC;
const sqR = s => (s / 9) | 0;
const sqC = s => s % 9;
const colorOf = p => p & 8;
const typeOf  = p => p & 7;
const other   = s => s ^ 8;

/* --- 궁성 --- */
/* PAL[sq]: 0=궁성 아님, 1=한(漢)의 궁성(아래), 2=초(楚)의 궁성(위) */
const PAL = new Int8Array(NSQ);
for (let r = 0; r < 3; r++) for (let c = 3; c <= 5; c++) PAL[r * 9 + c] = 2;
for (let r = 7; r < 10; r++) for (let c = 3; c <= 5; c++) PAL[r * 9 + c] = 1;
const palOf = side => (side === HAN ? 1 : 2);

/* --- 궁성 대각선 --- */
/* DLINES: 세 점으로 된 대각선 4개, DIAGN: 대각으로 이어진 이웃, DINFO: 각 점이 속한 선 */
const DLINES = [];
const DIAGN = []; for (let i = 0; i < NSQ; i++) DIAGN.push([]);
const DINFO = []; for (let i = 0; i < NSQ; i++) DINFO.push([]);
for (const r0 of [0, 7]) {
  const a = r0 * 9 + 3, mid = (r0 + 1) * 9 + 4, b = (r0 + 2) * 9 + 5;
  const d = r0 * 9 + 5, e = (r0 + 2) * 9 + 3;
  DLINES.push([a, mid, b]);
  DLINES.push([d, mid, e]);
  DIAGN[a].push(mid); DIAGN[b].push(mid); DIAGN[d].push(mid); DIAGN[e].push(mid);
  DIAGN[mid].push(a, b, d, e);
}
for (const L of DLINES) for (let i = 0; i < 3; i++) DINFO[L[i]].push([L, i]);

/* --- 방향 테이블 (평탄 배열: 속도) --- */
const OD = [-1, 0, 1, 0, 0, -1, 0, 1];
/* 마: [막는칸dr, dc, 목적지dr, dc] */
const HORSE = [
  -1, 0, -2, -1,  -1, 0, -2, 1,   1, 0, 2, -1,   1, 0, 2, 1,
   0, -1, -1, -2,  0, -1, 1, -2,  0, 1, -1, 2,   0, 1, 1, 2];
/* 상: [막는칸1, 막는칸2, 목적지] 각 dr,dc */
const ELEPH = [
  -1, 0, -2, -1, -3, -2,   -1, 0, -2, 1, -3, 2,
   1, 0,  2, -1,  3, -2,    1, 0,  2, 1,  3, 2,
   0, -1, -1, -2, -2, -3,   0, -1, 1, -2, 2, -3,
   0, 1,  -1, 2,  -2, 3,    0, 1,  1, 2,  2, 3];

/* --- 판 상태 --- */
let bd = new Int8Array(NSQ);
let kpos = [0, 0];               /* [한 궁 위치, 초 궁 위치] */
const kIdx = side => (side === HAN ? 0 : 1);

/* --- 저브리스트 해시 --- */
const ZR1 = new Int32Array(16 * NSQ), ZR2 = new Int32Array(16 * NSQ);
let ZTURN1 = 0, ZTURN2 = 0;
(function initZobrist() {
  let s = 0x9e3779b9 >>> 0;
  const rnd = () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s | 0; };
  for (let i = 0; i < 16 * NSQ; i++) { ZR1[i] = rnd(); ZR2[i] = rnd(); }
  ZTURN1 = rnd(); ZTURN2 = rnd();
})();
let h1 = 0, h2 = 0;
function rehash() {
  h1 = 0; h2 = 0;
  for (let s = 0; s < NSQ; s++) { const p = bd[s]; if (p) { h1 ^= ZR1[p * NSQ + s]; h2 ^= ZR2[p * NSQ + s]; } }
}

/* --- 시작 배치 --- */
/* 배치 코드: 좌우 각 날개가 'MS'(마가 바깥=차 옆) 또는 'SM'(상이 바깥) */
const SETUPS = [
  { id: 'gwima_l', left: 'MS', right: 'SM', name: '귀마 (왼쪽)', desc: '왼쪽 마만 차 옆. 가장 흔한 배치' },
  { id: 'gwima_r', left: 'SM', right: 'MS', name: '귀마 (오른쪽)', desc: '오른쪽 마만 차 옆' },
  { id: 'yanggwima', left: 'MS', right: 'MS', name: '양귀마', desc: '두 마가 모두 차 옆(바깥)' },
  { id: 'wonangma', left: 'SM', right: 'SM', name: '원앙마', desc: '두 마가 모두 안쪽. 두 마가 서로 지킴' }
];
/* 날개 표기는 "차에서 궁성 쪽으로" 읽음.
   왼쪽 날개: c1, c2 / 오른쪽 날개: c7, c6  → 'MS'면 차 옆이 마 */
/* 마·상이 놓이는 넉 자리 (내부 세로줄 기준).
   장기는 배치를 부를 때 좌·우를 '그 진영이 앉은 자리'에서 봄.
   한(漢)은 아래쪽에 앉으므로 제 왼쪽이 내부 0번 줄 쪽이고,
   초(楚)는 판 건너편에 앉으므로 제 왼쪽이 내부 8번 줄 쪽임 → 좌우가 뒤집힘. */
function wingCols(side) {
  return side === CHO
    ? { outL: 7, inL: 6, outR: 1, inR: 2 }
    : { outL: 1, inL: 2, outR: 7, inR: 6 };
}
/* 어느 세로줄이 그 진영의 어느 날개인지 */
function wingOfCol(side, c) {
  const w = wingCols(side);
  if (c === w.outL || c === w.inL) return 'left';
  if (c === w.outR || c === w.inR) return 'right';
  return '';
}
/* 뒷줄 아홉 자리의 기물 종류를 내부 세로줄 차례대로 돌려줌 (빈 자리는 0) */
function backRankTypes(side, setup) {
  const t = new Array(9).fill(0);
  t[0] = T_R; t[8] = T_R; t[3] = T_S; t[5] = T_S;
  const w = wingCols(side);
  t[w.outL] = setup.left === 'MS' ? T_H : T_E;
  t[w.inL] = setup.left === 'MS' ? T_E : T_H;
  t[w.outR] = setup.right === 'MS' ? T_H : T_E;
  t[w.inR] = setup.right === 'MS' ? T_E : T_H;
  return t;
}
function setupBackRank(side, setup) {
  const row = side === HAN ? 9 : 0;
  const t = backRankTypes(side, setup);
  for (let c = 0; c < 9; c++) if (t[c]) bd[row * 9 + c] = t[c] + side;
}
function setupSide(side, setup) {
  const back = side === HAN ? 9 : 0;
  const dir  = side === HAN ? -1 : 1;
  setupBackRank(side, setup);
  bd[(back + dir) * 9 + 4] = T_K + side;                        /* 궁: 궁성 한가운데 */
  bd[(back + dir * 2) * 9 + 1] = T_P + side;                    /* 포 */
  bd[(back + dir * 2) * 9 + 7] = T_P + side;
  for (const c of [0, 2, 4, 6, 8]) bd[(back + dir * 3) * 9 + c] = T_J + side;
  kpos[kIdx(side)] = (back + dir) * 9 + 4;
}
function newBoard(hanSetup, choSetup) {
  bd.fill(0);
  setupSide(HAN, hanSetup);
  setupSide(CHO, choSetup);
  rehash();
}

/* ============================================================================
   2. 착수 생성 — 수는 정수 f*90+t 로 인코딩. 한수쉼은 -1.
   ============================================================================ */
const MVFROM = m => (m / 90) | 0;
const MVTO   = m => m % 90;

function genMoves(side, buf) {
  let n = 0;
  for (let sq = 0; sq < NSQ; sq++) {
    const p = bd[sq];
    if (!p || (p & 8) !== side) continue;
    const t = p & 7, r = (sq / 9) | 0, c = sq % 9;
    if (t === T_K || t === T_S) {
      const mp = side === HAN ? 1 : 2;
      for (let k = 0; k < 8; k += 2) {
        const nr = r + OD[k], nc = c + OD[k + 1];
        if (!inB(nr, nc)) continue;
        const d = nr * 9 + nc;
        if (PAL[d] !== mp) continue;
        const q = bd[d]; if (q && (q & 8) === side) continue;
        buf[n++] = sq * 90 + d;
      }
      const dn = DIAGN[sq];
      for (let k = 0; k < dn.length; k++) {
        const d = dn[k];
        if (PAL[d] !== mp) continue;
        const q = bd[d]; if (q && (q & 8) === side) continue;
        buf[n++] = sq * 90 + d;
      }
    } else if (t === T_R) {
      for (let k = 0; k < 8; k += 2) {
        const dr = OD[k], dc = OD[k + 1];
        let nr = r + dr, nc = c + dc;
        while (inB(nr, nc)) {
          const d = nr * 9 + nc, q = bd[d];
          if (!q) buf[n++] = sq * 90 + d;
          else { if ((q & 8) !== side) buf[n++] = sq * 90 + d; break; }
          nr += dr; nc += dc;
        }
      }
      const di = DINFO[sq];
      for (let k = 0; k < di.length; k++) {
        const L = di[k][0], i = di[k][1];
        for (let st = -1; st <= 1; st += 2) {
          for (let j = i + st; j >= 0 && j < 3; j += st) {
            const d = L[j], q = bd[d];
            if (!q) buf[n++] = sq * 90 + d;
            else { if ((q & 8) !== side) buf[n++] = sq * 90 + d; break; }
          }
        }
      }
    } else if (t === T_P) {
      for (let k = 0; k < 8; k += 2) {
        const dr = OD[k], dc = OD[k + 1];
        let nr = r + dr, nc = c + dc, scr = -1;
        while (inB(nr, nc)) { const d = nr * 9 + nc; if (bd[d]) { scr = d; break; } nr += dr; nc += dc; }
        if (scr < 0 || (bd[scr] & 7) === T_P) continue;          /* 다리 없음 / 다리가 포 */
        let rr = ((scr / 9) | 0) + dr, cc = (scr % 9) + dc;
        while (inB(rr, cc)) {
          const d = rr * 9 + cc, q = bd[d];
          if (!q) buf[n++] = sq * 90 + d;
          else { if ((q & 8) !== side && (q & 7) !== T_P) buf[n++] = sq * 90 + d; break; }
          rr += dr; cc += dc;
        }
      }
      const di = DINFO[sq];
      for (let k = 0; k < di.length; k++) {
        const L = di[k][0], i = di[k][1];
        if (i === 1) continue;                                   /* 한가운데서는 넘을 자리가 없음 */
        const mid = L[1], far = L[2 - i], mp = bd[mid];
        if (!mp || (mp & 7) === T_P) continue;
        const q = bd[far];
        if (!q) buf[n++] = sq * 90 + far;
        else if ((q & 8) !== side && (q & 7) !== T_P) buf[n++] = sq * 90 + far;
      }
    } else if (t === T_H) {
      for (let k = 0; k < 32; k += 4) {
        const br = r + HORSE[k], bc = c + HORSE[k + 1];
        if (!inB(br, bc) || bd[br * 9 + bc]) continue;            /* 다리(첫 칸)가 막히면 못 감 */
        const nr = r + HORSE[k + 2], nc = c + HORSE[k + 3];
        if (!inB(nr, nc)) continue;
        const d = nr * 9 + nc, q = bd[d];
        if (q && (q & 8) === side) continue;
        buf[n++] = sq * 90 + d;
      }
    } else if (t === T_E) {
      for (let k = 0; k < 48; k += 6) {
        const b1r = r + ELEPH[k], b1c = c + ELEPH[k + 1];
        if (!inB(b1r, b1c) || bd[b1r * 9 + b1c]) continue;
        const b2r = r + ELEPH[k + 2], b2c = c + ELEPH[k + 3];
        if (!inB(b2r, b2c) || bd[b2r * 9 + b2c]) continue;
        const nr = r + ELEPH[k + 4], nc = c + ELEPH[k + 5];
        if (!inB(nr, nc)) continue;
        const d = nr * 9 + nc, q = bd[d];
        if (q && (q & 8) === side) continue;
        buf[n++] = sq * 90 + d;
      }
    } else { /* T_J 졸 */
      const fd = side === HAN ? -1 : 1;
      const cr = [r + fd, r, r], cc2 = [c, c - 1, c + 1];
      for (let k = 0; k < 3; k++) {
        const nr = cr[k], nc = cc2[k];
        if (!inB(nr, nc)) continue;
        const d = nr * 9 + nc, q = bd[d];
        if (q && (q & 8) === side) continue;
        buf[n++] = sq * 90 + d;
      }
      const dn = DIAGN[sq];
      for (let k = 0; k < dn.length; k++) {
        const d = dn[k];
        if (((d / 9) | 0) !== r + fd) continue;                   /* 앞 대각만 */
        const q = bd[d]; if (q && (q & 8) === side) continue;
        buf[n++] = sq * 90 + d;
      }
    }
  }
  return n;
}

/* --- 착수 / 되돌리기 --- */
function mk(m) {
  const f = (m / 90) | 0, t = m % 90;
  const cap = bd[t], pc = bd[f];
  if (cap) { h1 ^= ZR1[cap * NSQ + t]; h2 ^= ZR2[cap * NSQ + t]; }
  h1 ^= ZR1[pc * NSQ + f] ^ ZR1[pc * NSQ + t];
  h2 ^= ZR2[pc * NSQ + f] ^ ZR2[pc * NSQ + t];
  bd[t] = pc; bd[f] = 0;
  if ((pc & 7) === T_K) kpos[(pc & 8) ? 1 : 0] = t;
  return cap;
}
function unmk(m, cap) {
  const f = (m / 90) | 0, t = m % 90, pc = bd[t];
  bd[f] = pc; bd[t] = cap;
  h1 ^= ZR1[pc * NSQ + f] ^ ZR1[pc * NSQ + t];
  h2 ^= ZR2[pc * NSQ + f] ^ ZR2[pc * NSQ + t];
  if (cap) { h1 ^= ZR1[cap * NSQ + t]; h2 ^= ZR2[cap * NSQ + t]; }
  if ((pc & 7) === T_K) kpos[(pc & 8) ? 1 : 0] = f;
}

/* --- 장군 판정 ---
   궁 자리에서 거꾸로 훑어 본다. 모든 수를 만들어 보는 것보다 수십 배 빠르므로
   탐색 안쪽(정숙탐색 포함)에서도 마음 놓고 쓸 수 있음. */
function inCheck(side) {
  const k = kpos[kIdx(side)];
  if (bd[k] !== (T_K + side)) return false;
  const kr = (k / 9) | 0, kc = k % 9, enemy = other(side);

  /* 1) 가로·세로: 차와 포 */
  for (let d = 0; d < 8; d += 2) {
    const dr = OD[d], dc = OD[d + 1];
    let r = kr + dr, c = kc + dc, scr = 0;
    while (inB(r, c)) {
      const p = bd[r * 9 + c];
      if (p) {
        if ((p & 8) === enemy && (p & 7) === T_R) return true;
        scr = p; break;
      }
      r += dr; c += dc;
    }
    if (!scr || (scr & 7) === T_P) continue;        /* 다리가 없거나 다리가 포면 포는 못 넘음 */
    r += dr; c += dc;
    while (inB(r, c)) {
      const p = bd[r * 9 + c];
      if (p) { if ((p & 8) === enemy && (p & 7) === T_P) return true; break; }
      r += dr; c += dc;
    }
  }

  /* 2) 궁성 대각선: 차와 포 */
  const di = DINFO[k];
  for (let i = 0; i < di.length; i++) {
    const L = di[i][0], at = di[i][1];
    for (let st = -1; st <= 1; st += 2) {
      let j = at + st, scr = 0, sj = -1;
      for (; j >= 0 && j < 3; j += st) { const p = bd[L[j]]; if (p) { scr = p; sj = j; break; } }
      if (!scr) continue;
      if ((scr & 8) === enemy && (scr & 7) === T_R) return true;
      if ((scr & 7) === T_P) continue;
      for (j = sj + st; j >= 0 && j < 3; j += st) {
        const p = bd[L[j]];
        if (p) { if ((p & 8) === enemy && (p & 7) === T_P) return true; break; }
      }
    }
  }

  /* 3) 마 */
  for (let i = 0; i < 32; i += 4) {
    const orr = kr - HORSE[i + 2], occ = kc - HORSE[i + 3];
    if (!inB(orr, occ)) continue;
    const p = bd[orr * 9 + occ];
    if (!p || (p & 8) !== enemy || (p & 7) !== T_H) continue;
    const br = orr + HORSE[i], bc = occ + HORSE[i + 1];
    if (!inB(br, bc) || bd[br * 9 + bc]) continue;
    return true;
  }

  /* 4) 상 */
  for (let i = 0; i < 48; i += 6) {
    const orr = kr - ELEPH[i + 4], occ = kc - ELEPH[i + 5];
    if (!inB(orr, occ)) continue;
    const p = bd[orr * 9 + occ];
    if (!p || (p & 8) !== enemy || (p & 7) !== T_E) continue;
    const b1r = orr + ELEPH[i], b1c = occ + ELEPH[i + 1];
    if (!inB(b1r, b1c) || bd[b1r * 9 + b1c]) continue;
    const b2r = orr + ELEPH[i + 2], b2c = occ + ELEPH[i + 3];
    if (!inB(b2r, b2c) || bd[b2r * 9 + b2c]) continue;
    return true;
  }

  /* 5) 졸 (앞·옆, 그리고 궁성 대각선) */
  const efd = enemy === HAN ? -1 : 1;              /* 적 졸이 나아가는 방향 */
  let rr = kr - efd;
  if (inB(rr, kc)) { const p = bd[rr * 9 + kc]; if (p && (p & 8) === enemy && (p & 7) === T_J) return true; }
  for (let dc = -1; dc <= 1; dc += 2) {
    const c = kc + dc;
    if (inB(kr, c)) { const p = bd[kr * 9 + c]; if (p && (p & 8) === enemy && (p & 7) === T_J) return true; }
  }
  const dn = DIAGN[k];
  for (let i = 0; i < dn.length; i++) {
    const q = dn[i];
    if (kr !== ((q / 9) | 0) + efd) continue;
    const p = bd[q];
    if (p && (p & 8) === enemy && (p & 7) === T_J) return true;
  }
  /* 궁과 사는 제 궁성을 못 벗어나므로 상대 궁을 위협할 수 없음 */
  return false;
}

/* 느리지만 확실한 판정 — 빠른 판정기를 검증할 때 씀 */
const chkBuf = new Int32Array(256);
function inCheckSlow(side) {
  const sq = kpos[kIdx(side)], n = genMoves(other(side), chkBuf);
  for (let i = 0; i < n; i++) if (chkBuf[i] % 90 === sq) return true;
  return false;
}

/* --- 빅장: 두 궁이 같은 세로줄에서 사이에 말 없이 마주 봄 --- */
function isBikjang() {
  const a = kpos[0], b = kpos[1];
  if (a % 9 !== b % 9) return false;
  const c = a % 9;
  const r1 = Math.min((a / 9) | 0, (b / 9) | 0), r2 = Math.max((a / 9) | 0, (b / 9) | 0);
  for (let r = r1 + 1; r < r2; r++) if (bd[r * 9 + c]) return false;
  return true;
}

/* --- 합법수(자기 궁이 잡히지 않는 수)만 추리기 --- */
const legalBuf = new Int32Array(256);
function legalMoves(side) {
  const n = genMoves(side, legalBuf);
  const out = [];
  for (let i = 0; i < n; i++) {
    const m = legalBuf[i];
    const cap = mk(m);
    if (!inCheck(side)) out.push(m);
    unmk(m, cap);
  }
  return out;
}

/* --- 묘수풀이: side 가 n수 안에 외통을 강제할 수 있는가 ---
   기물이 몇 개 없는 자리에서만 쓰므로 합법수를 모두 펼쳐 확실하게 따짐 */
function forcedMate(side, n) {
  if (n <= 0) return false;
  for (const m of legalMoves(side)) {
    const cap = mk(m);
    const ok = defenderBeaten(side, n);
    unmk(m, cap);
    if (ok) return true;
  }
  return false;
}
function defenderBeaten(side, n) {
  const d = other(side), rep = legalMoves(d);
  if (rep.length === 0) {
    if (inCheck(d)) return true;                 /* 외통 */
    return n > 1 ? forcedMate(side, n - 1) : false;   /* 장군이 아니면 한수쉼 */
  }
  if (n <= 1) return false;
  for (const r of rep) {
    const c2 = mk(r);
    const sub = forcedMate(side, n - 1);
    unmk(r, c2);
    if (!sub) return false;
  }
  return true;
}
function matingMoves(side, n) {
  const out = [];
  for (const m of legalMoves(side)) {
    const cap = mk(m); const ok = defenderBeaten(side, n); unmk(m, cap);
    if (ok) out.push(m);
  }
  return out;
}

/* --- 묘수풀이 문제 (모두 초(楚)가 두어 외통을 만드는 자리) ---
   기물 표기: 종류 + 가로줄(0~9) + 세로줄(0~8), 내부 좌표 기준.
   전부 엔진으로 "정답 첫수가 꼭 하나"임을 확인해 둠 */
const PUZZLES = [
  /* ── 1수 외통: 기물마다 궁을 몰아넣는 모양을 익히는 문제 ── */
  { n: 1, t: '차',          cho: 'K13 R46 R64 J72', han: 'K95' },
  { n: 1, t: '차',          cho: 'K14 P72 R55 R45', han: 'K74 E60' },
  { n: 1, t: '포',          cho: 'K04 R44 P96 J84', han: 'K75 H95' },
  { n: 1, t: '포',          cho: 'K15 P55 R64 J62', han: 'K75' },
  { n: 1, t: '포',          cho: 'K15 E95 R73 P56', han: 'K94 S74 E66' },
  { n: 1, t: '마',          cho: 'K05 H51 H82 R88', han: 'K73 S74 E52' },
  { n: 1, t: '마',          cho: 'K13 H86 H78 R54', han: 'K73 S75 S83 E65' },
  { n: 1, t: '상',          cho: 'K05 E96 R74 P51', han: 'K85 S93 S95' },
  { n: 1, t: '상',          cho: 'K03 E63 R83 P52', han: 'K74 S75' },
  { n: 1, t: '졸',          cho: 'K03 P44 R80 J95', han: 'K93 S85 S74' },
  { n: 1, t: '졸',          cho: 'K15 R64 J74 E97', han: 'K95 J53' },
  { n: 1, t: '궁성 대각선', cho: 'K24 P83 R73 R53', han: 'K93' },
  { n: 1, t: '궁성 대각선', cho: 'K25 R95 P86 J94', han: 'K75 S85 S93' },

  /* ── 2수 외통 ── */
  { n: 2, cho: 'K14 R45 J86 E98', han: 'K94 J50' },
  { n: 2, cho: 'K13 R50 H44 E96', han: 'K95' },
  { n: 2, cho: 'K23 J72 R46 P80', han: 'K84 S74' },
  { n: 2, cho: 'K03 J88 H64 R45', han: 'K74 J85' },
  { n: 2, cho: 'K03 P74 R40 E76', han: 'K83 S94 S93' },
  { n: 2, cho: 'K03 R44 R75 J55', han: 'K83 S73 S94' },
  { n: 2, cho: 'K13 R52 J65 J44', han: 'K74 S95 S84' },

  /* ── 3수 외통 ── */
  { n: 3, cho: 'K25 R92 P67 J82', han: 'K73 S95' },
  { n: 3, cho: 'K23 J60 R51 E61', han: 'K95 E72' },
  { n: 3, cho: 'K04 R65 J81 P82', han: 'K93 S75 J51' },
  { n: 3, cho: 'K03 P66 R40 E43', han: 'K83 E68' },
  { n: 3, cho: 'K25 R53 P42 H58', han: 'K74 S83' },
  { n: 3, cho: 'K13 R54 P73 J60', han: 'K83 S95 S74' },
  { n: 3, cho: 'K24 R48 P71 J67', han: 'K74' },

  /* ── 4수 외통 ── */
  { n: 4, cho: 'K15 R42 H70 P80', han: 'K85 S94 S93' },
  { n: 4, cho: 'K13 R63 H84 P66', han: 'K94 S85' },
  { n: 4, cho: 'K05 R46 P94 H48', han: 'K75 S73' }
];
const PZ_TYPE = { K: T_K, S: T_S, R: T_R, P: T_P, H: T_H, E: T_E, J: T_J };
function setPuzzleBoard(p) {
  bd.fill(0);
  const put = (str, side) => {
    for (const tok of str.split(' ')) {
      if (!tok) continue;
      bd[(+tok[1]) * 9 + (+tok[2])] = PZ_TYPE[tok[0]] + side;
    }
  };
  put(p.cho, CHO); put(p.han, HAN);
  for (let i = 0; i < NSQ; i++) {
    if (bd[i] === T_K + HAN) kpos[0] = i;
    if (bd[i] === T_K + CHO) kpos[1] = i;
  }
  rehash();
}

/* --- 점수제 --- */
function sideScore(side) {
  let s = 0;
  for (let i = 0; i < NSQ; i++) { const p = bd[i]; if (p && (p & 8) === side) s += SCORE_VAL[p & 7]; }
  return side === HAN ? s + DUM : s;
}

/* ============================================================================
   3. 형세 판단(평가 함수)
   ============================================================================ */
const CEN = [0, 1, 2, 3, 4, 3, 2, 1, 0];      /* 세로줄 중앙성 */

function evaluate(side) {
  let s = 0;
  let hanS = 0, choS = 0;                      /* 사 개수: 궁 방어 */
  for (let sq = 0; sq < NSQ; sq++) {
    const p = bd[sq]; if (!p) continue;
    const t = p & 7, col = p & 8;
    const r = (sq / 9) | 0, c = sq % 9;
    let v = PV[t];
    if (t === T_J) {
      const adv = col === HAN ? (6 - r) : (r - 3);
      v += adv * 2 + CEN[c];
      const ep = col === HAN ? 2 : 1;          /* 상대 궁성 */
      if (PAL[sq] === ep) v += 8;
    } else if (t === T_H) {
      const adv = col === HAN ? (9 - r) : r;
      v += CEN[c] * 2 + Math.min(adv, 6);
    } else if (t === T_E) {
      const adv = col === HAN ? (9 - r) : r;
      v += CEN[c] + Math.min(adv, 6);
    } else if (t === T_R) {
      v += CEN[c];
      /* 차의 활동성: 네 방향으로 뻗는 길이 */
      let mob = 0;
      for (let k = 0; k < 8; k += 2) {
        const dr = OD[k], dc = OD[k + 1];
        let nr = r + dr, nc = c + dc;
        while (inB(nr, nc)) { const d = nr * 9 + nc; mob++; if (bd[d]) break; nr += dr; nc += dc; }
      }
      v += mob * 2;
    } else if (t === T_P) {
      v += CEN[c];
      if (PAL[sq] && c === 4) v += 10;         /* 면포 자리 */
    } else if (t === T_S) {
      const k = kpos[col === HAN ? 0 : 1];
      const dr = Math.abs(((k / 9) | 0) - r), dc = Math.abs((k % 9) - c);
      if (dr <= 1 && dc <= 1) v += 8;          /* 궁 곁을 지킴 */
      if (col === HAN) hanS++; else choS++;
    } else if (t === T_K) {
      if (c === 4 && PAL[sq]) v -= 6;          /* 한가운데 궁은 면포에 약함 */
    }
    s += (col === side) ? v : -v;
  }
  const sDiff = (side === HAN ? hanS - choS : choS - hanS);
  s += sDiff * 4;
  return s;
}

/* ============================================================================
   4. 탐색 — 알파베타 + 반복심화 + 치환표 + 정숙탐색
   ============================================================================ */
const MATE = 900000, INF = 9000000;
const MAXPLY = 40;
const MB = [], SB = [];
for (let i = 0; i < MAXPLY; i++) { MB.push(new Int32Array(256)); SB.push(new Int32Array(256)); }

const TT_BITS = 19, TT_SIZE = 1 << TT_BITS, TT_MASK = TT_SIZE - 1;
const ttLock = new Int32Array(TT_SIZE), ttMove = new Int32Array(TT_SIZE);
const ttScore = new Int32Array(TT_SIZE), ttDepth = new Int8Array(TT_SIZE), ttFlag = new Int8Array(TT_SIZE);
let ttStamp = new Int8Array(TT_SIZE), curStamp = 1;
const F_EXACT = 1, F_LOWER = 2, F_UPPER = 3;

const killers = new Int32Array(MAXPLY * 2);
const history = new Int32Array(NSQ * NSQ);

let nodes = 0, deadline = 0, aborted = false, useQ = true;

/* 치환표 주소 — 둘 차례까지 해시에 넣어야 같은 배치라도 구분됨 */
let tIdx = 0, tLock = 0;
function ttAddr(side) {
  const a = h1 ^ (side ? ZTURN1 : 0), b = h2 ^ (side ? ZTURN2 : 0);
  tLock = b;
  tIdx = (a ^ Math.imul(b, 0x45d9f3b)) & TT_MASK;
}

function scoreMoves(n, buf, sc, ply, ttm) {
  const k1 = killers[ply * 2], k2 = killers[ply * 2 + 1];
  for (let i = 0; i < n; i++) {
    const m = buf[i], t = m % 90, f = (m / 90) | 0;
    const vic = bd[t];
    if (m === ttm) sc[i] = 2000000;
    else if (vic) sc[i] = 1000000 + PV[vic & 7] * 16 - PV[bd[f] & 7];
    else if (m === k1) sc[i] = 900000;
    else if (m === k2) sc[i] = 890000;
    else sc[i] = history[f * NSQ + t];
  }
}
function pickMove(i, n, buf, sc) {
  let bi = i;
  for (let j = i + 1; j < n; j++) if (sc[j] > sc[bi]) bi = j;
  if (bi !== i) {
    const tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm;
    const ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts;
  }
}

function qsearch(side, alpha, beta, ply) {
  if (aborted) return 0;
  if ((++nodes & 1023) === 0 && Date.now() > deadline) { aborted = true; return 0; }
  if (ply >= MAXPLY - 2) return evaluate(side);
  /* 장군을 받고 있으면 가만히 있을 수 없음 — 모든 수를 살펴야 궁을 그냥 내주지 않음 */
  const chk = inCheck(side);
  if (!chk) {
    const stand = evaluate(side);
    if (stand >= beta) return beta;
    if (stand > alpha) alpha = stand;
  }
  const buf = MB[ply], sc = SB[ply];
  const n = genMoves(side, buf);
  let cn = 0;
  for (let i = 0; i < n; i++) {
    const m = buf[i], vic = bd[m % 90];
    if (vic && (vic & 7) === T_K) return MATE - ply;
    if (!chk && !vic) continue;                    /* 평시에는 잡는 수만 */
    buf[cn] = m;
    sc[cn] = vic ? (PV[vic & 7] * 16 - PV[bd[((m / 90) | 0)] & 7]) : 0;
    cn++;
  }
  if (chk && cn === 0) return -MATE + ply;         /* 외통 */
  for (let i = 0; i < cn; i++) {
    pickMove(i, cn, buf, sc);
    const m = buf[i];
    const cap = mk(m);
    const v = -qsearch(other(side), -beta, -alpha, ply + 1);
    unmk(m, cap);
    if (aborted) return 0;
    if (v >= beta) return beta;
    if (v > alpha) alpha = v;
  }
  return alpha;
}

function alphabeta(side, depth, alpha, beta, ply) {
  if (aborted) return 0;
  if ((++nodes & 1023) === 0 && Date.now() > deadline) { aborted = true; return 0; }
  if (ply >= MAXPLY - 4) return evaluate(side);

  ttAddr(side);
  const ai = tIdx, lock = tLock;
  let ttm = 0;
  if (ttLock[ai] === lock && ttStamp[ai] === curStamp) {
    ttm = ttMove[ai];
    if (ttDepth[ai] >= depth) {
      /* 외통 점수는 저장할 때 뿌리 기준으로 바꿔 두었으므로 여기서 되돌림 */
      let v = ttScore[ai];
      if (v >= MATE - 1000) v -= ply; else if (v <= -MATE + 1000) v += ply;
      const fl = ttFlag[ai];
      if (fl === F_EXACT) return v;
      if (fl === F_LOWER && v >= beta) return v;
      if (fl === F_UPPER && v <= alpha) return v;
    }
  }
  if (depth <= 0) return useQ ? qsearch(side, alpha, beta, ply) : evaluate(side);
  if (depth <= 2 && ply < 24 && inCheck(side)) depth++;   /* 장군 연장 */

  const buf = MB[ply], sc = SB[ply];
  const n = genMoves(side, buf);
  if (n === 0) {                                  /* 둘 수 없으면 한수쉼 */
    return -alphabeta(other(side), depth - 1, -beta, -alpha, ply + 1);
  }
  scoreMoves(n, buf, sc, ply, ttm);

  let best = -INF, bestM = 0, a0 = alpha;
  for (let i = 0; i < n; i++) {
    pickMove(i, n, buf, sc);
    const m = buf[i], t = m % 90;
    if ((bd[t] & 7) === T_K) { best = MATE - ply; bestM = m; break; }   /* 궁을 잡음 */
    const cap = mk(m);
    const v = -alphabeta(other(side), depth - 1, -beta, -alpha, ply + 1);
    unmk(m, cap);
    if (aborted) return 0;
    if (v > best) { best = v; bestM = m; }
    if (v > alpha) alpha = v;
    if (alpha >= beta) {
      if (!cap) {
        const kb = ply * 2;
        if (killers[kb] !== m) { killers[kb + 1] = killers[kb]; killers[kb] = m; }
        history[((m / 90) | 0) * NSQ + (m % 90)] += depth * depth;
      }
      break;
    }
  }
  let store = best;
  if (store >= MATE - 1000) store += ply; else if (store <= -MATE + 1000) store -= ply;
  ttLock[ai] = lock; ttStamp[ai] = curStamp; ttMove[ai] = bestM;
  ttScore[ai] = store; ttDepth[ai] = depth;
  ttFlag[ai] = best <= a0 ? F_UPPER : (best >= beta ? F_LOWER : F_EXACT);
  return best;
}

/* 난이도 설정 */
const LEVELS = {
  easy:     { name: '쉬움',      depth: 1,  time: 300,  q: false, blunder: 0.32, spread: 150, icon: '🌱' },
  normal:   { name: '보통',      depth: 3,  time: 1000, q: true,  blunder: 0.08, spread: 25,  icon: '🌿' },
  hard:     { name: '어려움',    depth: 7,  time: 2500, q: true,  blunder: 0.0,  spread: 10,  icon: '🌳' },
  veryhard: { name: '매우 어려움', depth: 14, time: 4500, q: true,  blunder: 0.0,  spread: 0,   icon: '🔥' },
  master:   { name: '최고 어려움', depth: 24, time: 8500, q: true,  blunder: 0.0,  spread: 0,   icon: '👑' }
};

/* 뿌리 탐색: 합법수만 대상으로 점수를 매겨 돌려줌 */
let yieldNow = null;
async function searchBest(side, level) {
  const cfg = LEVELS[level] || LEVELS.normal;
  const roots = legalMoves(side);
  if (roots.length === 0) return { move: -1, score: 0, depth: 0 };

  nodes = 0; aborted = false; useQ = cfg.q;
  deadline = Date.now() + cfg.time;
  /* 0.12초 넘게 붙들고 있었으면 한 번 놓아 준다 */
  if (cfg.time >= 1500) {
    let last = Date.now();
    yieldNow = () => {
      const now = Date.now();
      if (now - last < 120) return null;
      last = now;
      return new Promise(r => setTimeout(r, 0));
    };
  } else yieldNow = null;
  curStamp = (curStamp % 100) + 1;
  history.fill(0); killers.fill(0);

  const scored = roots.map(m => ({ m, s: -INF }));
  let doneDepth = 0, lastGood = null;

  /* 뿌리에서는 창을 좁히지 않는다.
     창을 좁히면 뒤로 밀린 수들이 "기준값 언저리" 값으로만 돌아오는데, 이 엔진에서는
     그 값들이 다음 깊이의 수 정렬을 흐트러뜨려 오히려 약해졌다(자체 대국으로 두 번 확인).
     전체 창은 노드를 더 쓰지만 고른 수가 확실하다. */
  for (let d = 1; d <= cfg.depth; d++) {
    const cur = [];
    scored.sort((x, y) => y.s - x.s);            /* 이전 깊이에서 좋았던 수부터 */
    for (const it of scored) {
      const t = it.m % 90;
      if ((bd[t] & 7) === T_K) { cur.push({ m: it.m, s: MATE }); continue; }
      const cap = mk(it.m);
      const v = -alphabeta(other(side), d - 1, -INF, INF, 1);
      unmk(it.m, cap);
      if (aborted) break;
      cur.push({ m: it.m, s: v });
      if (yieldNow) await yieldNow();            /* 오래 생각하는 단계는 중간에 화면을 숨 쉬게 함 */
      if (aborted) break;
    }
    /* 중간에 끊겨도 좋은 수부터 살펴본 뒤이므로 그때까지의 결과를 씀 */
    if (cur.length) {
      for (const c of cur) { const f = scored.find(x => x.m === c.m); if (f) f.s = c.s; }
      if (!aborted || cur.length >= 3 || !lastGood) { lastGood = cur.slice(); doneDepth = d; }
    }
    if (aborted) break;
    const top = cur.reduce((a, b) => (b.s > a.s ? b : a), cur[0]);
    if (top.s >= MATE - 100) break;                /* 외통을 찾았으면 그만 */
    if (Date.now() > deadline) break;
  }

  const list = (lastGood && lastGood.length) ? lastGood.slice() : scored.map(x => ({ m: x.m, s: 0 }));
  list.sort((a, b) => b.s - a.s);

  /* 난이도에 따른 흔들림 */
  if (cfg.blunder > 0 && Math.random() < cfg.blunder) {
    const pick = list[Math.floor(Math.random() * list.length)];
    return { move: pick.m, score: pick.s, depth: doneDepth };
  }
  const best = list[0].s;
  const pool = list.filter(x => x.s >= best - cfg.spread);
  const pick = pool[Math.floor(Math.random() * pool.length)];
  return { move: pick.m, score: pick.s, depth: doneDepth };
}

/* ============================================================================
   5. 화면 · 조작
   ============================================================================ */
const $ = id => document.getElementById(id);
const boardEl = $('board'), gridSvg = $('grid-svg');
const layMark = $('layer-mark'), layPieces = $('layer-pieces'), layCells = $('layer-cells');

/* --- 판 위 좌표(%) --- */
const PAD = 62, CELL = 100, VW = 924, VH = 1024;
function pctX(c) { return ((PAD + c * CELL) / VW) * 100; }
function pctY(r) { return ((PAD + r * CELL) / VH) * 100; }

/* --- 설정 저장 --- */
const SKEY = 'daram-janggi-v1';
const S = {
  level: 'normal', side: 'han', setup: 'gwima_l', oppSetup: 'gwima_r', oppRandom: false,
  korean: false, bikjang: false, sound: true
};
function loadSettings() {
  try {
    const raw = localStorage.getItem(SKEY);
    if (raw) Object.assign(S, JSON.parse(raw));
  } catch (e) { /* 저장소를 못 쓰는 환경이면 기본값 사용 */ }
  if (S.oppSetup === 'random') { S.oppSetup = 'gwima_r'; S.oppRandom = true; }   /* 예전 저장값 정리 */
  if (typeof S.oppRandom !== 'boolean') S.oppRandom = false;
}
function saveSettings() { try { localStorage.setItem(SKEY, JSON.stringify(S)); } catch (e) {} }

const STATKEY = 'daram-janggi-stats-v1';
function loadStats() {
  try { return JSON.parse(localStorage.getItem(STATKEY)) || {}; } catch (e) { return {}; }
}
function saveStat(level, result) {
  try {
    const st = loadStats();
    st[level] = st[level] || { w: 0, d: 0, l: 0 };
    st[level][result]++;
    localStorage.setItem(STATKEY, JSON.stringify(st));
  } catch (e) {}
}

/* --- 소리 --- */
let actx = null;
function tone(freq, dur, type, vol) {
  if (!S.sound) return;
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'triangle'; o.frequency.setValueAtTime(freq, actx.currentTime);
    o.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.5), actx.currentTime + dur);
    g.gain.setValueAtTime(vol || 0.16, actx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + dur);
    o.connect(g); g.connect(actx.destination);
    o.start(); o.stop(actx.currentTime + dur + 0.02);
  } catch (e) {}
}
const sndMove = () => tone(260, 0.09, 'triangle', 0.15);
const sndCap  = () => { tone(150, 0.16, 'square', 0.13); setTimeout(() => tone(300, 0.08, 'triangle', 0.1), 40); };
const sndChk  = () => { tone(620, 0.14, 'sine', 0.16); setTimeout(() => tone(820, 0.2, 'sine', 0.14), 110); };
const sndEnd  = () => { [520, 660, 780].forEach((f, i) => setTimeout(() => tone(f, 0.25, 'sine', 0.15), i * 130)); };

/* --- 토스트 --- */
let toastT = null;
function toast(msg) {
  const el = $('toast'); el.textContent = msg; el.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2200);
}

/* --- 대국 상태 --- */
const G = {
  mode: 'ai', level: 'normal',
  humanSide: HAN, bottomSide: HAN, flip: false,
  turn: CHO, sel: -1, selMoves: [],
  stack: [], posKeys: [], log: [],
  captured: { 0: [], 8: [] },
  names: { 0: '한', 8: '초' },
  lastMove: null, hint: null, puzzle: null,
  over: false, overText: '', thinking: false, noMoveStreak: 0
};

const sideKo = s => (s === HAN ? '한' : '초');
const sideHanja = s => (s === HAN ? '漢' : '楚');
const glyphOf = p => {
  const t = p & 7;
  if (S.korean) return (p & 8) ? KO_CHO[t] : KO_HAN[t];
  return (p & 8) ? GLYPH_CHO[t] : GLYPH_HAN[t];
};
const nameOf = p => ((p & 8) ? KO_CHO[p & 7] : KO_HAN[p & 7]);

/* 화면 기준 좌표 */
function dispRC(sq) {
  let r = (sq / 9) | 0, c = sq % 9;
  if (G.flip) { r = 9 - r; c = 8 - c; }
  return [r, c];
}
function coordLabel(sq) {
  const [r, c] = dispRC(sq);
  return String(c + 1) + String((r + 1) % 10);
}

/* --- 판 그리기 --- */
function buildGrid() {
  let out = '';
  const L = (x1, y1, x2, y2, w, op) =>
    \`<line x1="\${x1}" y1="\${y1}" x2="\${x2}" y2="\${y2}" stroke="#6b4420" stroke-width="\${w}" stroke-linecap="round" opacity="\${op}"/>\`;
  const x0 = PAD, x1 = PAD + 8 * CELL, y0 = PAD, y1 = PAD + 9 * CELL;
  for (let c = 0; c < 9; c++) { const x = PAD + c * CELL; out += L(x, y0, x, y1, (c === 0 || c === 8) ? 5 : 3, .82); }
  for (let r = 0; r < 10; r++) { const y = PAD + r * CELL; out += L(x0, y, x1, y, (r === 0 || r === 9) ? 5 : 3, .82); }
  for (const r0 of [0, 7]) {
    const ya = PAD + r0 * CELL, yb = PAD + (r0 + 2) * CELL;
    const xa = PAD + 3 * CELL, xb = PAD + 5 * CELL;
    out += L(xa, ya, xb, yb, 3, .82);
    out += L(xb, ya, xa, yb, 3, .82);
  }
  /* 바깥 테두리 */
  out += \`<rect x="\${x0 - 16}" y="\${y0 - 16}" width="\${x1 - x0 + 32}" height="\${y1 - y0 + 32}" fill="none" stroke="#7a4f22" stroke-width="4" opacity=".55" rx="6"/>\`;
  gridSvg.innerHTML = out;
}

function buildCells() {
  let html = '';
  for (let sq = 0; sq < NSQ; sq++) {
    html += \`<button class="cell" type="button" data-sq="\${sq}" aria-label="\${coordLabel(sq)}"></button>\`;
  }
  layCells.innerHTML = html;
  positionCells();
}
function positionCells() {
  const cells = layCells.children;
  for (let i = 0; i < cells.length; i++) {
    const sq = +cells[i].dataset.sq;
    const [r, c] = dispRC(sq);
    cells[i].style.left = pctX(c) + '%';
    cells[i].style.top = pctY(r) + '%';
    cells[i].setAttribute('aria-label', coordLabel(sq));
  }
}

function renderPieces() {
  let html = '';
  for (let sq = 0; sq < NSQ; sq++) {
    const p = bd[sq]; if (!p) continue;
    const [r, c] = dispRC(sq);
    const cls = ['pc', 'sz' + SZ[p & 7], (p & 8) ? 'cho' : 'han'];
    if (S.korean) cls.push('ko');
    if (sq === G.sel) cls.push('sel');
    html += \`<div class="\${cls.join(' ')}" style="left:\${pctX(c)}%; top:\${pctY(r)}%">\${glyphOf(p)}</div>\`;
  }
  layPieces.innerHTML = html;
}

function renderMarks() {
  let html = '';
  const mk = (sq, cls) => {
    const [r, c] = dispRC(sq);
    html += \`<div class="mk \${cls}" style="left:\${pctX(c)}%; top:\${pctY(r)}%"></div>\`;
  };
  if (G.lastMove) { mk(G.lastMove.f, 'last'); mk(G.lastMove.t, 'last'); }
  if (G.hint) { mk(G.hint.f, 'hint'); mk(G.hint.t, 'hint'); }
  for (const m of G.selMoves) mk(m % 90, bd[m % 90] ? 'cap' : 'dot');
  if (!G.over && inCheck(G.turn)) mk(kpos[kIdx(G.turn)], 'checkmk');
  layMark.innerHTML = html;
}

function renderAll() { renderPieces(); renderMarks(); updatePanel(); }

/* 판 크기에 맞춰 말 크기 단위(--u) 갱신 */
function syncUnit() {
  const w = boardEl.clientWidth;
  if (w > 0) boardEl.style.setProperty('--u', (w / 9.24) + 'px');
}
if (window.ResizeObserver) new ResizeObserver(syncUnit).observe(boardEl);
window.addEventListener('resize', syncUnit);

/* --- 옆 패널 --- */
function updatePanel() {
  const topSide = other(G.bottomSide), botSide = G.bottomSide;
  const set = (pos, side) => {
    $('f-' + pos).textContent = sideHanja(side);
    $('f-' + pos).className = 'flag ' + (side === HAN ? 'han' : 'cho');
    $('n-' + pos).textContent = G.names[side];
    $('s-' + pos).textContent = sideScore(side).toFixed(1);
    $('d-' + pos).textContent = side === HAN ? '한(漢) · 후수 · 덤 1.5' : '초(楚) · 선수';
    $('pl-' + pos).classList.toggle('turn', !G.over && G.turn === side);
    $('cap-' + pos).innerHTML = G.captured[side].map(p => {
      const t = p & 7;
      return \`<span class="\${(p & 8) ? 'cho' : 'han'}" title="\${nameOf(p)}">\${(p & 8) ? GLYPH_CHO[t] : GLYPH_HAN[t]}</span>\`;
    }).join('');
  };
  set('top', topSide); set('bot', botSide);

  const pz = G.mode === 'puzzle';
  $('puzzle-card').hidden = !pz;
  $('pl-top').hidden = pz; $('pl-bot').hidden = pz;
  $('btn-pass').hidden = pz; $('btn-resign').hidden = pz; $('btn-flip').hidden = pz;
  if (pz) {
    $('pz-title').textContent = \`\${G.puzzle.i + 1}번 · \${G.puzzle.n}수 외통\`;
    $('pz-left').textContent = G.over ? '성공' : '남은 ' + G.puzzle.left + '수';
    $('pz-sub').textContent = G.over
      ? '다음 문제로 넘어가 보세요.'
      : '외통이 안 되는 수를 두면 저절로 물러집니다.';
    $('btn-undo').textContent = '↩ 처음부터';
    $('btn-restart').textContent = '↻ 다음 문제';
  } else {
    $('btn-undo').textContent = '↩ 무르기';
    $('btn-restart').textContent = '↻ 다시';
  }
  const myTurn = G.mode === 'pvp' || G.turn === G.humanSide;
  $('btn-undo').disabled = G.thinking || (!pz && (G.over || G.stack.length === 0));
  $('btn-pass').disabled = G.thinking || G.over || !myTurn;
  $('btn-hint').disabled = G.thinking || G.over || !myTurn;
}

function updateStatus() {
  const el = $('game-status');
  el.className = '';
  if (G.over) { el.textContent = G.overText || '대국 종료'; return; }
  if (G.thinking) { el.classList.add('thinking'); el.textContent = '컴퓨터가 생각 중…'; return; }
  const chk = inCheck(G.turn);
  const who = G.mode === 'ai'
    ? (G.turn === G.humanSide ? '내 차례' : '상대 차례')
    : (G.names[G.turn] + ' 차례');
  if (chk) { el.classList.add('check'); el.textContent = '장군! · ' + who; }
  else el.textContent = sideKo(G.turn) + '(' + sideHanja(G.turn) + ') · ' + who;
}

function pushLog(text, side) {
  G.log.push({ text, side });
  renderLog();
}
function renderLog() {
  const box = $('movelog');
  if (!G.log.length) { box.innerHTML = '<div class="empty">아직 둔 수가 없습니다.</div>'; return; }
  box.innerHTML = G.log.map((e, i) =>
    \`<div class="ml\${i === G.log.length - 1 ? ' new' : ''}"><span class="no">\${i + 1}</span>\` +
    \`<span class="sd \${e.side === HAN ? 'han' : 'cho'}">\${sideHanja(e.side)}</span>\` +
    \`<span>\${e.text}</span></div>\`).join('');
  box.scrollTop = box.scrollHeight;
}

/* ============================================================================
   6. 대국 진행
   ============================================================================ */
function posKey() { return h1 + '|' + h2 + '|' + G.turn; }

function applyMove(m) {
  const f = (m / 90) | 0, t = m % 90;
  const mover = bd[f], cap = bd[t];
  const label = nameOf(mover) + ' ' + coordLabel(f) + '→' + coordLabel(t) + (cap ? ' ×' + nameOf(cap) : '');
  G.stack.push({ m, cap, turn: G.turn });
  if (cap) G.captured[G.turn].push(cap);
  mk(m);
  G.lastMove = { f, t };
  G.sel = -1; G.selMoves = []; G.hint = null;
  pushLog(label, G.turn);
  G.turn = other(G.turn);
  G.posKeys.push(posKey());
  G.noMoveStreak = 0;
  if (cap) sndCap(); else sndMove();
  renderAll();
  afterMove();
}

function doPass(auto) {
  G.stack.push({ m: -1, cap: 0, turn: G.turn });
  pushLog('한수쉼', G.turn);
  G.turn = other(G.turn);
  G.posKeys.push(posKey());
  G.sel = -1; G.selMoves = []; G.hint = null;
  G.noMoveStreak++;
  if (!auto) toast('한 수 쉬었습니다.');
  renderAll();
  afterMove();
}

function repeatCount() {
  const k = G.posKeys[G.posKeys.length - 1];
  let n = 0;
  for (const x of G.posKeys) if (x === k) n++;
  return n;
}

function afterMove() {
  if (G.mode === 'puzzle') return afterPuzzleMove();
  updateStatus();
  if (G.over) return;

  /* 빅장 (옛 규칙을 켠 경우) */
  if (S.bikjang && isBikjang()) {
    return endGame('bikjang', null, '두 궁이 마주 보아 빅장이 되었습니다.');
  }
  const moves = legalMoves(G.turn);
  const chk = inCheck(G.turn);
  if (moves.length === 0) {
    if (chk) return endGame('mate', other(G.turn), sideKo(G.turn) + '의 궁이 외통에 걸렸습니다.');
    if (G.noMoveStreak >= 2) return endGame('score', null, '양쪽 모두 둘 수가 없어 점수로 가립니다.');
    toast(sideKo(G.turn) + '은(는) 둘 수가 없어 한 수 쉽니다.');
    return setTimeout(() => doPass(true), 500);
  }
  if (chk) sndChk();
  if (repeatCount() >= 3) return endGame('repeat', null, '같은 자리가 세 번 되풀이되어 점수로 가립니다.');
  if (G.stack.length >= 400) return endGame('score', null, '수가 너무 길어져 점수로 가립니다.');

  if (G.mode === 'ai' && G.turn !== G.humanSide) setTimeout(aiTurn, 220);
}

function aiTurn() {
  if (G.over || G.thinking) return;
  G.thinking = true; updateStatus(); updatePanel();
  /* 화면을 한 번 그린 뒤 계산 시작 */
  requestAnimationFrame(() => setTimeout(async () => {
    let res = null;
    try { res = await searchBest(G.turn, G.level); }
    catch (e) { res = null; }
    G.thinking = false;
    if (G.over) { updateStatus(); updatePanel(); return; }   /* 생각하는 사이에 판이 끝났으면 */
    if (!res || res.move === -1) { doPass(true); return; }
    applyMove(res.move);
  }, 30));
}

/* ============================================================================
   6-2. 묘수풀이
   ============================================================================ */
const PZKEY = 'daram-janggi-puzzles-v2';
function loadSolved() {
  try { return new Set(JSON.parse(localStorage.getItem(PZKEY)) || []); } catch (e) { return new Set(); }
}
function markSolved(i) {
  try { const st = loadSolved(); st.add(i); localStorage.setItem(PZKEY, JSON.stringify([...st])); } catch (e) {}
}

const PZ_HOW = { 1: '한 수로 끝내기', 2: '두 수 만에 몰아넣기', 3: '세 수 만에 몰아넣기', 4: '네 수 만에 몰아넣기' };
/* '차로 / 상으로' 처럼 받침에 맞는 조사를 붙임 */
function withRo(w) {
  const code = w.charCodeAt(w.length - 1) - 0xAC00;
  if (code < 0 || code > 11171) return w + '로';
  const jong = code % 28;
  return w + (jong === 0 || jong === 8 ? '로' : '으로');
}
function renderPuzzleList() {
  const solved = loadSolved();
  let done = 0;
  for (let i = 0; i < PUZZLES.length; i++) if (solved.has(i)) done++;
  $('pz-progress').innerHTML = \`푼 문제 <b>\${done}</b> / <b>\${PUZZLES.length}</b>\`;

  const steps = [...new Set(PUZZLES.map(p => p.n))].sort((a, b) => a - b);
  let html = '';
  for (const n of steps) {
    const idx = PUZZLES.map((p, i) => [p, i]).filter(([p]) => p.n === n);
    const cleared = idx.filter(([, i]) => solved.has(i)).length;
    html += \`<div class="pz-group"><div class="pz-group-title"><b>\${n}수 외통</b>\` +
            \`<span>\${PZ_HOW[n] || n + '수 만에 몰아넣기'} · \${cleared}/\${idx.length}</span></div>\` +
            '<div class="puzzle-grid">';
    for (const [p, i] of idx) {
      const ok = solved.has(i);
      html += \`<button class="pz-card\${ok ? ' done' : ''}" type="button" data-pz="\${i}">\` +
        \`<div class="pn">\${i + 1}번</div>\` +
        \`<div class="pd">\${p.t ? withRo(p.t) + ' 끝내기' : p.n + '수 외통'}</div>\` +
        (ok ? '<div class="pk">✔ 해결</div>' : '') + '</button>';
    }
    html += '</div></div>';
  }
  $('puzzle-list').innerHTML = html;
}
$('puzzle-list').addEventListener('click', ev => {
  const b = ev.target.closest('[data-pz]');
  if (b) startPuzzle(+b.dataset.pz);
});

function startPuzzle(i) {
  const p = PUZZLES[i];
  G.mode = 'puzzle'; G.level = 'hard';
  G.puzzle = { i, n: p.n, left: p.n };
  G.humanSide = CHO; G.bottomSide = CHO; G.flip = true;
  setPuzzleBoard(p);
  G.turn = CHO;
  G.sel = -1; G.selMoves = []; G.stack = []; G.posKeys = [posKey()];
  G.log = []; G.captured = { 0: [], 8: [] };
  G.lastMove = null; G.hint = null; G.over = false; G.overText = '';
  G.thinking = false; G.noMoveStreak = 0;
  G.names[CHO] = '나 (초)'; G.names[HAN] = '수비 (컴퓨터)';
  $('game-title').textContent = \`🧩 묘수풀이 \${i + 1}번 · \${p.n}수 외통\`;
  show('game');
  positionCells(); renderLog(); renderAll(); updateStatus(); syncUnit();
  toast(p.n + '수 안에 외통을 만드세요.');
}

/* 수비는 가장 오래 버티는 수를 고름 */
function stubbornReply(rep, k) {
  let best = [], bestJ = -1;
  for (const r of rep) {
    const cap = mk(r);
    let j = k + 1;
    for (let t = 1; t <= k; t++) { if (forcedMate(CHO, t)) { j = t; break; } }
    unmk(r, cap);
    if (j > bestJ) { bestJ = j; best = [r]; }
    else if (j === bestJ) best.push(r);
  }
  return best[Math.floor(Math.random() * best.length)];
}

function afterPuzzleMove() {
  updateStatus(); updatePanel();
  if (G.over) return;
  if (G.turn !== HAN) return;                       /* 수비가 둔 뒤라면 그대로 사람 차례 */
  const rep = legalMoves(HAN);
  if (rep.length === 0 && inCheck(HAN)) return puzzleSolved();
  const remain = G.puzzle.left - 1;
  if (remain <= 0 || !forcedMate(CHO, remain)) return puzzleFailed();
  G.puzzle.left = remain;
  G.thinking = true; updateStatus(); updatePanel();
  requestAnimationFrame(() => setTimeout(() => {
    G.thinking = false;
    if (rep.length === 0) { doPass(true); return; }
    applyMove(stubbornReply(rep, remain));
  }, 320));
}

function puzzleFailed() {
  toast('그 수로는 외통이 되지 않습니다. 무르고 다시 생각해 보세요.');
  setTimeout(() => {
    undoOne();
    G.sel = -1; G.selMoves = []; G.hint = null;
    renderLog(); renderAll(); updateStatus(); updatePanel();
  }, 950);
}

function puzzleSolved() {
  G.over = true; G.overText = '외통 성공';
  markSolved(G.puzzle.i);
  $('go-icon').textContent = '🎉';
  $('go-title').textContent = '외통! 성공입니다';
  $('go-text').textContent = G.puzzle.n + '수 만에 궁을 몰아넣었습니다.';
  $('go-score').textContent = \`묘수풀이 \${G.puzzle.i + 1}번 · \${G.puzzle.n}수 외통\`;
  setModalButtons();
  updateStatus(); updatePanel(); renderMarks(); sndEnd();
  setTimeout(() => $('gameover-modal').classList.add('open'), 420);
}

function setModalButtons() {
  const pz = G.mode === 'puzzle';
  $('go-again').textContent = pz ? '다시 풀기' : '한판 더';
  $('go-setup').textContent = pz ? '다음 문제' : '설정 바꾸기';
  $('go-menu').textContent = pz ? '목록으로' : '메뉴로';
}

function endGame(reason, winner, detail) {
  G.over = true; G.thinking = false;
  G.sel = -1; G.selMoves = []; G.hint = null;

  const hs = sideScore(HAN), cs = sideScore(CHO);
  let w = winner;
  if (w === null && (reason === 'score' || reason === 'repeat')) {
    w = hs > cs ? HAN : (cs > hs ? CHO : null);
  }
  let title, icon, text;
  if (reason === 'bikjang') { title = '빅장 — 무승부'; icon = '🤝'; text = detail; }
  else if (w === null) { title = '무승부'; icon = '🤝'; text = detail || '승부를 가리지 못했습니다.'; }
  else {
    const human = G.mode === 'ai' ? G.humanSide : null;
    if (human === null) { title = G.names[w] + ' 승리'; icon = '🏆'; }
    else if (w === human) { title = '이겼습니다'; icon = '🏆'; }
    else { title = '졌습니다'; icon = '😥'; }
    text = (detail ? detail + ' ' : '') + sideKo(w) + '(' + sideHanja(w) + ')의 승리입니다.';
  }
  G.overText = title;
  $('go-icon').textContent = icon;
  $('go-title').textContent = title;
  $('go-text').textContent = text;
  $('go-score').textContent = \`최종 점수 — 한(漢) \${hs.toFixed(1)}점 · 초(楚) \${cs.toFixed(1)}점 (한 덤 1.5 포함)\`;

  if (G.mode === 'ai') {
    const r = w === null ? 'd' : (w === G.humanSide ? 'w' : 'l');
    saveStat(G.level, r);
  }
  setModalButtons();
  updateStatus(); updatePanel(); renderMarks();
  sndEnd();
  setTimeout(() => $('gameover-modal').classList.add('open'), 420);
}

/* --- 판 클릭 --- */
layCells.addEventListener('click', ev => {
  const btn = ev.target.closest('.cell'); if (!btn) return;
  const sq = +btn.dataset.sq;
  onPoint(sq);
});

function onPoint(sq) {
  if (G.over || G.thinking) return;
  if (G.mode === 'ai' && G.turn !== G.humanSide) return;

  /* 이미 고른 말이 있고, 그 말이 갈 수 있는 자리를 누른 경우 */
  const target = G.selMoves.find(m => m % 90 === sq);
  if (target !== undefined) { applyMove(target); return; }

  const p = bd[sq];
  if (p && (p & 8) === G.turn) {
    if (G.sel === sq) { G.sel = -1; G.selMoves = []; }
    else {
      G.sel = sq;
      G.selMoves = legalMoves(G.turn).filter(m => ((m / 90) | 0) === sq);
      if (G.selMoves.length === 0) toast(nameOf(p) + '은(는) 지금 둘 곳이 없습니다.');
    }
    G.hint = null;
    renderAll();
    return;
  }
  if (G.sel !== -1) { G.sel = -1; G.selMoves = []; renderAll(); }
}

/* --- 버튼 --- */
$('btn-pass').addEventListener('click', () => {
  if (G.over || G.thinking) return;
  if (inCheck(G.turn)) { toast('장군을 받은 상태에서는 쉴 수 없습니다.'); return; }
  doPass(false);
});

$('btn-hint').addEventListener('click', () => {
  if (G.over || G.thinking) return;
  G.thinking = true; updateStatus(); updatePanel();
  requestAnimationFrame(() => setTimeout(async () => {
    let mv = -1;
    try {
      if (G.mode === 'puzzle') {
        const list = matingMoves(CHO, G.puzzle.left);
        if (list.length) mv = list[0];
      } else {
        const res = await searchBest(G.turn, 'hard');
        if (res) mv = res.move;
      }
    } catch (e) { /* 훈수를 못 찾아도 대국은 계속됨 */ }
    G.thinking = false;
    if (mv >= 0) {
      const f = (mv / 90) | 0, t = mv % 90;
      G.hint = { f, t };
      toast('훈수: ' + nameOf(bd[f]) + ' ' + coordLabel(f) + '→' + coordLabel(t));
    } else toast('마땅한 수를 찾지 못했습니다.');
    updateStatus(); renderAll(); updatePanel();
  }, 30));
});

$('btn-flip').addEventListener('click', () => {
  G.flip = !G.flip;
  positionCells(); renderAll();
});

function undoOne() {
  const rec = G.stack.pop();
  if (!rec) return false;
  if (rec.m !== -1) { unmk(rec.m, rec.cap); if (rec.cap) G.captured[rec.turn].pop(); }
  G.turn = rec.turn;
  G.log.pop(); G.posKeys.pop();
  const prev = G.stack[G.stack.length - 1];
  G.lastMove = (prev && prev.m !== -1) ? { f: (prev.m / 90) | 0, t: prev.m % 90 } : null;
  return true;
}
$('btn-undo').addEventListener('click', () => {
  if (G.thinking) return;
  if (G.mode === 'puzzle') { startPuzzle(G.puzzle.i); return; }
  if (!G.stack.length) { toast('무를 수가 없습니다.'); return; }
  G.over = false; G.overText = '';
  undoOne();
  if (G.mode === 'ai' && G.turn !== G.humanSide) undoOne();   /* 상대 수까지 함께 무름 */
  G.sel = -1; G.selMoves = []; G.hint = null; G.noMoveStreak = 0;
  renderLog(); renderAll(); updateStatus();
  toast('한 수 물렀습니다.');
});

let confirmCb = null;
function askConfirm(title, text, cb) {
  $('cf-title').textContent = title; $('cf-text').textContent = text;
  confirmCb = cb; $('confirm-modal').classList.add('open');
}
$('cf-yes').addEventListener('click', () => { $('confirm-modal').classList.remove('open'); if (confirmCb) confirmCb(); });
$('cf-no').addEventListener('click', () => { $('confirm-modal').classList.remove('open'); confirmCb = null; });

$('btn-resign').addEventListener('click', () => {
  if (G.over || G.thinking) return;
  askConfirm('기권하시겠습니까?', '이번 판은 상대의 승리로 기록됩니다.', () => {
    endGame('resign', other(G.mode === 'ai' ? G.humanSide : G.turn), '기권하였습니다.');
  });
});
$('btn-restart').addEventListener('click', () => {
  if (G.thinking) return;
  if (G.mode === 'puzzle') { startPuzzle((G.puzzle.i + 1) % PUZZLES.length); return; }
  askConfirm('다시 두시겠습니까?', '지금 판은 사라지고 처음부터 시작합니다.', () => startGame(G.mode));
});
$('btn-quit').addEventListener('click', () => {
  if (G.thinking) return;
  const back = G.mode === 'puzzle' ? 'puzzles' : 'menu';
  if (G.over || !G.stack.length) { show(back); return; }
  askConfirm(G.mode === 'puzzle' ? '목록으로 돌아가시겠습니까?' : '메뉴로 나가시겠습니까?',
             '풀던 문제는 처음으로 돌아갑니다.', () => show(back));
});
$('go-again').addEventListener('click', () => {
  $('gameover-modal').classList.remove('open');
  if (G.mode === 'puzzle') startPuzzle(G.puzzle.i); else startGame(G.mode);
});
$('go-setup').addEventListener('click', () => {
  $('gameover-modal').classList.remove('open');
  if (G.mode === 'puzzle') startPuzzle((G.puzzle.i + 1) % PUZZLES.length);
  else show(G.mode === 'ai' ? 'ai-setup' : 'pvp-setup');
});
$('go-menu').addEventListener('click', () => {
  $('gameover-modal').classList.remove('open');
  show(G.mode === 'puzzle' ? 'puzzles' : 'menu');
});

/* ============================================================================
   7. 화면 전환 · 설정 UI
   ============================================================================ */
function show(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = $('screen-' + name);
  if (el) el.classList.add('active');
  window.scrollTo(0, 0);
  if (name === 'stats') renderStats();
  if (name === 'puzzles') renderPuzzleList();
  if (name === 'game') syncUnit();
}
document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => show(b.dataset.go)));
document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => show('menu')));

/* --- 선택 카드 묶음 --- */
function bindChoices(containerId, attr, getter, setter) {
  const box = $(containerId);
  box.addEventListener('click', ev => {
    const c = ev.target.closest('.choice'); if (!c) return;
    box.querySelectorAll('.choice').forEach(x => x.classList.remove('sel'));
    c.classList.add('sel');
    setter(c.dataset[attr]);
    saveSettings();
  });
  const cur = getter();
  box.querySelectorAll('.choice').forEach(x => x.classList.toggle('sel', x.dataset[attr] === cur));
}

/* --- 마·상 배치판 --- */
const setupById = id => SETUPS.find(s => s.id === id) || SETUPS[0];
const randomSetup = () => SETUPS[Math.floor(Math.random() * SETUPS.length)];
const setupByWings = (l, r) => SETUPS.find(s => s.left === l && s.right === r);

/* 내 진영 색 (아무거나이면 한 쪽으로 보여 줌) */
function mySideForUI() { return S.side === 'cho' ? CHO : HAN; }

/* 뒷줄 아홉 자리 — 마·상 넉 자리만 누를 수 있음 */
/* 배치판은 대국 때 판에 놓일 모습 그대로 그림.
   내 진영이 초면 대국 중 판이 돌아가므로 미리보기도 함께 뒤집음. */
function renderRank(who) {
  const st = setupById(who === 'me' ? S.setup : S.oppSetup);
  const side = who === 'me' ? mySideForUI() : other(mySideForUI());
  const cc = side === HAN ? 'han' : 'cho';
  const types = backRankTypes(side, st);
  const GL = side === HAN ? GLYPH_HAN : GLYPH_CHO;

  const cols = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  if (mySideForUI() === CHO) cols.reverse();          /* 대국 때 돌아갈 방향에 맞춤 */

  let html = '';
  for (let i = 0; i < cols.length; i++) {
    const c = cols[i], t = types[c], wing = wingOfCol(side, c);
    const g = c === 4 ? sideHanja(side) : GL[t];      /* 뒷줄 한가운데는 비어 있어 진영 글자를 놓음 */
    if (wing) {
      const wn = wing === 'left' ? '왼쪽' : '오른쪽';
      html += \`<button class="sb-pc \${cc} wing" type="button" data-who="\${who}" data-wing="\${wing}" title="\${g} — 눌러서 \${wn} 마·상 자리 바꾸기">\${g}</button>\`;
    } else {
      html += \`<span class="sb-pc \${cc} fixed">\${g}</span>\`;
    }
    const nx = cols[i + 1];
    if (nx !== undefined && wing && wing === wingOfCol(side, nx)) {
      const wn = wing === 'left' ? '왼쪽' : '오른쪽';
      html += \`<button class="sb-swap" type="button" data-who="\${who}" data-wing="\${wing}" aria-label="\${wn} 마·상 자리 바꾸기">↔</button>\`;
    }
  }
  $('sb-rank-' + who).innerHTML = html;
  $('sb-name-' + who).textContent = st.name;
}
function renderSetupBoard() {
  const mine = mySideForUI(), opp = other(mine);
  $('sb-who-me').innerHTML = \`<span class="tag \${mine === HAN ? 'han' : 'cho'}">\${sideHanja(mine)}</span>내 진영\` +
    (S.side === 'random' ? ' <span style="font-weight:400; color:var(--muted); font-size:.78rem;">(진영은 시작할 때 정해짐)</span>' : '');
  $('sb-who-opp').innerHTML = \`<span class="tag \${opp === HAN ? 'han' : 'cho'}">\${sideHanja(opp)}</span>상대 진영\`;
  renderRank('me'); renderRank('opp');
  $('sb-row-opp').classList.toggle('dim', !!S.oppRandom);
  $('opt-opp-random').checked = !!S.oppRandom;
}
$('setup-board').addEventListener('click', ev => {
  const b = ev.target.closest('[data-wing]'); if (!b) return;
  const who = b.dataset.who, wing = b.dataset.wing;
  const key = who === 'me' ? 'setup' : 'oppSetup';
  const cur = setupById(S[key]);
  const l = wing === 'left' ? (cur.left === 'MS' ? 'SM' : 'MS') : cur.left;
  const r = wing === 'right' ? (cur.right === 'MS' ? 'SM' : 'MS') : cur.right;
  S[key] = setupByWings(l, r).id;
  if (who === 'opp') S.oppRandom = false;
  saveSettings(); renderSetupBoard();
});
$('opt-opp-random').addEventListener('change', e => {
  S.oppRandom = e.target.checked; saveSettings(); renderSetupBoard();
});

/* --- 전적 --- */
function renderStats() {
  const st = loadStats();
  let w = 0, d = 0, l = 0;
  for (const k in st) { w += st[k].w || 0; d += st[k].d || 0; l += st[k].l || 0; }
  const total = w + d + l;
  const rate = total ? Math.round((w / total) * 100) : 0;
  $('stats-summary').innerHTML =
    [['총 대국', total], ['승', w], ['무', d], ['패', l], ['승률', rate + '%']]
      .map(([k, v]) => \`<div class="stat-tile"><div class="sv">\${v}</div><div class="sl">\${k}</div></div>\`).join('');
  let rows = '<tr><th>난이도</th><th class="n">승</th><th class="n">무</th><th class="n">패</th></tr>';
  for (const key of ['easy', 'normal', 'hard', 'veryhard']) {
    const r = st[key] || { w: 0, d: 0, l: 0 };
    rows += \`<tr><td>\${LEVELS[key].icon} \${LEVELS[key].name}</td><td class="n">\${r.w}</td><td class="n">\${r.d}</td><td class="n">\${r.l}</td></tr>\`;
  }
  $('stats-table').innerHTML = rows;
}
$('btn-reset-stats').addEventListener('click', () => {
  askConfirm('기록을 지우시겠습니까?', '승·무·패 기록이 모두 사라집니다.', () => {
    try { localStorage.removeItem(STATKEY); } catch (e) {}
    renderStats(); toast('기록을 지웠습니다.');
  });
});

/* ============================================================================
   8. 대국 시작
   ============================================================================ */
function startGame(mode) {
  G.mode = mode;
  G.level = S.level;

  let bottom;
  if (mode === 'ai') {
    let mine = S.side;
    if (mine === 'random') mine = Math.random() < 0.5 ? 'han' : 'cho';
    G.humanSide = mine === 'han' ? HAN : CHO;
    bottom = G.humanSide;
    G.names[G.humanSide] = '나';
    G.names[other(G.humanSide)] = '컴퓨터 (' + LEVELS[G.level].name + ')';
  } else {
    bottom = pvpBottom === 'han' ? HAN : CHO;
    G.names[CHO] = ($('pvp-cho-name').value || '').trim() || '초 (초록)';
    G.names[HAN] = ($('pvp-han-name').value || '').trim() || '한 (빨강)';
  }
  G.bottomSide = bottom;
  G.flip = (bottom === CHO);

  const mySetup = setupById(S.setup);
  const oppSetup = S.oppRandom ? randomSetup() : setupById(S.oppSetup);
  const bottomSetup = mySetup, topSetup = oppSetup;
  const hanSetup = bottom === HAN ? bottomSetup : topSetup;
  const choSetup = bottom === CHO ? bottomSetup : topSetup;
  newBoard(hanSetup, choSetup);

  G.turn = CHO;                       /* 초(楚)가 선수 */
  G.sel = -1; G.selMoves = []; G.stack = []; G.posKeys = [posKey()];
  G.log = []; G.captured = { 0: [], 8: [] };
  G.lastMove = null; G.hint = null; G.over = false; G.overText = '';
  G.thinking = false; G.noMoveStreak = 0;
  curStamp = (curStamp % 100) + 1;

  $('game-title').textContent = mode === 'ai'
    ? LEVELS[G.level].icon + ' ' + LEVELS[G.level].name + ' · 컴퓨터와 대국'
    : '👥 둘이서 대국';

  show('game');
  positionCells(); renderLog(); renderAll(); updateStatus(); syncUnit();

  toast(mode === 'ai'
    ? '내 진영: ' + sideKo(G.humanSide) + '(' + sideHanja(G.humanSide) + ') · 배치: ' + mySetup.name
    : '초(楚)가 먼저 둡니다.');

  if (mode === 'ai' && G.turn !== G.humanSide) setTimeout(aiTurn, 600);
}

let pvpBottom = 'han';

/* ============================================================================
   9. 초기화
   ============================================================================ */
loadSettings();
buildGrid();
buildCells();
bindChoices('ai-levels', 'level', () => S.level, v => { S.level = v; });
bindChoices('ai-sides', 'side', () => S.side, v => { S.side = v; renderSetupBoard(); });
bindChoices('pvp-bottom', 'side', () => pvpBottom, v => { pvpBottom = v; });
renderSetupBoard();

$('opt-korean').checked = S.korean;
$('opt-bikjang').checked = S.bikjang;
$('opt-sound').checked = S.sound;
$('opt-korean').addEventListener('change', e => { S.korean = e.target.checked; saveSettings(); renderPieces(); });
$('opt-bikjang').addEventListener('change', e => { S.bikjang = e.target.checked; saveSettings(); });
$('opt-sound').addEventListener('change', e => { S.sound = e.target.checked; saveSettings(); });

$('ai-start-btn').addEventListener('click', () => startGame('ai'));
$('pvp-start-btn').addEventListener('click', () => startGame('pvp'));

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    if ($('gameover-modal').classList.contains('open')) { $('gameover-modal').classList.remove('open'); return; }
    if ($('confirm-modal').classList.contains('open')) { $('confirm-modal').classList.remove('open'); return; }
    if (G.sel !== -1) { G.sel = -1; G.selMoves = []; renderAll(); }
  }
});

/* 메뉴 화면에서도 판이 한 번은 준비되도록 초기 배치를 만들어 둠 */
newBoard(setupById(S.setup), setupById(S.oppSetup));
renderAll();
syncUnit();
</script>
</body>
</html>
`;

export default {
  fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/favicon.ico') return new Response(null, { status: 204 });
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      return new Response('Method Not Allowed', { status: 405 });
    }
    return new Response(APP_HTML, {
      headers: {
        'content-type': 'text/html; charset=utf-8',
        'cache-control': 'no-cache'
      }
    });
  }
};
