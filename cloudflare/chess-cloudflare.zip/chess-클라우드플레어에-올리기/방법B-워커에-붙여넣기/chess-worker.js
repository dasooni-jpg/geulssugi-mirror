/*
 * 어린이 체스 교실 — Cloudflare Worker (자동 생성본: build-cloudflare.mjs)
 * ──────────────────────────────────────────────
 * 화면 하나짜리 앱이라 이 워커는 화면(HTML)을 내려 주기만 함.
 * 데이터베이스·비밀키·설정이 필요 없음. 학생 기록은 각 기기에만 저장됨.
 *
 * 올리는 법:
 *  1. Cloudflare 대시보드 → Workers & Pages → Create → Worker 만들기 (이름 예: kids-chess)
 *  2. Edit code 를 눌러 기존 내용을 모두 지우고 이 파일 내용을 그대로 붙여넣기 → Deploy
 *  3. 주소: https://kids-chess.<계정이름>.workers.dev
 */

const APP_HTML = `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🏰 어린이 체스 교실 (Magic Chess Kingdom)</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  :root {
    --navy:#0d1b3e; --navy2:#16265c; --gold:#f5c542; --gold-dark:#c9971e;
    --purple:#a970ff; --ivory:#fdf6e3; --light-sq:#f3dfae; --dark-sq:#b98b4e;
    --danger:#ff6b6b; --ok:#5ad18a;
  }
  body {
    font-family:'Segoe UI','Malgun Gothic','Apple SD Gothic Neo',sans-serif;
    background:radial-gradient(ellipse at 50% -20%, #24408f 0%, var(--navy) 55%, #070f26 100%);
    color:var(--ivory); min-height:100vh; overflow-x:hidden;
  }
  #stars { position:fixed; inset:0; pointer-events:none; z-index:0; }
  .star { position:absolute; background:#fff; border-radius:50%; opacity:.7; animation:twinkle 3s ease-in-out infinite; }
  @keyframes twinkle { 0%,100%{opacity:.15; transform:scale(.8);} 50%{opacity:.9; transform:scale(1.2);} }
  #app { position:relative; z-index:1; max-width:1100px; margin:0 auto; padding:16px; }

  .screen { display:none; animation:fadein .3s ease; }
  .screen.active { display:block; }
  @keyframes fadein { from{opacity:0; transform:translateY(8px);} to{opacity:1; transform:none;} }

  /* ===== 공통 ===== */
  h1.title {
    text-align:center; font-size:clamp(1.6rem,5vw,2.6rem); margin:18px 0 4px;
    color:var(--gold); text-shadow:0 2px 12px rgba(245,197,66,.45);
  }
  .subtitle { text-align:center; color:#c9d4f5; font-size:.95rem; margin-bottom:20px; }
  .btn {
    display:inline-block; border:none; cursor:pointer; font-family:inherit;
    background:linear-gradient(180deg,#ffd968,var(--gold) 45%,var(--gold-dark));
    color:#3a2703; font-weight:800; font-size:1.05rem; padding:13px 22px;
    border-radius:14px; box-shadow:0 4px 0 #8a6510, 0 6px 16px rgba(0,0,0,.35);
    transition:transform .08s, box-shadow .08s;
  }
  .btn:active { transform:translateY(3px); box-shadow:0 1px 0 #8a6510; }
  .btn.secondary { background:linear-gradient(180deg,#3b5bc2,#28418f); color:#fff; box-shadow:0 4px 0 #17285c, 0 6px 16px rgba(0,0,0,.35); }
  .btn.ghost { background:transparent; color:#c9d4f5; box-shadow:none; border:2px solid #40529c; font-weight:600; }
  .btn.danger { background:linear-gradient(180deg,#ff8f8f,#e05252); color:#fff; box-shadow:0 4px 0 #8f2626; }
  .btn:disabled { filter:grayscale(.7) brightness(.7); cursor:not-allowed; }
  input.field {
    font-family:inherit; font-size:1.05rem; padding:12px 14px; border-radius:12px;
    border:2px solid #40529c; background:#0f1d47; color:var(--ivory); outline:none; width:100%;
  }
  input.field:focus { border-color:var(--gold); }
  .card {
    background:linear-gradient(180deg,rgba(37,58,128,.55),rgba(20,33,80,.7));
    border:1px solid rgba(245,197,66,.25); border-radius:18px; padding:20px;
    box-shadow:0 8px 24px rgba(0,0,0,.35);
  }
  .backrow { margin-bottom:14px; }

  /* ===== 메인 메뉴 ===== */
  #mascot-box { display:flex; align-items:center; justify-content:center; gap:14px; margin:10px 0 22px; }
  #mascot {
    width:84px; height:84px; border-radius:50%; flex:0 0 auto; overflow:hidden;
    background:#fff;
    display:flex; align-items:center; justify-content:center;
    border:3px solid var(--gold); box-shadow:0 0 22px rgba(245,197,66,.6);
  }
  #mascot img { width:100%; height:100%; object-fit:cover; }
  #mascot-bubble {
    background:#fff; color:#33406e; border-radius:14px; padding:10px 14px; font-size:.92rem;
    position:relative; max-width:330px; font-weight:600;
  }
  #mascot-bubble::before {
    content:''; position:absolute; left:-8px; top:50%; transform:translateY(-50%);
    border:8px solid transparent; border-right-color:#fff; border-left:0;
  }
  #nick-row { display:flex; justify-content:center; align-items:center; gap:8px; margin-bottom:22px; flex-wrap:wrap; }
  #nick-label { color:#c9d4f5; }
  #nick-name { color:var(--gold); font-weight:800; font-size:1.1rem; }
  #nick-edit-row { display:none; gap:8px; align-items:center; }
  #nick-edit-row input { width:180px; }
  .menu-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(230px,1fr)); gap:14px; max-width:760px; margin:0 auto; }
  .menu-btn {
    border:none; cursor:pointer; font-family:inherit; text-align:left;
    background:linear-gradient(160deg,rgba(52,78,168,.85),rgba(26,42,100,.9));
    border:1px solid rgba(245,197,66,.3); border-radius:18px; padding:18px;
    color:var(--ivory); transition:transform .12s, box-shadow .12s, border-color .12s;
    box-shadow:0 6px 18px rgba(0,0,0,.35);
  }
  .menu-btn:hover { transform:translateY(-3px); border-color:var(--gold); box-shadow:0 10px 26px rgba(0,0,0,.45), 0 0 18px rgba(245,197,66,.25); }
  .menu-btn .mi { font-size:1.9rem; display:block; margin-bottom:6px; }
  .menu-btn .mt { display:block; font-weight:800; font-size:1.12rem; color:var(--gold); }
  .menu-btn .md { display:block; font-size:.85rem; color:#c9d4f5; margin-top:4px; line-height:1.45; }
  .footer-note { text-align:center; color:#7787bd; font-size:.78rem; margin-top:28px; line-height:1.6; }

  /* ===== 난이도/색 선택 ===== */
  .choice-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:12px; margin:14px 0; }
  .choice {
    cursor:pointer; border-radius:16px; padding:16px; border:2px solid #40529c;
    background:rgba(18,31,76,.8); transition:.12s;
  }
  .choice:hover { border-color:#7f95e0; }
  .choice.sel { border-color:var(--gold); background:rgba(72,58,10,.45); box-shadow:0 0 14px rgba(245,197,66,.35); }
  .choice .ci { font-size:1.6rem; }
  .choice .ct { font-weight:800; margin-top:4px; }
  .choice .cd { font-size:.82rem; color:#c9d4f5; margin-top:4px; line-height:1.45; }
  .section-label { color:var(--gold); font-weight:800; margin:18px 0 6px; }

  /* ===== 게임 화면 ===== */
  #game-header { display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; margin-bottom:12px; }
  #game-title { font-weight:800; color:var(--gold); font-size:1.1rem; }
  #game-status {
    text-align:center; font-weight:800; font-size:1.05rem; padding:9px 16px; border-radius:12px;
    background:rgba(20,33,80,.85); border:1px solid rgba(245,197,66,.3); min-width:220px;
  }
  #game-status.check { color:var(--danger); border-color:var(--danger); animation:pulse 1s infinite; }
  #game-status.thinking { color:#9fb4ff; }
  @keyframes pulse { 0%,100%{box-shadow:0 0 0 rgba(255,107,107,0);} 50%{box-shadow:0 0 16px rgba(255,107,107,.6);} }
  #game-layout { display:flex; gap:18px; justify-content:center; align-items:flex-start; flex-wrap:wrap; }
  #board-wrap { position:relative; width:min(92vw,560px); }
  #board {
    display:grid; grid-template-columns:repeat(8,1fr); width:100%; aspect-ratio:1;
    border:6px solid var(--gold-dark); outline:3px solid #6d5312; border-radius:8px;
    box-shadow:0 0 0 4px rgba(245,197,66,.35), 0 14px 40px rgba(0,0,0,.55);
    overflow:hidden; user-select:none;
  }
  .sq { position:relative; display:flex; align-items:center; justify-content:center; cursor:pointer; }
  .sq.light { background:var(--light-sq); }
  .sq.dark { background:var(--dark-sq); }
  .sq .pc { font-size:clamp(26px,6.2vw,44px); line-height:1; z-index:2; pointer-events:none; transition:transform .1s; }
  .pc.w { color:#fffdf5; text-shadow:0 0 3px #6b5211, 0 2px 3px rgba(0,0,0,.55); }
  .pc.b { color:#2b2035; text-shadow:0 0 3px rgba(255,255,255,.35), 0 2px 3px rgba(0,0,0,.4); }
  .sq.sel { background:#ffe08a !important; box-shadow:inset 0 0 0 3px var(--gold-dark); }
  .sq.lastmv { box-shadow:inset 0 0 0 3px rgba(245,197,66,.85); }
  .sq.dot::after {
    content:''; position:absolute; width:26%; height:26%; border-radius:50%;
    background:rgba(169,112,255,.85); box-shadow:0 0 8px rgba(169,112,255,.8); z-index:1;
  }
  .sq.dot.cap::after { width:86%; height:86%; background:transparent; border:4px solid rgba(169,112,255,.85); }
  .sq.incheck { animation:checkflash 1s infinite; }
  @keyframes checkflash { 0%,100%{background:inherit;} 50%{background:#ff9d9d;} }
  .sq .coord { position:absolute; font-size:.55rem; font-weight:700; opacity:.65; z-index:1; }
  .coord.file { right:3px; bottom:2px; } .coord.rank { left:3px; top:2px; }
  .sq.light .coord { color:#8a6229; } .sq.dark .coord { color:#f3dfae; }
  #arrow-svg { position:absolute; inset:6px; width:calc(100% - 12px); height:calc(100% - 12px); pointer-events:none; z-index:3; }

  #side-panel { width:250px; display:flex; flex-direction:column; gap:12px; }
  .pl-card { background:rgba(20,33,80,.85); border:1px solid rgba(245,197,66,.25); border-radius:14px; padding:12px 14px; }
  .pl-card.turn { border-color:var(--gold); box-shadow:0 0 14px rgba(245,197,66,.3); }
  .pl-name { font-weight:800; }
  .pl-color { font-size:.78rem; color:#c9d4f5; }
  .cap-row { min-height:26px; font-size:1.15rem; letter-spacing:2px; margin-top:4px; }
  #game-actions { display:flex; gap:8px; flex-wrap:wrap; }
  #game-actions .btn { flex:1; font-size:.92rem; padding:11px 8px; text-align:center; }
  #online-info { font-size:.82rem; color:#9fb4ff; line-height:1.5; }
  @media (max-width:900px) { #side-panel { width:min(92vw,560px); } }

  /* ===== 모달 ===== */
  .modal-bg {
    display:none; position:fixed; inset:0; background:rgba(5,9,25,.75); z-index:50;
    align-items:center; justify-content:center; padding:16px;
  }
  .modal-bg.open { display:flex; }
  .modal {
    background:linear-gradient(180deg,#233a85,#141f4e); border:2px solid var(--gold);
    border-radius:20px; padding:28px 26px; max-width:420px; width:100%; text-align:center;
    box-shadow:0 0 40px rgba(245,197,66,.35); animation:pop .25s ease;
  }
  @keyframes pop { from{transform:scale(.85); opacity:0;} to{transform:scale(1); opacity:1;} }
  .modal h2 { color:var(--gold); margin-bottom:10px; font-size:1.5rem; }
  .modal p { color:#dbe3ff; margin-bottom:18px; line-height:1.6; }
  .modal .btnrow { display:flex; gap:10px; justify-content:center; flex-wrap:wrap; }
  #promo-choices { display:flex; gap:10px; justify-content:center; }
  .promo-pc {
    font-size:2.6rem; width:70px; height:70px; border-radius:14px; cursor:pointer;
    background:rgba(255,255,255,.08); border:2px solid #40529c;
    display:flex; align-items:center; justify-content:center; transition:.12s;
  }
  .promo-pc:hover { border-color:var(--gold); background:rgba(245,197,66,.15); transform:scale(1.08); }
  #badge-icon { font-size:4rem; animation:bounce 1s infinite; }
  @keyframes bounce { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-10px);} }

  /* ===== 업적 ===== */
  .badge-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr)); gap:12px; margin-top:14px; }
  .badge-card { border-radius:16px; padding:16px 14px; text-align:center; border:1px solid rgba(245,197,66,.35);
    background:linear-gradient(160deg,rgba(72,58,10,.5),rgba(30,45,105,.7)); }
  .badge-card.locked { filter:grayscale(1) brightness(.6); border-color:#3a4a86; }
  .badge-card .bi { font-size:2.2rem; }
  .badge-card .bn { font-weight:800; color:var(--gold); margin-top:6px; }
  .badge-card.locked .bn { color:#aab4d8; }
  .badge-card .bc { font-size:.78rem; color:#c9d4f5; margin-top:4px; line-height:1.4; }
  #stats-summary { display:flex; gap:16px; flex-wrap:wrap; justify-content:center; margin-top:16px; color:#c9d4f5; font-size:.9rem; }
  #stats-summary b { color:var(--gold); }

  /* ===== 퍼즐 ===== */
  .puzzle-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:12px; margin-top:14px; }
  .puzzle-card { cursor:pointer; border-radius:16px; padding:16px; border:2px solid #40529c; background:rgba(18,31,76,.8); transition:.12s; }
  .puzzle-card:hover { border-color:var(--gold); transform:translateY(-2px); }
  .puzzle-card .pt { font-weight:800; color:var(--gold); }
  .puzzle-card .pd { font-size:.82rem; color:#c9d4f5; margin-top:4px; }
  .puzzle-card .solved { color:var(--ok); font-weight:800; font-size:.85rem; margin-top:6px; }

  /* ===== 온라인 로비 ===== */
  #lobby-box { max-width:480px; margin:0 auto; }
  #room-code-display {
    font-size:2.6rem; letter-spacing:10px; font-weight:900; color:var(--gold);
    text-align:center; text-shadow:0 0 18px rgba(245,197,66,.5); margin:10px 0;
  }
  #lobby-wait, #lobby-join { display:none; }
  .spinner {
    width:26px; height:26px; border-radius:50%; border:4px solid #40529c; border-top-color:var(--gold);
    animation:spin 1s linear infinite; margin:10px auto;
  }
  @keyframes spin { to{transform:rotate(360deg);} }

  #toast {
    position:fixed; left:50%; bottom:30px; transform:translateX(-50%) translateY(80px);
    background:#1c2c68; color:#fff; border:1px solid var(--gold); border-radius:12px;
    padding:12px 20px; font-weight:700; z-index:99; opacity:0; transition:.25s; pointer-events:none;
    max-width:90vw; text-align:center;
  }
  #toast.show { opacity:1; transform:translateX(-50%) translateY(0); }
</style>
</head>
<body>
<div id="stars"></div>
<div id="app">

  <!-- ===== 메인 메뉴 ===== -->
  <section id="screen-menu" class="screen active">
    <h1 class="title">🏰 어린이 체스 교실</h1>
    <div class="subtitle">Magic Chess Kingdom · 친구와 함께, AI와 대결, 퍼즐 풀이</div>
    <div id="mascot-box">
      <div id="mascot"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYoAAAGwCAYAAAC3nyLbAAABY2lDQ1BrQ0dDb2xvclNwYWNlRGlzcGxheVAzAAAokX2QsUvDUBDGv1aloHUQHRwcMolDlJIKuji0FURxCFXB6pS+pqmQxkeSIgU3/4GC/4EKzm4Whzo6OAiik+jm5KTgouV5L4mkInqP435877vjOCA5bnBu9wOoO75bXMorm6UtJfWMBL0gDObxnK6vSv6uP+P9PvTeTstZv///jcGK6TGqn5QZxl0fSKjE+p7PJe8Tj7m0FHFLshXyieRyyOeBZ71YIL4mVljNqBC/EKvlHt3q4brdYNEOcvu06WysyTmUE1jEDjxw2DDQhAId2T/8s4G/gF1yN+FSn4UafOrJkSInmMTLcMAwA5VYQ4ZSk3eO7ncX3U+NtYMnYKEjhLiItZUOcDZHJ2vH2tQ8MDIEXLW54RqB1EeZrFaB11NguASM3lDPtlfNauH26Tww8CjE2ySQOgS6LSE+joToHlPzA3DpfAEDp2ITpJYOWwAAAARjSUNQDA0AAW4D4+8AAACgZVhJZk1NACoAAAAIAAYBBgADAAAAAQACAAABDQACAAAAGwAAAFYBGgAFAAAAAQAAAHIBGwAFAAAAAQAAAHoBKAADAAAAAQACAACHaQAEAAAAAQAAAIIAAAAA7KCc66qpIOyXhuuKlCDslYTtirjsm4ztgawAAAAAAIQAAAABAAAAhAAAAAEAAqACAAQAAAABAAABiqADAAQAAAABAAABsAAAAAAJJITAAAAACXBIWXMAABRNAAAUTQGUyo0vAAAEDWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNi4wLjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICAgICAgICAgICB4bWxuczpJcHRjNHhtcEV4dD0iaHR0cDovL2lwdGMub3JnL3N0ZC9JcHRjNHhtcEV4dC8yMDA4LTAyLTI5LyI+CiAgICAgICAgIDx0aWZmOkRvY3VtZW50TmFtZT7soJzrqqkg7JeG64qUIOyVhO2KuOybjO2BrDwvdGlmZjpEb2N1bWVudE5hbWU+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOkNvbXByZXNzaW9uPjU8L3RpZmY6Q29tcHJlc3Npb24+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjEzMjwvdGlmZjpYUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6UGhvdG9tZXRyaWNJbnRlcnByZXRhdGlvbj4yPC90aWZmOlBob3RvbWV0cmljSW50ZXJwcmV0YXRpb24+CiAgICAgICAgIDx0aWZmOllSZXNvbHV0aW9uPjEzMjwvdGlmZjpZUmVzb2x1dGlvbj4KICAgICAgICAgPGRjOnRpdGxlPgogICAgICAgICAgICA8cmRmOkFsdD4KICAgICAgICAgICAgICAgPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij7soJzrqqkg7JeG64qUIOyVhO2KuOybjO2BrDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpBbHQ+CiAgICAgICAgIDwvZGM6dGl0bGU+CiAgICAgICAgIDxJcHRjNHhtcEV4dDpBcnR3b3JrVGl0bGU+7KCc66qpIOyXhuuKlCDslYTtirjsm4ztgaw8L0lwdGM0eG1wRXh0OkFydHdvcmtUaXRsZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cn5TvssAAEAASURBVHgB7L0JwCVXVS5a5597njsJGUgCISEkjFEThAAqJCi5eJ0R7nNABRV8KI4gDhfM9Smol0EExOdTUXioj0kMswSQKYYhCQmQeerudHd6/Pufz3nft+usU7t27RpPneE/Z1Xy957WXmvtb+9aq/ZQdYJAL0VAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUASGHoHG0GuoCioCikBRBFoOod7fDiCarIaADqRquGktRWBQCLjOoIgeep8XQUlpUhHQAZQKzdgW5Bkie8yQ1k6PLWh9aHhevxRRQfuqCEpKk0BAB04CkrHO6MYY6Vjq3dDppl/StNL+SkNG8xMI6GBJQDKWGXUaIh1T9Q2hOvvFp5X2lQ8VzUsgoAMlAclYZfTKEOm4qj6MetUnPo20n3yoaF4CAR0oCUjGJqPXBknHVvmhVLlPDl33wo603Ve/i9iX4aV91UFPIz4EdID4UBn9vDJGpBs0dHwVR69Un9iOIU8EHEceCcu1r4qgNKY0OjjGr+NzDZIYIRqYtHgJ2HSMFQMrt1+EjfSJpIuGBWYa2ldFwRwzOh0Y49XhucaojBHSJ9VaBk9un9hSyvSPXS+KN4LdV/9DlEzG1CYkMRn7HB0U4zUEUo1StwaogNPQsZYca6n9IaTd9ovwiYeZzkL7KQ6WpoDAhKIwNgikGqU6jFEBHqnyx6YHSja0AKYlOQp5ZldkFgoHDccLAXUU49Xfidb2zhglRGlGCQR63S+95l+iqUq6DhBQR7EOOqkGFb1PiXUbi7r51dBumwUxqPJn86gz7u0TChhyHOvEQHmtEwTUUayTjqpbzV4Zo17xrdh+2zFUZJFwLlX5FKo3ZPgV0lmJRh8BdRSj38epT669anqGseuVLrZDsOO9aKLNX+K9kKM8FYGhQWBqaDRRRcYFARrXsidrWGeYr7Jt8rYnw8EOc9tVtzFAQGcUo93J690gUX9vG4aw20TX9aKv7oUM4SAaVpXUUQxrz/RIr7JPrbsu+4WAf2Uvyikry5IhRtfK6m30a9dOBvzrQmdbwSz9vY6kDrnsp/bb17YuGlcEukZAl566hnBoGSQMUlljFDmIhnEWh294e68am9C1TkF0AGUuG6cCLxJmsZZ2lV1qy+LpLdt12UtMfuvQ9ZDZCnrYV175mjnaCKijGO3+rdw620nI6g/zyhigHCMrRrSyjm7Fsg7Bre9Li9N44MZ3B0941ZqPpEhe7W21hYZ9FRdRtq9sfhpXBFwE1FG4iIxhWpyCOAFJ+6CoyQDFrZpPUMG8XjgHVzSdBC9XVheOIyZCnFEss2Ai3lcycakN3oJaKNmoI6COYjR7uJSloIOgwYkbHQEmyaomZyECCoWuMRXjXahyQaIzn/wTBSlDMttx1OU0yigQ9RcdhPSThGU4JWjJRLxOolAzxg8BdRTj1+cpLbaNTQpJn7JtA9wnkUGakyjqkETnsg7DdYBF2xs5CbtG3EkMwqHb2mh8dBDQU0+j05ddtiRuZPKY+Q1VXq3schpbMbguZVGD7dYb7bQ89Jfru9HGRFvXCwTUUfQC1SHkWfXJNa0psp+RVp6zkZ2oluYgbML14CyynJ3dlm7ioZNuOwnjIxgXp9ENZ62rCPgR0KUnPy5jlyv7FL1ueBGHkKZD2vJQGn3R/F7wZTtdvmWdZ7b+9BBwDsY/tOPZFcqUqtcpg9YY0OqMYgw6uRdNjD3VegTYMxh5yu7GSXhE9Dyr7hmMjYko373zEJuuy0+CqYb1I6COon5Mx4hjtnGiYfQZx2ECyH3q77VuLh5uupx84l/7bKKcCko9Fgjo0tNYdLM2st8IZDmg7pyDryV+h523j+TjpHmKgA8BnVH4UBnBvO6XOEYQlIwm1b3slCGqYhGXnGTZqSKL9Gp+z5NOryUjjoDOKEa8g6V59T/FCuf1G2Y99Q9rq6K9IbXlw9pHo6iXOopR7FVtUy4CvXQSveAddxA+J8HZhS8/FwofQc+mKj5hmjf8COjS0/D30VBqWMf6dxmz5hpfNz2UINWkVOQkshgKmj1dkspSQMtGGAF1FCPcuXbTiuxRFDX+Rels+b54N4+tvdxD6IZ3UQeG/ijRfJLSEYgz8KEZ5h2+4W34wi//evZJ+HThWjKyCKijGM2u9RqhVr6dyUSDxmcYDJBtyKs0qagxzwTDU1iWb1FnQcPfiyvl4cE7dnohX3muHwR0j2L99FXXmu557rtKv9cwDI4hq+Hr1arhcEEpH8d+CJegiIbMMCJkhr2fIk01th4R0BnFeuy1HuocGpzQ/I6j8bFnK2VgLjubKMNbaNkfYZ/EfUyVfkqZTYgoDRWBGALqKGJwjH6imIEYrp/SjJvF4eujfjgJu9W2Y7DjNk1WvNgYyOKgZeOGgC49jW6PJ9cn1mlb61xeKmPU6aDyZJfhVyf8VRxEnfKV13ghoDOK8epv01r3idJN122Ehn1GIEPAXnYaZich+vYgzPOLPRCpLNcDAjqjWA+9VF3H1FmF6xyY7tXb291an0E8tRfRmY5lELpVHw5B4PZ7N7y07vggoDOK8enrsW9p3Ua9bn4D7qAivnHAKqr4QSGgjmJQyPdPrhqANtb20pILf1aZS8v0enQSOpvw9aTmFUFAHUURlJSmKwS6Mard1HWVrpOXy3vY0+okhr2Hhls/3aMY7v6pSzvOKjL3lHu1P1FXA4RP2Sd/qVdnuJ4cTkEHobPOOgfICPLSGcUIdmpKk1KNwbA6iWE0yMOok7+/U7vbT665ikAGAuooMsAZsaLMGUWv21rWwJal77X+5D+MOqW3u3B3q0dJB1FL2gioo9Ch0DcEBmlou5HNut3U7xvA5QWpkyiP2VjWUEcxlt0eNXoYl53qNspF+BWhiVBbP7Gc/i087Vg/LVZNe4GAPlH0AtXh4+k1CDlGZPhaAY2qbGZXcQKUU6XeUILWVipjY1vtwDB33BDopjOKIegEVaF3CFQ19lXr9a4l3XNejw8G3bdaOdSBgDqKOlAcbh4jM5sYbphVO0VgdBFQRzG6fTu2LfN6xrFFo1DDFbJCMI0vkTqK0e57rwEYlSUIb+NGuz+7bl1G3yucXaM7ugzUUYxu345ky+y9g7Qd2LT8kQREG6UI9AEBdRR9AHlAIrxPiBlPlANSs7xY21mUr601MsaAd8woYoqAOgodAyOFgFq6kepObcyQIKCOYkg6omY1vPYy40myZvGDY2cvO+nMI70fxmEspLdeS8oioI6iLGLDT+91Er1T2zbNvZNSlrM6ibKIdeg5fvo8hjqyNTKkCKijGNKOqVut3j1BDsamZDmCrLK6cVV+isA4IDCcj4PjgHxv2ui12r1zEr1pRBmu7ic91EmUQS/3N7TVPpSDc2SpdSCMVtd26Sg4HLwsRgslbU0MAf0GVAwOTXgQ0KUnDyjjm6VOos6+33XZLwT8W8eXDoh13Hl1qq4/hVonmoPl1fVNrfOJ+jrQdhB23JZw+Ia320mNKwJDi4AuPQ1t15RWzOsoRnl/ojRCtVaIu9Vdl70E3L1dUEBqxGuQzkOXoAp01ZiS6IxiTDtem90dArsu+3mHgTiJyOg7BBlJqRuYpapBOosMJbVojBHQGcXodH5kbZw29XpWwaUVGrdwiSUylKNk8KLlo6h9IcySllsptRucXklLRvwO3/C2NKKe5GNGIcJd/tI4N1/TY4KADoDR6Wivheqlk4iMp4Bo2xkZWlSrAUfSX6MnGtUVRm1NayMl2WW+tK2NSyv0DKUr+4+bLj/ZfaRxQUCXngQJDWtAQAwcWaXFaxDTRxaRg6BQcX6igN1G5rlpofOFPlo3r6VLUT7oNK/vCLgjv+8KqMBaEHAtjGFa92wibjSr6N3/J+QqWrJO/ua0zAgkZC2Jy23l6xahsekZT7nIos2uX0t5KbMKaVSKopo9ygjoexSj0bs9v4njToLi5I8Aing3tMFlmc9w2jTDEQ/balnohFppbZH2MZQ4KwsujNv5jNtlTjHJreJ4H7Cwr5eteF8Fq7DBI6COYvB90DMNUp4MS8mjcUoaKNoM+SM7sSFuyDKxdGFZ+KTO/OG8orZSb2kPdZV2SCj6C43kuyHpSOPLZ55dZpEhGtUxiUH/Iw0YtB4qfwAI6B7FAEBfDyLTDWae9mL8hE4MaZSmsxi2ze2ovZGeYcy2j3bb7DgppZ1uyDKbVsrtOowP1WUrPFSKqTKDQUBnFIPBvW6ptvXp8K66RxEaTdoKXi5ryQ9Lk/+69DaF1M2isel7H2dbk07Clktd7T+WSTvcONO+K6+9drnNm/l2OnzPwiehD3m2kn0QpyKGCQF1FMPUG9V1iVuTinx4jj5cGiI7sQuM2+zT8vOECo8wHIYlqLiDEP2y2iE0NgYSz6pnlwmPtDyXn6R99Wwe9cXxgCFC62OqnNY1Auoo1nX31ac8jWbr0KdhIFwbwbSdJwZL8iWdp4vQC1149FNSgw/dNrJdbttII3lue+wW2HWFXsptOVl5Uiahr56UaagI9BYBdRS9xXddcI8/WVPlMkapDK0DRxdVHU6lk8k2CwsadlFMQilj6Muzy4Umj851IC6PtHTVemn8SuXnNaoUsxxiynL/7Cr91MWWO5ZxdRRj2e1Ro8svAdn3pxgtCSO+yZjQWPUlK0k8wBzRT0JXFSotiksoNG6a+Wl8mC/0dihx4SlhWr6Ur8uQIAhAdihxt1FCL+Vu2qXXdE0IqKOoCcgBs5Ebp4IaWVXzjJPUlTBLPGlcfo2cjeQsftXLon2YPB62vhJnO6QtEgofpnkJrRt300LPfF5Mu3nkxT/JlxBZ/b/shlWVLo20GyJxCavw7qZuFXljVUcdxVh1d9nG1nHv2bbF5Remy89qyrbDpadcVxehEX1t4+zGSSv1JYQ53/2MNpMoL6IjD5tPm9QEpJdyyWeaF8tsfgM9+WQ0KvmPNEDCktVLkceBKlVVibMQ0PcostAZ8bLQQMu9ZRsmabib56aFLisk/7R6zO+H/Yj0S9+bII3oI6GdZ8ej8sg5sBwc4CxwKCBMePkZKvwjuLdJvelIjlCtk9BtXD/VdmUTRL26REBnFF0COCTVS98MocG07ynG7bS0zM4TGlecm5a6DFkm9ex8xm3ebtkg0qKPhNk6uE4iSS18JBQKNy35bkg6H7a+PLfuwNJFG9cvBYdNn361u1Y5OqOoFc6BMSt1M6Q/VYsBKsJOHADbTHo77eKQVRbSUqdef/Quvd2uvnba17aWtcxk0/YqXqZfeqVDJt8iAyaTQVahvDjq9l++o+5wFf0EyE6BRoohoI6iGE5jRCX3FJsscdfQS74Niy/P5mHTunGXv1teNR3xjS+z+fiJDWE7onohpbStqoNw+fnku3lSR2SzXPJc2r6kKdy+bMXs/FJxOgH7m2TiFHxMoh/HCktliU8dhg+tevPczq+Xu3LrFwLemzbtpos2j73VMnR2h0vZ+hms20W9mlXEn0Zdg2ul2aROMyU/zGjsvjK3Aa1D17dpqmJjy3R5iGKhkr36XpZtuK0G28Kt7GrRtLGZx439+PW3f08q2RNetZZa5hRIe5xsTfoQ0BmFD5WRz7MNkBimIo0ODVQ00/DVcfm5aV+dKI+GoFfOIpJit5+5VjpmPiS/2Eyieychuvgwc/NEt6hVdcXcp/xu+Qq/Ks7hgRvfHRPvpmOFSHzt2smgoLMQAGM97vLTdIiAOooxGwnJJRi5X4oC0aZn0HCNF3m4/Ny0LcdXPzz+2XtnkaVHXK8iSxvhMoi0NV7fluSNGyztEh8fySMd+ff9shUoJNx2DHY8r3KeM8irT2chVwGnkUBf6moYIaCOIsJipGKHrnsR2uO7t+0826ClxVNg8TqJFFpvti0vSUCH1qullaQ0GxOWRuk8JyHr5CFPMeBR/aQsT45USxTZfCy8WshPrZNgUjojZempEJ8yDsFm2K1zsHnZcXEaOQ6DQPcQUVuj9RlXR7E++y1X691X/0OQf9O2DZG5Tdpxc79I3BVjGSvLmLpUxdIiw+Zp15RyO69aPL4/QR5pMsvxjzsJ1i2qcxH5QiOhpRuzcPXXmYYy0/7NH2vxmlUcA9FtNz3OrECqwJJUN+wLaLC+SdRRrO/+o/ZFrVN6SwvffVmihEkWjU8Fl5583DxfvTJ5Ls8s/nFaOgPfrCLpJOL1sp0R5WfR22U+Wml7VjuEpvdhGSdRxUFIC4hKN1eB2YWA3Y2YkayrjmIkuzUoMJtIa3hV41O1nm0UqVNVPmntKcPT1SVUJ+kUfLJsvT18fFW8eb66Pt4hXX82/5OKlnEOUrsbJyE86ghzZhcCNgHWq42Avpk90kPBN9Z9eXWDUEaG3JdJHZJLRkmavJxyPKiLo7uTjMtLK0xvU1if9Xw0afm2VKknoV3Wn3hZJ0EHMSxOoj8IjZ4UdRSj16dWi5LGJNwg9hk45vnyLXaFo0m5hasOlLBs+6u201ePeb58GxDRT0K7bDjjw+ogZBkqA7W8zsioOnpF6ihGr08LtMh3DxQxVAVYGxIasqrGzK7Xj8+Q2/KkfZInIfPtuND1O5R+YzgM+mS3f1idhGhdwFkI6diH6ihGegikGRNfvi+vKjjdOB0xhvXok/4+hvAXeWxrW28ePzWXhEzYcakbUiX/zStP1iifY+tTvnYva6ynpaYcZ0GQhxfoXnaiw1sdhQPIKCSjNeS0Mc5815il0VZBxOVdhUekT/TJkSp8fHVy9MspTrcdUjHS3Se9WJ7w8lFLmYQ+miJ5/vrR+PHzSHvPYj05CLtldBYFHIZdZezi6ijWd5fnWCS/IQibnFO1JC48Qip/SUOapYcIsmkkXq+OIimpX1QSxkS+m+9L27SuvmGZ4GKHkRy7vs3f5eUry6Kx6dPi6fXznEUax/Wcr84ivff0eGw6NiNQkjQEyVNANFRJuqKNp/FzLzsvPFpahL9NY8fJ3U27EqukbZ4uBnZZHm/SuvXDOlkfESRGxY7duvJFloRueX/Tw74PUTMa0tk1sx1+djqjGP4+StOwjDUzPJJOgtml2XT0sR1CJ9OJxGlo3NKurLK0OsXyk/sUIkvCYnziVHbdOIZsc7zd8ZrVU5QpshjaOlTn6qtZZLlvFJ1EzqyCUEkH+GAb2Tx1FCPWtcWWDHpnYHxw5htN2wDaHERPCe0yO55XbtMyLve6a2yL8Emn6Z2DaOvf2WSnDvwL2+F/AGjXKRGQj/yRd9aMJ22fooS4oSUt4CyGVvdeKaZLT71Ctrd8xdLFpGQ5iciYRAYmVrlkIt/4+xh61QZhXn5aucjILo/aLvR2aNe146TxYSU0Eoa8quHh42/rZusA2oYt046Hx4iTM6eIVzYGEZ0bCz+dXuwz627dfqWJBJGs8xJnkfIxwV6IrFP92nmpo6gd0p4ztC1EIWGRkRDDJLdVaVaF5PmIaEiznlCTdUTXsIRtyDKEyfp2TpxXWOLLs+swXgyfok6C7RdaMcB+Z0TZop/PJrl6hemon6U+Q7ncOpKfF2bXYyk1HeRVVL7oeuaTf8K8KS5hlu50GOosBt/HWX2kZUkEUu9aGiGfIU0aj1QWSWkpOWLsUopzs0OHIYbQRy5lEkY0vjZGpfFYvO3xsvSUK1PSEiZr5uEROch0HnGuNp0dj1OZlFg/T1H89vb1u83bjieZpbVRnryTNYYjh86gyiX7L6yfscxG0Mbi0hnFCHSzGKJ0w1hkPAuNWB6fYakLLNso2XHhL7Kr6xLHwidDZOWFokucLs1wxqkwJ4EDp8HmCajoF/CoDy+bN/I6vzNht9umCWvF/hVWsUxJ5NSNyZc66y+s6gyyWmrz5JJuirOQjspiNRJl6ijWTzfm3fUZLbGr0rLYaalm59lxKa8ztPnbcVuG6BkvjzsA0gudXdeNk0cROtYDrZDH2ER6FHUSrG7TynFZcewhe+rFC/w7PwYlukoYUkRtSMsnncVPqsXaLnUlFKKofWGOXS48hbZ3oRd6iLMNd++kK+c0BPo3AtI00PyiCLh3sqkXNzo+VnYX2yzEELihj0eUZxu+KLdaTJ62445L9KnGMzKmrG/x6lggKy9VRDpNne2neINBR7dUhdoF6XqFBFIuYR6/rHLy4CXK+Te0e7n0NGzOIWVWIUCFcI3ovzqjWB8da1v4ChpLdduASB7Z2fnZ7GnY6jWWth6U7aZtfeSezKKRMrtNiHdODEm5zdeN+2nqbXcokzwjZ2/r7OpUJC16S5hXR/AUOqeeWQrrVifhnR8Om2PI13h8KPQ9ilHva3P2XgwCDYHEpeGOcZDsvoSuLiKU+XaZHRcaJ/Q2Q+p5Cx0G2cleOIm4ROqap6dbLu2Lc4pSeeXkJ39RLROL7Zc4ZT1IqpPoAag1stQZRY1g9ptV9CSaIdnYCtvA2HExTr68DJ41FIW623KFqegkaYZCJyHcCJ7Es65C2HQY+GR2ChExINoZPYhHbctmLroUpRduafXcfKbBO7ZfQh7hC3h5uIu0MQrZEQLiyDZbZxSj1LUcsvJXqF0kdi9fXj/vA1d+UnYRY5VN4/J0ZRbBxKWpli7m0ERfhtRV9GUoZbZ8yZNyu56UCb3Nj3k2bzst9PWHOpuoH9O6OeqMom5E6+cnd24G57Yh6NgAMQxpVdzyrHSHKZiFdDRu2YY4TW5WvquD0NrND4+ZSkn10OaZx6Vcm/MMv+CWR0etWp+/Ml05G652vHHF9W16u30Slwp22khxZAidnS117LxknFSsXeRS51AEpeGhKdqvw6Px+GnivUsjQyM3toQEyI6XAUyGA0R27no/LzF4ZbgLbai7j6/kSSg1orCM3AijqH4US5cR0TBGOl7ebgiLUv8tKiPOoPWFtoMoKxLiGpeLs7B5FtHDpXHTIT8f/mVOPq13BzGuJ590RmHfT+skHjeAZa2Jr5FiFCxenTVqK8+qSh18RsMiyYn6+EqehDksKhWzrbyKyhC6rHqCX8g5+pd108osqqyZA8nyWEg5xJlZCNKNyz+DiqJ7JCuKSSXJcWndtNBVD9e7k6je8vVfU/cohrsPC9ytvOF5FSBtPx3TmGQua3T4CW9m2HFDYB3rDNNF/o07OdZI8s3ik6yfRe0rI05FsHLr2vWos623j5+U+8pC3sX6IUddihERlsjW558eCjH/CoGV1alk5/UuPuJOwgdw78AcAGedUQwA9HpFYoxymIqRMMyT49a3nNFxFpaxida5yUgYM7R5WhWMvG7+sfm6fKrL6d6huLrY6Sydhc6mSWmHZLuhsMgLpZ7Q2SKRxz73L0VJhd6Ho+YgMj7n0XswByhBZxQDBL+6aFoIXu1QkmFm4t+OQ3AMSYfQyqdxkSfd0LlYhSLPchplDHIqrRHha4RPNgyg+X5SR/ucCPn6eOdUSy2uh5fB1m2enfbJd0WT3s1jWvJQ3ul7H78e542ak+gxXEPNXobUUCs55sp5zUdoLNl93mLzNJkossntuA1wSn7jCq558xLr5Jfr7lvE9bSZ23HyddPMsy+33H8CKulE3Ho2z17H02XXasBtMRKXEE0MZ4mSwZCXv//C7hXakNL+1+1fKXM3tEfZSYzjhrYuPclI94cpd1Pnmc1fq77cNPltCSxO3viJp1VbH7EBaZyFpVPe+sLT28sYwsDHFOan87Tvo7OZ2nHyctM2f1+5/AKbT067LlmyuOAlRjBqg10xQ45NlnB4yXq1OgnK9kHn5sXetKZOSb1MMzqHGEyq0j+j7CQyACk52jI4DWGRLj2ld4p7q9mUWWU2XU/iSUMWqiPLRl7DQU1IZmsu9sLVkjQss69OvU7EKvXlWcUxoXa+HXcF2mV23FU6Q3YBlnQO8idSxGFIOtWoRgRWzNaHcTuNFE84+fTy5Vlcc6NS3xbXzovLZGZSr4i/zSDKFaXdmYNNwfiYOgkXhpFLq6NIdmnWXWRTp91RNk1f42IrYkK9maBw7YVNlxJPPgmT0Ca2JdvwCI2ENp3EhZ5LSq7xtutldY9NR75MC1+RE4VJhxCVxWPpPOJ0BVM2O1HZzivIJkbmq+/LS+AhCsS4IeHPT/m1N1NZnYSL4eik1VHE+9J7a8VJYqmy9LHKVRORgRND2Ag3oH3aMI9k7n3v0tppxiUtYVvZcIO7neg8mbrMpZyhXWYzs/MjOvnNBuEQttWu1ymRSDskP9DFSGOJGH2EYSy79wmqKX+URhVdKJhf5crl4yMQjGylINx8TJJKxOukzSjUSVTpsPVTRx1F2Fe8W+SOKdt7VeuVlePQ8wYW0RK2SeL3dkjmkDj3v8M7JdkWmZxZkLkrVHiwzBUuZRLabZG8vFB4sq61sZ2mBqkSM5U8GT0oFzhEfYqw41kiw6ZmUXjLoiPPWYKcsg6Oki+hV4RmjjgCupldTwfzLurcWvWwzOMiIp0bmFo4WR3N7Hw77qsj4u0y1rHTQmNCYZhKEKOOKyl1HZJ2kgY+uS8TFtozEJkl+GilzC+hP7mdvYKs5mbBl1WPTcgrT++8NgDCIE2JRvD4X/hUELwq4xtU/YEyV8quy17iANLAb8q/LQh/IVHaF+blMlOCYFwdBe8Ijha5ZORIuhO+4Q1vMPFXvvKVnbxBRyJDKDe2pZEnq2NAfK305VnsOnUlz8dfyjINkS3IjncqI4IltJRPg5Qx9K5jKVPX1qbeONuMKwu/NFjCmuX+bYvLlNfhaAu24x0CRNLybZrBx40jMBi7QLfaToI6smx9tGfwiIYajJujsEePHeeoybwG5DC6Gs2JyqVa3IYjwcQDk9x3mVbJFm7HhV9uFwhhoXA4nENcVS4BJZftLBofLFZxZtTtpzavaNmJtYsIEBqXYab0gRZGv6Pe1rkzlLLaELaTdQ/f8PaB6r8ehI/THoXcAb5+SS1zZxLiMDxMUnl4aPuS1ercMCniqHGe1iy3+djxBNvMwgR1mCF1iiiTwmJos9k2aV8PlHRZu2mvSJeIaXsQSLmdR0Zu2su875nhEpOIdXV000InYdjWyNFIvoYuAuPiKPJGjIvLsKS9ertPy521b1drX+00O+DWZdqllbRL28m3BXYyXWonbddxinqcbP3Cr/ZaAvhL+ySsUaTLkmkL9olrzNtzfoFu3Q6VXWAx65QPR4TGPbkPUVa3qK0Rv2weKW9lZ1cagdJxW3qq1GUve9nLTL0Wjgy+5S1vqcSj55WiMR8aCzvdrXDaC/LL5SmGpRBxqlZp+xSpFUoWtH7uFWGNzhHQkgw65AKMhFLgpiUfXcPlJ/7eRC6WUZ1SsTZfI+fQpz1ShEC42iR2/7HcLhP6wYfRDKAb/Xx9FO5jpC1FwUn4Kg0ekD5oICOjD6IGKqKbERUsLi7iJ4QjqGZnZ7MaExFmURUv8+oebWiHjDLXvovLiijllpAwKjGOKPwqqd1UUdNXgZWFVuiEYVp+WMc+1SQ1fOGdO84Lzj9yl6+ok9dxEJ0caPXXf2GloqiLb1Qi7ZMwKknG/DSJvnLJ8tIURBpeLpzIiu9LGCrm+olz8+161jFkYYuQX1TtxxU5iLqk2W2L83SdRdtJkMiDuKkrPRJnNCIpnVEU6EjbSRQg7wtJeLLneshKG7cokqFLEjeeUS1mO7LovLIzKnS+N2TfoBn04C8G211u84FMZ+Fe5/3w892s3LTI9BOKvhL6qcJcP03urEKq2TC5YoTGyg8/3OgpMDS+fBkUwsQnMKpX1GkLtzrD7peZRBtpo4SSHw8jpxTStQ69BEC0+C5OdsU4m5FJjcseReUOy9i8rsyzZEUOzJRLbmKQkMpHSRLmCyk5SR7jvsumtXm24+Gvp6GiobMJfMysvA6pLcAqT0Q7FYzDoAFPM+Jps4m7/uX9Ca6SkTabkPLsMNItm85Xiidz8wt0KMtiI/0kocXKnTWEaRfXLOZk5tLbaY9QS37/o7ZuVaS7WBThxzqCQxhi/BWpWEXBoa4zDo7C27F0AEWdwJvf/OZYJ+bU88qLMSifcEe5wwFPOvytZJ9kGeusYZfbceEmUiR06yAdM0iGzsdIGNoh6WzGdtymqx5PcxY+jsWcRIaOsf0Nl85N+zRAn2G/gg4j9uNCblWBtx1y1iBOwtQnD/z5L6nsL41yRShDiUeljBWZ0cVr1JeKnu674Wlj4bbRTYscqROFg8RBtBpEOPZLT2L03WOw7AwpG0THFJHJQds6RCPRHsgc7zKmycCOM+1eNr0dt+tZ+TGD5vJKTVsMUml8BVJPQh9NMo/OwrcEJZR5DiI+YxEgPDowq3MJnWS4acmX0C4P42nGXr6tVQ17kZcVJnUJnQXz7bIkj37sTdTjJGzdfW3y5dl1NB4b7iMMh3ckuI7AdhZuGbHh6SeZXdi0Htx6gau3DaFhE0OGEL8bYQh91EImCrtp5jOPgVka8TEJy7v7VwRLWJ5b0Sc7cRpFZxtxR5GmVxW97Tp23JWRVebS9iKdlJ+Gda8dRXUnkWxDMaTy66VhAf6sPLLXSDfO6jWvxfM5A6tOZnRYHAWVjBs3fkn26Zm6myEtiDj3RtqTbfSUabN2KttF3rhNL3EJ3Qpp+RFdxk0bEZWIxXGUivl6COX6D9lWXjI40OuYtaZdvXQU1ZxE7/sqAw8BLw2udZ0/9ktPZXtP3qlgvRxnUZZ1l/Ryk4Rr37zXzbKFZKeFkU1or3W7hFRL8rpU0Rgg4SWCJXR5p+W7dPWk/U6CvLP0YFt4ZdGEFOvjX7sd/qOw0o7hcxLULK5/PC2aFwlljEpYpM5o06ijqNi/dBgZjoIjVqxIRQmJaqmjlk854V4F67TJ8N5H+uwgwbtkhqhi35h5LOw6ErfrFM2L6tC4ZzzhRYQ5saST8OniYyLtL0rv4+HmkZd9iQw7rxdxtw39khtvS/czCWlHN/p3UzfenlFJuaNyVNrla0fp3vctTdkzCu5XZDiLXmCb2Ya4wZMbxlYjszowE1qhEx4Cp6QllPy00EcneRKm1S2eX8VZxLFyZVXRrUodkdtNXeFRJaRcXtLfYSoPz/pnEw18juPnQ+GV/+0PhinYCJCVtR/2iuNwPLZyH2Q4gSI843dfkRr5NJkDMhzEQiLi3VDKKcyOi3ChZ9qO22k3X+q6IelcGVJXQrfc5ZGXDj9NzhkVjX+2Awh5ZdIYtXx623r4dJb2kM5XnlaftHZdm66XcZFbTnb9TiLowkm4OEtawl7iN168x8lR1Dp65PSTb9YxyCHkf3vWNgaId5KdCFQmPHa6m1bYUOfxlHK7ThnZUl9CtAIOQy5xHnYoZd7QqMF/In5JuqyyJHUyx60vbZcwWaOeHJu/qwMlcF/iGV5R/AnUXjgJr7DCmdIGaZekJSzMSAlzEBCEc8hGprjSCMpzBhkzj17hW6gdtsGMOwKqJSzcOPvaLstKs6zKZcusUt+tI/wY8hL9w1T0r9BFOeVj3fDopm55TaMarlw3HVKmOQmWym9l9+K3savtS0Sti49tO7/eeAY+BHSkr3GaUVTuyAxHYHjmOZLKgtMrcmCWHJw0nlLFNqRu3E1TCbueXc6yOi7hb/Py5dnldpw6kZ5hL/SjLNGnKn/RT/hISN69vmydRY/iMsVJFK9RnLI7JyEY2u3zy6aRlz8/heZmITBup55kZPkwyRxtdBYVHAJ5Zsn06VEmL/Ou541hZhUdLaSJUk1Uk3xbtND4ymy6snHhy3p23OVTVm4Reh9Nlg62Tt3UJR+p74a2jKLxojrb/KQO5UtcytOPwvbSSYTSXV1Ep6xQ6giWbU4py2YuJ5kZxGfcLpWmbQR0RhGhwdHHv9Qra2aR4UTiozmVe+WCTJ3NTRGjYMI2Fj71hEZ0ijGQzAqhy9fWQ9jVJUv49TL0YZcmr852VZErWFO/KB4+ZeP3MQpcdS87hbOJMm2hku4YCvPE+BdoRoekSp1O5TGLqKNIdnidd7RwL3s3SL2iYabO8RtCVJHQJ8Iu892YUidTrBBZoc3Xyu5b1Kdvlk4+ejfPTduNYZmUZ8mx69QR98llnq0DXszMeQLv/WyibFvdNoT1/Qc4yvJW+iwE1FH40ZG72186nLmZOkdGIYvMV2YbF7vhpE0rc+nstB338SBPnx52vapxW98iMorQ2zSuXizLKnfpu01Lm3wy43nRePDLdJ1E3bMJv9S83HgbSJ3XjjyONZQL6DWwGl4W47ZH0XVPyPJTxlJTmgyO8oEOKrmpwrVZqiIqyQ0oYVoT7PwsWuFNepfOhsAus+vYciSeVy50aaFbX2S7+Wn1hV7CNLp+54v+bmjrES+TcWBTSNx1EJJfd1hsE1v09kvPaofUkH0IH62UCa2G6QiwJ/RKRyDTKvichTiSdJY9dxaZOotecWchuXWF9g1ux8k/LW3n23HRSfIklPyyoV3fjvv4sFwuH6x59aVur8I8+XZ5+oa1rV2ao6h7RtHtL9b5DL/djnqdgIwD73KdFNriRy6uS0/ZXVp6EPichyPCZ3GY58t3qhZKFtKZN1p8bTerGsvkT3TIorebYsdZNy1t50tcZDCUPAlFj6Kh8CpTn7TyV1ZOUfpu6Ky2dKLSTvJlZvgSXbyv/TL75SRC6R2F/cp0kdu9kyCGLo7IydnT6ULloa+qjiK/i+wRE6NOmz2UdBb2HWPHY7JKJlJ1dvmEDuMZyBbRvqoskz/hIPSSTgttfhJnKPG0enZ+UVl2HTdOHq7MbvlKfZuv5Lnyq6Rtvmn12zQppEUcBDmnOYk0qf3JZ6OSDcsy2PU4CV8f+vL6g8IwSNE9ihp7Ic1xpInAoG55Bj1HZPLuSGOSnk8ehUc39QhvMqmSVT2rjArZ5cKP+Wlxlsll10UeqzCrlsuWn8bQkW/IbAV8PHx5Pv4+3jadWy58Rb6k7TpuXpj2jCu7UizebydRfH+Carrti6keS3TvJGx2rlzpA5vGxEmYWpigXqcZOqMo1nGpA0Gcg4TF2GH4Z/9IuztKi7J16ai3/LlliXQR4wIa8Mu6NyguT323nHXkssvsuJRXCW3+efV9Mpnny8/j5ZaTh+giodAwnSbDJ5/0cR7sP/kTrnlhESdx/43vzmPTg3Jfm9Hini7/2H3gYlvsXZMeADEULONoDIVKQ61E2p1cSWk+AeUM/F70T24bYr/DnWiZqCRsmPbF29lC3uEj9FIgdTsEORGpn0NWqbgo76J0okRZel894SFhSJMzfoRRaljEUbByXZvZxWYTlBhvJ3N4pbU3ezbh5xVytP9Np0uT267NiiN96YxioN0bfiI7QwVa0bKWNIOdKcod1FzXDm8MH6mrjpumjHY9X/VOc6o2zScvr8mWTqJbkSqpNNTB27iUGj6d8+qzXORInOxDXuyfHOOVoks8+wmvWotneFJ1OQkP64wsH2YZ5J0iYuViW5RXUbqOsLGJ6B7FQLu68MAkoTv6e645HUb8SU0Mlq2OxBnacVFP6kg6LbSbRz7uJeW+MpfWShuVRAcJrfJYtAzvPNo8ffPqS3kY1uEUYk0dQKL4bKIb5QQ34ZHX50Jnh6XqSEfbDEYuro6ieJe6I7B4zRRKufkLLEGlcKicLYM7t02iIyWFS1L2TWRXl3xfXhE97Xo+eikXOT4aT55pqdSV0ENXOcvWxwgDJ8rhn6SFuU0reaBqr7uLU5Z0RDEqMX/7e9u6Kn1epU5vWzFo7uooivVApZFjH5PN2uymYRiAs2DLS9259lFLMWohfJXgKYZ8h0pUrVuW8O0IciK+cl8eq7m6+dLxurZTsOOOEpWS1z3+zejgUF4Lqlx908tK86ln2Una7OJRTp268SkjPeX+ZMPG4hqbhnbZm12NcHEYWc5CDG/GzdCrvqrcNtE53d+IgSiKfln6InxdnpJ2Q5uXlNl5jEu+hG65m7bponhGH7sMSqdvePUng8Mf+IZRlc4hmJgIGo12FzdbwVVf9zuLtE3tehxF2Ixul57ScIvGYWm4CldIkw0G7NiRv3RGkd/FlQ2psKaDoLPgX5qzkIGY8uQirIYqFJ2plP9mLQtdGr3ci1nlUhYZ5BAsyWdK+IQlUXleHeERD+322xwZD/uxf0cq6SDkooMwLeU/zWaYaODghBCMdej29ViDUbjx6iiyocq8t8oY9TQH4Yqn8UnhK7oYG+DWG3Q6y2jauvkdik3BuDRRmsxQ8mxauemFjmV2nGmhcctsOjtOOv8lbeRejb0M56MWWl9ZXXm2c7B57nr+Y4OHP3gboKCTwMFGeA62sNHyYWjXHN54fXgW62sbiQzZ6xdQu4EF4uooCoDkIxGDJ2HGYIpVL7IMFauQTJh7PpldKSf1rhEjdNkffU8lxmmVsnASLENjX+QeTFU/Tbwn33Yk8eI0XfOcRJxL/SnpGx9nuoQQOYRYdgpdBChzRg2PyaYtP/nkDENeNF5sbWTc+MZGel/bHDSeREBQTZZoDhHwjTY88V9vFcUHX5pxseGswVmQXR19522fzxDV7TBsPLLiSWMgzfaqnsIq3kcRUVo+wG2fRIpo+xvz9UGeBqGTwBIToDn8IexTYAYR7k8IZg3sUfxSKps0R1HHPkUv9ieSYyOtaen9nFbDzs8YCwKsTT6ScZ1RVOpW20jZcdybeNuaV8bgqiTRU4mC+zZQxXD122EIjoJriu+24HGNgp2246wS7zvmiDzGe30RU8FT8O1GZmIwYBPbDBIuPaEwUd6NsJJ1D9/w9qBbZ1FcpPSzhFLTTUu+hnkIqKNIRyhpRdJpEyU0bGlGRza3E5XKZ4iOfbMBtkETI1de7fI1iGXkLNz60nzCIZDYNGIg0spIi6WaPs0ibAztuK1x2bjMJqSeHHSKp33tF4pehg04iZ+vLKB8v0g7GUrfU7zkF1clQ7YMuuLM1jHlWDW2ZD+ljiq/wbIHZBRPG2iy/ESdsja6RVYaH6dNVfrT284yBsx2GFn1bDpH70JJwSKTWGxDJpG/sCDG/srIzWp7aqWaCsRRcNnp4Q9+I8BJWCw7WeOQckw6wPLTL3ul9nLpiQKrzijS+iV7PNi3gneIezGwM9PktmlsAXa1kYyPVWNL9mDq6PIPULkp42HWYCvnLLDejE9qFLjK9qm3nf0welUchx97FxXpAzef6WRZVh+5HPqBiyuzWJrdGO5PkL7zLgWaizcpcOKJy08IcQjqOV8dB0dRDLUsqpxxUfY+yxI19GW69NRVF9lGR+ytG6YLkJmE7TB81BywNJBFjmWivigw9ANZjG5Rh1HMSRBBgcCDJh+5gUyOEUhUFF0TBQPOCGcSVCLe3buff7FxFpLLs1AtTDPkTNSA1e6DeLY8YxzkaFB2fOSwW/fFeL7QqwwCcWNVfSDaMovuWRScUQjrepQTbj0MuzPCYgptBTPy+FTdp70IW6Mw7tMrSVUmB60BOf/C7m6vLpmTTzuvudjkcqnpqpt+Obj65pcFV6csO5WRWZWWG9p1XuzH9L60h7+Lu5uOa5XOs0OXzaBDNjqRsWtwia6zR1qnWtxRdLJTIwUGXWpdu4ByK/BK619v22x5jHdnwF1u+ekiM4ts/O3m2k1kfpgui2G/MchHKZuCE6bvuLbauy/DuEdRpL+yx4QPr2g8eEvTHyTsAearOrJ5Y9vwAj1qW5oOeTQoswebPOUVGegd5hmRio6CHO0+9rYpQ+w6chZp/RHml+mH9eUcWjhi+71ZXVi4rNeOgopU2dAu0nfRfZnX3LRxEtbLkWXfS3mCRqpcl55Kdmc0kGybK+NHQjINy4sP4GxFIrnZdBmltsIZZPEiPuUXedKP16qeKmKkQyyIdRLvpORyx16LyE/KGExO2Df1OIm0FlQaNGnMhiI/vUU595g92IaiJf1UQjezu0ab40cGn4Rkauf7hXQxS4gxFOOWYtBtpWL1yiRs3iKvTP0ytMLflunW535NthMW/Ivd3yLTlTNs6SxMutE1bTZRDL1uJA++bo6DoILjAENmR4w9AJnoRB4gRpZtoGKkJpE2EIVPWnmSUzLHNXBVDAl5VKkn2rg6SH5dYZZugqFPVlFce62/T7fsPN6WXFKqttfg4/2RS99iNrR9ZcxLcxQsq+MTHuTDK770FLYzLEn/t2g/Zo2FdO7wAul7ElJt7O2kzihkKFQOiw32NPYcpO4ALzBw09iVyrcNpMSrGCdfHeFXSqEKxIJVhGHYH5KfxbJfOmbp4Cu77I+e5csunHfDq/CbFB+6tfOY08SnxlvY5b7u0jfhx4teXphP3YRxJ0HutUx2u1KzwDgZeydBgBWE/GHmHc1ZHwa0WRYYiDa5cRpF66QZOp/htoWk1bNpODS6NljWbyTEeVdL5bVLnEUR/IphUE3PsrXy2pXH78uv/gR6K3zZztzQ+OfgB25BDrYgeQwK1wTyGLsq41fu0mYVvZtRGNVy/ynSn2Qi/Z/LEARFeZK0CL9Rp1EQ8nvY6yhYLT4wCWWStMSAzNfEoUgzdnmGJ62ew76TzOPXIcyJFJVry3Pr2GU54lKLXZ6phDUW1KG3Tx27Le13CQ0ZR+LhD94CMxfd4nxDm6/crbdfuSt7D9n3Zdm6DsYReE7BuCUViPweT1p/q044s2CGn6zLgWpJSkZtI+GWZhmmrHouH186i7eP3s6jbCLlG3hpfH36ptHasnxxHy8fXbd5VfUrKldmEaQP37duzygsYA99EMtPKA1fyiOVSab+drZvRlHnbILio+UnKmrfM5bisfxST/8UUddlK1QXz3XLR/couu46e7DHmQ3KScS1SKZoxLoxmHbdsgbRR2/zS2rrz2EdHy8/dZhbRU4WPykrq4fUKxr69G6bfcMitGhwCJg9mFmFmDgMTc4imviULJ2FyZYyj/D+/niRe98wTeXcfOSkv2zqr+BpW8msDJRKchoRcgWkWEcmR69VT6a64hgyBrZVq7uoz3i4HLMMWJH6Lr8i6SyZReqn0aTpW0ZeUR4+ujJy0tpQJt+ng1tfZhJhvhjaONWh9+MHjIyjoAmG2zB3fPryE2vbM4vezSjieoYp2xzFbzm5t3y1asyzFaiR7fpnpTOKYn3IARQfuVY9dxC7aYu0r1Eam0EZuLrlkp/PeBZto68uO8Onpy+vVx2XplcReWYDuz0sJR5ZujBGx4BfzoaD4Lu1GMLmd7MjqiJy+kuTepulqcHGlK7kMBtmQBxVB5NUgMrh3u2ADJofzGYxcU1+l5Q1Lj7DV5ZHOZgiap/sqLRcLEvnLDlp9bLqlNOsOHWaLsU5JCllGaq9uGQI2oedzAzi8AduDf0Dhh4dB8vwc9rBc77m/9w4GcisorczCo51534wP8Xn5IEq4+HLvmGSFdmY7Muun005xqUKUrXOrzIgc50EVclzFFUNjW0U/+H815pWX/SC767W+pK1bNklqybIi7TflpdGb9MkhNSQkSa3BtYdFrL0FDkKKQr3KpiiYzj4/ltwPDa81UNaeAksR1399ZdJhURIR1G3k6CQaDM7IdLKoK7xW6ygoyCPeMWIq9q6CIvSMQWvNGSdCmkDskNgR5ofAnlOjV45Cepx2z99rq0OlYi6vV/Ooi08FlQx1nUZ4CqyY8o7ibr0irNNGkyW2w5ClpyYL3F7ZmGo8ZR++EPYq8BUgmVN/E3AUbTwcsXVKT9idOi6F5Jl7VdxR0HR0Q1TwlF0dMZeIRigxbuvjAZ8p1QjZRDQPYoyaMVp/XdxnCaaRURj3qHIn0UkKnSVEb9n6EAG5SzEuNZttLuCJ6Wy6JpS3KNs/6ARR8DQdhoSD5VhKnok2P08/JARnAVdxQQchinD5sVHnvCXwVVf+6WE/ruvflfQK2eREBbLKHRbxWqkJeBc4oM9jVDzcxHgDpde9SPAAdrI2o/g7EH+iojv1lDZzsCOU3Y02yiiSd9oenqTd4tn31AwgvxQ2I6BTkMciP0k3sJsInQnQbATzsKsQLWXoQxdi1vd/ovOov+X3zn2Xw+VaCOgjsJGo1w8a0RHZdY9Lo4hb4nJVaNuoxbNIiI1XZmaHiYE/P3EoRXODaIw0tp2HNEg3PkDjw1/Ozv0GHicaZhZRVQvHuuNs4j0iUurlPKDU4mVVkpDQB1FGjI15MMh8GHOXGWdAyvRQdTrJNx7Sm7Y1rDOKkLwevBv2eWusvQ9UDnBkr0pziKcTdBthK5DHEhYbvyBmU3QP3CXQiYSXIrixvZ1T3hLgr9k1O8s3HEoktyQ2vOSMEzpv/1HQB1FdcwLjV46i6pOorpqaTXjKkdLUPH8tNqaP1wIhM4hPnMIU+28tj02kwd5YkETdmEJyvgHdDvLWvhnAhvb3K9Iu+p3FmmS7HxxKHB7eDtbr8EhoJvZvcNeRnkpCfXOIIqKpqqDcRbD+KReFLXhoIv6zp5FGN1CD2Gi3KuQi9kmNcnnRDgVTC9aTfDJGbF0Fv3d4BadcxSThmnYMwR0RtEdtDKSu+OC2vUvMyVVimYQUVmYV1szIsbdxWpSiGz8rDIcsr9Cd+3JrU2HKX+5xB6CyElEbZY8l5wv3O265rHBjqsvhIPgZjYWoPAGXgOO4yNPTJ9VuHzKp4tCK3R0EPyTdKpE9SSp0NRToDOK7nHkKK48UDMMVveaORyG9HSTo2WdycrdUqcSubzcWRXTRceFmFEuNnEY8r8wHv4rhlYmF3QSoeEFHao06CjCiPx0Ra6+1QmK9odL56YTGuR6kkQNzSiFgDqKUnDVS1zUGNQrNcnNN9Owjdew6JnUvCc5uVapTqk2zlX4ijug8Y+cBDlJM3w2NCyj0+CR2SMfvs3UZS1Sf+TJeLfixuS7FSzv5ir2sp0rgRpRX187XFpN9woBXXrqFbIZfGl4B2F8fQ7Bp6ZrvNy0r47mVUOgrnHQMp/+C3UIl5xoWPONqzHDOPVkrva0I3I+Ybb9bzeb2odveLvNqmC8rVvH8RWspmS1IqAzinrgNPdbGqsbXv0pFMmAT6PqT35RZ9EfbVRKGgJ0zllOJD57oEtIcwocd2FZuOwUpiRO+Twqy9+yIJk5LruW/hJemr6aP9oI6IyiL/07HE6iL00dDSFpVndoWpfuGGjvRf3ISbiKk0KoWEbK0PmwwC5hqV7jjoDOKOobAby71CPUh2fPOfGJvcyyWt5Tfi8ULqOfOwMRN8HZg2v6ZaAyn0+LLRLhf/4aHsOP4gW8tM+Q9/+YbIhsxg+CQeNEE8NK+m8tCOiMohZ1m5ZdAABAAElEQVQYlYkiUD8CZZwEpdv09tKUmSBYnoJW1b74WQ8eeWryXYr2+xTDtfhkKW8rrvG+IaCOog9Q2zewX5zeCB5cXHvmIelvlvvEXpf0OvmGY02OyMY1NNsQ1lALo4QZf3gzG/8jin9AyP8+8vh6P+tR7dQT2xAOhYxPjZNIrx4ioI6iXnCt27AM46GziWWUV9qhQ8AehvGxFdvEFr3hGHZ9P2YVvOgnYJgbIORy1HWPf3OYP5B/7XbAXehnPAbSCxSqjqJ+6OOju37+PeWYP/upT3yGrLh1q09kGU7rsh+//OpPoI1ceAr/c5fuZVbBkBfnHnQeNuDh6hNKQCO/jBdSd/dvteOxkUydUURY9DumjqLfiKu8DgJll1zK0ncElY/Qbtq203DIcGzlJVg1yvJNw4H54Ymn0AtEp58iYcYp0DG0W2c7jl3X4GOBKJgwTgZ1sBaVtVfRzTsVkQPL8seJLogaEo9lMYlTaqoSAnrqqRJs5SvRGKTd4OW5aY1RQaCIk/CNG8njvIGX7RSYZ6cFK3EOkjZh2xZ3TDKcQ8P82BF9BnLNxkWsRpcJ2nRKE4kSprEV+rRyze8HAjqj6AfKKkMRqIiAOIS06nQIXqcAQyz/SV1ZbuqkJWKFDaw7rbXWzJ85AbW6lrlPUWZWEW5m246hzESgDK3VII3WgoA6ilpgTDDxjuoiT48JTn3OyDNMfVanBnHerjB8B9kflJ0ln/1QtS/sFkfx0EDLUpMAa3JB1MlHhP9xb6KFdyrCN7ZxAupJdXxVNtImlG87DdHIDYvQuHU0XTcC6ijqRjSHX5ZxyKk6csX9wWL4DE1eu6s6CBkgdovDOP+NG2k6BmYx5AqT/O18Hk4/GWdBbiFRg8tRpgLzurlszcry6aZuWVlK7yKgexQuIvWleZd5R7cYim4NQn2qRpxEtygn/K0MO63x3iBQx3iw9ywkzkFoBmN7NKbZ/M6A5Q8ZNfD7FKjXwqMkw6xd7WpvanekkbteQ46AziiGvINGVT2fQ+p3W+swzHXp3CtdwoWkUEtxELKpLSHzTRlDkPJHjLiJzbwJOhccfWo217pqavJlO+8zVKoMPRqbCk1fCnRG0ReY/UJsY9krQ+GXvF5zacbKGZhha6nd53XrxhmEICSziVAGc9uxdlSchOQz3aEyTMIPlxsHgkIuP+k1vgjojKK3fc+7S+8wD8ZlHWNIX6+TKGu0y+rsNjtNXrd8bTlEKJxFhMMu7jBsynjcOIR2lvl5CjoOzCRwAMrMKPgp8sFcevsMBve4VHUUcTx6lcp1GGlGpFcKDQPfOg3kMLQnS4d+9S+dROgcQqcauQumoz86Bts5UHeecuJjTWsNHHBMlr+nbeqTNmSX1cSayozENi/GcwXbFWrSQdm4CKijcBHpbTpzUPfLmJRp4jAY82HQoQxmZWjrbJs4CYa0+GEYaZNlcsOlp/bnPOhBzHKTYWMcylU3/XLEyIkduu6FTk48Ge5PZA79dgWhkTBL47gMTfUWAXUUvcXXx13uAl9Z5tl6b4UuMumY5I9sBuGoaCizjGVWWRdN72vVNFx70bbQOYiBjeYWoduQoSezjhAGOgm5zEzDeA3ShvT8oGzVa9dlL2lXtYTEmAlzhqSRv4hIN7IjLAYVk14alPxxlpt25yQw6cag0EhJ/TSDlRBoZUhdK2ukokUxqYpDEf5VeWd1ROgixNSHt7lxCHyJru0AkvU5JBvBofd/wxQ1zFJUWPeqr78sSY6crNlE8qSTj4U4CF9ZmJfjKNSGpUNXW4mCXBuUlRgVdhaVuNdQqRdGrAa1amWRZ8yrYJDH021AFRkuDzdNZyFOIXIc2bf84baTMN95Amn4ol0ruOqml7vsTTrbURSZTYTOKWsvIsNRZDfGq7FmVkFAj8dWQa2+OhzoQ+ssemG86oOuPk6j1k7bQcjwEodB1OLlEY7MN4MR/9BBMMVPjj/3Zr+TiGomY8nvOiVpRLcoFJqhvi1EybEKdY9i8N2tT0WD74NaNSg7m6DwKnXylKZzoOE3xt8itgccl6Pk7+EP3BbSgqCJTNYLOViVrWjWbCIksyVZFTvRtPJQcjEeHWYa6SEC6ih6CG4J1rxj0u6aEmyUdD0jUJezsGcPjHNghWZfXEY01MzmtXX2VQwC384Of7Qooi2KbbQ3kZQX8Qi1Sh/2UlfCqKbG+o+AjIv+S1aJPgR495S/M32ciud5ZY7ackxxOLqjzDL2zQ9iKedD2YYvq36+ZuRNlxDKCGOMh+4ikhzFWNZq//7ErmsuMt92ohwzk7DJmFngipyEEItDkDRDO6+CEJuVxvuCgDqKvsBcWog4C68Rb3MTmqLMbXrhK3k1363Ctqhq65+OBj7LyNsOgnE6jbQri09aHeaHHKP5ROgefH1h57VfqmNtTC/4W9nG2ZiwEVx9s/+0U5YeoSMQCl87fXlCHw8zNrLjhJrqKQK6md1TeLtibt/NdtxmynzedWnlNi3jRenceiXTxQ1BScbrl9yGxI7X2CLbRXA2EXV2FIvEhcPG/IulJ84qOJJkdsH86u9PsHbeJTql0aI1u6/MYiIMsmi0rCYEdEZRE5ADZKM3TAnw5cm/zFO7r45d346nqTJxTbubLLvYi1mFyA+dBmWGckPHwQWl8D/mh5OHkIZ7FYfffwsmFVAQcaazLt9GdnLZyeVgMyUQFhguqaaHCgGdUQxVdwxEmb7drWJQ7f0PySvbcpuHr67wFTpJ27S+PLvcF7frMC78fbRuHp1FlnNw6cvyd+vbaZpo21mwzOxD0CvICGh7B0lGBTanrJfsQilxakm5ZXbajgt9pIXkaDg4BNhDeo03Aok7sozxKwKdbVyL0I8yjc9RdGYbnoZ32xd0DnJxliFpY5rba0v0D4fed4uhlF+yY95VN/n3J/yzCb5cF8kSmVFoJEbJnFjO3gSZ6dVHBHTpqY9gD6GorDu7FnXVScRhNE7BMXM+5xGvVSUVdq2Ikv0Lhp24HIuVUQDvIPR80c53+ZyEjy6Zl8IwSag5Q4iAOooh7JRRUWmcnUTr0KfTu9GxmXAetM9io2P1qmAos4YwjBxDyFiEc48iFHnoA98wG9dMhfsWraC8YRC+MfXbCV/T7Dw77qsfyytFHKupicoIKOiVoRuJiom7u9ulDkGlioGTuus9FCdRYfkk0R+CRV39IvzoRBpwFMZJIJOOgcL5jScuP6Udi/XNKPI3sSmVpia1eSToXBm4qb3qoNTfSPkHh/7qp9IUgVIbxv2Aqyaj3cKSUwvvVIQh4lm698rxci7Dk04ivDdOgi0TCWmtpA/A7Gf3M9IINH+ACOippwGCP2DRiTu3JgOY2yxXjhhBN99mlFYmdYU2jU7Ki4TkWZWPzCYoR+Kpxk8estsh9yqyNraL6G5mCv5VLJjq6GuyFMnZhHEUmE+soWxS9iyKCAJNsZmEzcxpsF1E3bKdBCvrNSAE1FEMCPhRFusab2lrmvFNy5d6WWE3ddP49oKnT9bE83Bclp/0EJcNU9gPZ0FdxOqG8xg4qPY2ifm8uE/ZWvKkoRIKU84kMl+uE0INB4SALj0NCPgBi3Xv1NrUSXMStQkYYkYyg3BVTMs3dHZP2HGXCdJFsA23rsUNJJmwnL85ceh9+HEieImOyFYzaOI3sovuTZSfTSR1iXI6WkRZGhsqBNRRDFV3rG9lsgxZv57S1xuCvqWmrOOyWRhHbfc7isPvu9U4CONMzAyivcVsphWN4Lm35P/uBB1ENSfh14k65yw5GZKobRobBAK69DQI1IdQZreGPMuAdct7COEqrRJnFZkGkXa0tgfrJCPzy3WQYZaWWAxHYX6cCE4iz0HwpFM15+DCJM4iqZ9LaaWlkpWl0X4joDOKfiOu8tY9AllOMatxaUtQZlbh2E77a7NZPIuUHcYyU+gguJnNC04C8jiRuDp/FtHYffW7ajDWbKD8hToYPXQDm2AM/aWOYui7aPgVrGo4h79l/dPQOIsazLGrMT/N0TQGOsn86lv8n+hwebQOXU8LX9MlevCUk25g1wRqz9no0lPPIR46ATXe9PkbrLrsVLz/zSko63cquj0BZTasMXvg06BsW3N/4qrCDuLTVB7jpc4hE/LKXIYLIROPEqb034EioI5ioPAPh/BeGfNe8R0O1KppUXivAvbUt9FNqZzBFcWW1pZOosASU6xB0TJZyCFWWDph8aCfyHcB+RSlddAK3SCgjqIb9NZf3TofDVOPaxY1YusPvlBjti99uc0yihUa6M4qyrOw5bcwe8g/yeTIaMBJWOPEijqExZMRj8aeZxSvppRDg4A6iqHpivWlSLqhXF/tqKpturOIjGIa77xZBWcS8nOpabOKNN6X/dGz0oqK5DtOokiVIjSh89LlpiJYDSeNOorh7Jeh1mrcnURa54ghjJZt0iixHJR3XJb+hvY146qxH+AguGHNc1D2jCRDeKEi4ZX7eQ5yy2ltIYFK1CME9NRTj4AdUrY9vxlHfdmpSL+Kw8ijzXIoZiYBs5328l0NToJjgQ6CTotOoq2uhHnap5Unh1gBPJKV0thr/kAQ0BnFQGAfTaHqJKJ+FeOY5Qwi6oxYTSb0use9qSOEruDqTz8eAZnbjsFNd6qUiNj87Hgqi5pamMpfC2pAQB1FDSCuIxaF7tx11J5UVRuTOBY6PRW08P2i5vJaKl2vC/IcRt4SFDe3u7mue9ybUT3sdv5LbiFH/tur4RDxlvZDmO8KVfGVaN5QIaCOYqi6o+fKRHdwz0UNTsDE5ETQmJ6Ao8Df5FTQ2DIRLJ9YDII1HBTFMjx/2G1iaiKYmpsOJmdwC+BzFnQoi4dPwXb6jWdjgjTxsvQN7WTbXYNpzzTSnEXZjWxKtWd1fNnOdga2Vf7IM74WXPXpxzuKxtvnFJZIFtqTKMFPSQeNgDqKQffAiMi3DVRak4yxhSFuwJC3VpteMpoq26B5ibIyUbkBJ0AHQDmTM5NITwYzcAYrx+Es8JVUvnQ2gbzWWjNYXVgx3BifRL0Wdu2aS+EMZBKOZGbLTDAxCx7wLpOYocwfON6pw4plnIWttus47LIy8Vvf8l/B/IPHTBXqh59BCprANnQSZTjVQ1uiXV11cz3aKpeiCKijKIqU0pVCwDzVw1DziXYCRru5vArD3Apmd2wIZrbOBWtYDlp46ETQXIkchjHIMOhri6ulZMWI4WmmNs6YmQEdU2NCnBL0gHOgJ1hrrmGmMWEM6sQ03QYcx4ZpM9tYehizCutqTE8apzO9eQ68GsG2TTPB4Vv2WRTVnUWMSYnEbX91Y7ByYgkzpslgbWnV4MnqXGKb2ghs6fyga+DMgEqIyCClfffPPNRJZMC2zovUUazzDqxDfZ6gKTIjyJK1YcfGYOFIaGSnYHRpxPhky6Wc1cUVmOIgmN46G8zt2oT8tWAZT/c04hMYgYYO5WaWgbypjTDaqNuEoUubeXh1gRDOImRPYmZm2nwhtQnHsLZAR9V2SrBzNPqTs1Pmz8Sh78rCsnEmXJZaOYU49jnIbwqOjnUbE5hZYDlrdtuGYOnYAlSIjKaNXw0nkrzN++rrPhNMzk0FS4cXgubaWtBYwe/SwflO0ClA10k4yAZ8M9s1txs4o3z5CPWs8/I7iYISCJhe6xAB7bh12Gk1qOy9221jlyWDhvUpr31WguRr134Oz5owqHhqb+BJnQ+eNFZrmE1w+WfDzo3mWXTtFJ54YdiMQQcvsyQEblwyooOZAx1nF6snV4LV+SVT3555JAQjg0tN0zCUTTgmPmVj2gAeYd4q5K/Nr5gyTFiMk2AbKG9qw0wwh1nOBJzK8vEFzGZWgqlZ7F1smjb6ra2sQocVQxNwaQoObOX4UrBw6GR8zwJ8zdIPP8tKf8Snech48h88w6du6byb3/AFgx11PX73ETP74ayIMqYxy+EeC/Vmms7j4Y9/CzIQh1M+de9Rjzx88+nTl3ryy2XpLKIcXuuVWmcU67XneqB30ZmFu6krqkxuwBM6DPYEnnqnYYBX4RBWsInMJ1waMBrwlfnlME1Div+nYdxWJ5Y6T/hcNoLNDQ07DDxpZvAET5nuslBHLmTyWp7nHkToCLhhbWY22KOY4T4Flo6oAx0XZwfTW2aNI5jdvjGYxAyoubQS0IHRQU1vmTOzGnNyCs5hEnmc9Zy8/yj2A45zkmTqc5ZCJ0gHMY29jFW0j8s+dEZG702zRq8q/9zzz98OFrAfcurgibDtRxeCTadvheHHb1ujPcSSenGWw+W8VSzXNaAYVDNOkg6thWU90m1+1C44waVg+SCcG4qpnlHQhNX+KeEgKCAUWU2U1hoCBNRRDEEnDECFtikrJplLMbR+XDIyl7FGybqX/Op3Bfe//3YzK2Dp2uaZYGYnDDSecLlpvHoSxgpLToxzSYcGbhIzjc1nbzdP6vwpThrhJgw5ZfGEEmcITdSj0d+wd0uwAGNniNriOTPg03RondEs/s8lLeTzh3lm4CAmpjBrgROgk5iAkW2tNcw+xgROQ4VP49APMjl7YP2lY6fAY2MwQycCYzyJWU6rCaeH5SjurywemsfJqUaw9dydZj9l+eRisHISS1VYlppqH8mlc5yGo7j9/7k5ePRPXZIEq51zGzajuTTHi7ptOWcHdIcjWIa+0GnDXjgH6D0D50X+NPzbHr0nmN6GPRPUYXoJToTLY3RsxGwFTpX7LpwBTU1ivwbxFujmTttiHPLCvuOeE0/UoCcX1dRrnSOgjmKdd2AX6vMGTph836zCnCCCsV1b5nHT8Kk8TW4DBnLpSHi6iDMBPsUvw5BxmYTGjkbrFJ6UKdosScHg0gkE3NOAIW5yWQqa0chzaWrC7GM0sBy1KcyHfDqLzt4FWwFaGkku9zThlALoyr2Q0LhiAxvX1CzKYGg5M1k+vmJmFTT21M/80hvyZ1GHzox60WhPgr4JA/t/vfNPgw9/9t+D7zz/KcFvXfMKM8PhXsAyaI1DoDOCg+BeCJ3UDGZTG8/YahzF0tFTwT3v+Sac0Fpw/osuNrrY/3CzHOqa5SLqdvL+Y8HysUWz/Mb9CJ62msDSEvvAnODi0tz2ENeTDx7Fstgy2oRmAPdJMOIMY/Hr+4NZyF+FU57ZheU+7mNgtrfzSWcGK+DNJbbW2kZUguMHXA3M6IpeJWYS7Bm9RgQB7cwR6ciKzUg4CpcP9y24eTsFQ7MMo0Sjyg3dS3/tcpfUpO+GUVzBEtBGPAnTOJp1fyyBzGJpZmYLNoFhXI/feSh8hwF8ZrAJzr2FxcPz5j2GFZRz+UdORvFpnnHOIlbhSKiDOb7aHrk0gu0fXDBPy2bfActZdBTc7yA/PrGb2RAMKg07DfA0Nsy5LzEFWVwy4pIY28nlMp7Q2oCnbxrmP/mb1wfv+vd3B/OL88HaGpZxNm4OvvS2zxraBsrXoBNPIJ3EU/os9KS+dDTckOe+inGQePpfwdLQuT/6GC9mt//tTWbWwH2cUzgJRuO95ZztcH6T4fsfaOvMpjk4hDVsuHNmhn6Ag+Nsgh246YwtmLnByWGDm5vcCzfuw4myec4jzMxp+eiimY1sPm+nmRU99pd2o2wRfpWOGx6vhSUs7K00JpbhNbCE1aAjj18lHAQrql2Jw7fuUzqjWPdd2NsGcIZx059+3giZwVLS3J4txqj5pN78+i9gOWkORnYTnoSxLHIEa/54F2Fu96yZifC9hEkY7S3n7AxamC1MbgidQIOP53hy5pHZKTw9b9i72cwQuIlMp8QlIy6vcFnFOAIYVBp+mXXwdNTkDJZZNkIO9xQgh5OFZZxMWsRJLOaZGQLy8dhvjDkNJJ0GRXPzeQrOwywdwcDPnLYZesxi5nLCOJmFZWxyN1fNMtix+ePBRS96QvDxd340uOhRFwansG/B47xzfHKHHrTcXEJbeHgBjhF7FGY5KIATxJJZyvXon740uPVNNwRTmyfgtFYwM5gyjmt682zAP7af+jWbcGqQxbbw2rx3B2YecOJo91377g5ece2vBfv3PRjs3Lg9+KurXgfnPmMc5RLaQYe1ypcOMeNpNDA7Q/vpSJprOGEWcOZC606HAUcxyZNS4cuJE3uehnipS51EKbjWB7E6ivXRTwPV8tLfuCK49S03YDN1m1k3h131Xtsu2A1HAiOP0mU8ZU9uwHHYnVNm9mD2H5A/A8NHA22WsMxsYDL4xOc+Hrzzg38XbJ3bHPz+z77azDDoGLgEs0bDCQNvjqpyWQfLPDSAq4uYWcCAzpzOPYgJ80TPE0urcCazMIrct6BT4VO+ea8CDoHLOCuoxydx7pXQGHLfYwOcglnm4nITdDN7IODDk1Ivf95Lg0995dPBt+6/3TgqNpxbxt/74mcH7/nTfwwuv+g7g9VVzCAwi6E+nMFghwUYwLhjFjaLZaIWVni4uZ91cXOdL/NxiY0zLM56uKTUamHTGu1fxdFdnt7iLIdGn0ttdEQNLElxueyv/+mvg7vuuzOYn58PHjy8P3jNx14f/M8rfxUOZyl42gd+siN6df/N4Mm9IPYiHQMdRHvpCc4COzRsIDKx7LfnSmYUvdRBFEVqHdJp567DTqtZZWMeyvK8573fDB75oxfGqu376D1mX4Dr+vNYSppuv0/BdfsGnvgbsE1LMP6wUlhO4tP/ZHD7XbcHr3nLHwS33XVbcPTkMWPgzzvzvODf/+IDwQJOGC1iVmBOUsHoc7ll6yN3YfIBU423p/kATyfBz3NwyYb7GTSgpJvdgaUnLCtxI52Ogk7k1IETxklwaYgXDfJGLDHRuXHJiPX4xE5HQMex8NBJ46i4hPaiP/u54OZ7+EmM9i1DAwsr+9AXsczDl/Qgl/LpLGjU+Z4FdeXTP4+omnrQd9dT91J04rr5z76I5TroghlCAzOKqY3hMxxnRSsnlnH66aTZsJ7ALIyG3LyUiJAOhXguT64G3/mSp2N5rH0IAOB86NlvDZ5z3YsTspixuu8OsOEyE09p8Y+tBnZwFI0JOLrdT/XW82SqDfGAMmpZ2smj1qPl2wNz07vr3vd9G04CRzixxk4DTQNMw8+nYS4fHXzwoeAnXv0/gnv33RssruBp3DzpYuYxNR38+cv/NLj8tCcbRzCDp36ektp42lYzQ6G9buKU0tKx5eDY3QfNUVBuik9hxsJlGrNxbjxJOMS56cvTVpzZ0LhOca8CexQzeOI3x2hh5HnqifsN3K/gkpWZ+cAR8a1sPt7ff+e9wTN/+7kdsOgo5mZmg2/im0rh50IwC8B/dBZcMuKxWbaRMxjjnKDP3med2akvkW+/42vB/IblYNvebcG2bTswA4FH5aM+NqeJ1zw2uLmBv+XM7WZGZDaw0WvkbdqMpSfq932//rzgvv33hWw5s2rMBMdX0pe8RH7FUG1HReDWYzXt7PXYa/Xq3FNHYau6/5P3mVkEDaF5gscSyiJOBZ1cXAi+76XPCQ4eOWQMrV3ney69Mrj2+a8JNp+13SzjzG6fg8EPHQ6Pj3IJiS+/8Sgq33XgSSXuc3C2csf9dwYnV+eDDVM40rq0aL7jtLi8GHzjjluDmbmZ4GRrMbhz353Bjbd8JViEDrPT2JdYWgiWlnHUFY7jSY96QvD3f/y3xqmRHzeSf+LXfzL47Fc+F6kI9H79x14R/NILXhpMwfnxuC8dBWdRnPksPYyjtJhQ8JitORqMpTTux5j2wwnxxcD/+TfXBtff+p8m769f947g4kddZByFmaHQmd53IJhewPYzluPodLiMde/x+4NvH7gTtBcH3/0j3/smTIYuuvvGbz370h9+iplhiIJ/+d//KHjxe39Dkl2HKw+uXA0P1ppaCq5vnNfg+p1eY4CAOoox6OQCTUw4iwc/dGfwiOedX6BqcZIDcBRcgjGnkGAg+dTNl8L4wtvRh48E1/yfPxjcg5kFN607F6Ivfe6Lg1+8+sXBRrxwNo03puFNgiU8+Zs9DM5SYJg34JQTn/y5t8FlpsOrR4MXv/6lwX0H7jengciPD+msywu22jgDypK/sKT9r6HDHsbchuCOj+AtZ1hi8z4InvAfefX5kY6gm5mcDr70+v8INmCjf2ozNuy5GY3lpwUsv83hVBeXtKgjj/Ryf8G8r8GTqfAT9zx0T/DDv/eTwdIqXkSEczlj9xnB3/3BO4PzzjvfOIT3XvfPwV/87RuD1ZWV4Pdf8Krg8XseGyytLQWv/eDrg8/e+vnjdEzvfec/v/uKJ19+9sJ9x5776B+4ODhxEien2tfebbuDb994x6/PnTP3esmrGi7evfg8LO3NNRsTR/FV3v2rS6ce3nTupn1V+Wm99YMAhqpeikASAW6cctmozotr4ItYz+cSEA3mBCw3ncUU9ge279gWfObv/iP4j//74zDo8eeXt133zuDI6nE4lHDdnp8DpzPgy3KcSYTLWPi0BjZ1eYqJSzIf+uyHg8NHH+6s2dMZcNnJvMDHeQvSXM83m+xcopKL0U4S72wsLgbnfM/5xgHNP3Qc4Sm8xIZTQqIjVF3Gy3hbzttlNp2xU2GWrdjObefvNg6Mx3t5HJd7Jdw34bHXtfay0Re+8WUsuWHTHrqsrK4EDxx8MPjgF/4dTgUvzmEp7A/f8trg3gP3mQ3qn33jLx4/70cu/cOjF6y+41M3XX8Cs6SNJ0+e3PDfXnjNjy/MLzxq4znbv/DYR2LfiPDhD61sHjh2cPX4iZPnSPOqhAv3LPz00r1LP0EnMdmYXMKuyzy2nA5tnNx4tHVLa6b1UGtzFb5aZ/0goI5i/fRVLzWNW2ZIai6HT7+HP38gOPDJ+4N7/7V7p8G3pbmEQyPLJ2yzCY33D07iM9mT2JPgksqFFzw2uP/jd8HOGUtn2kyjfs1rfsQs53BzmC+XmR8lAg86G/LjvgePyZ46cDJYwnLUjz/xB4O5ab4nYDghpPVPNDNyCh3nYES26cP4Kt6feMUf/5r5xtMsXho847QzhKgT8oW8ZTiRE3cfNnscfGubp7O4x8A9hbX2zImzC27kb8QRXG6m/+v17+/ogGYGSytLy0tTK1/cfuGejxxqHvnkkRNHl5GHCcrCEpzahsc943GvuPLyZ8zBScxBrwn+ocaW/7rpv7YBp7kf+7EX3EMHgTjgaMJnrjb/7K/+bGXx3sXfWLh34TVL9y+9evG+xTd2FE+JLN239EPL9y3/POhfRQeBQwMPgPTbK8srN602Vh+gFwpwoCzYFmzBIS+I4/xIr1FFQDt3VHu2RLsW7198nks+g5fEzBMwlkP44hhP4xz63P7g4Gf3d0jvS3Eeh794IDhy48Hg2NePBCe+Ef5WAuN8CY2/78D1el5cKtqCz3dse9QeMyvg5jFpuNH8f1wtRzpDA39i4WRwauUUDC9OTPFYKAwuT1BxeWeNMwKcOlrCBjRfluNJKJ4g+vQbPxpcccl3BbPYcJ7AVINLO/zjjGASbzBPI5zCMtHM9LR5kW7Lhs3B5g2bgu2bt0E7OBX6lbZv+ciXPmZmDNPYUD9t12nR0hMbgusv/+VtOD21yXyCYyPeA+EyUxOzHjqtPU8887f2POns/7X7otN/edfjH/E7Oy854507Lz3jH6fO3fjmW+699cTy2soyPn2+utpcxeneVvCbv/ybH4d7u+HI8SMHwdq4QugP1Sew/z4ziZlHC21YhePAx0hCPa9907U03c2f/CGDGz77BE+xhikUrr/5x7/+ERQ+jBkd3rILLgDdhXAA71m4b+nv4TQ+QRq5MHt4+ql7Vp4GtlOojLf8gnuajcmbcEBqojWBD4FsXF1YW1hbwqGzHUuLS6cj3HbyxMmNwR/C37W4oKfXKCIQzuVHsWXapkIItPa3zsMG7+OX711+w8w5M6+USjsvPv0DeIrYDxu8A4bv1iO3H/q9icnwsfvgpx7A8gr2AvD+wN3/jM9TYCmJG9Q8sLTjor3m6Z6nhyY3cLlnMnj4ywfNWX9+KwmGyiw38X0Bzgp4lJTLP+YILYw/EsboH13GOjvNDm1P2/z8yrW/Grz91W/FV2g34QW3zcHW83eZZaxj334oOHnvkfCpHctYm/G9JH6Blk/of/d77wwe2P8g9j7uCY4fORY84dFPCO548I5gcW05OO+MRwZb9mwLNm7aEBw9ejyYwHLP1pktwYc/d13wO3/7+wKFkQ9jDtWhG2YIV13x7ODLX/tyWN7W7a4H7zJ7LdsfveffUGE/DPi9rdbak7ecv+sUnu+Pon1LK63m/TONqcW11tpis9GY/PO3/e+n4IkfR5bwigcvWOXp6emVbVu2nY9mb33fv71vOxyIKSENncLrfvt1+6YmJw8vryyfBG5b8JLgBGs+fORhfKSktePE/IkNoENXoOdC3RrHTh7bjTnX3ESj9STwuQDlD0HU/ITpzsb9i/ctY4bR3IQ8bm5cjkeD29FUTN3wMkgzODW1htcjW82dE82JxbnW3CMCvEzfbK3tak1MnWw1VudnZmb2B88IjmBmF547BhO9RgsBdRSj1Z+lW7O0unQxXkSbX2mu3NK6f/nvcSan0VpevQDBo2H6H4axeSxM1TfwMt3v4qn2iTBKk3iav/Hk5+56Lc/ecwmJS0H8nhOPiPKFOjoEvkcw28D3hPBeAs/8c09hCieNAnx+nAacG7q/+OpfCj75n58MtuNI6Ot/+0+Cpz7xCvOC2DJeEnvE1tM6SzIwYOb66m1fw3IN3ubeAieA9fxlvDx38r4jeIfipJlh8AU3bh7zb8dj9r4PuqM5wZG1L6/9ws6ZbcHEo/FdJby8tmPbNnM0lvsF5l0L2NRZbKjzFBU3hx911vlmOYuGu3PB6G7CZ0n4CZEXPe3Hgz9627VhO/jNDFzzi6ea287f8y5AsrPVaG5DzSvxgL0NrYU9bp0E84tgoB/G1vsx7KJfD2O84cBD+y6EsQ+FoJAGfse2HfMw8igOgn983z+dj70LdAP33elFg+YPPveH/u3osYfvQnoKDogrAshvNI4cPbIVhnpp+9ZtD0HeTtQzelE3vBAINRrfAvu9EMYPwOP/CXwjpHkHik8H/4vBYhEKHEH+RnitB5oTzSdj5Won8jmz2IglvrOxlPUs6HgcqC62GhN4CaO11Gg275mZnp0/uPcg1/l6dhaX7dBrcAiooxgc9gOXjMWIbWvzy3NYwfhic7LxSDw2PgZPsPfhqfYgHMKmZmv1vInG1Ak4iD1YudkOw/R52KvvwkPunkd893nvOXzk0Im/+ou//Lm7DtwdXHnRFcHyLN6U3j8XfM+j8dkH2LUbvvgVswz04c9cF9xy+y3BQ0cPBlhOMeaXvzJnjqzCa/CzGD/z2y8O3vonb/3iNc/+gc+2mo3/xLsM/xJ6CtrH8OKm8ezOLdgIh6XbNHdgavvsrVsfueO3sBRyAM5uBk/X27F880zshFwIo7YXRu0QbOx1Zzzl3LeuTaxtvuNfv/4Zc2yVp4+w13HuNRf/BtTYA4e3Ac4P51mDz8EA797xpDPOW3vd2suBgRHOPRB+U2rr+bu/Ap2Wtl6wh98IeQo/AohLvAlsJlSbauA8bLADWF0Evpwp8MF9J3g8AEj2oew4Zk0b4R5a7//39z8K8ibhoDibaE1ik/tdb/2HT6LaVtQ8dujwQXwvBc/1NOzQBMtk8K8r8zu273gmvjm18eT8Sa7hQbsgwN4BmSxMT88cB7FRDDJh382Fb7e3+ALIGeAzBzoUtO5tAjOovwtlWNAL/guMvoGWbocu39/A8wB2ks7FQ8JJOL9NyMMYmHiYsxiwXWs0mvsxAbsDK37fCPAJrs1bN2978MFW8xGPaMR/IhBC9Vr/CKijWP99WL0Fa8HGxZWVb2P1mwYJprB11kxj4tRac+VxMCJb4CTOhZFYw+czpvAZ7tNhOTbDwN8O03T2saMnnvibr/2trR/9j48eP7VwauY9H3+vMVpQBrYmwMoKzFVoplo84YMHXFkKob44+DM5CaPTxF7BFIxw89iJY8GvvPpXHv+873vebTCNs4dnjr9xZW31F0ncfprG5zlW5zfs3PBXjbXJy7H0cRTG7f9dXsWHmBrBDth5Lr3MYHnktjUYfji0SVhOfCCqefVqo3UchvuO83/o0h/HaSJ+EQ9GvLG30WxchLnNIbTnEHR4BJT6boj75if+8xM3w3gb4ww62PrQFyDjHXAGO2BYr6L5pV7YBsADtyFo/M0/vX37z7/oJQ9gGW7H8vLS/Fe+8dWd+/bvn3jKE55y4qwzzz4Mg346oIHhb2z99Oc/dQFw22ScEQqMMASPe/Qld0GHyRPHTuATsbhQYGRhj2LL5i2N6anJnwK+++A0DLqoz++FTJxaon1u4buCk2diKWgCatHBsH54oe/QIVuwKIUubTyIM2f/AbxejDo7kD6J9asZONf94Hu01Zw4gtnEU0F4D8ST0QPwPF/DNKeJJs/hq7t8/XsfPtd+d2u2ubK4sDiNejt2BwGmgcGNbYkajBAC6ihGqDPLNAUGZmrlvpUzp6caZ3LNCOlz8bdzrTGxDabpQhgJ3vSLWNw4BoO7GYZ4L5ZEHgPDwTEzcfzkkeXPfelzGw4fObwZ9egWAth+WEz+j41P/IMVbl50HOYRFsYLhKHlQx0UwOJgE5flNLowNgt4kv4CvpO0cPNtN5MvHQ5sGwhwhcspXL5Z+RKeuo9Dxt6p1cnXY21mN6g+3FxpfRE71Y/Ap0LwgaVgAR/02A8h/D75HWBzJuTvhRM6ALm3g/dNCBfe/f53Nx86+NCTvnXHt5586+237f3mHbe9EAZ8A/Si46OV5sY3Xh3A0d6lU5fjvQossTQ+ibZegad7LOPguZsnftCc1/35656NvwZmStPLeGkP8jhxYJtnzz7j7MlbPnPL50HGmdn0/37HG5+EYnCl3YYYMIWc1W07tsFttu54+e++/Ocgfo648KIuO7fvJKI3HXr40J2zs7OPQz080Juy1sICm2u+kkJSnnii7pzUQECrtbS0ODs3O0ua4zD8/wXv9kzEsXneOIkOOsw6YPd8TJIOoJ8Po0FfwlzoBmC5htZNttYmtmAmeV4DL9ljAOyDe3xo08bpQ0uLzU0tdDvOrB3G6ayZ1oHWaY3TGgeohF6jg4A6itHpy1ItOXn7ycfMzcztwOvA2/CUPQ+jAOMwgQ3Y1jlgtBPGBQa2dQSGZhEGDbOJxg7YoQMwIGfA3E8ffPjQZ2Eof4ymCFeDhgnr6nzKRgQmCH+gD3VCYIho02DzwdvMODCTWaYxhdENtm/dvnLt77zueiQxu2kcef6zn//lW2675UWk58Ys5OCN6aVNrbW17wRTPkXzCf0xkIyPJzVugtD/xPIZvoTU3IZtgceBfBU67Xr9X75+85e++qVLrnn28z+6d+/uh6//3PVPu+m2m77rtjtuOw1LNzMwsFuhD7+9gdNT2A/oaMwcWHE4NOTTWrdOzJ+8ZHZ2DjvywVnbNm+bhEOhgzU0rHbw0MEN0zPTYGeayyzjbMh/30P7znrc0y+54qsf+8pbcJT3MTd+7cbN2JA2T/2UMT01vXrm6Wfi5+yCczGzedpHP/3R78DeAnwHDhthVYztf+lP/dJtcFh/s3PnzgPYk/jv4H86/uiIuUDVOPzw4cWtW7YtbN60dW3+1Pw5yIUHBlhYI4OIb6JxcOWNw3BJqLW2A32L42MNfAUQ+xet5tk4EIarhR5sTUHOA0D5cWA8j29CLWMecmhyau1LE8uTm1ZmpuZXVpfmVk7O752Y3XSksbJIO7Iwuzx7MDjH7AuRkV4jhIA6ihHqzDJNwW8xnI8vk+5tNhuzMMTz083pb+JU/hSe2mdhnBbxtgPWiozBwy/5BE/FHGEDHnkfxAe9b0b24Xvuv+9sGLIpHNOEn1mFm2i2YNWwdt1Y5VIVlt65/EHHsQpHsAojzydlpk9haaR5/jnnzZ7/yEfd/7u/+upvb9u6fctZZ5yJ+UNrFgs6F8M0B8+/+vlb/vgtf0wFYAnNUz2fnmHTJh4Lo8aTRGfACB7GQaw3LbfWZvBRCbzaDHOGk7w4nTWDJ+MLUH/7377nbzfvO7Bvw4c/8WEeAabDWcWfuYgXIngeZkthIfmrPxBi5KBM9oNZTke4K3yi34pyvDEIRCwnQV601219yYJJCGAJwFxbmzoxf3zXt+65ffMnP/vxjx98+KEXg7ZDAaeLCdXUSWA68b6P/Gvz2PFjsNdAdbWJo0T4Ou3UVOuKy77r/0O78WMRkxds3LhxATTY08fCGlXHfvWFT73wArKEA6PzYhvRCNOuiV//w1de9KZr33wbpkfnAmjsQTS47MUXQnDwFSeWJho3gDe+Dz+BAwAtvADCpargBNYN4Rin4CmXN06uwp9OYQMbjmFuZmJutTkzM9VY2YNexQ9eYCMb31iETGyI6zVqCKijGLUeLdCe5XuWnwIjhIfFxizWiPD0ODndWmotNDY0HgFDziWnz+Po6iz2FvA519VzsI3Al6224YF7I8rxIaRg9RlXPOMcLK9gYxQbvlh9wX9rFz/m4uu/eN0X/wpG8ZlYUdpy6MghHuNcPOu0s47s37/v6BlnnrFMgzgzhRcWguDRMHDb8VbDaXBYWB9vPYAnWuzINjEmWxdecvElx8CYjkXW4mEC6Uuan5yemP7QQrBwYnp1+jH4OYVzJvGoDAX4jgCXifZAzw2YcrQ+9umPbT3w0IE5c+onNNlQtzUNYwazioV9XMwgX8pCVugkEHKWgwtL9ViRwXXu2eceBfkeUJD8wCLWcpCNWVd0kZPxFcZDwClBddCiSqMFQ7+2d/feU4+94MKJF7z0x58FWj6/h26kzeKOu+84a8djdvzohg0bsE8QbqQLd7QhuPz7L3/lS37qJa03/P4bHo2TRmetrKwYZ0UaKMU3u7kERudjLqMPYsT0nz/43se96Y/e+A7sP+D18GAXkOSJpkUQn0KNY2j40VZj8puYTqA/Jh4BjqvYtzkHbYYvXjuCN7K5wU5B35ybm5vHkeqz0Dp8WqS1xp9/nV+aP2vzeZu/2hatwYghoI5ixDq0SHNgVI9gQQPPmsF+ziJmmhN7WnMTWyfWJs7CevMmGLbtDazRw9DMYCtzFnlTeALFsc5gGU+eO2GI9+zasWsD6LisgdWg8Cjmt+/69qVwLvg5CGyWTs3Mn7Hr9IN4N/h+TE3mzjrnkedDHjZCsVHaaD0KT7pzODmz3Gqs3Q2DegaOj87BuO+A/jtgnHBOPzgK4zqBZR8+HdNB4BBWi5vfn4DdPWeqMXNJMLl6I/aGJ2H8llDnlZgRzBw9fvzU1q2b92IlZss1z/lvJ7544xe5KSzLQ1DZXHj7wCyR0TfQkJu9AvzLWRG/7wS/Zexta9PGTavf+cTvPPwPf/muk7DBm2ArV1Cy4ZKLLjn6mc9fjydw2M6QlmLwQN5Y2LJpyxqMaWvr5q0tvCA3gVNkS8962vd++bW/+Yefu+PeO7bfefedPwuZK6iHD1cB1fCiTE6f+K0m7AvHL9BTzuw7/u4dr/mXD/5LC46DR39jjoY1yAMXo1JmPNup+VOn4YHgR+H6TsduBJascHaZy3fYo0DeUSw4nQnf8N3cAwdYkxgcIJ+EA1/FRjceDvAjhdD0O4DBxXD++zCh4suBh7HLshE/OIV9j4kFCtVrNBFQRzGa/ZrZKqwlP3B06mhzU3PTdhiBvSs4vt9orV0EI3AA6y3fxvLS8/Dm1Nl4lIdRh4HAqgusxwG86vsZpJ8Ao3U2nM2ps854xKGbjx3l0U9eNHjbYax/GDOVm7EJOrs2EezH+djTp5uTF8ChLMKY4FsdwT7sUPwEtl2xsBLsw9nQC1oTk/xcKz4F0cSLFzBbsGCnTp06TucAy8fjpTh62qTjmtp98W48FbfmVtZWZhDym1F4boeFxwoLHBhMJJZcoOx3POk7Tn78PR+983+98dpt2IvgGX9z0YriWgZNEwac7y20Ljjvgnksg5246lnPOXXFZU9tbpibm8by2GEsq+Esb+MEltzOR+UtqMN3FE4hPPGaV/zux5775ef+D/DispLZQyEI733be996+WWXH9q2dRuPlD4d9RZBvx9ubgGtueanX/7T56Fd8KVAA/sPKMfPVayaGQzaiJRRU4y8SfAf6EJY6NAaR45hW2BlxZyKgsiOozLeFPsRyAuX08La1K2FpSq+wfJ9gGoRIGFvAm9d4+cxUHkH+hS+u4n3KNDfmIBAtVNwo3iXpnkvPrK+AIf+PaC/BG3FclSDn/j9T7TthsnW5Cm8cIc1xbXjMxP4+pNeI4uAOoqR7drshs2uzuLZf20L7PXFsE5c98Z5+cbjYZdxRHQNS0OTeJpvzjWwNwEbfAoLJQeC1Yk9fK4HPdY8Gthb2LEdhgdv/fKRnAa7MQ2Lg9MxzT1IY/G88RgYmE3NRvM0GMH9MCjzoHoO7D/XtGlj9+AYzw6sn/BFLTxdN7hmvg8F2Iheuxd1eCJqmpvJJGaLFhYXdkEeLCq0CK8GXIkxUnQSyDKzgS9/9cubn/vCH9jCyQ6WkXiK1dDgcx4rP/OCn/nolZdf+ZlnXv5MvHu3/Upw4tvR+O5GA8turWMwlnizOsAJLDSrQWOKPZEguBOP+8dgqb8JwXe845/e8UTOpDADodHHsVGzRBZc+thLD+IY62PgXJ8AjfGUjflY0NoITo+CN5v9+q1fxwktxCCAddiOTbObVn/v1///9s4DzI6zvPfzzcype/Zs1XbtqnfJcpWxjG1sA8aFZjAETAngkAAXSEJySUJLgBRq7hNCia+dCwRMdSgGY+PgBrZVbLmoa7VN2t5P2VNn5v7eWdnYFCd54MmTaN+RVnv2nJn5vu8/q//7vf0D//e9H37v9czzGeYs+ZzzZQ2ivbF0uXJRnLBW+UwEQYhNa0trH+cEiViiqW+oT4IPuFgMcpaPeaiO03pB53Yu6Aao53NxjufQxBnreT3JeXm+urlvlDuXOSfNpSv5eQP3SXNOiddzyOejTDwUXJwv/pOcYCGv9Tg9EQh/UU/PpemqfhUCwTcCZ9qfbsZButxUiHqx7Scgwl4xRcE5EIeEncLLlp+EZsRMQbhsgNJhUkQY0ewamiC8FNo9jt1edrowpUN2FixSKQeDw4NzIiQQFrgOfMmu44IAU5DdzSkSYTRtXGoOIVTgmt0wcT3cvgw5IM7Tac6hc4+1OpWsvQZylE0y3MSQpw55LWPJ8eR78l3OgyRFIECVSBgqJ+3Zt6dL7sF8ZJ5iVgqjrT75gU+O4ixPkrhGlFEgzohGSJUddpCHOHHGBqNkfoiJ6xsMNsbnJYZLQ+sykT459+ZP3XwAjcQN58FMWFcouMrVymuwP8UIM3qAGR7gXK6xu/i4Zf2F67cwOZEPogWJ8Atn3dHWMfjON73z0VRN6n6ZI2M84+DsYPOGzTPr16zPcZ2s8+mgkFsRCdCAgqM/O9rbt6tvz1uuf8uwOL+fXDvfnWKxKGau46yPLGtrHc+QxEDCYnnY4I6GRdoc2iIrWcmElzN3iQRD+wiWsbJZYGczERzi+d+M9jHFuYYghijrr5FFJFYmBp4xaf3htEJABcVp9Tj//cWY64wHsSSjJNlRpmGLX60QTuo+l11/pGr8H+K0PER4UR77AyYH9pRi7oAk2TCu5GUN/CZ5CFhNnIa2lrYBPhPiDklSCAxSG4JEBrhfmXNW8dkQQuYEZEN1arKgsY3jJG1mP7qCsd4Cx0im7whKwglIaZCv73LN/2ElX2tf1j71iyvicz5mYowon/Ez+W1ic1o8GCN8T8iLlAePsNuQeGVucj7fmAL5B76ph8wl1LWFO1FyA7MK9Y/4oiWfdT+mFNbpXAipRv/lW//S/vY/e/u2+x+6fxtS7wrObXv84OOvZAwGFsEZHuHEljU3i4lnJULlcgY6h09bmG36ngfuSY9PjtOzTjb54RJCQQdGwYH7DnwBjaMNn8aFOLLteCwuvphQqHGmhA5nMKWd2HPnnkcGHx68C61IzEtyn3Bg0XvCwzZnMrflb339W59KegvfZzyen0RRXYHZ782st4PL2RAYqnEFZOqZcb6jObFtMGaar8PceIDbH+KNUV6LOtfL91voKj7n4oBCxcHdTgiE5RT5Pfoln0o4Mf3ntEFATU+nzaP8jy+EDtIlCP8EdSkaUQbaILaDsNxjEEUdWdloGKYdRpMiQ6shkBREn4eMoljUH4Q80AyImiGMlqxo8R3IDl42HMLU1s233Dzx5+96f8517EE+6YSoaBJhneTekgNQz/c1iJ5GmJ7cPjOI0UaIiBrhRN1YQR2vkwRs3mbH7brGhsbNJ0ZPXIVDOOzVICuUMZKJZECEj9jpZewAwbcYSrooC4T8Pc4pv+GVb5jb+9jexompieQpf8AiTwfWSvbRx1nPJczlYKlYXA05SxG8w5/9f5+tfv5Ln79hbHJsNffHZkVc1aISY3311q92dXd2n/n9L992pHVZqwiJkK5ZnyTLhaG1n/zsJ7vf9+73EVVkVRAWhOKipQSm8OP7ftzM+bKEpw7Wa7W3tM8h5yT5ou1Nv/OmE39/49+vlfshcCWCK9i0dtMsEWbTH/vA37HDN2mOIzOHpm5Jrkq9DnxtNAe5HxKdbIdqdSziRAYwPbH75+ahTJK7hRoX/xqEf3CEsW4jSOEc3kVAmijPnwgoq8IJu7jPDLKYMOWA/ApxiQT3og0SKx0mRmakVmAYp+wbBKLbjjqSiy9P3ieT0OP0RUAFxen7bH/tyvgPHq+Q1GZ7pZ8VilCob2di6Vij4wVN7IAv5cJOIpUG4BrIziabGBKxDf0OcIB6fgbSeIJmQ4n1q9Z3c66YQqTktRBTsP/Q/pGIZf8Ui3oz5QK3IyiSEGE7foQ5KKaLa+cRCmXsQVQG8iUE9nLICY3Frw4ND1q3/uDWCy7ZeVHjuWft+HAynnyY+14phIlpxUgpECHQW2+6tXDe2edm8guFLGXBjzKuRGAdxdQ1xjnDTiSKGclDAJrxl//uy2+ABEVAhYeQ+8c+87Fl+w7uS/90989WE+Vaw27bFaLl+2pOEtJdPLhIzFZCtLwh9Z7M0PBQ4orfeeHmvXfsvVNYlHdl085JHPyw9/G9hJjabyCngD7ZXj1aE2a1YPkLL33h+I1fvvEV0m0iPHfxH3/3nbvfxW3OYIie9/3hn0+iLURvuuWmdhzW9vKO5cVdt+8a4voGvqiugo8kwERk23fhw7+OW0R5X+YbhsWSK9KHSa0VwV4VXwzhy7FwmMW1B+9479u/8Q9/89mD0P9laHwdPAdCm6wpFnEWaxGtr4d7tSP9mKOZQ1eb96v2ACFiEwjMRp7Dcga6YdFfbk4gJCbx49/P+p8pAZ+2QH15eiDw9F/a02NFuopnRSDbm22hPHSZ+MrGIBKfjZsSu+EIu1gSu6p2nWeq52LSptYPoaAktElasonYM3iMB4nvaWXv7NqBF/e8yqqtGzZL3aQwRPbUoIZw1GvitfGfFBYKUjfpHEglA5U1QpgupH+fsCqENJBfyJ09NjF22R994I86jg8ej5IUR0hsWNLC+sjff+RVV1x6xdo7vn77Xem1wvEwHf8wr3CYc886dwRne7WmpmYBYsMG4n/H8Z1RhFE6YiIEW5mClNhjjpd/5H9/pPGSl19iEdIp17KBtqyP/sNHN5+6ZWg2Cz/gRvKenCMvZJ7hD/KaBYTCAl4VODK5TPCpL3xackFCjQKSlVM5k2qAdQ3gRA2lspVAyOQpUniQHXnh4vMu9j/4ng8e/MinPrI+X8iLBhE0NzSPp5O127nNaoav5W7173nbe8pveu2bHiZjcYYsa5aCT8OyprHzUMvd38dEhomMxcQX1kt5amAwCAjZFX8C/gXT85bXvKX4uS9+Lsb78nywsgXBHXffcRH+BZImxdRmyIkh+kk2AWKG8n1xZhMya8rIngHGJPTXkDfi7+TiCKoLCXp+7fvb4wAANv9JREFUiSVKWZF9yNtRfFZjiT53t6xdj9MbARUUp/fz/aXV4bTuIhyzTNZbK53LVpogniKgv2AT0URqAVVGnRk4ZwohMch2mlBO04y+sJLgmWMQwwSEArH4L4F/jnS0dz2ItvAeiCl0zEIiVjabTRcXimgJZgsE+jgTWMCRbHY9uuuHf/Anf/C2sfGx1+YWcmIPXwzhhOo4L+Ra+QdakzlH77znjh3Xv/31K+Radvr0zgl37aFvAtK/E1NREcdEE29LlVgJyR2B0I+QOVxL6CwV8+xmPCk9TfVNNmYoyQyX6CO23sK7iwfn/FwYCNlDy+EcAIAjnAg/h4dcIYJAnOKU2ii/9x3/e+Bjn/m7CyDi8P8Q54vW4Y+MjUg9LAqrSrSY1c94HYyzHmjib3/zO4Lnnv/c3f948z9umpyenLz1n2/9DDamsFkR15DcyCDGmmisa2zj+zJ+knpUy8CEKDILf4K9BrVmClNbqb6uvkoPCkkeDNfAGBb1n1o5X/ws5m/f97dHKAOylSQ+4mrxyyDPz9x25rd5vodAGae1tZIpo/dQ3E8CDGwj0W1VhFyWavFSFLGX+0jxw/P5nGQWf4B77yZF+xB2wONoJCVwzZrnaQ8KsDztDxUUp/0j/vkCITJT6stkCbyZLxWsfNSlU2bES0cISw150Q3WkdSWZceIScF/PoZpqRQ6B2mJY7WDDXU3hNIJIeOAtm5vb23dKLZ/dtnhILy28Sucee8D97rDY6Otn//SZ68eOjlUS10i8TF8nJOE1yRCSl6ExCpygevgpjAXgqFC3iOKKTCDJwfqiSwS4QBPhpqI7I79D3/6w8v++k/++h9son08qxTH3NSJxtLOvLGZ290Q/kpOIznOJFuWtdpbNm4p3PfQfeKs5i/0eGoi8h1MQooP34Il+TycA/PDyhN+Km9Jn4qA0t6Fv/mLvxl62VUvH+PnbuZmI7Q4FZbmLHCQulV9LOkJNAG6w9ndSKVLWSlCypoRhWTbpm3BFz7xhQcZj4q35gauOQzJfxMBPk7cMVWYvGs5lwCDYA5ksBBC4iTa8d48pVEOkk6SAouGd//eu3/2V5/8q8tZp8xSTHKmub5BhI5AK7fyHv7xI4cvf8Vl6ydnJp2u9q6Jb974zeP4oHJoI/Ws/CFOTCMOWym028zzL6OxzHHvJLeUiKdrQX0LcxZMSMoL9rFpwPTl11csr74mqBkrFUoEAgR57sP09DidEVBBcTo/3V9Ym/yHzh7N4md2YiknPi1u45ydK1lltwjPTKA5sIv11kEaq6E+OqXZ0otAiCIKcXRxO6KWAsiLGHtjXwhJJbGFS1CqhF6GDI85qfGa111zCWOxP4fdsV0IgUJkYu8Pw2jZhWNjsknhQP6gEnBueC3nPjVj8Uv83vW/N/d3n/146sTwkNQQIvJGzjSGYoE7MTOR/0cXPePMc4994bXGauWe5yN8KKeNLY3cDJQD/7Yv3vboBS++oOvA0QMSpiqczt/FoeQFtww1BZmjEC8O4iqhqmbbxm2lbZu3z730ihfvIUP78LpV61YwjiQFrswXyHRm9qcmLDcM7/jIE49IVViKJ5qNAJNGYyDM2MxC51M4gSm+Z8hZsHq4rlbcOuCwjrle4BmvF6zP5LM1eexykHu1Z3kP4ckyAv4hEh5lXXxO2Y3gsne/9d09m9dvnn/jO99Yh7Zkmhub/WK5Mh2Li5Chwi9lxVlW8bav3LYbwd2EKU+ilnbg7BZ/gwjNKPfE5EhYcOBn+c5+gd+IIKCOFtnbgbWH+ZDHQmg0ZijGnGT+hzkPKeJ2F4PKtkRP/EsyOz1OfwR+/j/z9F/rkl8huz83ezx7HtkJRVrMjVUSkYJTdraxn38+W3ZM0WYzNCq1niRrF2IO6uGyBARCxdGgH8Lr530hR/y6wTF21avXnb/udUQVNYQ7W0iZz8JsaUg03GXzVkig/Cy/a8LLoUiBIBdNQCHDy1vQJadgPvEpgeF/9M8+OnHdNdcVz7ninJZjfcdSp4iYM4yU27Z6H+zN0xv7UWQQuQzWGDR9go9q+DzOvOlras9ZVe9awjhPhHOy7HL/yf79O67c8TpMWXVkTtvbN23P7jx358hZZ5w1TzRTpLOjazbqRmbYSc+gTnQjQqiaKz0trEPEIT2Gz/4F3GslsyW81FQb1tW3ybrlkIXx2oOwi327+g8geMWev4AYlFIbssBJoBjjuvN4T3biRHgRe0QDIcKn7onYZo9nmcbBk4MpBO3vgmnXGZvPeOyOr91x0wO7f7rlln/9+vkPPfxQ17LmZbGR8ZEOBGnkhtfekBHnOFpc5PpXXE81XcxOTIVDYOIvWeWYihiX2ISgidckzJFD4QezfIi/iVqvmAZBfozP5fmIXyLH+Q8h6I6D70/zVW+McC6q8nr1kq+BBlUwRAskl0d3cb4eSwQB+eXQYwkhMHN4ZqdLxhsmkgKEmcR+/dx4NIrpgaQqE1CmwUxAtHQzc3rYsqNV4EuwsZUb57Oc8y7IR4jzJmzUlKAOkjhIt7/2919zHaaqRc1AfqMQBiFxsnXluzCphI+KEhEe4Yecwi7dpGvT5rILL/dff93r57s6OnvbWjvSqBrS/+IwmsLsdW+97rwf/duPehhbbELwmKFeYcQaf2J8CjI7wtySfETilxVDaJD+Yd/NOezcrZ18vglBJS1CC1z6ODfI8HqGNbDDx5Eb+Pgx7AuI/KT/s2g8snZDYybrMOQ9zndRMRIiOCDTKzl/FWto4B7if6i0b2tvxjEt+SEhOzOWn0zU+OMHxr7LmvvQaaTw3nKmJbv3XMQ4w8S8IjgCsrSpdyUVeoPgCCN/F5zC3Iftl29/PTWz3oTQkX4cUXHgC0FzSCiyfAeIRS1Ifm2ZL8vkD3Lq6hdcPXjL524ht2FRGrNmrEUkDAb+IfDkQQQUMgzEd4TWIe1Ppby6GQIL6UmR5Dop4zHOZ4OcQ5IdobG2nSH5MEGwQE/VVFEkgr6km+w1PVolVvBfKoeanpbKkz61TggPvhKDEi0GbNMapaopLobdjiNmaS8HaXRBnnWLu1DqAvmSD2AvkIW7jfJ2LlTlcX2CAoLzEMnyK593Zf3AnsF7tz5v6wX0QEjIDhtSFJWjyv0DTB3wVDBfk6pZaG9tz5+7/dzJs7ednd+0brPV0dp6srtrRZT7S2KahN6uJNrHhT2xKUkiXDB/1aVX/fiHd/3wzRBYKCRkGVJJlXuTyGdBpphY2EmzrgcwBKUIwd2JgLuI+hL0dSZXw9iYVay9UGcH56xkbgf4LklwJImZ5m/869c7aLiTeN0rX8d6QufuWdWqd95D+3bN3PvA3Scp0FfP+C01Nall+EzSjG3L+MxZ2BjTDFG1AMhcRSMCIcqdB/YkAhg3vMkyXgYAGgkbEoIfhbrFTCfVWnuh+wT0fwRs+7i2EWtaO8L7YjCs5yv8vxmORYkQWTfXC7JPHvKG4ADgUD6WuO/c/p2utm1t5dHHRu/mHcxVFHcMQ2utGFfOUXblMNjWS8l4bjfFdWiJ4isJ26MOc+9jYCNCAie3v5XldLI2EbwtbAw2YOY74TneECYwWbseSwgBFRRL6GHLUp0YhUE9a8ZzHS9u4scrpK7hOWiACKSAnRAIpcPJdbAsei/DRWxFMbnITjPle570K5ilB8IW3pYoIjGv5Gtra6NDDw/d/c3vf/Osr3z7KylILtve3j5Lwtrhl7zgJZmXvuilU+xYW+GzVRDa/dwrzTltEFkXZo1V5FYswLZt6DkJ7l1xIk6B3fkQTtbY+WfvWCfT4BBBwcvwEMasRZsYQwjRE8MukshBGQ6rwBxrERAID+hMdvK2neO+5Ar4o/DbNogaYeHhWLGcD378gy3f+v636jCn2F//3tfsufn5VP+J/iQd6ggVrrZDkptZpwwKd6Jw8M+ThxA4bEn/DjHjU+WPTGW0pioC5z4ml3F9W2pVrUSVquN9aicFJ4GM4ouCQ4AgCQZCWWPMvfTSQE56m4kObqFUe7y3v/dJ38fiYheVsqeTs0yEpbMK7FUIrXBi4GNnspn4+p3r1/Y+1HsjADSCxVYc5dIgivEFwGCC0AQc5dbj6EtiYkSwWatYWzfPYpZbPMbzIMoJM5Yh1NY2CF5+C8CTTYIAcWnJy0gordxDjyWCgAqKJfKgn1xmPKDsD+xGT4dCpVSZj6bsFFzTjtlGQlYJfTXjhO73elLXSWgBUw2Ui0AwdZDmz9jaUnLcaoRkNvJzIySJsxY3J36Ba69+xcgrr3nloxBlPVfm+ex7GJw2QEyrIUZ28ZbUgermnveKUYc5XcJ57ZCSx46b5mvBqFzH+3vZvUpeRXFkchSnbCghiNDkDwfkFfo3eDtHVsc84UYIHHsVYyzIfSG8GU6VUuVSUClKLt+ruK+UvYDcgsO8L8Kx/svf+vIGWrm6QvrY/fFtmDh+F4qZ80c260Ks/An/CoDyEywvf/niVqByKtkMR/djf/jWP8q+9trr26HwMgG9DdzmQrzKmHTMSd7DlOefCVCzXEnRQeqZ+9ZC4MaO4i9uBwxqMJkWChYO3nbXbVvQyEJhISMJQRNQJmNKEAC3CcPMkA8SmMVHzFSmJwdvBKxlDV2iEPyBNFkS0xy42JsRAAhssxWMKsieNLOXXBAJkQUyi452Bo0yTFRsQnDRW9WdZyypwbWGc3czkUGuXRFfUyeOcT2WEAIqKJbQwy4OFVcTBDlrHH+eKBs7ICbINcl5r1ISu/xXeQ+HBHzNxhTyuAiC2QnxUK2V3hXsPNlmUjbc+gpxL9Kj+rkQvFSJrbDzxjlqHoDMxGx0BrvmBVhtFPNRpFL1BiFlSnRLRI0/RZxThs9TkOQqGJ9IG0kORjsxfp5x4Ga/BIl1EtV0CMGxOxlNrn6KqMWNwETloJ2pv23TGVSqpbd1yOdWmvl2Mp8F5i9Z32QSmq8jPM7kdKZgT/K51JWSlp9BpVxxKD/uoPWE95N/QtaFdxmCjXj4Y/iZkK98xlSfvqsPTwhJGprmPpte+/LXjrLxFjKew+4Ux3qURoiVWNQMF7YhOEhDsIvcezNTGGJat0pbcs+Oj1Ct+yBj1OJYl8RCEYhocqDFZEQgvPplr75/45qNuWuvunZ3e2vLRL5UfMnA4EBLV0eXs2bHmjM4N5wrgivECFnS7bhuAsOU+Im2cj/8EOZBJi1Z7Di2WaCPIKF1He+VUBdiDCU+Gvw3/gLaXIn5HubaLaxb+m5IiZMVQNMQDqT/LCkEVFAsoccNoWPioZGDHa2rOJVYFF9pvpKX0hgZCFlahOJVMDFI5VXsHs+D0FLsTMuYbqSqLBm7QRk7t1QYzUMmGchEKr/OQyK0VrMPYr66CNIhQxqfh2+tY1veTUbvDhipG6Kkh4H1NTi3g635ekhyhs1xHKJvwyQzihaDYoNJjFLXMF2RLwe5VW5oqGtiXkLKixKC58U8AsJTpW3rGnbhJT6Y4xScttKEB/XE8oZEekDtmxAWI1zcxb1jkCbzIL+BEtqEwJpfKKex+JvACfxh6syW/BGGCkt8gwv3W1RmGFdeMyFmJpPjmJmbiTEXSpOL38KslL6vzPQxMGmHxGk3S2eOiDtEUvUQtXYxm9l30L81HynFnZJDWQ/bGqBASbaprmkHta2kCi5qGm59xqFY4MKNH7/x88xHGggdkRlGUvE127eeKQJZ+nZsZQqLTu2Q/32rd+B4sH71+jKCcphpklMifm0jiX/SF4Nw40AEK94q088iO1FKEghX+o5Y9zLGH6B9fBGBdSXypJHzeQA+AobaLz3Jdy0Cpf8uJQRUUCyhp53P5wN8FAkczLia6StBUSap4BGJRdxStUQbVBzIxl4FeZyNEGCT6Y8SIUX0jzS1sSmiZ9cgIMiFIGMXpzicNMQmW3aqRYTDdknLY/Mbt333QghSkrjiGEwQMBQFFAK1ERyBfT6Qr2UCZ/G6lh02FEblUuPvxyEyhMkJx6s3Vq06ogE0Hjh86F8RcFvYVYu3HZ5btADte/yRth3bd8xw3zhs2gWfSlHBPshaci5SzD2NOW07zm2iknDe0k+Di4e4g/SckPLaI3SyK2N2EsH41G8Br30isYap2Dpzyc5L+j7wxx96qKGhsTo41HdmY12zvWxZ0/706vT7uT/jIM5kUlzDHKUk963Ed1Eiw68V0mXOKxBIuIEqda4bQduw+kjYwL4fSFLbtjIixXeKs+JnIAarH90sPbeQSVCjCYWDP6FmQxMnhCLNnUiU80erJkLob8G2K/a9DP4oGewJBn8dYy1OhdlwpXXwyIHs+lXr7kEfKdEZ6VHK/A3wzHvA5nqeXw9nSY7HvODEtR3MnSJ/5gIehmRtx6kd/xG+A63pQ5Wip7Z1F0rOqsJg/oZET82NTwGmL5YEAioolsRjXlykceJ1uE3rQ+uSbzI0AVpglzsVFINWGpRVEQKt2NQxCVmzmEsIkwxNTgcdE22C2Lt8EzxKAcHnY6JKEfqZoLz0nZB9J7y0goilLhiqCc2gBZKk9Kn0ODBbee8IfHqMuCByuO1XQlC8F3ayS0LS0BuxupaJccV2jO0LEC6Va+3lmKJOIhIuJFGshfBQ0R4WJcSp5/XYwceQMYaGQpKKgB3elkQzC0exdRxnfA8Utxy3Bxtz6hQRUQUhNkCM0oMhBnlyf8v69Ic+3X/Dn9ywQW4JUYp+YNHhbvrOb/z4S5B0F36CHO/RsjXIrF21fpBLNs5nMxdDrBF23fwo14WUblFShOXht7H8Tt6dQASPMkFqKHmUXYyKn6CdKwj7DYh0MpxsCd5U4Q3WMH+XFMa1Qto1iRpJlhNNAuZfnBfOdhc8KLGCtZB7WFSE9yJBD4NPzGXmejg/nIucL0JCfiJ5UgodTjJeBK9SDc+rHnNeP3P6HFh+EA8MUU/+o/wsAQniUwJhbxxMpSLsHO8JN4ggGUbY/sQreXudWLXXsWNaUlxwXmKHCool9MBrXBfbM8YjmB/iyEEK5Rq3Zp7aqsXcVG6E3e845R2kG10B1mQH79GbwVlOYTuKzdl3wG3SwGcvpFLP94dxD1cQCIPs4vPQ7NmYNyh25/dVLX8Lu2SJRpoB3ii7Z/wZQTPj9kLikhRAwUFTYS5iF59mzAMQrvSQlvpGPZhLSB6zhJAK5Hj8kKihl4hQYVwx+YRPrCaR+gnn72eneyZuBbQgT5rviNZANrmNhhMMcD46TtDBe0WExCAsigZkfYvX7SQlBNe88JqO6F9E14opiTVTZs+xDh490AIBv5pBJjgfYRXs4nw61TG05ydd29nCeRJTzPAcqENCzNwDe1ToixCyppie1QBuT0Rsaw9dL4om4m/gzEsREkmeQB/r2CVpDHSKGEf7ItKMsGNCZPlqYL2Szs5d5VaLIU8ve8OLa776T199oMFuKJUiwe8jRciDMNb37vjeTsElBIV/ECZPChjRrJrR+CoIDcn9KIH3RoT7Sk77EYJOkgGzYPMaLka3sW7jHMxUVp8n50tZeWM6kX7SJ30Q7WvB6sThrceSREAFxVJ67BRrIGGq7Jf9QiEozDf6jSVrAYrISPRN6NiUMg4UmnMSREhiN4fCxVltBz+E6HGK2lezG4cPvbuBbTlCoofvHWgLg5bv7ccUsxVfRRbN4zieTzEr9cOkNZD1OHz6A0h9I9dLFjfFBQO0DOt7UOXvQrrSYa4EqcW5ZgryyjEP8ZlQTsLaQolxh111qFEwuNBzcPtPfnDxJ/7yEz8igOsg+QrbYVk229YyduqYx8IeGpQdQXeS3TKEyCrbYXQpINjGTn4/bHoQ279BEwgKBUw5i/2rrYWitMRmZYsRYM3MZSeltPuhbNEI1kxOTTaIA1xUFdYgO39kjzFkes8yPj2kwwZAUuZDopaSVR+fj1sdhPxXcE9KnxBBFjrc/QZ0Ctnti+YlApXbmyeiTrSJ8iEZfB7S6e+pg1pNnX/6/j/90zvuueO5lE2pZb6Ss5IYODHQiRCV0iih0xshJleZFzzvBTnWSySbf5z149C314FLK3iKT2eP5do/QtvZCT4SjTbONftZDo/aJnIaZcSnhhNlXcibOCbBBpZdrKkOB+tcO/EY59LsSI+lhIAKiiX0tPvn+ye6Y91CnCbqRWNFt9gYd+PFyYXJXDqRrsPdSU1vzEL0BgIW2p7Soc3yIUnrcggRsotI/+peCK2Bn9fzvQN2q4GlImTvJSkxuBkDk8+OGZNNMCXCABrdynBCLG/EVv4TDCqP85mE1Z6HieNC6LZAkt0jOH9bEBJUm0UJME4L5wtZjaAZ1GMi4zT4mEF5PzyK5TJOWT9Gpwq28uYI2sxGPkhyYndoYiLck9NbEG/pUBfw/QbknsT+S1QVmdUklcGYUlkWH4A4juX2VF+vBrmF7L/VJGsJ2w3jftcj4DZx3RzXTS7v6qkQTXQWvSZEuwlnJN+JePoi50yiPSHR/DYEGiYrNC2fNrCBsx6zDiYvpxGtap654s8wTahIuyksKD6KatEuOpgArYnszGaisWqYxzP+b970lZv+jPmHfT/A4ske3VJZ96kw2lOakdSq8lOp1DHmkaSclmhvyAj/KPMRjY3z6XPuezcImMzhBPfrZ/2b8Q9hNsPZHfiTjHUIAX0XsODayqcIaUizhaiNdIXPktP0WEoIPOOXcSktfCmudfPmzeVvfCOYfuUFGJsqtP10rVwmk0nUJeokEa4H+wuk4ixgZeELM4NtdrPzxuyCq5UdPvy0gGFDehlQFdXkIRQpbRFBmAi5HBSNAdPTCJoFtaEo/WCCWhSRm7FxV0hZvp18hkvQUMYh+HMhUGL8qajqWNWKVz0Xwvw+EVCYSOx5TDb3soslzNXgCwmk77WHRkH0LbQGu4kEKZVK0Qjb9KrnZ5mDNNu5mo9qIUEpBEiymIXJyc9BzCfZaxPzynqlAquxJ7gv0UKEzRp/WASE/Dl1hNJixwt3XLX//oMPgINoC8dkTKKWZOS2bC4DiVfC0FXWEZI0c/Uefvzh8xEYuyFkj9F+IlIHTCRhr8Fygzob+xLDTOKHySG8KKwIIRt/DrHiTOWnis31zcWyKTe/+i3XvpdoLEmEe8bBfFk3/zAJcED2suJfcXDKYoAT5cllxuGCPB/zmTSeom6VoWCiRf9zMra5HPsZYgoguKqNnwWXNHOek5yL7FzWc2vceuZbjq2O9TPk0V8xpL61BBBQQbEEHvLTl3gdPbODscAZnx53WpOt1XR9uoacAmklKmUw2On6X6HJ6BDW/enyZE0h2Vy6Hp6N4aDGXm3th1CkJPgqdvoJXtLC1KcMtr0WTn0Vu3S25sEwpJqm58UOeJwuaWaD+AswTVE5wqaDnr8SgdRIYOYwbEdyX5jbwFZeEsRkl+9/mUirLIQljnB8H9ZwMpm8nfIgL4If8YGImAj/ive1B4H1NmFwrj3ER2vFAsN3HNpmBn9CD+fic8Hg79AD3PJrGJ/6Sza7fm+EknwvoO+3PTWz2Jqbu0qfJnvg5ED7hp3rnncqz0Kymn1MVBky0OswPTVhelrspXEKWO7p9A/1dzOLPgg5z+k5JIv4b04iRE9S7qQOoRtFBclBy4TwelNoVifjdkIc18VQfytaTVOZqUsHTw71QOSUCZdEuGccQMKqFv0RIgz4y4TDtXOXpx1oFDj5g+/wrsv3LM9LCj12cG071/AYEVricEe7gPzRHnGwU5AQ0YbApcaTFTyKBjTnJt0Y1yZpS5ssDZVSub7Z2tSqBjE96bHEEGCjpcdSQ4CaqBOt21rLc+5comiK+KTDkh39kNxJKoaORKqRCrtIP9awsA7yk3oSFBE0/fIZu02KwwWTEOEGfnmkXtG5xOhsgXFE66AokS+RRQmM/lRhDQ6jIRyAHCXUdQ8kJF9TbGNzxFMR1mlthezXwHZpvqSv9acxzzzEfaTOCHH9wfMZuuH4g8c/Q/e2HzF2FbILsKHbr37p71R4bi/mS3b1J7hmFSYndu1mEEHQi1RySbGmVajMKiTePHUL5ada5tjBfRvZNTt//Pt/jEMX3YPBEG7iewgd28Ojw3Vz83M1CIt6TFON+AxWnBg+0VQsYiIKN/bP+K0xnNeIMJPktb0Y36ZOhQKT/WzREpZKscyM66R1ac6rWLsSxURfMYsBrVROpIN0Paan5sZ0YyGdqpsCBymZUmQEEQRyyHfIffEQwcV85Wd841Sp/fl5LN8Et3z+lk+AEwLcpDAnrWdFY6w7hZDHtIiWFuaS8A7RCcwHYS7hwmE2PQLGzGH8G3UjqRwQviQoV3cQVttpe1UVEqfwX4rfVKNYik9d1vyX1I1+e72Xm8sV7LBiXRDEo/EqTm5kBBb4iFehepE4dfFzuzdBZLVu1ZWyHXuiOGQ5qQrhP5fM42WYd8oQTBmDyBOQ9d3w7R3EOj3hFbxudrcTEBS5FXauQmAS5z6B1/UyePlFwm9oFWyNqS/lBHPs5ofQQpxy1bsIwdODoWmEEyisZ7/xoR88kL/3gftm3/EX/yu2ce0m84kPfBJOtEaQAieheUkGjFFNYwotpxdBsJxby/UxBEKWISrCtDAjadCSeBdECMft4wb9OH3xK/iX8iVE/tRvg8yD+bDEp73Jp2g1TJ3tvGzuf34E52w/Z4bWrE2sFX8AQoukQqCTIkkShjqHMkTfaztTNeV5dIueXCk3Q5fBBV4nTNU0V61qAlIf33f3I2++56f3dF3/tuv/nJara9BeKO1B68FodADN6kQ+l8elY8efc95zdm1et7n56PGj3cs7lyeP9B5pokZUw7XXXPvolZddifD0tyJKxsFiCIGNb8OwXsxOhiqxkqWNCRDRNc5rMcVRskPKp9Du1vNPenb1iFPxWgnuypNKHsNfMplYU7v/58vVV0sNgaf/si+1tet6QSDYS5w9hhH8FfK7EIdaXVqV2qlYKlLySpTjwO9teaPkMhD/HyyHI9ezYxcl4wD/QJfBegh1nn39Y6ZaGV3wqrkap6aZXewOnKtBMp58mB35iyGkPL4GSYQbwjL+PmhWNIhBSJUWoD7lLax6nBBCzJTJNvtcx3kYDWfKq5ATQcMdttAriOKkbYOT51qyuu3P4fs4zPndmJESFd/v4X4d7Lu3c/5G7isaDpt5vOM2pUeMPQCF0/gn6IT6MU/RzQ1fCmT8eNeZXe+AKEWTEG0h/D+Bz4Q9O4GlIkFkn45Eg6AXfQPIE9YsIbF8YIKV3SuHDt57cB/jiWD9MeRMgT1HMqYpcytjWVIuPM37R9GGRhCyc+DtFyvF2YgVKSAIGrmbhLPWcG4ETDOoeZiDgsZQ5XftMrbBeZwTGZ4JGfF2klIr9dx7G9dIkyFplzrMbA3zpiESyoZNCCzSgrFKzHWG5/dizu/n+UlNL5QrfxpTYJpzZJz13OdY1bMOYDosY3YcQffp4PPzOH8u3hP/AufpsYQRUI1iCT98Wbo5x0j+AnnLViJTydhQq5+OpemWVox7tjcStaJx+DFNVdcSWcUkmvkDTsQ8HAncyWwlm4pH4gfyNfm+xhlqCNYEDVEn5RF/eyWVQuiRGhS4zxVc/xz4dBrCkkilV0C8dXDvMGT4kOWQQ4DA4b0TfJ9BgxiCqW3MQM9jLveQa7cPQqbJD329A7eVM2uI2Z2EhK/GJ7wCAfNo1DETdF2bxNR0OUydedKSTx0MKnmQkUdsJxniHoOk+DcC6dMbmnBcnAXlarkR30M5l8vFeB/HLpln+CkSsYQkJEoOgTjRE2BEFC5ikxtSONAnSmy+s71z9Ds3f+fWttY2NCppfWoNIuQk8W8aDSkD0VKLiixtIrfQ0uaZx8qK5y1HsxmpFqpHItFIGWe2u+AuzETdKDksnF8ho9uyexC0InSkm2CWAABxfNci86KRINKIOJKZkJ/iC9ETfoyvx5ghtDeSHQMpbf4A14pWI9Fpnbwf4/thxtrlR31JaqxDQL2I96QPCUX/MHVRBdiN2D1oXEWCENJogERoUR/Lr0qlWD2WOAKqUSzxXwBZfnCAVqcpupvZVnHBW6gnaSFBd9Miu0oPs1Oa4oFtfJfQ0aFcJTfbPNpcKK6pvAF94gIY6zBb9vvnxqYeb1zW8Ck4fgWZFn2Qj4/ZZIYt+MXs4o/RCOg+yEsigl7Od6RKIDWixMmKecgi+sh+EOJqJ2gIM41L5dLgCGb97Zx7IWQmpcYP4WF4gvj/H+D55jr7Kj5biQaxDOJjvkHade1e9v0HMLGcjTrQwBzI+vZn4P5BXpM8SCQXjmfInLBRmvQ4VjNaRuTgkf2dr3/nGzf0DfVJKQvT2dY5cvhnh98PIT9ClkMS0t+Enb52cGTwzGVNyzxCalk6mDF3CPokrymqSGQXwgwzGeVEPNw4ZhjCLhHB1cTuvxshIDWm2khjLLLzP1CxKneTLzFPTFkC7aKKFlcgO57i7842xl3BvQkwswtgsoBZqo91VhFQnWgWLQQXINAQg5RaYRyil8R8hNlosfkQuSfBowg4+mEHEu7ahcCYYow7EbhZmg6VK35lDQLs5ZwjghuY6c1tef2MMRjYboXywEWPzQH44rhxB2pWGCk/oscSRkAFxRJ++M+29GxvtgXntfTJbsPUQZKW6UdTiLJLJpFNemfT5Y1CHRydJIDdTq2oTXgCtmLmORsilmSIOHakEcJBv2tVqnQ0wOrtlYiSje2Emi6QsSFSqSrbiMUfE1RAxI39t7xNirQ9B39lsJe/mZ/OgFyPM540+1kH+ZGPEOZLsJNG/7ANpiuTJMSWjGb7uFiJiOmRMugYd4IFfCKH0DqwEQX7cRgcRzN6hBLr7TDtCtcO6qpVPwkjExpqD+KwTnz7h9+Or12xdvTyiy/fx1g4dAMihYz0qqbOoX8WwakrCAMmQij0XUh01iEIXYi5HvKNMnfajQYVxhdXhjRNKvO9C5JPox2w4/eGK8XK3XbMnsU8lbDpqy0OFhEqYJlBM+qiSGOcedex5qRcj2CZ4b51MgZCEYXEkv6vy1hDB6+lAiz9NoIHOV+CCaQcR00IL2XVGZvaUNaRGBVhFwhQcGNuA9W33sB5RK0Zmbdcm0fryTIfNMCgiHgNI65IP88lViUG5VnpsbQRUEGxtJ//s65+ZO9Isv3s9srCiYVlhHhKxE4LBFbLDneU4M1JXN7VukKlmo/KFtuSJLnLIJ4zYO+fIip+GouXpzNetD7umQhmnGIkHqmnnvhFEOYWdr/1MjikNocdno2yd4zU74cxiYxjkkoSotvmsl/HLo8Vy1tG4jQ9HczbfClsZ9lxPMZzmKCOcT3hrlL/iCQ2234Qc5VUYkXOeDsc1A8SjQdhYRL/gkOYbzL4CHz2/cVIIhKjLmIUEpbub8Ps+Ffx1QbZz0HY0LHXz8/zaAONELf4A9YhgrYzb7QZSpf4wUkEUC+OC1qysnM3VhOegRLjk9FMHop0yyPnnbCiAv4W6SInhL0PXMgtCRYiJjKa9/ItfF/NvMYx4cmuf65QKUTInG+ieVMjQsNIJBZObkqz41Q2VVaGAdB11nEPyX2pQUhRIdY/BuZ7mcNZzH8Vz4DIs7AkiiQ6Fnh9gnsbnmEj51KN1+oEP7oXBuM47SfRejIIogJzl7Ts6cArVWt7ag/I89FDERAE1Eehvwe/FoGOczqEaOQYyfYGLZFIqZUdLSly1lh2Mptvr2NjTsZAUJ9LQE7sdP15iOpHpFfAndbZfrZ8rx/1pnwnvi2ejGwiTIpKrdjUA9znlCZHp8D3gMPaBHfB6SciZadACfRsJVY8C+PKy3BDFxjrHth+AWLbRom/efIv7iNqSRzV2OgDqgoGP0MQVEKzfeBPUxm3yv2kTDkVvWk6YSIn8Dxg1LHbuJc0JYqz767BLEY9JvIGbHuE9dHkiMZMmF4QhGG5DyFkhEg9/0Ok7lGEdYkGJZrVOMIiw3klbFgIqaAODQk/CKXO2d0TliulPgYgbnIBvSZx+HO9R76H1FwivreKwgUGvlkBRmvkUtd2JzDpOaQEem7KpXKrUxuSOuoG1dCztGZNk1tSZscvjZkQnsG9+DIKkDthvtY00WkDCI1zEKtt3DvBlzyHcTAo4YypoxDwNKZDhgskgGCOJoLHEBDiaJevCfDNFqvFOcqHEGEV0IgileW+eigCTyGgGsVTUOiLfw+B6WMBpbunguY0qQH/RKG7D0HZh4PabDAc9d1UqCGwE46SCScEBgeZOBUIidjxieF3MA2RAGbQKCSTusqmPWKegOCyxBIVqEo3C/GeYNdOkx37BdhtMpD/bsxXXYTKpiB0qQArDYDIBof1MMMQVzuNfHoMKqa0CKYrO8C5a0PSYT9sKb/tY+kfZYxcNOomigv+CPW5UxjMJJ6J5DzMZ5Y/SZKItFStQp6Sm0GammvTb2gccpVoIDoAejh76W0h2c706JC14dUWYcjU0CACfAA4Q5iftIoVU5PUTuIkop5sa4r78pqILuPNep49jg+ghI/CqixULEJkGxAUwuKUJfQlOa4BIRRjd4/cwRyFSYgLRZvznagjJE81J2fad/wy/ow6pEx7peJtj7jSUc8i+AsrH0UMZU6CLfc6Sr8LyY2pwzTYQfLcBHn0C2C/EYf1BGuTSrH4+D0pN56i+F+v5NmE89d/FIFTCKig0F+F3woCBw4ciK5wVjRDYA30tyhSYmMZTlnfVOhoZ7Pht6KbIfIryJauw8o+jQnqIEKD2k7WpXwRzYTgsJ0CO3mJNEJzKd9O7sGZkF03woACg6YMEUYgwlrCa9n3WrtQYbiVNYg2QMkQdBLug79jHaPWco9jjFdHxOijVHDtFi2A6/eKeYUwW4pdRWy0CrpVU8Hc9WLs2DtJ8qhBAOCIptZRYFPCxHoOc1wGheOkNq0ETpUgcvwZzEPGk1LcIjDC/uJmQYiaOdFAyTrKeAUERg4hgB7hi1kuzs9ZdvREEgV58iLypUIphnDZwuc5NBBwwhuDc507Ig1oFlViyfGIJNSRKeJT1DBowAwl2dYECaAZ+JVhhJCY/S5DICwHK/qcU3nWqs5gvkNIS3dCI6XCh9Ad9iRSiRJJge0SmYuE6kHjiTCOVE7MIlPTLJzKfzV7zWr8PnooAk9DQAXF08DQl78ZAhCV/D45c/1znU7V2YrjdBZiP26Xi47vxjcQ6joQC4ozVavmHPwDOyA7Ib0keW1J+I06InY/O/iT7G6pF2WkWdFl3JP6TOyw2b3zmnBPNBnf/2YYx2r5dJWLZDDfSKVVAnWs9YwvNaKmq563mS15FNId5TOcs/YAXbkPViuElRrKhSN0SPMmrBWNxyZp0DI9EDUVYPkyph+/xAQmHoSHuwbVQe4pJbtxXlvbsf5I0loqFBYMiC1JtJxpyHqEXfsE4qMGgVRA8o1jgJokqS6G4AnnyA5+NBaLSXVcRi+4lkPYcaVWxJchCc9NRVIV4sCk30ViobLQjKCpcM20PBmEVILIszXkSkitpse4zyh9zxHA5iJwTqJFEGIczDAh/D0ezZLcLWhV9OymEmxAdBYaCiYvxhRXPP0s+AHDYTWxMvXPwd1oacRTmc20RtVDEfgFBFRQ/AIg+uNvhkDQT7VXU3iTT/8IKHS/40aPQKBOMV8k4tafaVjVkC8P5tZiuF9D2aHN0OU6CPgIJ+NcRfuwaF3Kbp09NKYeJwY7SsRTjLLnYn+XmH+aR+DINtZhiJyWrJQt9xAU9LGACOvFN0DoaD9kSdinUCKd+FBpOEeEhiS71UupWFQRqVlFST4c0D5CyFDKgvMQQhTuYzfPOdxPtAJ81NZKhBZ5DPg+qHMFMWPm8RFedN1j3lir0Iyc4ySAx8jw20ikl7QPpf8DEUuWPc2mfVq8ARD+SMyKzSIGsKrxp4j9aY+VNVJ/SxIfm3h/BdkOcgxbHZiZ6AMSFPEdZEpWiQgpu65qV12v6PWlEim8KJZTLFeudmk2hP/nJJauI3Y0QtkOQnDp3Y15rYX5toMFCpGpwWl9JOEk9nH3RqLUtqAhdSdWabe6EG/951kRUEHxrPDoh78JAggNcgcGrKlSKoLJxTTWEXSThdyc4ivYAUujIDbiiAcpBgiDQ9SSzZxHrqzGhCPNfKgCC/FzgmgfmEoykB4cT+gt5T7YMQ9isXo+PEj7TkP/bWz6rqGvQliMb46oIVwUwTJIcrxYqkjZcekT3YhmI8UFE9xTuruJ+aXITp1qhw6+XycjAUO4kXNuJCyUGK94QRdehPCg0hSxWL40JsLpIGG3lMIIqod9O1YylSIBTk4Lid+dpG3Dzk6FUFr6N+FEN868G7F6EQX5+Swii4T0umRd1SzDef5rjvKJ8g6EGIoPeSIQPdFfM7SynUeUGLpwLyA4pGhfI9pCnKXi37Y8xzetErsk2FUpXRU1mLrwiViRKNl6RFWVCvTCTTSi8fSaDi0Z/mug17d/AQGNevoFQPTH3x4CZmVY2M6aOppdiY2ItDLreMktPU924zicKVceTCEwpBwtPE/NIxgNIdHG+3PY/+F7Wo7SE1tmFIaJ2g6ZxF4JB3ISQq6F5J9DYp04ziX34hhO8aPkM59MmMpIrmBmqXm7AU0ijhmKbn5SejYySditCCDJEl9w4y5ZgX4DWoP0icBhTi6yh5kmEqEEiWmmvwZaRkDBK0qCV4MSEVVRSlwRIcWJDnOgdLlIFO7d7ARVDDl2plyNDNY41omy8aRBk5T0JukvqESizmSOvhMp7Fh1vlUYnV6w68+pfzKqTJb4S0ckEzlQqi1dIOAw3wkv5g3h+6k2pBtqECAe+SldlLZtQbMiTYKaXGHehTTowF1t+TSCsvP4P+bLdnku8KKoNVaRoiUmeUby5C8Npm8oAs+CgGoUzwKOfvTbQyB/PH9VNBKlvIa3EZv+SoiPWktGykNIbkAJOp2XXTCk3cIWnHwGfBFhq85gHLKth4VTkJ6U4JCeChdyzhA2ITbb/gJGpD6EzzD3E38E4UF+OeF4JUpD1ZWDStyvutliqWjqN9QPMZ6YYXB1PPOYPTS7Ih6Pr2CHPiZJ6DEnVil75TS+iiSahugAjmNHVzBvBBTqgvg3KHSIVwbTFUnTrlvEuJZJxaNT2YUyTudgFSYgdCZnjvbVJyulbJZSIRbGJg9vyOwzR/+P/xRMBrXcI8bc2sGzR5LzAlMly90psnbyS/xmBG604vnThNWOp1cl9/6q9f7HR9QzFQHNo9Dfgf8CBBAApjJcOYlj9hjmEDYnQYXXlAz0yH7ziex0pyoePTCo2YQ5SApoN+KYJoDJokep3cnOvAb+l2zhPKRHopsvrVkX2JwXLNstBdUS0USRCuVH2HTHPLtUji5EI14yRtWRij2TZD+e2Ngw9mxLbdjYMMDn8vXUMTIykqzz6uoo35GivEYKYRGD+BcQVrMEH0mZ8hqaMUVQiU6yuyermgOmJgU9T1bcNDWxSK5ziYQq0Re2VkxMDkLiWbWIpwb/dS9odVSOlXsQrFHGyqBNzLmkZ4ADVbro0UrJV6K0xqI9cfFF6KEI/FYQUI3itwKj3uQ/gwBNcF7Czn0WkZGkfMWUU/HnY0Flvmjc0MzE7nwdkUkpdshSiE9qFhUJgY3hb6BkuBnEKRwnimga4VHEnOXE3NgUDuJSvpRPR0zQ4FWdXCIW1lZKVFAOot01e/4z8/tV59LsqQU/xlbmNkGewRNPPyf4ELYockqe/t6Tr4MB8jv+i2oliUCmrGKtaTKZJ8fX74rAbwMBFRS/DRT1Hr8xAhKeWe4ub8TsI2U0pGx5hDKv2OKdLKakHAMYcg/GS5VSHbU3Kpl8eT4dTVfxCResLsJfsdEXvEIDWcqS9U192IoTicfSpiNy/288Ob2BIrDEEVBBscR/Af67Lr8wEvT45QXJcvbZxaeqXizvuiXxU5QQDVYimZBUt2ns9WGKWiFbaMA8FEXDcElEi6TSqSnTahYzpP+7LlLnpQj8D0FABcX/kAel08SzIY7cnOga5FO41ixu5Cj9pqulTEkipUqJ1QlxVuuhCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCSw+B/w8CzOLimTB/QAAAAABJRU5ErkJggg==" alt="다람쌤"></div>
      <div id="mascot-bubble">안녕! 나는 <b>다람쌤</b>이야.<br>마법 왕국에서 함께 체스를 배워 보자! ♟️</div>
    </div>
    <div id="nick-row">
      <span id="nick-label">내 닉네임:</span>
      <span id="nick-name">기사님</span>
      <button class="btn ghost" id="nick-edit-btn" style="padding:6px 14px; font-size:.85rem;">수정</button>
      <span id="nick-edit-row">
        <input class="field" id="nick-input" maxlength="10" placeholder="닉네임 입력">
        <button class="btn" id="nick-save-btn" style="padding:8px 16px; font-size:.9rem;">저장</button>
      </span>
    </div>
    <div class="menu-grid">
      <button class="menu-btn" data-go="pvp"><span class="mi">👥</span><span class="mt">애들끼리 대결</span><span class="md">같은 화면에서 친구와 번갈아 플레이해요.</span></button>
      <button class="menu-btn" data-go="ai"><span class="mi">🤖</span><span class="mt">컴퓨터 상대</span><span class="md">4단계 난이도의 AI와 대결해요.</span></button>
      <button class="menu-btn" data-go="online"><span class="mi">🌐</span><span class="mt">친구와 온라인 대결</span><span class="md">6자리 방 번호로 친구를 초대해 원격 대결! ⭐</span></button>
      <button class="menu-btn" data-go="puzzles"><span class="mi">🧩</span><span class="mt">체스 퍼즐</span><span class="md">실제 체스 포지션에서 최선의 수를 찾아요.</span></button>
      <button class="menu-btn" data-go="achievements"><span class="mi">🌟</span><span class="mt">내 업적 보기</span><span class="md">15개의 배지를 모아 보세요!</span></button>
    </div>
    <div class="footer-note">어린이 체스 교실 © 2026 다람쌤. All rights reserved.<br>캐슬링 · 앙파상 · 폰 승진 · 체크메이트까지, 진짜 체스 규칙 그대로!</div>
  </section>

  <!-- ===== PvP 설정 ===== -->
  <section id="screen-pvp-setup" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">👥 애들끼리 대결</h1>
    <div class="subtitle">같은 화면에서 2명이 번갈아 플레이 (흰색이 항상 아래)</div>
    <div class="card" style="max-width:480px; margin:0 auto;">
      <div class="section-label">♔ 흰색 플레이어 닉네임 (선택)</div>
      <input class="field" id="pvp-name-w" maxlength="10" placeholder="흰색 기사">
      <div class="section-label">♚ 검은색 플레이어 닉네임 (선택)</div>
      <input class="field" id="pvp-name-b" maxlength="10" placeholder="검은색 기사">
      <div style="text-align:center; margin-top:20px;"><button class="btn" id="pvp-start-btn">⚔️ 게임 시작</button></div>
    </div>
  </section>

  <!-- ===== AI 난이도 선택 ===== -->
  <section id="screen-ai-setup" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">🤖 컴퓨터 상대</h1>
    <div class="subtitle">난이도와 내 색을 고르세요</div>
    <div class="card" style="max-width:720px; margin:0 auto;">
      <div class="section-label">난이도</div>
      <div class="choice-grid" id="ai-levels">
        <div class="choice sel" data-level="easy"><span class="ci">🌱</span><div class="ct">쉬움</div><div class="cd">AI가 무작위로 수를 선택해요. 초보자 추천!</div></div>
        <div class="choice" data-level="normal"><span class="ci">🌿</span><div class="ct">보통</div><div class="cd">AI가 기본 전략(가치 평가)을 사용해요. 중급자 추천!</div></div>
        <div class="choice" data-level="hard"><span class="ci">🌳</span><div class="ct">어려움</div><div class="cd">미니맥스 알고리즘 (깊이 3). 상급자 추천!</div></div>
        <div class="choice" data-level="veryhard"><span class="ci">🔥</span><div class="ct">매우어려움</div><div class="cd">미니맥스 알고리즘 (깊이 4). 최상급자 추천!</div></div>
      </div>
      <div class="section-label">내 색</div>
      <div class="choice-grid" id="ai-colors" style="grid-template-columns:repeat(3,1fr);">
        <div class="choice sel" data-color="random"><span class="ci">🎲</span><div class="ct">랜덤</div><div class="cd">50% 확률</div></div>
        <div class="choice" data-color="w"><span class="ci">♔</span><div class="ct">흰색</div><div class="cd">먼저 시작</div></div>
        <div class="choice" data-color="b"><span class="ci">♚</span><div class="ct">검은색</div><div class="cd">나중에 시작</div></div>
      </div>
      <div style="text-align:center; margin-top:20px;"><button class="btn" id="ai-start-btn">⚔️ 게임 시작</button></div>
    </div>
  </section>

  <!-- ===== 온라인 로비 ===== -->
  <section id="screen-lobby" class="screen">
    <div class="backrow"><button class="btn ghost" data-back id="lobby-back-btn">← 메뉴로</button></div>
    <h1 class="title">🌐 친구와 온라인 대결</h1>
    <div class="subtitle">6자리 방 번호로 친구를 초대하세요 (방장=흰색, 게스트=검은색)</div>
    <div class="card" id="lobby-box">
      <div id="lobby-main">
        <div class="section-label">내 닉네임</div>
        <input class="field" id="lobby-nick" maxlength="10" placeholder="닉네임 입력">
        <div style="display:flex; gap:10px; margin-top:18px; flex-wrap:wrap;">
          <button class="btn" id="btn-create-room" style="flex:1;">🏠 방 만들기</button>
          <button class="btn secondary" id="btn-show-join" style="flex:1;">🔑 방 참가하기</button>
        </div>
        <div id="lobby-join" style="margin-top:16px;">
          <div class="section-label">친구가 알려준 6자리 방 번호</div>
          <input class="field" id="join-code" inputmode="numeric" maxlength="6" placeholder="예: 572791" style="text-align:center; letter-spacing:8px; font-size:1.4rem; font-weight:800;">
          <div style="text-align:center; margin-top:12px;"><button class="btn" id="btn-join-room">입장하기</button></div>
        </div>
      </div>
      <div id="lobby-wait">
        <p style="text-align:center; color:#c9d4f5;">방이 만들어졌어요! 친구에게 이 번호를 알려주세요.</p>
        <div id="room-code-display">------</div>
        <div style="text-align:center;"><button class="btn secondary" id="btn-copy-code" style="padding:9px 18px; font-size:.9rem;">📋 번호 복사</button></div>
        <div class="spinner"></div>
        <p style="text-align:center; color:#9fb4ff;">친구가 입장할 때까지 기다리는 중...</p>
      </div>
      <p class="footer-note" style="margin-top:18px;">⚠️ 온라인 대결에는 인터넷 연결이 필요해요. 같은 방 번호를 아는 친구와만 연결돼요.<br>게임 중 새로고침하면 연결이 끊겨요 · 30분 이상 활동이 없으면 방이 자동 종료돼요.</p>
    </div>
  </section>

  <!-- ===== 게임 화면 ===== -->
  <section id="screen-game" class="screen">
    <div id="game-header">
      <span id="game-title">게임</span>
      <span id="game-status">흰색 차례</span>
      <button class="btn ghost" id="btn-quit" style="padding:8px 14px; font-size:.85rem;">메뉴로</button>
    </div>
    <div id="game-layout">
      <div id="board-wrap">
        <div id="board"></div>
        <svg id="arrow-svg" viewBox="0 0 800 800">
          <defs><marker id="arrowhead" markerWidth="6" markerHeight="6" refX="4.5" refY="3" orient="auto">
            <polygon points="0 0, 6 3, 0 6" fill="rgba(245,197,66,.9)"/>
          </marker></defs>
          <line id="arrow-line" x1="0" y1="0" x2="0" y2="0" stroke="rgba(245,197,66,.9)" stroke-width="10" stroke-linecap="round" marker-end="url(#arrowhead)" visibility="hidden"/>
        </svg>
      </div>
      <div id="side-panel">
        <div class="pl-card" id="pl-top">
          <div class="pl-name">상대</div><div class="pl-color">검은색 ♚</div>
          <div class="cap-row" id="cap-top"></div>
        </div>
        <div class="pl-card" id="pl-bottom">
          <div class="pl-name">나</div><div class="pl-color">흰색 ♔</div>
          <div class="cap-row" id="cap-bottom"></div>
        </div>
        <div id="game-actions">
          <button class="btn danger" id="btn-resign">🏳️ 기권하기</button>
          <button class="btn secondary" id="btn-restart">🔄 다시 하기</button>
        </div>
        <div id="online-info"></div>
      </div>
    </div>
  </section>

  <!-- ===== 업적 ===== -->
  <section id="screen-achievements" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">🌟 내 업적</h1>
    <div class="subtitle">15개의 배지를 모아 보세요!</div>
    <div id="stats-summary"></div>
    <div class="badge-grid" id="badge-grid"></div>
  </section>

  <!-- ===== 퍼즐 목록 ===== -->
  <section id="screen-puzzles" class="screen">
    <div class="backrow"><button class="btn ghost" data-back>← 메뉴로</button></div>
    <h1 class="title">🧩 체스 퍼즐</h1>
    <div class="subtitle">주어진 포지션에서 한 수로 체크메이트를 만들어 보세요!</div>
    <div class="puzzle-grid" id="puzzle-grid"></div>
  </section>
</div>

<!-- ===== 모달들 ===== -->
<div class="modal-bg" id="promo-modal">
  <div class="modal">
    <h2>👑 폰 승진!</h2>
    <p>폰이 끝줄에 도착했어요. 어떤 말로 변신할까요?</p>
    <div id="promo-choices"></div>
  </div>
</div>

<div class="modal-bg" id="gameover-modal">
  <div class="modal">
    <h2 id="go-title">게임 종료</h2>
    <p id="go-text"></p>
    <div class="btnrow">
      <button class="btn" id="go-again">🔄 다시 하기</button>
      <button class="btn secondary" id="go-badges">🌟 내 업적 보기</button>
      <button class="btn ghost" id="go-menu">메뉴로</button>
    </div>
  </div>
</div>

<div class="modal-bg" id="badge-modal">
  <div class="modal">
    <div id="badge-icon">🏅</div>
    <h2>새 배지 획득!</h2>
    <p><b id="badge-name" style="color:var(--gold);"></b><br><span id="badge-desc"></span></p>
    <div class="btnrow"><button class="btn" id="badge-ok">멋져요! ✨</button></div>
  </div>
</div>

<div id="toast"></div>

<script>
'use strict';
/* ============================================================
   1. 체스 엔진 — 완전한 규칙 (캐슬링/앙파상/승진/체크메이트/스테일메이트)
   보드: 8x8, row 0 = 8랭크(검은색 진영), row 7 = 1랭크(흰색 진영)
   ============================================================ */
const VAL = { p:100, n:320, b:330, r:500, q:900, k:20000 };
const GLYPH = { k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟' };
const PIECE_KO = { k:'킹', q:'퀸', r:'룩', b:'비숍', n:'나이트', p:'폰' };
const KN = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
const KG = [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
const ORTH = [[-1,0],[1,0],[0,-1],[0,1]];
const DIAG = [[-1,-1],[-1,1],[1,-1],[1,1]];
const in8 = (r,c) => r>=0 && r<8 && c>=0 && c<8;

function initialPos() {
  const back = ['r','n','b','q','k','b','n','r'];
  const board = Array.from({length:8}, () => Array(8).fill(null));
  for (let c=0; c<8; c++) {
    board[0][c] = { t:back[c], c:'b' };
    board[1][c] = { t:'p', c:'b' };
    board[6][c] = { t:'p', c:'w' };
    board[7][c] = { t:back[c], c:'w' };
  }
  return { board, turn:'w', cr:{wk:true,wq:true,bk:true,bq:true}, ep:null, kings:{w:[7,4],b:[0,4]} };
}

function fromFEN(fen) {
  const [pieces, turn, castle, ep] = fen.trim().split(/\\s+/);
  const board = Array.from({length:8}, () => Array(8).fill(null));
  const kings = { w:null, b:null };
  pieces.split('/').forEach((rowStr, r) => {
    let c = 0;
    for (const ch of rowStr) {
      if (/\\d/.test(ch)) { c += +ch; continue; }
      const color = ch === ch.toUpperCase() ? 'w' : 'b';
      const t = ch.toLowerCase();
      board[r][c] = { t, c:color };
      if (t === 'k') kings[color] = [r,c];
      c++;
    }
  });
  return {
    board, turn: turn === 'w' ? 'w' : 'b',
    cr: { wk:castle.includes('K'), wq:castle.includes('Q'), bk:castle.includes('k'), bq:castle.includes('q') },
    ep: (ep && ep !== '-') ? [8 - +ep[1], ep.charCodeAt(0) - 97] : null,
    kings
  };
}

function attacked(pos, r, c, by) {
  const b = pos.board;
  const pr = by === 'w' ? r + 1 : r - 1;
  for (const dc of [-1,1]) {
    if (in8(pr, c+dc)) { const p = b[pr][c+dc]; if (p && p.c === by && p.t === 'p') return true; }
  }
  for (const [dr,dc] of KN) {
    if (in8(r+dr, c+dc)) { const p = b[r+dr][c+dc]; if (p && p.c === by && p.t === 'n') return true; }
  }
  for (const [dr,dc] of KG) {
    if (in8(r+dr, c+dc)) { const p = b[r+dr][c+dc]; if (p && p.c === by && p.t === 'k') return true; }
  }
  for (const [dr,dc] of ORTH) {
    let rr = r+dr, cc = c+dc;
    while (in8(rr,cc)) {
      const p = b[rr][cc];
      if (p) { if (p.c === by && (p.t === 'r' || p.t === 'q')) return true; break; }
      rr += dr; cc += dc;
    }
  }
  for (const [dr,dc] of DIAG) {
    let rr = r+dr, cc = c+dc;
    while (in8(rr,cc)) {
      const p = b[rr][cc];
      if (p) { if (p.c === by && (p.t === 'b' || p.t === 'q')) return true; break; }
      rr += dr; cc += dc;
    }
  }
  return false;
}

const enemy = c => c === 'w' ? 'b' : 'w';
const inCheck = (pos, color) => attacked(pos, pos.kings[color][0], pos.kings[color][1], enemy(color));

// 의사 이동(자기 킹 노출 여부는 아직 검사 안 함)
function pseudoMoves(pos, r, c, forSearch) {
  const b = pos.board, p = b[r][c], moves = [];
  const add = (tr, tc, extra) => moves.push(Object.assign({ fr:r, fc:c, tr, tc }, extra));
  if (p.t === 'p') {
    const dir = p.c === 'w' ? -1 : 1;
    const start = p.c === 'w' ? 6 : 1;
    const last = p.c === 'w' ? 0 : 7;
    const pushPawn = (tr, tc, extra) => {
      if (tr === last) {
        if (forSearch) { add(tr, tc, Object.assign({promo:'q'}, extra)); add(tr, tc, Object.assign({promo:'n'}, extra)); }
        else add(tr, tc, Object.assign({needPromo:true}, extra));
      } else add(tr, tc, extra);
    };
    if (in8(r+dir, c) && !b[r+dir][c]) {
      pushPawn(r+dir, c);
      if (r === start && !b[r+2*dir][c]) add(r+2*dir, c, { dbl:true });
    }
    for (const dc of [-1,1]) {
      const tr = r+dir, tc = c+dc;
      if (!in8(tr,tc)) continue;
      const tp = b[tr][tc];
      if (tp && tp.c !== p.c) pushPawn(tr, tc);
      else if (!tp && pos.ep && pos.ep[0] === tr && pos.ep[1] === tc) add(tr, tc, { ep:true });
    }
  } else if (p.t === 'n' || p.t === 'k') {
    for (const [dr,dc] of (p.t === 'n' ? KN : KG)) {
      const tr = r+dr, tc = c+dc;
      if (!in8(tr,tc)) continue;
      const tp = b[tr][tc];
      if (!tp || tp.c !== p.c) add(tr, tc);
    }
    if (p.t === 'k') {
      // 캐슬링: 킹이 체크가 아니고, 사이가 비어 있고, 지나가는 칸이 공격받지 않아야 함
      const row = p.c === 'w' ? 7 : 0;
      if (r === row && c === 4 && !attacked(pos, row, 4, enemy(p.c))) {
        const kr = p.c === 'w' ? pos.cr.wk : pos.cr.bk;
        const qr = p.c === 'w' ? pos.cr.wq : pos.cr.bq;
        if (kr && !b[row][5] && !b[row][6] && b[row][7] && b[row][7].t === 'r' && b[row][7].c === p.c
            && !attacked(pos, row, 5, enemy(p.c)) && !attacked(pos, row, 6, enemy(p.c)))
          add(row, 6, { castle:'k' });
        if (qr && !b[row][1] && !b[row][2] && !b[row][3] && b[row][0] && b[row][0].t === 'r' && b[row][0].c === p.c
            && !attacked(pos, row, 3, enemy(p.c)) && !attacked(pos, row, 2, enemy(p.c)))
          add(row, 2, { castle:'q' });
      }
    }
  } else {
    const dirs = p.t === 'r' ? ORTH : p.t === 'b' ? DIAG : ORTH.concat(DIAG);
    for (const [dr,dc] of dirs) {
      let tr = r+dr, tc = c+dc;
      while (in8(tr,tc)) {
        const tp = b[tr][tc];
        if (!tp) add(tr, tc);
        else { if (tp.c !== p.c) add(tr, tc); break; }
        tr += dr; tc += dc;
      }
    }
  }
  return moves;
}

function makeMoveM(pos, m) {
  const b = pos.board;
  const piece = b[m.fr][m.fc];
  const undo = { piece, captured: b[m.tr][m.tc], epCaptured: null,
                 cr: { ...pos.cr }, ep: pos.ep, kings: { w: pos.kings.w, b: pos.kings.b } };
  if (m.ep) {
    const dir = piece.c === 'w' ? 1 : -1;
    undo.epCaptured = b[m.tr + dir][m.tc];
    b[m.tr + dir][m.tc] = null;
  }
  b[m.tr][m.tc] = m.promo ? { t: m.promo, c: piece.c } : piece;
  b[m.fr][m.fc] = null;
  if (m.castle === 'k') { b[m.fr][5] = b[m.fr][7]; b[m.fr][7] = null; }
  if (m.castle === 'q') { b[m.fr][3] = b[m.fr][0]; b[m.fr][0] = null; }
  if (piece.t === 'k') {
    pos.kings = { ...pos.kings, [piece.c]: [m.tr, m.tc] };
    if (piece.c === 'w') { pos.cr.wk = pos.cr.wq = false; } else { pos.cr.bk = pos.cr.bq = false; }
  }
  const rookRight = (r, c) => {
    if (r === 7 && c === 0) pos.cr.wq = false;
    if (r === 7 && c === 7) pos.cr.wk = false;
    if (r === 0 && c === 0) pos.cr.bq = false;
    if (r === 0 && c === 7) pos.cr.bk = false;
  };
  if (piece.t === 'r') rookRight(m.fr, m.fc);
  if (undo.captured && undo.captured.t === 'r') rookRight(m.tr, m.tc);
  pos.ep = m.dbl ? [(m.fr + m.tr) / 2, m.fc] : null;
  pos.turn = enemy(pos.turn);
  return undo;
}

function unmakeMoveM(pos, m, u) {
  const b = pos.board;
  pos.turn = enemy(pos.turn);
  b[m.fr][m.fc] = u.piece;
  b[m.tr][m.tc] = u.captured;
  if (m.ep) {
    const dir = u.piece.c === 'w' ? 1 : -1;
    b[m.tr + dir][m.tc] = u.epCaptured;
  }
  if (m.castle === 'k') { b[m.fr][7] = b[m.fr][5]; b[m.fr][5] = null; }
  if (m.castle === 'q') { b[m.fr][0] = b[m.fr][3]; b[m.fr][3] = null; }
  pos.cr = u.cr; pos.ep = u.ep; pos.kings = u.kings;
}

function legalMovesFrom(pos, r, c, forSearch) {
  const p = pos.board[r][c];
  if (!p || p.c !== pos.turn) return [];
  const out = [];
  for (const m of pseudoMoves(pos, r, c, forSearch)) {
    const test = m.needPromo ? Object.assign({}, m, { promo:'q' }) : m;
    const u = makeMoveM(pos, test);
    const ok = !inCheck(pos, p.c);
    unmakeMoveM(pos, test, u);
    if (ok) out.push(m);
  }
  return out;
}

function allLegalMoves(pos, forSearch) {
  const out = [];
  for (let r=0; r<8; r++) for (let c=0; c<8; c++) {
    const p = pos.board[r][c];
    if (p && p.c === pos.turn) out.push(...legalMovesFrom(pos, r, c, forSearch));
  }
  return out;
}

/* ============================================================
   2. AI — 미니맥스 + 알파베타 (쉬움: 무작위 / 보통: 깊이1 / 어려움: 깊이3 / 매우어려움: 깊이4)
   ============================================================ */
const CENTER_BONUS = [
  [0,1,2,3,3,2,1,0],[1,2,3,4,4,3,2,1],[2,3,4,5,5,4,3,2],[3,4,5,6,6,5,4,3],
  [3,4,5,6,6,5,4,3],[2,3,4,5,5,4,3,2],[1,2,3,4,4,3,2,1],[0,1,2,3,3,2,1,0]
];
function evaluate(pos) { // 흰색 관점 점수
  let s = 0;
  for (let r=0; r<8; r++) for (let c=0; c<8; c++) {
    const p = pos.board[r][c];
    if (!p) continue;
    let v = VAL[p.t];
    if (p.t === 'p') v += (p.c === 'w' ? (6 - r) : (r - 1)) * 6;
    else if (p.t === 'n' || p.t === 'b') v += CENTER_BONUS[r][c] * 3;
    s += p.c === 'w' ? v : -v;
  }
  return s;
}
function orderMoves(pos, moves) {
  const b = pos.board;
  moves.sort((m1, m2) => {
    const c1 = b[m1.tr][m1.tc] ? VAL[b[m1.tr][m1.tc].t] : 0;
    const c2 = b[m2.tr][m2.tc] ? VAL[b[m2.tr][m2.tc].t] : 0;
    return c2 - c1;
  });
}
function minimax(pos, depth, alpha, beta) {
  if (depth === 0) return evaluate(pos);
  const moves = allLegalMoves(pos, true);
  if (moves.length === 0)
    return inCheck(pos, pos.turn) ? (pos.turn === 'w' ? -100000 - depth : 100000 + depth) : 0;
  orderMoves(pos, moves);
  if (pos.turn === 'w') {
    let best = -Infinity;
    for (const m of moves) {
      const u = makeMoveM(pos, m);
      best = Math.max(best, minimax(pos, depth - 1, alpha, beta));
      unmakeMoveM(pos, m, u);
      alpha = Math.max(alpha, best);
      if (beta <= alpha) break;
    }
    return best;
  } else {
    let best = Infinity;
    for (const m of moves) {
      const u = makeMoveM(pos, m);
      best = Math.min(best, minimax(pos, depth - 1, alpha, beta));
      unmakeMoveM(pos, m, u);
      beta = Math.min(beta, best);
      if (beta <= alpha) break;
    }
    return best;
  }
}
function pickAiMove(pos, level) {
  const moves = allLegalMoves(pos, true);
  if (moves.length === 0) return null;
  if (level === 'easy') return moves[Math.floor(Math.random() * moves.length)];
  const depth = level === 'normal' ? 1 : level === 'hard' ? 3 : 4;
  const maximizing = pos.turn === 'w';
  orderMoves(pos, moves);
  let bestV = maximizing ? -Infinity : Infinity;
  let bestList = [];
  let alpha = -Infinity, beta = Infinity;
  for (const m of moves) {
    const u = makeMoveM(pos, m);
    const v = minimax(pos, depth - 1, alpha, beta);
    unmakeMoveM(pos, m, u);
    if (maximizing ? v > bestV : v < bestV) { bestV = v; bestList = [m]; }
    else if (v === bestV) bestList.push(m);
    if (maximizing) alpha = Math.max(alpha, bestV); else beta = Math.min(beta, bestV);
  }
  return bestList[Math.floor(Math.random() * bestList.length)];
}

/* ============================================================
   3. 업적 시스템 — 15개 배지 (localStorage)
   ============================================================ */
const defaultStats = () => ({
  games:0, wins:0, checkmates:0, checksEscaped:0, streak:0,
  aiWins:0, hardWins:0, onlineGames:0,
  fastWin:false, longGame:false, perfect:false, difficulties:[]
});
const store = {
  get stats() { try { return Object.assign(defaultStats(), JSON.parse(localStorage.getItem('chessStats') || '{}')); } catch { return defaultStats(); } },
  set stats(v) { localStorage.setItem('chessStats', JSON.stringify(v)); },
  get badges() { try { return JSON.parse(localStorage.getItem('chessBadges') || '[]'); } catch { return []; } },
  set badges(v) { localStorage.setItem('chessBadges', JSON.stringify(v)); },
  get solvedPuzzles() { try { return JSON.parse(localStorage.getItem('chessPuzzles') || '[]'); } catch { return []; } },
  set solvedPuzzles(v) { localStorage.setItem('chessPuzzles', JSON.stringify(v)); },
  get nickname() { return localStorage.getItem('chessNickname') || ''; },
  set nickname(v) { localStorage.setItem('chessNickname', v); }
};
const BADGES = [
  { id:'first_win',  icon:'🎯', name:'첫 승리',        cond:'게임 1승',            check: s => s.wins >= 1 },
  { id:'fast_win',   icon:'⚡', name:'빠른 승리',      cond:'10수 이내 승리',       check: s => s.fastWin },
  { id:'defense',    icon:'🛡️', name:'방어 마스터',    cond:'체크 5회 이상 피하기',  check: s => s.checksEscaped >= 5 },
  { id:'cm_master',  icon:'👑', name:'체크메이트 마스터', cond:'체크메이트 10회',     check: s => s.checkmates >= 10 },
  { id:'long_game',  icon:'🎪', name:'장기전 마스터',   cond:'50수 이상 진행',       check: s => s.longGame },
  { id:'beat_ai',    icon:'🤖', name:'AI 격파',        cond:'AI 상대 1승',          check: s => s.aiWins >= 1 },
  { id:'hard_win',   icon:'🏅', name:'어려움 정복',     cond:'어려움 난이도 1승',    check: s => s.hardWins >= 1 },
  { id:'streak',     icon:'🔥', name:'연승',           cond:'3연승',               check: s => s.streak >= 3 },
  { id:'friend',     icon:'👥', name:'친구 대전',       cond:'온라인 게임 1회',      check: s => s.onlineGames >= 1 },
  { id:'puzzle',     icon:'🧩', name:'퍼즐 마스터',     cond:'퍼즐 5개 풀이',        check: (s, pz) => pz >= 5 },
  { id:'perfect',    icon:'💎', name:'완벽한 게임',     cond:'모든 기물 살리고 승리', check: s => s.perfect },
  { id:'student',    icon:'🎓', name:'학생',           cond:'게임 10회',            check: s => s.games >= 10 },
  { id:'champion',   icon:'🏆', name:'챔피언',         cond:'게임 50회',            check: s => s.games >= 50 },
  { id:'rainbow',    icon:'🌈', name:'무지개',         cond:'모든 난이도 플레이',    check: s => s.difficulties.length >= 4 },
  { id:'superstar',  icon:'🌟', name:'슈퍼스타',       cond:'모든 배지 획득',        check: null } // 나머지 14개 달성 시
];
function checkAchievements() {
  const s = store.stats, pz = store.solvedPuzzles.length;
  const owned = store.badges;
  const fresh = [];
  for (const b of BADGES) {
    if (owned.includes(b.id) || b.id === 'superstar') continue;
    if (b.check(s, pz)) { owned.push(b.id); fresh.push(b); }
  }
  if (!owned.includes('superstar') && BADGES.every(b => b.id === 'superstar' || owned.includes(b.id))) {
    owned.push('superstar');
    fresh.push(BADGES.find(b => b.id === 'superstar'));
  }
  if (fresh.length) store.badges = owned;
  return fresh;
}

/* ============================================================
   4. UI 공통
   ============================================================ */
const $ = sel => document.querySelector(sel);
const $$ = sel => [...document.querySelectorAll(sel)];
function show(id) {
  $$('.screen').forEach(s => s.classList.remove('active'));
  $('#' + id).classList.add('active');
  window.scrollTo(0, 0);
}
let toastTimer = null;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}
function openModal(id) { $('#' + id).classList.add('open'); }
function closeModal(id) { $('#' + id).classList.remove('open'); }

// 별 배경
(function makeStars() {
  const box = $('#stars');
  for (let i=0; i<80; i++) {
    const s = document.createElement('div');
    s.className = 'star';
    const size = 1 + Math.random() * 2.5;
    s.style.cssText = \`width:\${size}px;height:\${size}px;left:\${Math.random()*100}%;top:\${Math.random()*100}%;animation-delay:\${Math.random()*3}s;animation-duration:\${2+Math.random()*3}s\`;
    box.appendChild(s);
  }
})();

// 닉네임
function refreshNick() { $('#nick-name').textContent = store.nickname || '기사님'; }
$('#nick-edit-btn').addEventListener('click', () => {
  $('#nick-edit-row').style.display = 'inline-flex';
  $('#nick-input').value = store.nickname;
  $('#nick-input').focus();
});
$('#nick-save-btn').addEventListener('click', () => {
  const v = $('#nick-input').value.trim();
  if (v) store.nickname = v;
  $('#nick-edit-row').style.display = 'none';
  refreshNick();
  toast('닉네임이 저장되었어요! ✅');
});
refreshNick();

// 화면 이동
$$('.menu-btn').forEach(btn => btn.addEventListener('click', () => {
  const go = btn.dataset.go;
  if (go === 'pvp') show('screen-pvp-setup');
  else if (go === 'ai') show('screen-ai-setup');
  else if (go === 'online') { resetLobby(); $('#lobby-nick').value = store.nickname; show('screen-lobby'); }
  else if (go === 'puzzles') { renderPuzzleList(); show('screen-puzzles'); }
  else if (go === 'achievements') { renderAchievements(); show('screen-achievements'); }
}));
$$('[data-back]').forEach(btn => btn.addEventListener('click', () => { stopPolling(); show('screen-menu'); }));

/* ============================================================
   5. 게임 컨트롤러
   ============================================================ */
const game = {
  mode:null, pos:null, movesHist:[], captured:{ w:[], b:[] }, // captured.w = 흰색이 잡은 (검은) 말들
  lastMove:null, selected:null, targets:[],
  flipped:false, playerColor:null, aiLevel:null,
  names:{ w:'흰색 기사', b:'검은색 기사' },
  over:false, aiThinking:false,
  online:null, // { roomCode, myColor, pollTimer }
  puzzleIdx:null,
  pendingPromo:null
};

function colName(c) { return c === 'w' ? '흰색' : '검은색'; }
function playerLabel(c) { return \`\${game.names[c]} (\${colName(c)})\`; }

function startGame(opts) {
  Object.assign(game, {
    mode:opts.mode, pos:opts.pos || initialPos(), movesHist:[], captured:{w:[],b:[]},
    lastMove:null, selected:null, targets:[], flipped:!!opts.flipped,
    playerColor:opts.playerColor || null, aiLevel:opts.aiLevel || null,
    names:opts.names || { w:'흰색 기사', b:'검은색 기사' },
    over:false, aiThinking:false, online:opts.online || null, puzzleIdx:opts.puzzleIdx ?? null,
    pendingPromo:null
  });
  $('#game-title').textContent = opts.title;
  $('#btn-resign').style.display = opts.mode === 'puzzle' ? 'none' : '';
  $('#btn-restart').style.display = (opts.mode === 'pvp' || opts.mode === 'ai' || opts.mode === 'puzzle') ? '' : 'none';
  $('#btn-restart').textContent = opts.mode === 'puzzle' ? '🔄 처음부터' : '🔄 다시 하기';
  $('#online-info').textContent = opts.mode === 'online' ? \`방 번호: \${opts.online.roomCode} · 실시간 동기화(약 1.2초)\` : '';
  renderPanels();
  renderBoard();
  updateStatus();
  show('screen-game');
  if (opts.mode === 'ai' && game.pos.turn !== game.playerColor) scheduleAi();
}

/* ----- 보드 렌더링 ----- */
function dispToBoard(dr, dc) { return game.flipped ? [7-dr, 7-dc] : [dr, dc]; }
function boardToDisp(r, c) { return game.flipped ? [7-r, 7-c] : [r, c]; }

function renderBoard() {
  const boardEl = $('#board');
  boardEl.innerHTML = '';
  const checkedKing = inCheck(game.pos, game.pos.turn) ? game.pos.kings[game.pos.turn] : null;
  for (let dr=0; dr<8; dr++) for (let dc=0; dc<8; dc++) {
    const [r, c] = dispToBoard(dr, dc);
    const sq = document.createElement('div');
    sq.className = 'sq ' + ((r + c) % 2 === 0 ? 'light' : 'dark');
    sq.dataset.r = r; sq.dataset.c = c;
    if (dr === 7) { const f = document.createElement('span'); f.className = 'coord file'; f.textContent = 'abcdefgh'[c]; sq.appendChild(f); }
    if (dc === 0) { const k = document.createElement('span'); k.className = 'coord rank'; k.textContent = 8 - r; sq.appendChild(k); }
    const p = game.pos.board[r][c];
    if (p) {
      const el = document.createElement('span');
      el.className = 'pc ' + p.c;
      el.textContent = GLYPH[p.t];
      sq.appendChild(el);
    }
    if (game.selected && game.selected[0] === r && game.selected[1] === c) sq.classList.add('sel');
    if (game.targets.some(m => m.tr === r && m.tc === c)) {
      sq.classList.add('dot');
      if (p) sq.classList.add('cap');
    }
    if (game.lastMove && ((game.lastMove.fr === r && game.lastMove.fc === c) || (game.lastMove.tr === r && game.lastMove.tc === c)))
      sq.classList.add('lastmv');
    if (checkedKing && checkedKing[0] === r && checkedKing[1] === c) sq.classList.add('incheck');
    sq.addEventListener('click', onSquareClick);
    boardEl.appendChild(sq);
  }
  drawArrow();
  renderCaptured();
}

function drawArrow() {
  const line = $('#arrow-line');
  if (!game.lastMove) { line.setAttribute('visibility', 'hidden'); return; }
  const [fdr, fdc] = boardToDisp(game.lastMove.fr, game.lastMove.fc);
  const [tdr, tdc] = boardToDisp(game.lastMove.tr, game.lastMove.tc);
  line.setAttribute('x1', fdc * 100 + 50); line.setAttribute('y1', fdr * 100 + 50);
  line.setAttribute('x2', tdc * 100 + 50); line.setAttribute('y2', tdr * 100 + 50);
  line.setAttribute('visibility', 'visible');
}

function renderPanels() {
  const topColor = game.flipped ? 'w' : 'b';
  const botColor = enemy(topColor);
  $('#pl-top .pl-name').textContent = game.names[topColor];
  $('#pl-top .pl-color').textContent = \`\${colName(topColor)} \${topColor === 'w' ? '♔' : '♚'}\`;
  $('#pl-bottom .pl-name').textContent = game.names[botColor];
  $('#pl-bottom .pl-color').textContent = \`\${colName(botColor)} \${botColor === 'w' ? '♔' : '♚'}\`;
  renderCaptured();
}
function renderCaptured() {
  const topColor = game.flipped ? 'w' : 'b';
  const botColor = enemy(topColor);
  const line = arr => arr.map(t => GLYPH[t]).join(' ') || '·';
  $('#cap-top').textContent = '잡은 말: ' + line(game.captured[topColor]);
  $('#cap-bottom').textContent = '잡은 말: ' + line(game.captured[botColor]);
  $('#pl-top').classList.toggle('turn', !game.over && game.pos.turn === topColor);
  $('#pl-bottom').classList.toggle('turn', !game.over && game.pos.turn === botColor);
}

function updateStatus(text, cls) {
  const el = $('#game-status');
  el.className = '';
  if (text) { el.textContent = text; if (cls) el.classList.add(cls); return; }
  if (game.over) return;
  if (game.aiThinking) { el.textContent = '🤖 컴퓨터가 생각 중...'; el.classList.add('thinking'); return; }
  const check = inCheck(game.pos, game.pos.turn);
  if (game.mode === 'puzzle') { el.textContent = \`🧩 \${colName(game.pos.turn)} 차례 — 한 수로 체크메이트!\`; return; }
  el.textContent = (check ? '⚠️ 체크! ' : '') + \`\${playerLabel(game.pos.turn)} 차례\`;
  if (check) el.classList.add('check');
}

/* ----- 입력 처리 ----- */
function myTurn() {
  if (game.over || game.aiThinking) return false;
  if (game.mode === 'pvp') return true;
  if (game.mode === 'puzzle') return true;
  return game.pos.turn === game.playerColor;
}

function onSquareClick(e) {
  if (!myTurn()) return;
  const r = +e.currentTarget.dataset.r, c = +e.currentTarget.dataset.c;
  const p = game.pos.board[r][c];
  const target = game.targets.find(m => m.tr === r && m.tc === c);
  if (game.selected && target) {
    if (target.needPromo) { askPromotion(target); return; }
    playMove(target);
    return;
  }
  if (p && p.c === game.pos.turn) {
    game.selected = [r, c];
    game.targets = legalMovesFrom(game.pos, r, c, false);
    renderBoard();
  } else if (game.selected) {
    game.selected = null; game.targets = [];
    renderBoard();
  }
}

function askPromotion(move) {
  game.pendingPromo = move;
  const color = game.pos.turn;
  const box = $('#promo-choices');
  box.innerHTML = '';
  for (const t of ['q','r','b','n']) {
    const d = document.createElement('div');
    d.className = 'promo-pc';
    d.innerHTML = \`<span class="pc \${color}">\${GLYPH[t]}</span>\`;
    d.title = PIECE_KO[t];
    d.addEventListener('click', () => {
      closeModal('promo-modal');
      playMove(Object.assign({}, game.pendingPromo, { promo:t, needPromo:false }));
      game.pendingPromo = null;
    });
    box.appendChild(d);
  }
  openModal('promo-modal');
}

/* ----- 수 실행 ----- */
function playMove(move, opts = {}) {
  const wasCheck = inCheck(game.pos, game.pos.turn);
  const mover = game.pos.turn;
  const u = makeMoveM(game.pos, move);
  const capturedPiece = u.epCaptured || u.captured;
  if (capturedPiece) game.captured[mover].push(capturedPiece.t);
  game.movesHist.push({
    from:{ row:move.fr, col:move.fc }, to:{ row:move.tr, col:move.tc },
    ...(move.promo ? { promotion:{ q:'queen', r:'rook', b:'bishop', n:'knight' }[move.promo] } : {})
  });
  if (wasCheck) { // 체크에서 탈출 성공
    const s = store.stats; s.checksEscaped++; store.stats = s;
  }
  game.lastMove = move;
  game.selected = null; game.targets = [];
  renderBoard();

  // 게임 종료 판정
  const replies = allLegalMoves(game.pos, false);
  let finished = null;
  if (replies.length === 0) {
    finished = inCheck(game.pos, game.pos.turn)
      ? { result:'checkmate', winner:mover }
      : { result:'stalemate', winner:null };
  }

  if (game.mode === 'online' && !opts.remote) {
    postMove(finished);
  }

  if (finished) { endGame(finished.result, finished.winner); return; }
  updateStatus();
  renderCaptured();
  if (game.mode === 'ai' && game.pos.turn !== game.playerColor) scheduleAi();
  if (game.mode === 'puzzle') { // 메이트를 못 만들면 실패 → 리셋
    setTimeout(() => {
      toast('아쉬워요! 다시 생각해 보세요 🤔');
      loadPuzzle(game.puzzleIdx);
    }, 600);
  }
}

function scheduleAi() {
  game.aiThinking = true;
  updateStatus();
  setTimeout(() => {
    const m = pickAiMove(game.pos, game.aiLevel);
    game.aiThinking = false;
    if (m) playMove(m);
  }, 450);
}

/* ----- 게임 종료 & 통계 ----- */
function endGame(result, winner, opts = {}) {
  if (game.over) return;
  game.over = true;
  stopPolling();
  renderCaptured();
  const plies = game.movesHist.length;

  // 통계 갱신 (퍼즐 제외)
  let freshBadges = [];
  if (game.mode !== 'puzzle') {
    const s = store.stats;
    s.games++;
    if (plies >= 50) s.longGame = true;
    const humanWon = winner && (game.mode === 'pvp' ? true : winner === game.playerColor);
    if (game.mode === 'online') s.onlineGames++;
    if (humanWon) {
      s.wins++; s.streak++;
      if (result === 'checkmate') s.checkmates++;
      if (plies <= 20) s.fastWin = true;
      if (game.captured[enemy(winner)].length === 0) s.perfect = true; // 승자 기물 하나도 안 잡힘
      if (game.mode === 'ai') {
        s.aiWins++;
        if (game.aiLevel === 'hard' || game.aiLevel === 'veryhard') s.hardWins++;
      }
    } else if (winner) {
      s.streak = 0;
    }
    store.stats = s;
    freshBadges = checkAchievements();
  }

  // 결과 모달
  let title, text;
  if (result === 'checkmate') {
    title = '👑 체크메이트!';
    text = \`\${playerLabel(winner)} 승리! 정확한 마무리였어요.\`;
  } else if (result === 'stalemate') {
    title = '🤝 스테일메이트';
    text = '움직일 수 있는 수가 없어요. 무승부입니다!';
  } else if (result === 'resign') {
    title = '🏳️ 기권';
    text = \`\${playerLabel(enemy(winner))} 기권 — \${playerLabel(winner)} 승리!\`;
  } else if (result === 'puzzle_solved') {
    title = '🎉 퍼즐 성공!';
    text = '한 수로 체크메이트! 대단해요!';
  } else {
    title = '게임 종료'; text = '';
  }
  $('#go-title').textContent = title;
  $('#go-text').textContent = text;
  $('#go-again').style.display = (game.mode === 'online') ? 'none' : '';
  $('#go-again').textContent = game.mode === 'puzzle' ? '🧩 다음 퍼즐' : '🔄 다시 하기';
  openModal('gameover-modal');
  badgeQueue.push(...freshBadges);
}

/* 배지 모달 큐 */
const badgeQueue = [];
function showNextBadge() {
  if (!badgeQueue.length) return;
  const b = badgeQueue.shift();
  $('#badge-icon').textContent = b.icon;
  $('#badge-name').textContent = b.name;
  $('#badge-desc').textContent = b.cond;
  openModal('badge-modal');
}
$('#badge-ok').addEventListener('click', () => { closeModal('badge-modal'); showNextBadge(); });

$('#go-menu').addEventListener('click', () => { closeModal('gameover-modal'); stopPolling(); show('screen-menu'); showNextBadge(); });
$('#go-badges').addEventListener('click', () => { closeModal('gameover-modal'); renderAchievements(); show('screen-achievements'); showNextBadge(); });
$('#go-again').addEventListener('click', () => {
  closeModal('gameover-modal');
  if (game.mode === 'puzzle') {
    const next = PUZZLES.findIndex((p, i) => !store.solvedPuzzles.includes(i));
    if (game.lastResult === 'puzzle_solved' && next === -1) { renderPuzzleList(); show('screen-puzzles'); }
    else loadPuzzle(next !== -1 ? next : game.puzzleIdx);
  } else if (game.mode === 'pvp') startPvp();
  else if (game.mode === 'ai') startAi();
  showNextBadge();
});
$('#btn-quit').addEventListener('click', () => {
  if (game.mode === 'online' && !game.over && game.online) sendResign(true);
  stopPolling(); show('screen-menu');
});
$('#btn-restart').addEventListener('click', () => {
  if (game.mode === 'puzzle') loadPuzzle(game.puzzleIdx);
  else if (game.mode === 'pvp') startPvp();
  else if (game.mode === 'ai') startAi();
});
$('#btn-resign').addEventListener('click', () => {
  if (game.over) return;
  if (game.mode === 'online') { sendResign(false); return; }
  const loser = game.mode === 'ai' ? game.playerColor : game.pos.turn;
  endGame('resign', enemy(loser));
});

/* ============================================================
   6. 모드별 시작
   ============================================================ */
// PvP
let pvpNames = { w:'흰색 기사', b:'검은색 기사' };
$('#pvp-start-btn').addEventListener('click', () => {
  pvpNames = {
    w: $('#pvp-name-w').value.trim() || '흰색 기사',
    b: $('#pvp-name-b').value.trim() || '검은색 기사'
  };
  startPvp();
});
function startPvp() {
  startGame({ mode:'pvp', title:'👥 애들끼리 대결', names:{ ...pvpNames }, flipped:false });
}

// AI
let aiSetup = { level:'easy', color:'random' };
$$('#ai-levels .choice').forEach(el => el.addEventListener('click', () => {
  $$('#ai-levels .choice').forEach(x => x.classList.remove('sel'));
  el.classList.add('sel');
  aiSetup.level = el.dataset.level;
}));
$$('#ai-colors .choice').forEach(el => el.addEventListener('click', () => {
  $$('#ai-colors .choice').forEach(x => x.classList.remove('sel'));
  el.classList.add('sel');
  aiSetup.color = el.dataset.color;
}));
$('#ai-start-btn').addEventListener('click', startAi);
function startAi() {
  const myColor = aiSetup.color === 'random' ? (Math.random() < .5 ? 'w' : 'b') : aiSetup.color;
  const levelKo = { easy:'쉬움', normal:'보통', hard:'어려움', veryhard:'매우어려움' }[aiSetup.level];
  const s = store.stats;
  if (!s.difficulties.includes(aiSetup.level)) { s.difficulties.push(aiSetup.level); store.stats = s; }
  const names = {};
  names[myColor] = store.nickname || '기사님';
  names[enemy(myColor)] = \`🤖 컴퓨터(\${levelKo})\`;
  startGame({
    mode:'ai', title:\`🤖 컴퓨터 상대 · \${levelKo}\`,
    names, playerColor:myColor, aiLevel:aiSetup.level, flipped: myColor === 'b'
  });
}

/* ============================================================
   7. 체스 퍼즐 (메이트 인 원)
   ============================================================ */
const PUZZLES = [
  { name:'백랭크 습격', diff:'쉬움',  fen:'6k1/5ppp/8/8/8/8/8/R6K w - - 0 1', hint:'룩으로 맨 뒷줄을 노려요' },
  { name:'사다리 메이트', diff:'쉬움', fen:'7k/1R6/8/8/8/8/8/K2R4 w - - 0 1', hint:'두 룩이 사다리처럼!' },
  { name:'퀸과 킹의 합동 작전', diff:'쉬움', fen:'8/8/8/3Q4/8/8/5K2/7k w - - 0 1', hint:'킹이 도망갈 칸을 막아요' },
  { name:'스콜라 메이트', diff:'보통', fen:'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 1', hint:'약한 f7 칸을 노려요' },
  { name:'룩 맞교환의 함정', diff:'보통', fen:'3r2k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1', hint:'맞교환처럼 보이지만...' },
  { name:'질식 메이트', diff:'어려움', fen:'6rk/6pp/7N/8/8/8/8/6RK w - - 0 1', hint:'나이트만 갈 수 있는 칸이 있어요' }
];
function renderPuzzleList() {
  const grid = $('#puzzle-grid');
  const solved = store.solvedPuzzles;
  grid.innerHTML = '';
  PUZZLES.forEach((pz, i) => {
    const d = document.createElement('div');
    d.className = 'puzzle-card';
    d.innerHTML = \`<div class="pt">퍼즐 \${i+1}. \${pz.name}</div>
      <div class="pd">난이도: \${pz.diff} · 흰색 차례</div>
      <div class="pd">💡 \${pz.hint}</div>
      \${solved.includes(i) ? '<div class="solved">✅ 풀이 완료</div>' : ''}\`;
    d.addEventListener('click', () => loadPuzzle(i));
    grid.appendChild(d);
  });
}
function loadPuzzle(idx) {
  const pz = PUZZLES[idx];
  startGame({
    mode:'puzzle', title:\`🧩 퍼즐 \${idx+1}. \${pz.name} (\${pz.diff})\`,
    pos: fromFEN(pz.fen), puzzleIdx: idx, flipped:false,
    names:{ w: store.nickname || '기사님', b:'퍼즐' }
  });
}
// 퍼즐 성공 판정: playMove의 종료 판정에서 checkmate가 나오면 성공
const origEndGame = endGame;
endGame = function(result, winner, opts) {
  game.lastResult = result;
  if (game.mode === 'puzzle') {
    if (result === 'checkmate') {
      const solved = store.solvedPuzzles;
      if (!solved.includes(game.puzzleIdx)) { store.solvedPuzzles = [...solved, game.puzzleIdx]; }
      game.over = true;
      $('#go-title').textContent = '🎉 퍼즐 성공!';
      $('#go-text').textContent = '한 수로 체크메이트! 정말 대단해요!';
      $('#go-again').style.display = '';
      $('#go-again').textContent = '🧩 다음 퍼즐';
      openModal('gameover-modal');
      badgeQueue.push(...checkAchievements());
      return;
    }
    // 퍼즐에서 다른 종료(스테일메이트)는 실패 처리
    toast('아쉬워요! 다시 생각해 보세요 🤔');
    loadPuzzle(game.puzzleIdx);
    return;
  }
  origEndGame(result, winner, opts);
};

/* ============================================================
   8. 온라인 대결 (6자리 방 코드 + 1.2초 폴링)
   ============================================================ */
// 온라인 대결 방 API 주소.
// - 빈 문자열('')이면 지금 이 페이지를 서빙하는 서버(예: chess-server.ps1)의 /api/...를 사용합니다.
// - Cloudflare Worker를 배포했다면, 그 주소(예: 'https://chess-rooms.내계정.workers.dev')를 넣으세요.
//   그러면 선생님 컴퓨터를 켜두지 않아도 학생들이 언제든 온라인 대결을 할 수 있습니다.
const CHESS_API_BASE = '';
const API = {
  async call(path, body) {
    const res = await fetch(CHESS_API_BASE + '/api/' + path, body !== undefined
      ? { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(body) }
      : undefined);
    if (!res.ok) throw new Error('서버 오류 (' + res.status + ')');
    return res.json();
  },
  createRoom: hostName => API.call('createRoom', { hostName }),
  joinRoom: (roomCode, guestName) => API.call('joinRoom', { roomCode, guestName }),
  makeMove: p => API.call('makeMove', p),
  resign: (roomCode, color) => API.call('resign', { roomCode, color }),
  getRoom: roomCode => API.call('getRoom?roomCode=' + roomCode)
};
const colorApi = c => c === 'w' ? 'white' : 'black';
const colorEng = c => c === 'white' ? 'w' : 'b';

let lobbyPoll = null;
function resetLobby() {
  $('#lobby-main').style.display = '';
  $('#lobby-wait').style.display = 'none';
  $('#lobby-join').style.display = 'none';
  stopPolling();
}
function stopPolling() {
  if (lobbyPoll) { clearInterval(lobbyPoll); lobbyPoll = null; }
  if (game.online && game.online.pollTimer) { clearInterval(game.online.pollTimer); game.online.pollTimer = null; }
}
function lobbyNick() {
  const v = $('#lobby-nick').value.trim();
  if (v) store.nickname = v;
  refreshNick();
  return v || store.nickname || '기사님';
}

$('#btn-show-join').addEventListener('click', () => {
  const j = $('#lobby-join');
  j.style.display = j.style.display === 'block' ? 'none' : 'block';
  $('#join-code').focus();
});

$('#btn-create-room').addEventListener('click', async () => {
  const name = lobbyNick();
  try {
    const room = await API.createRoom(name);
    $('#lobby-main').style.display = 'none';
    $('#lobby-wait').style.display = 'block';
    $('#room-code-display').textContent = room.roomCode;
    lobbyPoll = setInterval(async () => {
      try {
        const r = await API.getRoom(room.roomCode);
        if (r && r.status === 'playing') {
          clearInterval(lobbyPoll); lobbyPoll = null;
          startOnlineGame(room.roomCode, 'w', name, r.guestName || '친구');
        }
      } catch {}
    }, 1200);
  } catch (err) {
    toast('⚠️ 서버에 연결할 수 없어요. chess-server.ps1이 켜져 있는지 확인하세요!');
  }
});

$('#btn-copy-code').addEventListener('click', async () => {
  const code = $('#room-code-display').textContent;
  try { await navigator.clipboard.writeText(code); toast('방 번호가 복사되었어요! 📋'); }
  catch { toast('복사 실패 — 번호를 직접 알려주세요: ' + code); }
});

$('#btn-join-room').addEventListener('click', async () => {
  const code = $('#join-code').value.trim();
  if (!/^\\d{6}$/.test(code)) { toast('방 번호는 6자리 숫자예요!'); return; }
  const name = lobbyNick();
  try {
    const room = await API.joinRoom(code, name);
    if (!room) { toast('그 번호의 방을 찾을 수 없어요 😢'); return; }
    startOnlineGame(code, 'b', room.hostName || '친구', name);
  } catch (err) {
    toast('⚠️ 서버에 연결할 수 없어요. chess-server.ps1이 켜져 있는지 확인하세요!');
  }
});

function startOnlineGame(roomCode, myColor, hostName, guestName) {
  const s = store.stats; // 온라인 게임 시작만으로도 '친구 대전' 조건 충족되도록 종료 시 카운트
  const names = { w: hostName, b: guestName };
  startGame({
    mode:'online', title:'🌐 친구와 온라인 대결',
    names, playerColor:myColor, flipped: myColor === 'b',
    online:{ roomCode, myColor, pollTimer:null }
  });
  game.online.pollTimer = setInterval(syncRoom, 1200);
}

async function syncRoom() {
  if (!game.online || game.over) return;
  try {
    const room = await API.getRoom(game.online.roomCode);
    if (!room) return;
    const remoteMoves = JSON.parse(room.moves || '[]');
    while (remoteMoves.length > game.movesHist.length) {
      const sm = remoteMoves[game.movesHist.length];
      applySerializedMove(sm);
    }
    if (room.status === 'finished' && !game.over) {
      if (room.result === 'resign') endGame('resign', colorEng(room.winner));
      else if (room.result && room.winner) endGame(room.result, colorEng(room.winner));
      else if (room.result === 'stalemate') endGame('stalemate', null);
    }
  } catch {}
}

function applySerializedMove(sm) {
  const promoMap = { queen:'q', rook:'r', bishop:'b', knight:'n' };
  const legal = legalMovesFrom(game.pos, sm.from.row, sm.from.col, false);
  let m = legal.find(x => x.tr === sm.to.row && x.tc === sm.to.col);
  if (!m) return;
  if (m.needPromo) m = Object.assign({}, m, { promo: promoMap[sm.promotion] || 'q', needPromo:false });
  playMove(m, { remote:true });
}

async function postMove(finished) {
  try {
    await API.makeMove({
      roomCode: game.online.roomCode,
      color: colorApi(game.online.myColor),
      moves: JSON.stringify(game.movesHist),
      nextTurn: colorApi(game.pos.turn),
      finished: finished ? { result: finished.result, winner: finished.winner ? colorApi(finished.winner) : null } : null
    });
  } catch { toast('⚠️ 서버 연결이 불안정해요...'); }
}

async function sendResign(silent) {
  try {
    await API.resign(game.online.roomCode, colorApi(game.online.myColor));
    if (!silent) endGame('resign', enemy(game.online.myColor));
  } catch { if (!silent) toast('⚠️ 서버에 연결할 수 없어요'); }
}

/* ============================================================
   9. 업적 화면
   ============================================================ */
function renderAchievements() {
  const s = store.stats, pzCount = store.solvedPuzzles.length, owned = store.badges;
  $('#stats-summary').innerHTML =
    \`<span>게임 <b>\${s.games}</b>회</span><span>승리 <b>\${s.wins}</b>회</span>\` +
    \`<span>체크메이트 <b>\${s.checkmates}</b>회</span><span>연승 <b>\${s.streak}</b></span>\` +
    \`<span>퍼즐 풀이 <b>\${pzCount}</b>개</span><span>배지 <b>\${owned.length}/15</b></span>\`;
  const grid = $('#badge-grid');
  grid.innerHTML = '';
  for (const b of BADGES) {
    const has = owned.includes(b.id);
    const d = document.createElement('div');
    d.className = 'badge-card' + (has ? '' : ' locked');
    d.innerHTML = \`<div class="bi">\${has ? b.icon : '🔒'}</div><div class="bn">\${b.icon} \${b.name}</div><div class="bc">\${b.cond}</div>\`;
    grid.appendChild(d);
  }
}
</script>
</body>
</html>
`;

export default {
  fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/favicon.ico') return new Response(null, { status: 204 });
    if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method Not Allowed', { status: 405 });
    return new Response(APP_HTML, {
      headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff' }
    });
  }
};
