/*
 * 우리 반 카트 그랑프리 — Cloudflare Worker (자동 생성본: build-cloudflare.mjs)
 * ──────────────────────────────────────────────
 * 화면 하나짜리 앱이라 이 워커는 화면(HTML)을 내려 주기만 함.
 * 데이터베이스·비밀키·설정이 필요 없음. 학생 기록은 각 기기에만 저장됨.
 *
 * 올리는 법:
 *  1. Cloudflare 대시보드 → Workers & Pages → Create → Worker 만들기 (이름 예: kart-game)
 *  2. Edit code 를 눌러 기존 내용을 모두 지우고 이 파일 내용을 그대로 붙여넣기 → Deploy
 *  3. 주소: https://kart-game.<계정이름>.workers.dev
 */

const APP_HTML = `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
<meta name="theme-color" content="#0b1020" />
<meta name="description" content="우리 반 학생들이 별명만으로 함께 달리는 3D 카트 레이싱 게임" />
<title>🏎️ 우리 반 카트 그랑프리</title>
<style>
/* ══════════════════════════════════════════════════════════
   우리 반 카트 그랑프리 — 화면 스타일
   외부 라이브러리·CDN을 전혀 쓰지 않습니다(학교 망 차단 대비).
   ══════════════════════════════════════════════════════════ */
:root{
  --ink:#0b1020;          /* 가장 어두운 남색 */
  --panel:#141b32;
  --panel-2:#1d2745;
  --line:#2c3860;
  --text:#eef2ff;
  --muted:#98a3c9;
  --brand:#4d8dff;        /* 파랑 (속도계와 동일 계열) */
  --brand-d:#2f6ae0;
  --accent:#ff4d7d;       /* 분홍 (미니맵 내 위치) */
  --gold:#ffc84d;
  --green:#38d39f;
  --red:#ff5f5f;
  --radius:18px;
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;height:100%;overflow:hidden;overscroll-behavior:none}
body{
  font-family:"Apple SD Gothic Neo","Malgun Gothic","Noto Sans KR",system-ui,-apple-system,sans-serif;
  background:var(--ink); color:var(--text);
  -webkit-font-smoothing:antialiased; touch-action:none;
  font-variant-numeric:tabular-nums;
}
button{font-family:inherit;cursor:pointer;color:inherit}
input{font-family:inherit}
.hidden{display:none !important}

/* ─────────── 3D 화면 ─────────── */
#stage{position:fixed;inset:0;background:#7fb2e5}
#gl{display:block;width:100%;height:100%}

/* 화면이 준비되지 않았을 때(웹지엘 미지원) */
#nogl{
  position:fixed;inset:0;display:flex;align-items:center;justify-content:center;
  flex-direction:column;gap:14px;text-align:center;padding:30px;background:var(--ink);z-index:99
}
#nogl h2{margin:0;font-size:22px}
#nogl p{margin:0;color:var(--muted);font-size:15px;line-height:1.7;max-width:420px}

/* ══════════════ HUD (경기 중 화면 표시) ══════════════ */
#hud{position:fixed;inset:0;pointer-events:none;z-index:10;
  padding:calc(14px + env(safe-area-inset-top)) calc(16px + env(safe-area-inset-right))
          calc(14px + env(safe-area-inset-bottom)) calc(16px + env(safe-area-inset-left));
  font-weight:800}
#hud.off{display:none}

.hud-glass{
  background:rgba(10,15,30,.62);
  border:1px solid rgba(255,255,255,.14);
  border-radius:16px;
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  box-shadow:0 8px 26px rgba(0,0,0,.32);
}

/* 오른쪽 위: 랩 + 시간 */
#lapbox{position:absolute;top:calc(14px + env(safe-area-inset-top));right:calc(16px + env(safe-area-inset-right));
  text-align:right;display:flex;flex-direction:column;gap:7px;align-items:flex-end}
#lapbox .lap{padding:7px 16px;display:flex;align-items:baseline;gap:9px;line-height:1}
#lapbox .lap .k{font-size:13px;letter-spacing:2px;color:var(--muted)}
#lapbox .lap .v{font-size:31px;letter-spacing:-1px}
#lapbox .lap .v small{font-size:18px;color:var(--muted);font-weight:800}
#lapbox .time{padding:6px 16px;font-size:25px;letter-spacing:-.5px;line-height:1.15;
  font-feature-settings:"tnum";min-width:132px}
#lapbox .split{font-size:14px;padding:4px 12px;color:var(--gold);min-height:0}
#lapbox .split.neg{color:var(--green)}

/* 왼쪽 아래: 순위 */
#posbox{position:absolute;left:calc(10px + env(safe-area-inset-left));bottom:calc(6px + env(safe-area-inset-bottom));
  line-height:.82;text-shadow:0 6px 22px rgba(0,0,0,.55)}
#posbox .n{font-size:96px;font-weight:900;letter-spacing:-6px;
  -webkit-text-stroke:3px rgba(10,16,32,.55)}
#posbox .s{font-size:34px;font-weight:900;margin-left:4px;
  -webkit-text-stroke:2px rgba(10,16,32,.55)}
#posbox .of{font-size:15px;color:#dfe6ff;margin-left:8px;letter-spacing:0;
  -webkit-text-stroke:0;opacity:.85}
#posbox.p1 .n,#posbox.p1 .s{color:#ffd85e}
#posbox.p2 .n,#posbox.p2 .s{color:#e8eeff}
#posbox.p3 .n,#posbox.p3 .s{color:#ffab6b}

/* 가운데 아래: 속도계 */
#speedbox{position:absolute;left:50%;bottom:calc(4px + env(safe-area-inset-bottom));transform:translateX(-50%);
  width:186px;height:112px;pointer-events:none}
#speedbox svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}
#speedbox .stxt{position:absolute;left:0;right:0;top:44px;text-align:center;line-height:1}
#speedbox .stxt .v{font-size:41px;font-weight:900;letter-spacing:-2px;text-shadow:0 4px 16px rgba(0,0,0,.5)}
#speedbox .stxt .u{font-size:11px;letter-spacing:3px;color:#cfd9ff;margin-top:3px;font-weight:700}
#speedbox .gearwrap{position:absolute;left:0;right:0;bottom:-2px;text-align:center}
#boostbar{position:absolute;left:50%;transform:translateX(-50%);bottom:-6px;width:126px;height:7px;
  border-radius:99px;background:rgba(10,16,32,.6);overflow:hidden;border:1px solid rgba(255,255,255,.18)}
#boostbar i{display:block;height:100%;width:0%;border-radius:99px;
  background:linear-gradient(90deg,#4d8dff,#8ad4ff);transition:width .08s linear}
#boostbar.full i{background:linear-gradient(90deg,#ffb638,#ffe98a);box-shadow:0 0 12px #ffc84d}

/* 오른쪽 아래: 미니맵 */
#mapbox{position:absolute;right:calc(16px + env(safe-area-inset-right));bottom:calc(14px + env(safe-area-inset-bottom));
  width:172px;height:132px;padding:8px}
#minimap{width:100%;height:100%;display:block}

/* 왼쪽 위: 아이템 슬롯 + 순위표 */
#itembox{position:absolute;left:calc(16px + env(safe-area-inset-left));top:calc(14px + env(safe-area-inset-top));
  width:88px;height:88px;display:flex;align-items:center;justify-content:center;font-size:44px;
  transition:transform .12s}
#itembox.spin{animation:itemroll .45s linear infinite}
#itembox.pop{transform:scale(1.16)}
#itembox .none{font-size:12px;color:var(--muted);font-weight:700;letter-spacing:1px}
@keyframes itemroll{0%{transform:rotateY(0)}100%{transform:rotateY(360deg)}}
#itemhint{position:absolute;left:calc(16px + env(safe-area-inset-left));top:calc(108px + env(safe-area-inset-top));
  font-size:11.5px;color:#cfd9ff;font-weight:700;opacity:.92;white-space:nowrap;letter-spacing:.2px}

#board{position:absolute;left:calc(16px + env(safe-area-inset-left));top:calc(140px + env(safe-area-inset-top));
  width:206px;padding:8px 10px;font-size:13px;display:flex;flex-direction:column;gap:3px}
#board .row{display:flex;gap:7px;align-items:center;padding:2px 4px;border-radius:8px;line-height:1.3}
#board .row.me{background:rgba(77,141,255,.26)}
#board .row .r{width:16px;color:var(--muted);text-align:right;font-size:12px}
#board .row .c{width:9px;height:9px;border-radius:3px;flex:0 0 auto}
#board .row .n{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:700}
#board .row .g{font-size:11px;color:var(--muted);font-weight:700}
#board .row.fin .g{color:var(--green)}

/* 가운데: 카운트다운 / 안내 문구 */
#center{position:absolute;left:0;right:0;top:34%;text-align:center;pointer-events:none}
#count{font-size:132px;font-weight:900;letter-spacing:-6px;line-height:1;
  text-shadow:0 12px 40px rgba(0,0,0,.55);-webkit-text-stroke:4px rgba(10,16,32,.4)}
#count.go{color:var(--green);font-size:112px}
#toast{margin-top:10px;font-size:23px;font-weight:900;text-shadow:0 6px 20px rgba(0,0,0,.6)}
.pulse{animation:pulse .5s ease-out}
@keyframes pulse{0%{transform:scale(.55);opacity:0}45%{transform:scale(1.14);opacity:1}100%{transform:scale(1);opacity:1}}

/* 역주행·장외 경고 */
#warn{position:absolute;left:0;right:0;top:22%;text-align:center;font-size:26px;font-weight:900;
  color:#ffd34d;text-shadow:0 4px 18px rgba(0,0,0,.6);animation:blink .7s steps(2,end) infinite}
@keyframes blink{50%{opacity:.25}}

/* 부스터 사용 시 화면 가장자리 효과 */
#speedfx{position:fixed;inset:0;pointer-events:none;z-index:9;opacity:0;transition:opacity .2s;
  background:radial-gradient(ellipse at center,rgba(0,0,0,0) 42%,rgba(90,170,255,.42) 100%)}
#speedfx.on{opacity:1}
#hitfx{position:fixed;inset:0;pointer-events:none;z-index:9;opacity:0;transition:opacity .25s;
  background:radial-gradient(ellipse at center,rgba(0,0,0,0) 40%,rgba(255,70,70,.5) 100%)}
#hitfx.on{opacity:1}

/* ─── 둘이 나눠 달리기: 화면을 반으로 나눴을 때의 간단 HUD ─── */
#hud.slim > *:not(#center){display:none}
#splitHud{position:fixed;inset:0;pointer-events:none;z-index:10;font-weight:800}
#splitHud .sh{position:absolute;left:14px;display:flex;align-items:center;gap:12px;
  padding:7px 14px;border-radius:14px;font-size:15px;
  background:rgba(10,15,30,.62);border:1px solid rgba(255,255,255,.14);
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);box-shadow:0 6px 20px rgba(0,0,0,.34)}
#splitHud .sh .p{font-size:21px;font-weight:900;color:var(--gold);min-width:44px}
#splitHud .sh .l{color:var(--muted);font-size:13px}
#splitHud .sh .s{min-width:80px;text-align:right}
#splitHud .sh .i{font-size:21px;min-width:26px;text-align:center;font-style:normal}
#splitHud .who{position:absolute;left:14px;font-size:11px;color:#b9c4e8;letter-spacing:1px}
#sh1{top:14px} #splitHud .w1{top:56px}
#sh2{top:calc(50% + 14px)} #splitHud .w2{top:calc(50% + 56px)}
#splitLine{position:fixed;left:0;right:0;top:50%;height:3px;z-index:10;pointer-events:none;
  background:rgba(8,13,28,.75);box-shadow:0 0 10px rgba(0,0,0,.5)}

/* ─── 터치 조작 (패드·휴대폰) ─── */
#touch{position:fixed;inset:0;z-index:11;pointer-events:none}
#touch.off{display:none}
#touch .pad{position:absolute;pointer-events:auto;display:flex;align-items:center;justify-content:center;
  border-radius:50%;background:rgba(15,22,44,.5);border:2px solid rgba(255,255,255,.2);
  color:#fff;font-size:30px;font-weight:900;user-select:none;white-space:nowrap;
  backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
#touch .pad.on{background:rgba(77,141,255,.7);transform:scale(.94)}
/* 아래 단추들은 반드시 '#touch #tXxx' 로 써야 한다.
   '#tXxx' 만 쓰면 위의 '#touch .pad'(아이디+클래스)가 더 세서 색과 글자 크기가 모두 묻히고,
   30px 글자가 동그라미 밖으로 삐져나온다. */
#touch #tLeft{left:calc(18px + env(safe-area-inset-left));bottom:calc(112px + env(safe-area-inset-bottom));width:82px;height:82px}
#touch #tRight{left:calc(114px + env(safe-area-inset-left));bottom:calc(112px + env(safe-area-inset-bottom));width:82px;height:82px}
#touch #tGas{right:calc(18px + env(safe-area-inset-right));bottom:calc(160px + env(safe-area-inset-bottom));width:96px;height:96px;
  background:rgba(56,211,159,.34);border-color:rgba(56,211,159,.55);font-size:17px}
#touch #tGas.on{background:rgba(56,211,159,.8)}
#touch #tDrift{right:calc(126px + env(safe-area-inset-right));bottom:calc(112px + env(safe-area-inset-bottom));width:80px;height:80px;
  background:rgba(255,200,77,.3);border-color:rgba(255,200,77,.5);font-size:15px}
#touch #tDrift.on{background:rgba(255,200,77,.8);color:#3a2a00}
#touch #tItem{right:calc(24px + env(safe-area-inset-right));bottom:calc(58px + env(safe-area-inset-bottom));width:72px;height:72px;
  background:rgba(255,77,125,.3);border-color:rgba(255,77,125,.5);font-size:15px}
#touch #tItem.on{background:rgba(255,77,125,.8)}
/* 브레이크(뒤로 가기) — 벽에 부딪혀 멈췄을 때 빠져나올 수 있어야 한다 */
#touch #tBrake{right:calc(126px + env(safe-area-inset-right));bottom:calc(200px + env(safe-area-inset-bottom));
  width:72px;height:72px;background:rgba(255,110,110,.28);border-color:rgba(255,110,110,.5);font-size:14px}
#touch #tBrake.on{background:rgba(255,110,110,.8)}

/* 경기 중 잠깐 멈춤 단추 — 터치 기기에는 Esc 키가 없다 */
#pauseBtn{position:fixed;left:50%;transform:translateX(-50%);top:calc(14px + env(safe-area-inset-top));
  z-index:12;pointer-events:auto;width:46px;height:46px;border-radius:50%;cursor:pointer;
  display:flex;align-items:center;justify-content:center;font-size:18px;color:#fff;
  background:rgba(10,15,30,.62);border:1px solid rgba(255,255,255,.18);
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
#pauseBtn.off{display:none}
#pauseBtn:active{transform:translateX(-50%) scale(.93)}

/* ══════════════ 메뉴 화면 ══════════════ */
#ui{position:fixed;inset:0;z-index:30;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;
  background:
    radial-gradient(1100px 620px at 50% -12%,rgba(77,141,255,.34),transparent 62%),
    radial-gradient(760px 460px at 88% 108%,rgba(255,77,125,.2),transparent 60%),
    linear-gradient(170deg,#0b1020,#0e1530 46%,#131b38);
}
#ui.off{display:none}
.wrap{max-width:940px;margin:0 auto;padding:26px 18px calc(48px + env(safe-area-inset-bottom))}
.screen{display:none;animation:fade .28s ease-out}
.screen.on{display:block}
@keyframes fade{from{opacity:0;transform:translateY(9px)}to{opacity:1;transform:none}}

.brand{display:flex;align-items:center;gap:13px;justify-content:center;margin:6px 0 4px;flex-wrap:wrap}
.brand img{width:56px;height:56px;object-fit:contain;filter:drop-shadow(0 6px 14px rgba(0,0,0,.45))}
.brand h1{margin:0;font-size:30px;font-weight:900;letter-spacing:-1.1px}
.brand .sub{width:100%;text-align:center;color:var(--muted);font-size:14px;margin-top:2px}

.card{background:rgba(255,255,255,.045);border:1px solid var(--line);border-radius:var(--radius);
  padding:18px;margin-top:16px;box-shadow:0 10px 30px rgba(0,0,0,.25)}
.card h2{margin:0 0 4px;font-size:17px;font-weight:900}
.card .desc{margin:0 0 13px;color:var(--muted);font-size:13px;line-height:1.65}

label.fld{display:block;font-size:13px;color:var(--muted);font-weight:700;margin-bottom:6px}
.inp{width:100%;background:rgba(0,0,0,.3);border:2px solid var(--line);border-radius:13px;
  padding:13px 15px;font-size:16px;color:var(--text);font-weight:700;outline:none}
.inp:focus{border-color:var(--brand)}
.inp::placeholder{color:#63719c;font-weight:600}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:11px}
@media(max-width:520px){.row2{grid-template-columns:1fr}}

.btn{border:none;border-radius:14px;padding:14px 20px;font-size:15px;font-weight:900;
  transition:transform .1s,filter .15s;display:inline-flex;align-items:center;justify-content:center;gap:8px}
.btn:active{transform:scale(.975)}
.btn:disabled{opacity:.4;cursor:not-allowed}
.btn.primary{background:linear-gradient(135deg,var(--brand),var(--brand-d));color:#fff;
  box-shadow:0 8px 22px rgba(77,141,255,.34)}
.btn.gold{background:linear-gradient(135deg,#ffd25e,#f0a819);color:#3a2a00;
  box-shadow:0 8px 22px rgba(255,200,77,.3)}
.btn.ghost{background:rgba(255,255,255,.07);border:1px solid var(--line);color:var(--text)}
.btn.wide{width:100%}
.btn.sm{padding:9px 14px;font-size:13px;border-radius:11px}
.btn.danger{background:rgba(255,95,95,.16);border:1px solid rgba(255,95,95,.45);color:#ffb0b0}

/* 모드 선택 카드 */
.modes{display:grid;grid-template-columns:repeat(auto-fit,minmax(206px,1fr));gap:13px;margin-top:16px}
.mode{background:rgba(255,255,255,.05);border:1px solid var(--line);border-radius:var(--radius);
  padding:18px 16px;text-align:left;transition:transform .12s,border-color .15s,background .15s;
  display:flex;flex-direction:column;gap:5px}
.mode:hover{transform:translateY(-3px);border-color:var(--brand);background:rgba(77,141,255,.13)}
.mode .ico{font-size:32px;line-height:1}
.mode .t{font-size:16px;font-weight:900}
.mode .d{font-size:12.5px;color:var(--muted);line-height:1.6}

/* 선택 칩 */
.chips{display:flex;gap:9px;flex-wrap:wrap}
.chip{background:rgba(0,0,0,.25);border:2px solid var(--line);border-radius:12px;
  padding:10px 15px;font-size:14px;font-weight:800;color:var(--muted);transition:.12s}
.chip.on{border-color:var(--brand);background:rgba(77,141,255,.2);color:var(--text)}
.chip:active{transform:scale(.97)}

/* 트랙 고르기 */
.tracks{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}
.trk{background:rgba(0,0,0,.25);border:2px solid var(--line);border-radius:15px;padding:0;
  overflow:hidden;text-align:left;transition:.14s}
.trk.on{border-color:var(--brand);box-shadow:0 8px 24px rgba(77,141,255,.24)}
.trk canvas{display:block;width:100%;height:96px;background:#0c1226}
.trk .info{padding:10px 13px 12px}
.trk .info .t{font-size:15px;font-weight:900}
.trk .info .d{font-size:12px;color:var(--muted);margin-top:2px;line-height:1.5}
.trk .info .m{font-size:11px;color:var(--brand);margin-top:5px;font-weight:800;letter-spacing:.3px}

/* 카트 고르기 */
.karts{display:flex;gap:10px;flex-wrap:wrap}
.kt{width:66px;border-radius:13px;border:2px solid var(--line);background:rgba(0,0,0,.25);
  padding:7px 4px 8px;text-align:center;transition:.12s}
.kt.on{border-color:var(--brand);background:rgba(77,141,255,.18)}
.kt .sw{width:38px;height:26px;border-radius:7px;margin:0 auto 5px;box-shadow:0 3px 8px rgba(0,0,0,.4)}
.kt .nm{font-size:10.5px;color:var(--muted);font-weight:800}
.kt.on .nm{color:var(--text)}

/* 대기실 */
.plist{display:flex;flex-direction:column;gap:7px;margin-top:11px}
.pl{display:flex;align-items:center;gap:11px;background:rgba(0,0,0,.25);border:1px solid var(--line);
  border-radius:13px;padding:11px 14px}
.pl .c{width:15px;height:15px;border-radius:5px;flex:0 0 auto;box-shadow:0 2px 6px rgba(0,0,0,.4)}
.pl .n{font-weight:800;font-size:15px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pl .tag{font-size:11px;font-weight:800;padding:3px 9px;border-radius:99px;background:rgba(255,200,77,.2);color:var(--gold)}
.pl .tag.me{background:rgba(77,141,255,.24);color:#a9c9ff}
.pl.empty{opacity:.4;font-size:13px;color:var(--muted);justify-content:center;font-weight:700}

.code{font-size:44px;font-weight:900;letter-spacing:9px;text-align:center;color:var(--gold);
  background:rgba(0,0,0,.3);border:2px dashed rgba(255,200,77,.42);border-radius:15px;padding:15px 8px;
  margin:6px 0 4px;font-feature-settings:"tnum"}

/* 결과 화면 */
.podium{display:flex;gap:9px;align-items:flex-end;justify-content:center;margin:14px 0 6px;min-height:132px}
.pod{flex:1;max-width:118px;text-align:center}
.pod .who{font-size:13px;font-weight:900;margin-bottom:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pod .bar{border-radius:12px 12px 0 0;display:flex;align-items:flex-start;justify-content:center;
  padding-top:9px;font-size:25px;font-weight:900;color:rgba(0,0,0,.55)}
.pod.g1 .bar{height:96px;background:linear-gradient(180deg,#ffd85e,#e5a800)}
.pod.g2 .bar{height:74px;background:linear-gradient(180deg,#dfe7ff,#a8b4d8)}
.pod.g3 .bar{height:56px;background:linear-gradient(180deg,#ffab6b,#d97b32)}

.tbl{width:100%;border-collapse:collapse;font-size:14px;margin-top:6px}
.tbl th{text-align:left;font-size:11.5px;color:var(--muted);font-weight:800;padding:6px 8px;letter-spacing:.5px}
.tbl td{padding:9px 8px;border-top:1px solid var(--line)}
.tbl td.r{width:34px;color:var(--muted);font-weight:900;text-align:center}
.tbl td.t{text-align:right;font-weight:900;font-feature-settings:"tnum"}
.tbl tr.me td{background:rgba(77,141,255,.15)}
.tbl tr.me td:first-child{border-radius:9px 0 0 9px}
.tbl tr.me td:last-child{border-radius:0 9px 9px 0}
.tbl .c{display:inline-block;width:9px;height:9px;border-radius:3px;margin-right:7px;vertical-align:middle}

.note{font-size:12px;color:var(--muted);line-height:1.75;margin:10px 0 0}
.note b{color:var(--green)}
.err{background:rgba(255,95,95,.13);border:1px solid rgba(255,95,95,.4);color:#ffb6b6;
  border-radius:12px;padding:11px 14px;font-size:13px;font-weight:700;margin-top:11px;line-height:1.6}
.ok{background:rgba(56,211,159,.12);border:1px solid rgba(56,211,159,.4);color:#93e8cb;
  border-radius:12px;padding:11px 14px;font-size:13px;font-weight:700;margin-top:11px;line-height:1.6}

.keys{display:grid;grid-template-columns:repeat(auto-fit,minmax(148px,1fr));gap:9px;margin-top:4px}
.key{display:flex;align-items:center;gap:9px;font-size:13px;color:var(--muted);font-weight:700}
.key kbd{background:rgba(0,0,0,.4);border:1px solid var(--line);border-bottom-width:3px;border-radius:8px;
  padding:5px 9px;font-size:12px;font-weight:900;color:var(--text);font-family:inherit;min-width:30px;text-align:center}

.items{display:grid;grid-template-columns:repeat(auto-fit,minmax(214px,1fr));gap:9px;margin-top:4px}
.itm{display:flex;align-items:center;gap:10px;font-size:13px;color:var(--muted);font-weight:700}
.itm .ic{font-size:21px;width:30px;text-align:center;flex:0 0 auto}
.itm b{color:var(--text);font-weight:900;margin-right:2px}

.foot{text-align:center;font-size:11.5px;margin-top:22px;color:#5d688e;line-height:1.8}
.rowbtn{display:flex;gap:10px;margin-top:14px;flex-wrap:wrap}
.rowbtn .btn{flex:1;min-width:132px}

/* 로딩 */
#load{position:fixed;inset:0;z-index:40;display:flex;align-items:center;justify-content:center;
  flex-direction:column;gap:16px;background:linear-gradient(170deg,#0b1020,#131b38)}
#load .sp{width:52px;height:52px;border-radius:50%;border:5px solid rgba(255,255,255,.13);
  border-top-color:var(--brand);animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
#load .t{font-size:15px;color:var(--muted);font-weight:800}

/* 일시정지 */
#pause{position:fixed;inset:0;z-index:25;display:flex;align-items:center;justify-content:center;
  background:rgba(8,12,26,.82);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}
#pause .box{width:min(340px,88vw);text-align:center}
#pause h2{margin:0 0 16px;font-size:25px;font-weight:900}
</style>
</head>
<body>
<!-- ═══════════ 3D 화면 ═══════════ -->
<div id="stage"><canvas id="gl"></canvas></div>
<div id="speedfx"></div>
<div id="hitfx"></div>

<!-- ═══════════ 경기 중 HUD ═══════════ -->
<div id="hud" class="off">
  <div id="itembox" class="hud-glass"><span class="none">아이템<br>없음</span></div>
  <div id="itemhint" class="hidden">스페이스</div>

  <div id="board" class="hud-glass"></div>

  <div id="lapbox">
    <div class="lap hud-glass"><span class="k">LAP</span><span class="v" id="lapv">1<small>/3</small></span></div>
    <div class="time hud-glass" id="timev">0:00.000</div>
    <div class="split hud-glass hidden" id="splitv"></div>
  </div>

  <div id="posbox" class="p1">
    <span class="n" id="posn">1</span><span class="s">위</span><span class="of" id="posof">/ 8</span>
  </div>

  <div id="speedbox">
    <svg viewBox="0 0 186 112" aria-hidden="true">
      <defs>
        <linearGradient id="spdg" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#3f7ff0"/><stop offset="55%" stop-color="#5fb8ff"/>
          <stop offset="100%" stop-color="#8ee8ff"/>
        </linearGradient>
      </defs>
      <!-- 배경 호 -->
      <path d="M 20 96 A 73 73 0 1 1 166 96" fill="none" stroke="rgba(8,13,28,.55)"
            stroke-width="13" stroke-linecap="round"/>
      <!-- 속도 호 -->
      <path id="spdarc" d="M 20 96 A 73 73 0 1 1 166 96" fill="none" stroke="url(#spdg)"
            stroke-width="9" stroke-linecap="round" stroke-dasharray="0 999"/>
    </svg>
    <div class="stxt"><div class="v" id="spdv">0</div><div class="u">KM / H</div></div>
    <div id="boostbar"><i id="boostfill"></i></div>
  </div>

  <div id="mapbox" class="hud-glass"><canvas id="minimap" width="312" height="240"></canvas></div>

  <div id="center">
    <div id="count" class="hidden"></div>
    <div id="toast" class="hidden"></div>
  </div>
  <div id="warn" class="hidden">⚠️ 반대 방향이에요!</div>
</div>

<!-- ═══════════ 둘이 나눠 달리기 HUD ═══════════ -->
<div id="splitHud" class="hidden">
  <div class="sh" id="sh1"><span class="p">1위</span><span class="l">LAP 1/3</span><span class="s">0 km/h</span><i class="i"></i></div>
  <div class="who w1">1번 학생 · W A S D</div>
  <div class="sh" id="sh2"><span class="p">2위</span><span class="l">LAP 1/3</span><span class="s">0 km/h</span><i class="i"></i></div>
  <div class="who w2">2번 학생 · ↑ ← ↓ →</div>
  <div id="splitLine"></div>
</div>

<!-- ═══════════ 터치 조작 ═══════════ -->
<div id="touch" class="off">
  <div class="pad" id="tLeft">◀</div>
  <div class="pad" id="tRight">▶</div>
  <div class="pad" id="tGas">달리기</div>
  <div class="pad" id="tBrake">브레이크</div>
  <div class="pad" id="tDrift">드리프트</div>
  <div class="pad" id="tItem">아이템</div>
</div>

<!-- ═══════════ 잠깐 멈춤 단추 (경기 중에만 보임) ═══════════ -->
<button id="pauseBtn" class="off" type="button" title="잠깐 멈춤">⏸</button>

<!-- ═══════════ 일시정지 ═══════════ -->
<div id="pause" class="hidden">
  <div class="box">
    <h2>⏸️ 잠깐 멈춤</h2>
    <button class="btn primary wide" id="btnResume">이어서 달리기</button>
    <div class="rowbtn">
      <button class="btn ghost" id="btnRestart">처음부터</button>
      <button class="btn danger" id="btnQuit">그만하기</button>
    </div>
  </div>
</div>

<!-- ═══════════ 메뉴 ═══════════ -->
<div id="ui">
<div class="wrap">

  <!-- ── 1. 첫 화면 ── -->
  <section class="screen on" id="scHome">
    <div class="brand">
      <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYoAAAGwCAYAAAC3nyLbAAABY2lDQ1BrQ0dDb2xvclNwYWNlRGlzcGxheVAzAAAokX2QsUvDUBDGv1aloHUQHRwcMolDlJIKuji0FURxCFXB6pS+pqmQxkeSIgU3/4GC/4EKzm4Whzo6OAiik+jm5KTgouV5L4mkInqP435877vjOCA5bnBu9wOoO75bXMorm6UtJfWMBL0gDObxnK6vSv6uP+P9PvTeTstZv///jcGK6TGqn5QZxl0fSKjE+p7PJe8Tj7m0FHFLshXyieRyyOeBZ71YIL4mVljNqBC/EKvlHt3q4brdYNEOcvu06WysyTmUE1jEDjxw2DDQhAId2T/8s4G/gF1yN+FSn4UafOrJkSInmMTLcMAwA5VYQ4ZSk3eO7ncX3U+NtYMnYKEjhLiItZUOcDZHJ2vH2tQ8MDIEXLW54RqB1EeZrFaB11NguASM3lDPtlfNauH26Tww8CjE2ySQOgS6LSE+joToHlPzA3DpfAEDp2ITpJYOWwAAAARjSUNQDA0AAW4D4+8AAACgZVhJZk1NACoAAAAIAAYBBgADAAAAAQACAAABDQACAAAAGwAAAFYBGgAFAAAAAQAAAHIBGwAFAAAAAQAAAHoBKAADAAAAAQACAACHaQAEAAAAAQAAAIIAAAAA7KCc66qpIOyXhuuKlCDslYTtirjsm4ztgawAAAAAAIQAAAABAAAAhAAAAAEAAqACAAQAAAABAAABiqADAAQAAAABAAABsAAAAAAJJITAAAAACXBIWXMAABRNAAAUTQGUyo0vAAAEDWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNi4wLjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICAgICAgICAgICB4bWxuczpJcHRjNHhtcEV4dD0iaHR0cDovL2lwdGMub3JnL3N0ZC9JcHRjNHhtcEV4dC8yMDA4LTAyLTI5LyI+CiAgICAgICAgIDx0aWZmOkRvY3VtZW50TmFtZT7soJzrqqkg7JeG64qUIOyVhO2KuOybjO2BrDwvdGlmZjpEb2N1bWVudE5hbWU+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOkNvbXByZXNzaW9uPjU8L3RpZmY6Q29tcHJlc3Npb24+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjEzMjwvdGlmZjpYUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6UGhvdG9tZXRyaWNJbnRlcnByZXRhdGlvbj4yPC90aWZmOlBob3RvbWV0cmljSW50ZXJwcmV0YXRpb24+CiAgICAgICAgIDx0aWZmOllSZXNvbHV0aW9uPjEzMjwvdGlmZjpZUmVzb2x1dGlvbj4KICAgICAgICAgPGRjOnRpdGxlPgogICAgICAgICAgICA8cmRmOkFsdD4KICAgICAgICAgICAgICAgPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij7soJzrqqkg7JeG64qUIOyVhO2KuOybjO2BrDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpBbHQ+CiAgICAgICAgIDwvZGM6dGl0bGU+CiAgICAgICAgIDxJcHRjNHhtcEV4dDpBcnR3b3JrVGl0bGU+7KCc66qpIOyXhuuKlCDslYTtirjsm4ztgaw8L0lwdGM0eG1wRXh0OkFydHdvcmtUaXRsZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cn5TvssAAEAASURBVHgB7L0JwCVXVS5a5597njsJGUgCISEkjFEThAAqJCi5eJ0R7nNABRV8KI4gDhfM9Smol0EExOdTUXioj0kMswSQKYYhCQmQeerudHd6/Pufz3nft+usU7t27RpPneE/Z1Xy957WXmvtb+9aq/ZQdYJAL0VAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUAQUAUVAEVAEFAFFQBFQBBQBRUARUASGHoHG0GuoCioCikBRBFoOod7fDiCarIaADqRquGktRWBQCLjOoIgeep8XQUlpUhHQAZQKzdgW5Bkie8yQ1k6PLWh9aHhevxRRQfuqCEpKk0BAB04CkrHO6MYY6Vjq3dDppl/StNL+SkNG8xMI6GBJQDKWGXUaIh1T9Q2hOvvFp5X2lQ8VzUsgoAMlAclYZfTKEOm4qj6MetUnPo20n3yoaF4CAR0oCUjGJqPXBknHVvmhVLlPDl33wo603Ve/i9iX4aV91UFPIz4EdID4UBn9vDJGpBs0dHwVR69Un9iOIU8EHEceCcu1r4qgNKY0OjjGr+NzDZIYIRqYtHgJ2HSMFQMrt1+EjfSJpIuGBWYa2ldFwRwzOh0Y49XhucaojBHSJ9VaBk9un9hSyvSPXS+KN4LdV/9DlEzG1CYkMRn7HB0U4zUEUo1StwaogNPQsZYca6n9IaTd9ovwiYeZzkL7KQ6WpoDAhKIwNgikGqU6jFEBHqnyx6YHSja0AKYlOQp5ZldkFgoHDccLAXUU49Xfidb2zhglRGlGCQR63S+95l+iqUq6DhBQR7EOOqkGFb1PiXUbi7r51dBumwUxqPJn86gz7u0TChhyHOvEQHmtEwTUUayTjqpbzV4Zo17xrdh+2zFUZJFwLlX5FKo3ZPgV0lmJRh8BdRSj38epT669anqGseuVLrZDsOO9aKLNX+K9kKM8FYGhQWBqaDRRRcYFARrXsidrWGeYr7Jt8rYnw8EOc9tVtzFAQGcUo93J690gUX9vG4aw20TX9aKv7oUM4SAaVpXUUQxrz/RIr7JPrbsu+4WAf2Uvyikry5IhRtfK6m30a9dOBvzrQmdbwSz9vY6kDrnsp/bb17YuGlcEukZAl566hnBoGSQMUlljFDmIhnEWh294e68am9C1TkF0AGUuG6cCLxJmsZZ2lV1qy+LpLdt12UtMfuvQ9ZDZCnrYV175mjnaCKijGO3+rdw620nI6g/zyhigHCMrRrSyjm7Fsg7Bre9Li9N44MZ3B0941ZqPpEhe7W21hYZ9FRdRtq9sfhpXBFwE1FG4iIxhWpyCOAFJ+6CoyQDFrZpPUMG8XjgHVzSdBC9XVheOIyZCnFEss2Ai3lcycakN3oJaKNmoI6COYjR7uJSloIOgwYkbHQEmyaomZyECCoWuMRXjXahyQaIzn/wTBSlDMttx1OU0yigQ9RcdhPSThGU4JWjJRLxOolAzxg8BdRTj1+cpLbaNTQpJn7JtA9wnkUGakyjqkETnsg7DdYBF2xs5CbtG3EkMwqHb2mh8dBDQU0+j05ddtiRuZPKY+Q1VXq3schpbMbguZVGD7dYb7bQ89Jfru9HGRFvXCwTUUfQC1SHkWfXJNa0psp+RVp6zkZ2oluYgbML14CyynJ3dlm7ioZNuOwnjIxgXp9ENZ62rCPgR0KUnPy5jlyv7FL1ueBGHkKZD2vJQGn3R/F7wZTtdvmWdZ7b+9BBwDsY/tOPZFcqUqtcpg9YY0OqMYgw6uRdNjD3VegTYMxh5yu7GSXhE9Dyr7hmMjYko373zEJuuy0+CqYb1I6COon5Mx4hjtnGiYfQZx2ECyH3q77VuLh5uupx84l/7bKKcCko9Fgjo0tNYdLM2st8IZDmg7pyDryV+h523j+TjpHmKgA8BnVH4UBnBvO6XOEYQlIwm1b3slCGqYhGXnGTZqSKL9Gp+z5NOryUjjoDOKEa8g6V59T/FCuf1G2Y99Q9rq6K9IbXlw9pHo6iXOopR7FVtUy4CvXQSveAddxA+J8HZhS8/FwofQc+mKj5hmjf8COjS0/D30VBqWMf6dxmz5hpfNz2UINWkVOQkshgKmj1dkspSQMtGGAF1FCPcuXbTiuxRFDX+Rels+b54N4+tvdxD6IZ3UQeG/ijRfJLSEYgz8KEZ5h2+4W34wi//evZJ+HThWjKyCKijGM2u9RqhVr6dyUSDxmcYDJBtyKs0qagxzwTDU1iWb1FnQcPfiyvl4cE7dnohX3muHwR0j2L99FXXmu557rtKv9cwDI4hq+Hr1arhcEEpH8d+CJegiIbMMCJkhr2fIk01th4R0BnFeuy1HuocGpzQ/I6j8bFnK2VgLjubKMNbaNkfYZ/EfUyVfkqZTYgoDRWBGALqKGJwjH6imIEYrp/SjJvF4eujfjgJu9W2Y7DjNk1WvNgYyOKgZeOGgC49jW6PJ9cn1mlb61xeKmPU6aDyZJfhVyf8VRxEnfKV13ghoDOK8epv01r3idJN122Ehn1GIEPAXnYaZich+vYgzPOLPRCpLNcDAjqjWA+9VF3H1FmF6xyY7tXb291an0E8tRfRmY5lELpVHw5B4PZ7N7y07vggoDOK8enrsW9p3Ua9bn4D7qAivnHAKqr4QSGgjmJQyPdPrhqANtb20pILf1aZS8v0enQSOpvw9aTmFUFAHUURlJSmKwS6Mard1HWVrpOXy3vY0+okhr2Hhls/3aMY7v6pSzvOKjL3lHu1P1FXA4RP2Sd/qVdnuJ4cTkEHobPOOgfICPLSGcUIdmpKk1KNwbA6iWE0yMOok7+/U7vbT665ikAGAuooMsAZsaLMGUWv21rWwJal77X+5D+MOqW3u3B3q0dJB1FL2gioo9Ch0DcEBmlou5HNut3U7xvA5QWpkyiP2VjWUEcxlt0eNXoYl53qNspF+BWhiVBbP7Gc/i087Vg/LVZNe4GAPlH0AtXh4+k1CDlGZPhaAY2qbGZXcQKUU6XeUILWVipjY1vtwDB33BDopjOKIegEVaF3CFQ19lXr9a4l3XNejw8G3bdaOdSBgDqKOlAcbh4jM5sYbphVO0VgdBFQRzG6fTu2LfN6xrFFo1DDFbJCMI0vkTqK0e57rwEYlSUIb+NGuz+7bl1G3yucXaM7ugzUUYxu345ky+y9g7Qd2LT8kQREG6UI9AEBdRR9AHlAIrxPiBlPlANSs7xY21mUr601MsaAd8woYoqAOgodAyOFgFq6kepObcyQIKCOYkg6omY1vPYy40myZvGDY2cvO+nMI70fxmEspLdeS8oioI6iLGLDT+91Er1T2zbNvZNSlrM6ibKIdeg5fvo8hjqyNTKkCKijGNKOqVut3j1BDsamZDmCrLK6cVV+isA4IDCcj4PjgHxv2ui12r1zEr1pRBmu7ic91EmUQS/3N7TVPpSDc2SpdSCMVtd26Sg4HLwsRgslbU0MAf0GVAwOTXgQ0KUnDyjjm6VOos6+33XZLwT8W8eXDoh13Hl1qq4/hVonmoPl1fVNrfOJ+jrQdhB23JZw+Ia320mNKwJDi4AuPQ1t15RWzOsoRnl/ojRCtVaIu9Vdl70E3L1dUEBqxGuQzkOXoAp01ZiS6IxiTDtem90dArsu+3mHgTiJyOg7BBlJqRuYpapBOosMJbVojBHQGcXodH5kbZw29XpWwaUVGrdwiSUylKNk8KLlo6h9IcySllsptRucXklLRvwO3/C2NKKe5GNGIcJd/tI4N1/TY4KADoDR6Wivheqlk4iMp4Bo2xkZWlSrAUfSX6MnGtUVRm1NayMl2WW+tK2NSyv0DKUr+4+bLj/ZfaRxQUCXngQJDWtAQAwcWaXFaxDTRxaRg6BQcX6igN1G5rlpofOFPlo3r6VLUT7oNK/vCLgjv+8KqMBaEHAtjGFa92wibjSr6N3/J+QqWrJO/ua0zAgkZC2Jy23l6xahsekZT7nIos2uX0t5KbMKaVSKopo9ygjoexSj0bs9v4njToLi5I8Aing3tMFlmc9w2jTDEQ/balnohFppbZH2MZQ4KwsujNv5jNtlTjHJreJ4H7Cwr5eteF8Fq7DBI6COYvB90DMNUp4MS8mjcUoaKNoM+SM7sSFuyDKxdGFZ+KTO/OG8orZSb2kPdZV2SCj6C43kuyHpSOPLZ55dZpEhGtUxiUH/Iw0YtB4qfwAI6B7FAEBfDyLTDWae9mL8hE4MaZSmsxi2ze2ovZGeYcy2j3bb7DgppZ1uyDKbVsrtOowP1WUrPFSKqTKDQUBnFIPBvW6ptvXp8K66RxEaTdoKXi5ryQ9Lk/+69DaF1M2isel7H2dbk07Clktd7T+WSTvcONO+K6+9drnNm/l2OnzPwiehD3m2kn0QpyKGCQF1FMPUG9V1iVuTinx4jj5cGiI7sQuM2+zT8vOECo8wHIYlqLiDEP2y2iE0NgYSz6pnlwmPtDyXn6R99Wwe9cXxgCFC62OqnNY1Auoo1nX31ac8jWbr0KdhIFwbwbSdJwZL8iWdp4vQC1149FNSgw/dNrJdbttII3lue+wW2HWFXsptOVl5Uiahr56UaagI9BYBdRS9xXddcI8/WVPlMkapDK0DRxdVHU6lk8k2CwsadlFMQilj6Muzy4Umj851IC6PtHTVemn8SuXnNaoUsxxiynL/7Cr91MWWO5ZxdRRj2e1Ro8svAdn3pxgtCSO+yZjQWPUlK0k8wBzRT0JXFSotiksoNG6a+Wl8mC/0dihx4SlhWr6Ur8uQIAhAdihxt1FCL+Vu2qXXdE0IqKOoCcgBs5Ebp4IaWVXzjJPUlTBLPGlcfo2cjeQsftXLon2YPB62vhJnO6QtEgofpnkJrRt300LPfF5Mu3nkxT/JlxBZ/b/shlWVLo20GyJxCavw7qZuFXljVUcdxVh1d9nG1nHv2bbF5Remy89qyrbDpadcVxehEX1t4+zGSSv1JYQ53/2MNpMoL6IjD5tPm9QEpJdyyWeaF8tsfgM9+WQ0KvmPNEDCktVLkceBKlVVibMQ0PcostAZ8bLQQMu9ZRsmabib56aFLisk/7R6zO+H/Yj0S9+bII3oI6GdZ8ej8sg5sBwc4CxwKCBMePkZKvwjuLdJvelIjlCtk9BtXD/VdmUTRL26REBnFF0COCTVS98MocG07ynG7bS0zM4TGlecm5a6DFkm9ex8xm3ebtkg0qKPhNk6uE4iSS18JBQKNy35bkg6H7a+PLfuwNJFG9cvBYdNn361u1Y5OqOoFc6BMSt1M6Q/VYsBKsJOHADbTHo77eKQVRbSUqdef/Quvd2uvnba17aWtcxk0/YqXqZfeqVDJt8iAyaTQVahvDjq9l++o+5wFf0EyE6BRoohoI6iGE5jRCX3FJsscdfQS74Niy/P5mHTunGXv1teNR3xjS+z+fiJDWE7onohpbStqoNw+fnku3lSR2SzXPJc2r6kKdy+bMXs/FJxOgH7m2TiFHxMoh/HCktliU8dhg+tevPczq+Xu3LrFwLemzbtpos2j73VMnR2h0vZ+hms20W9mlXEn0Zdg2ul2aROMyU/zGjsvjK3Aa1D17dpqmJjy3R5iGKhkr36XpZtuK0G28Kt7GrRtLGZx439+PW3f08q2RNetZZa5hRIe5xsTfoQ0BmFD5WRz7MNkBimIo0ODVQ00/DVcfm5aV+dKI+GoFfOIpJit5+5VjpmPiS/2Eyieychuvgwc/NEt6hVdcXcp/xu+Qq/Ks7hgRvfHRPvpmOFSHzt2smgoLMQAGM97vLTdIiAOooxGwnJJRi5X4oC0aZn0HCNF3m4/Ny0LcdXPzz+2XtnkaVHXK8iSxvhMoi0NV7fluSNGyztEh8fySMd+ff9shUoJNx2DHY8r3KeM8irT2chVwGnkUBf6moYIaCOIsJipGKHrnsR2uO7t+0826ClxVNg8TqJFFpvti0vSUCH1qullaQ0GxOWRuk8JyHr5CFPMeBR/aQsT45USxTZfCy8WshPrZNgUjojZempEJ8yDsFm2K1zsHnZcXEaOQ6DQPcQUVuj9RlXR7E++y1X691X/0OQf9O2DZG5Tdpxc79I3BVjGSvLmLpUxdIiw+Zp15RyO69aPL4/QR5pMsvxjzsJ1i2qcxH5QiOhpRuzcPXXmYYy0/7NH2vxmlUcA9FtNz3OrECqwJJUN+wLaLC+SdRRrO/+o/ZFrVN6SwvffVmihEkWjU8Fl5583DxfvTJ5Ls8s/nFaOgPfrCLpJOL1sp0R5WfR22U+Wml7VjuEpvdhGSdRxUFIC4hKN1eB2YWA3Y2YkayrjmIkuzUoMJtIa3hV41O1nm0UqVNVPmntKcPT1SVUJ+kUfLJsvT18fFW8eb66Pt4hXX82/5OKlnEOUrsbJyE86ghzZhcCNgHWq42Avpk90kPBN9Z9eXWDUEaG3JdJHZJLRkmavJxyPKiLo7uTjMtLK0xvU1if9Xw0afm2VKknoV3Wn3hZJ0EHMSxOoj8IjZ4UdRSj16dWi5LGJNwg9hk45vnyLXaFo0m5hasOlLBs+6u201ePeb58GxDRT0K7bDjjw+ogZBkqA7W8zsioOnpF6ihGr08LtMh3DxQxVAVYGxIasqrGzK7Xj8+Q2/KkfZInIfPtuND1O5R+YzgM+mS3f1idhGhdwFkI6diH6ihGegikGRNfvi+vKjjdOB0xhvXok/4+hvAXeWxrW28ePzWXhEzYcakbUiX/zStP1iifY+tTvnYva6ynpaYcZ0GQhxfoXnaiw1sdhQPIKCSjNeS0Mc5815il0VZBxOVdhUekT/TJkSp8fHVy9MspTrcdUjHS3Se9WJ7w8lFLmYQ+miJ5/vrR+PHzSHvPYj05CLtldBYFHIZdZezi6ijWd5fnWCS/IQibnFO1JC48Qip/SUOapYcIsmkkXq+OIimpX1QSxkS+m+9L27SuvmGZ4GKHkRy7vs3f5eUry6Kx6dPi6fXznEUax/Wcr84ivff0eGw6NiNQkjQEyVNANFRJuqKNp/FzLzsvPFpahL9NY8fJ3U27EqukbZ4uBnZZHm/SuvXDOlkfESRGxY7duvJFloRueX/Tw74PUTMa0tk1sx1+djqjGP4+StOwjDUzPJJOgtml2XT0sR1CJ9OJxGlo3NKurLK0OsXyk/sUIkvCYnziVHbdOIZsc7zd8ZrVU5QpshjaOlTn6qtZZLlvFJ1EzqyCUEkH+GAb2Tx1FCPWtcWWDHpnYHxw5htN2wDaHERPCe0yO55XbtMyLve6a2yL8Emn6Z2DaOvf2WSnDvwL2+F/AGjXKRGQj/yRd9aMJ22fooS4oSUt4CyGVvdeKaZLT71Ctrd8xdLFpGQ5iciYRAYmVrlkIt/4+xh61QZhXn5aucjILo/aLvR2aNe146TxYSU0Eoa8quHh42/rZusA2oYt046Hx4iTM6eIVzYGEZ0bCz+dXuwz627dfqWJBJGs8xJnkfIxwV6IrFP92nmpo6gd0p4ztC1EIWGRkRDDJLdVaVaF5PmIaEiznlCTdUTXsIRtyDKEyfp2TpxXWOLLs+swXgyfok6C7RdaMcB+Z0TZop/PJrl6hemon6U+Q7ncOpKfF2bXYyk1HeRVVL7oeuaTf8K8KS5hlu50GOosBt/HWX2kZUkEUu9aGiGfIU0aj1QWSWkpOWLsUopzs0OHIYbQRy5lEkY0vjZGpfFYvO3xsvSUK1PSEiZr5uEROch0HnGuNp0dj1OZlFg/T1H89vb1u83bjieZpbVRnryTNYYjh86gyiX7L6yfscxG0Mbi0hnFCHSzGKJ0w1hkPAuNWB6fYakLLNso2XHhL7Kr6xLHwidDZOWFokucLs1wxqkwJ4EDp8HmCajoF/CoDy+bN/I6vzNht9umCWvF/hVWsUxJ5NSNyZc66y+s6gyyWmrz5JJuirOQjspiNRJl6ijWTzfm3fUZLbGr0rLYaalm59lxKa8ztPnbcVuG6BkvjzsA0gudXdeNk0cROtYDrZDH2ER6FHUSrG7TynFZcewhe+rFC/w7PwYlukoYUkRtSMsnncVPqsXaLnUlFKKofWGOXS48hbZ3oRd6iLMNd++kK+c0BPo3AtI00PyiCLh3sqkXNzo+VnYX2yzEELihj0eUZxu+KLdaTJ62445L9KnGMzKmrG/x6lggKy9VRDpNne2neINBR7dUhdoF6XqFBFIuYR6/rHLy4CXK+Te0e7n0NGzOIWVWIUCFcI3ovzqjWB8da1v4ChpLdduASB7Z2fnZ7GnY6jWWth6U7aZtfeSezKKRMrtNiHdODEm5zdeN+2nqbXcokzwjZ2/r7OpUJC16S5hXR/AUOqeeWQrrVifhnR8Om2PI13h8KPQ9ilHva3P2XgwCDYHEpeGOcZDsvoSuLiKU+XaZHRcaJ/Q2Q+p5Cx0G2cleOIm4ROqap6dbLu2Lc4pSeeXkJ39RLROL7Zc4ZT1IqpPoAag1stQZRY1g9ptV9CSaIdnYCtvA2HExTr68DJ41FIW623KFqegkaYZCJyHcCJ7Es65C2HQY+GR2ChExINoZPYhHbctmLroUpRduafXcfKbBO7ZfQh7hC3h5uIu0MQrZEQLiyDZbZxSj1LUcsvJXqF0kdi9fXj/vA1d+UnYRY5VN4/J0ZRbBxKWpli7m0ERfhtRV9GUoZbZ8yZNyu56UCb3Nj3k2bzst9PWHOpuoH9O6OeqMom5E6+cnd24G57Yh6NgAMQxpVdzyrHSHKZiFdDRu2YY4TW5WvquD0NrND4+ZSkn10OaZx6Vcm/MMv+CWR0etWp+/Ml05G652vHHF9W16u30Slwp22khxZAidnS117LxknFSsXeRS51AEpeGhKdqvw6Px+GnivUsjQyM3toQEyI6XAUyGA0R27no/LzF4ZbgLbai7j6/kSSg1orCM3AijqH4US5cR0TBGOl7ebgiLUv8tKiPOoPWFtoMoKxLiGpeLs7B5FtHDpXHTIT8f/mVOPq13BzGuJ590RmHfT+skHjeAZa2Jr5FiFCxenTVqK8+qSh18RsMiyYn6+EqehDksKhWzrbyKyhC6rHqCX8g5+pd108osqqyZA8nyWEg5xJlZCNKNyz+DiqJ7JCuKSSXJcWndtNBVD9e7k6je8vVfU/cohrsPC9ytvOF5FSBtPx3TmGQua3T4CW9m2HFDYB3rDNNF/o07OdZI8s3ik6yfRe0rI05FsHLr2vWos623j5+U+8pC3sX6IUddihERlsjW558eCjH/CoGV1alk5/UuPuJOwgdw78AcAGedUQwA9HpFYoxymIqRMMyT49a3nNFxFpaxida5yUgYM7R5WhWMvG7+sfm6fKrL6d6huLrY6Sydhc6mSWmHZLuhsMgLpZ7Q2SKRxz73L0VJhd6Ho+YgMj7n0XswByhBZxQDBL+6aFoIXu1QkmFm4t+OQ3AMSYfQyqdxkSfd0LlYhSLPchplDHIqrRHha4RPNgyg+X5SR/ucCPn6eOdUSy2uh5fB1m2enfbJd0WT3s1jWvJQ3ul7H78e542ak+gxXEPNXobUUCs55sp5zUdoLNl93mLzNJkossntuA1wSn7jCq558xLr5Jfr7lvE9bSZ23HyddPMsy+33H8CKulE3Ho2z17H02XXasBtMRKXEE0MZ4mSwZCXv//C7hXakNL+1+1fKXM3tEfZSYzjhrYuPclI94cpd1Pnmc1fq77cNPltCSxO3viJp1VbH7EBaZyFpVPe+sLT28sYwsDHFOan87Tvo7OZ2nHyctM2f1+5/AKbT067LlmyuOAlRjBqg10xQ45NlnB4yXq1OgnK9kHn5sXetKZOSb1MMzqHGEyq0j+j7CQyACk52jI4DWGRLj2ld4p7q9mUWWU2XU/iSUMWqiPLRl7DQU1IZmsu9sLVkjQss69OvU7EKvXlWcUxoXa+HXcF2mV23FU6Q3YBlnQO8idSxGFIOtWoRgRWzNaHcTuNFE84+fTy5Vlcc6NS3xbXzovLZGZSr4i/zSDKFaXdmYNNwfiYOgkXhpFLq6NIdmnWXWRTp91RNk1f42IrYkK9maBw7YVNlxJPPgmT0Ca2JdvwCI2ENp3EhZ5LSq7xtutldY9NR75MC1+RE4VJhxCVxWPpPOJ0BVM2O1HZzivIJkbmq+/LS+AhCsS4IeHPT/m1N1NZnYSL4eik1VHE+9J7a8VJYqmy9LHKVRORgRND2Ag3oH3aMI9k7n3v0tppxiUtYVvZcIO7neg8mbrMpZyhXWYzs/MjOvnNBuEQttWu1ymRSDskP9DFSGOJGH2EYSy79wmqKX+URhVdKJhf5crl4yMQjGylINx8TJJKxOukzSjUSVTpsPVTRx1F2Fe8W+SOKdt7VeuVlePQ8wYW0RK2SeL3dkjmkDj3v8M7JdkWmZxZkLkrVHiwzBUuZRLabZG8vFB4sq61sZ2mBqkSM5U8GT0oFzhEfYqw41kiw6ZmUXjLoiPPWYKcsg6Oki+hV4RmjjgCupldTwfzLurcWvWwzOMiIp0bmFo4WR3N7Hw77qsj4u0y1rHTQmNCYZhKEKOOKyl1HZJ2kgY+uS8TFtozEJkl+GilzC+hP7mdvYKs5mbBl1WPTcgrT++8NgDCIE2JRvD4X/hUELwq4xtU/YEyV8quy17iANLAb8q/LQh/IVHaF+blMlOCYFwdBe8Ijha5ZORIuhO+4Q1vMPFXvvKVnbxBRyJDKDe2pZEnq2NAfK305VnsOnUlz8dfyjINkS3IjncqI4IltJRPg5Qx9K5jKVPX1qbeONuMKwu/NFjCmuX+bYvLlNfhaAu24x0CRNLybZrBx40jMBi7QLfaToI6smx9tGfwiIYajJujsEePHeeoybwG5DC6Gs2JyqVa3IYjwcQDk9x3mVbJFm7HhV9uFwhhoXA4nENcVS4BJZftLBofLFZxZtTtpzavaNmJtYsIEBqXYab0gRZGv6Pe1rkzlLLaELaTdQ/f8PaB6r8ehI/THoXcAb5+SS1zZxLiMDxMUnl4aPuS1ercMCniqHGe1iy3+djxBNvMwgR1mCF1iiiTwmJos9k2aV8PlHRZu2mvSJeIaXsQSLmdR0Zu2su875nhEpOIdXV000InYdjWyNFIvoYuAuPiKPJGjIvLsKS9ertPy521b1drX+00O+DWZdqllbRL28m3BXYyXWonbddxinqcbP3Cr/ZaAvhL+ySsUaTLkmkL9olrzNtzfoFu3Q6VXWAx65QPR4TGPbkPUVa3qK0Rv2weKW9lZ1cagdJxW3qq1GUve9nLTL0Wjgy+5S1vqcSj55WiMR8aCzvdrXDaC/LL5SmGpRBxqlZp+xSpFUoWtH7uFWGNzhHQkgw65AKMhFLgpiUfXcPlJ/7eRC6WUZ1SsTZfI+fQpz1ShEC42iR2/7HcLhP6wYfRDKAb/Xx9FO5jpC1FwUn4Kg0ekD5oICOjD6IGKqKbERUsLi7iJ4QjqGZnZ7MaExFmURUv8+oebWiHjDLXvovLiijllpAwKjGOKPwqqd1UUdNXgZWFVuiEYVp+WMc+1SQ1fOGdO84Lzj9yl6+ok9dxEJ0caPXXf2GloqiLb1Qi7ZMwKknG/DSJvnLJ8tIURBpeLpzIiu9LGCrm+olz8+161jFkYYuQX1TtxxU5iLqk2W2L83SdRdtJkMiDuKkrPRJnNCIpnVEU6EjbSRQg7wtJeLLneshKG7cokqFLEjeeUS1mO7LovLIzKnS+N2TfoBn04C8G211u84FMZ+Fe5/3w892s3LTI9BOKvhL6qcJcP03urEKq2TC5YoTGyg8/3OgpMDS+fBkUwsQnMKpX1GkLtzrD7peZRBtpo4SSHw8jpxTStQ69BEC0+C5OdsU4m5FJjcseReUOy9i8rsyzZEUOzJRLbmKQkMpHSRLmCyk5SR7jvsumtXm24+Gvp6GiobMJfMysvA6pLcAqT0Q7FYzDoAFPM+Jps4m7/uX9Ca6SkTabkPLsMNItm85Xiidz8wt0KMtiI/0kocXKnTWEaRfXLOZk5tLbaY9QS37/o7ZuVaS7WBThxzqCQxhi/BWpWEXBoa4zDo7C27F0AEWdwJvf/OZYJ+bU88qLMSifcEe5wwFPOvytZJ9kGeusYZfbceEmUiR06yAdM0iGzsdIGNoh6WzGdtymqx5PcxY+jsWcRIaOsf0Nl85N+zRAn2G/gg4j9uNCblWBtx1y1iBOwtQnD/z5L6nsL41yRShDiUeljBWZ0cVr1JeKnu674Wlj4bbRTYscqROFg8RBtBpEOPZLT2L03WOw7AwpG0THFJHJQds6RCPRHsgc7zKmycCOM+1eNr0dt+tZ+TGD5vJKTVsMUml8BVJPQh9NMo/OwrcEJZR5DiI+YxEgPDowq3MJnWS4acmX0C4P42nGXr6tVQ17kZcVJnUJnQXz7bIkj37sTdTjJGzdfW3y5dl1NB4b7iMMh3ckuI7AdhZuGbHh6SeZXdi0Htx6gau3DaFhE0OGEL8bYQh91EImCrtp5jOPgVka8TEJy7v7VwRLWJ5b0Sc7cRpFZxtxR5GmVxW97Tp23JWRVebS9iKdlJ+Gda8dRXUnkWxDMaTy66VhAf6sPLLXSDfO6jWvxfM5A6tOZnRYHAWVjBs3fkn26Zm6myEtiDj3RtqTbfSUabN2KttF3rhNL3EJ3Qpp+RFdxk0bEZWIxXGUivl6COX6D9lWXjI40OuYtaZdvXQU1ZxE7/sqAw8BLw2udZ0/9ktPZXtP3qlgvRxnUZZ1l/Ryk4Rr37zXzbKFZKeFkU1or3W7hFRL8rpU0Rgg4SWCJXR5p+W7dPWk/U6CvLP0YFt4ZdGEFOvjX7sd/qOw0o7hcxLULK5/PC2aFwlljEpYpM5o06ijqNi/dBgZjoIjVqxIRQmJaqmjlk854V4F67TJ8N5H+uwgwbtkhqhi35h5LOw6ErfrFM2L6tC4ZzzhRYQ5saST8OniYyLtL0rv4+HmkZd9iQw7rxdxtw39khtvS/czCWlHN/p3UzfenlFJuaNyVNrla0fp3vctTdkzCu5XZDiLXmCb2Ya4wZMbxlYjszowE1qhEx4Cp6QllPy00EcneRKm1S2eX8VZxLFyZVXRrUodkdtNXeFRJaRcXtLfYSoPz/pnEw18juPnQ+GV/+0PhinYCJCVtR/2iuNwPLZyH2Q4gSI843dfkRr5NJkDMhzEQiLi3VDKKcyOi3ChZ9qO22k3X+q6IelcGVJXQrfc5ZGXDj9NzhkVjX+2Awh5ZdIYtXx623r4dJb2kM5XnlaftHZdm66XcZFbTnb9TiLowkm4OEtawl7iN168x8lR1Dp65PSTb9YxyCHkf3vWNgaId5KdCFQmPHa6m1bYUOfxlHK7ThnZUl9CtAIOQy5xHnYoZd7QqMF/In5JuqyyJHUyx60vbZcwWaOeHJu/qwMlcF/iGV5R/AnUXjgJr7DCmdIGaZekJSzMSAlzEBCEc8hGprjSCMpzBhkzj17hW6gdtsGMOwKqJSzcOPvaLstKs6zKZcusUt+tI/wY8hL9w1T0r9BFOeVj3fDopm55TaMarlw3HVKmOQmWym9l9+K3savtS0Sti49tO7/eeAY+BHSkr3GaUVTuyAxHYHjmOZLKgtMrcmCWHJw0nlLFNqRu3E1TCbueXc6yOi7hb/Py5dnldpw6kZ5hL/SjLNGnKn/RT/hISN69vmydRY/iMsVJFK9RnLI7JyEY2u3zy6aRlz8/heZmITBup55kZPkwyRxtdBYVHAJ5Zsn06VEmL/Ou541hZhUdLaSJUk1Uk3xbtND4ymy6snHhy3p23OVTVm4Reh9Nlg62Tt3UJR+p74a2jKLxojrb/KQO5UtcytOPwvbSSYTSXV1Ep6xQ6giWbU4py2YuJ5kZxGfcLpWmbQR0RhGhwdHHv9Qra2aR4UTiozmVe+WCTJ3NTRGjYMI2Fj71hEZ0ijGQzAqhy9fWQ9jVJUv49TL0YZcmr852VZErWFO/KB4+ZeP3MQpcdS87hbOJMm2hku4YCvPE+BdoRoekSp1O5TGLqKNIdnidd7RwL3s3SL2iYabO8RtCVJHQJ8Iu892YUidTrBBZoc3Xyu5b1Kdvlk4+ejfPTduNYZmUZ8mx69QR98llnq0DXszMeQLv/WyibFvdNoT1/Qc4yvJW+iwE1FH40ZG72186nLmZOkdGIYvMV2YbF7vhpE0rc+nstB338SBPnx52vapxW98iMorQ2zSuXizLKnfpu01Lm3wy43nRePDLdJ1E3bMJv9S83HgbSJ3XjjyONZQL6DWwGl4W47ZH0XVPyPJTxlJTmgyO8oEOKrmpwrVZqiIqyQ0oYVoT7PwsWuFNepfOhsAus+vYciSeVy50aaFbX2S7+Wn1hV7CNLp+54v+bmjrES+TcWBTSNx1EJJfd1hsE1v09kvPaofUkH0IH62UCa2G6QiwJ/RKRyDTKvichTiSdJY9dxaZOotecWchuXWF9g1ux8k/LW3n23HRSfIklPyyoV3fjvv4sFwuH6x59aVur8I8+XZ5+oa1rV2ao6h7RtHtL9b5DL/djnqdgIwD73KdFNriRy6uS0/ZXVp6EPichyPCZ3GY58t3qhZKFtKZN1p8bTerGsvkT3TIorebYsdZNy1t50tcZDCUPAlFj6Kh8CpTn7TyV1ZOUfpu6Ky2dKLSTvJlZvgSXbyv/TL75SRC6R2F/cp0kdu9kyCGLo7IydnT6ULloa+qjiK/i+wRE6NOmz2UdBb2HWPHY7JKJlJ1dvmEDuMZyBbRvqoskz/hIPSSTgttfhJnKPG0enZ+UVl2HTdOHq7MbvlKfZuv5Lnyq6Rtvmn12zQppEUcBDmnOYk0qf3JZ6OSDcsy2PU4CV8f+vL6g8IwSNE9ihp7Ic1xpInAoG55Bj1HZPLuSGOSnk8ehUc39QhvMqmSVT2rjArZ5cKP+Wlxlsll10UeqzCrlsuWn8bQkW/IbAV8PHx5Pv4+3jadWy58Rb6k7TpuXpj2jCu7UizebydRfH+Carrti6keS3TvJGx2rlzpA5vGxEmYWpigXqcZOqMo1nGpA0Gcg4TF2GH4Z/9IuztKi7J16ai3/LlliXQR4wIa8Mu6NyguT323nHXkssvsuJRXCW3+efV9Mpnny8/j5ZaTh+giodAwnSbDJ5/0cR7sP/kTrnlhESdx/43vzmPTg3Jfm9Hini7/2H3gYlvsXZMeADEULONoDIVKQ61E2p1cSWk+AeUM/F70T24bYr/DnWiZqCRsmPbF29lC3uEj9FIgdTsEORGpn0NWqbgo76J0okRZel894SFhSJMzfoRRaljEUbByXZvZxWYTlBhvJ3N4pbU3ezbh5xVytP9Np0uT267NiiN96YxioN0bfiI7QwVa0bKWNIOdKcod1FzXDm8MH6mrjpumjHY9X/VOc6o2zScvr8mWTqJbkSqpNNTB27iUGj6d8+qzXORInOxDXuyfHOOVoks8+wmvWotneFJ1OQkP64wsH2YZ5J0iYuViW5RXUbqOsLGJ6B7FQLu68MAkoTv6e645HUb8SU0Mlq2OxBnacVFP6kg6LbSbRz7uJeW+MpfWShuVRAcJrfJYtAzvPNo8ffPqS3kY1uEUYk0dQKL4bKIb5QQ34ZHX50Jnh6XqSEfbDEYuro6ieJe6I7B4zRRKufkLLEGlcKicLYM7t02iIyWFS1L2TWRXl3xfXhE97Xo+eikXOT4aT55pqdSV0ENXOcvWxwgDJ8rhn6SFuU0reaBqr7uLU5Z0RDEqMX/7e9u6Kn1epU5vWzFo7uooivVApZFjH5PN2uymYRiAs2DLS9259lFLMWohfJXgKYZ8h0pUrVuW8O0IciK+cl8eq7m6+dLxurZTsOOOEpWS1z3+zejgUF4Lqlx908tK86ln2Una7OJRTp268SkjPeX+ZMPG4hqbhnbZm12NcHEYWc5CDG/GzdCrvqrcNtE53d+IgSiKfln6InxdnpJ2Q5uXlNl5jEu+hG65m7bponhGH7sMSqdvePUng8Mf+IZRlc4hmJgIGo12FzdbwVVf9zuLtE3tehxF2Ixul57ScIvGYWm4CldIkw0G7NiRv3RGkd/FlQ2psKaDoLPgX5qzkIGY8uQirIYqFJ2plP9mLQtdGr3ci1nlUhYZ5BAsyWdK+IQlUXleHeERD+322xwZD/uxf0cq6SDkooMwLeU/zWaYaODghBCMdej29ViDUbjx6iiyocq8t8oY9TQH4Yqn8UnhK7oYG+DWG3Q6y2jauvkdik3BuDRRmsxQ8mxauemFjmV2nGmhcctsOjtOOv8lbeRejb0M56MWWl9ZXXm2c7B57nr+Y4OHP3gboKCTwMFGeA62sNHyYWjXHN54fXgW62sbiQzZ6xdQu4EF4uooCoDkIxGDJ2HGYIpVL7IMFauQTJh7PpldKSf1rhEjdNkffU8lxmmVsnASLENjX+QeTFU/Tbwn33Yk8eI0XfOcRJxL/SnpGx9nuoQQOYRYdgpdBChzRg2PyaYtP/nkDENeNF5sbWTc+MZGel/bHDSeREBQTZZoDhHwjTY88V9vFcUHX5pxseGswVmQXR19522fzxDV7TBsPLLiSWMgzfaqnsIq3kcRUVo+wG2fRIpo+xvz9UGeBqGTwBIToDn8IexTYAYR7k8IZg3sUfxSKps0R1HHPkUv9ieSYyOtaen9nFbDzs8YCwKsTT6ScZ1RVOpW20jZcdybeNuaV8bgqiTRU4mC+zZQxXD122EIjoJriu+24HGNgp2246wS7zvmiDzGe30RU8FT8O1GZmIwYBPbDBIuPaEwUd6NsJJ1D9/w9qBbZ1FcpPSzhFLTTUu+hnkIqKNIRyhpRdJpEyU0bGlGRza3E5XKZ4iOfbMBtkETI1de7fI1iGXkLNz60nzCIZDYNGIg0spIi6WaPs0ibAztuK1x2bjMJqSeHHSKp33tF4pehg04iZ+vLKB8v0g7GUrfU7zkF1clQ7YMuuLM1jHlWDW2ZD+ljiq/wbIHZBRPG2iy/ESdsja6RVYaH6dNVfrT284yBsx2GFn1bDpH70JJwSKTWGxDJpG/sCDG/srIzWp7aqWaCsRRcNnp4Q9+I8BJWCw7WeOQckw6wPLTL3ul9nLpiQKrzijS+iV7PNi3gneIezGwM9PktmlsAXa1kYyPVWNL9mDq6PIPULkp42HWYCvnLLDejE9qFLjK9qm3nf0welUchx97FxXpAzef6WRZVh+5HPqBiyuzWJrdGO5PkL7zLgWaizcpcOKJy08IcQjqOV8dB0dRDLUsqpxxUfY+yxI19GW69NRVF9lGR+ytG6YLkJmE7TB81BywNJBFjmWivigw9ANZjG5Rh1HMSRBBgcCDJh+5gUyOEUhUFF0TBQPOCGcSVCLe3buff7FxFpLLs1AtTDPkTNSA1e6DeLY8YxzkaFB2fOSwW/fFeL7QqwwCcWNVfSDaMovuWRScUQjrepQTbj0MuzPCYgptBTPy+FTdp70IW6Mw7tMrSVUmB60BOf/C7m6vLpmTTzuvudjkcqnpqpt+Obj65pcFV6csO5WRWZWWG9p1XuzH9L60h7+Lu5uOa5XOs0OXzaBDNjqRsWtwia6zR1qnWtxRdLJTIwUGXWpdu4ByK/BK619v22x5jHdnwF1u+ekiM4ts/O3m2k1kfpgui2G/MchHKZuCE6bvuLbauy/DuEdRpL+yx4QPr2g8eEvTHyTsAearOrJ5Y9vwAj1qW5oOeTQoswebPOUVGegd5hmRio6CHO0+9rYpQ+w6chZp/RHml+mH9eUcWjhi+71ZXVi4rNeOgopU2dAu0nfRfZnX3LRxEtbLkWXfS3mCRqpcl55Kdmc0kGybK+NHQjINy4sP4GxFIrnZdBmltsIZZPEiPuUXedKP16qeKmKkQyyIdRLvpORyx16LyE/KGExO2Df1OIm0FlQaNGnMhiI/vUU595g92IaiJf1UQjezu0ab40cGn4Rkauf7hXQxS4gxFOOWYtBtpWL1yiRs3iKvTP0ytMLflunW535NthMW/Ivd3yLTlTNs6SxMutE1bTZRDL1uJA++bo6DoILjAENmR4w9AJnoRB4gRpZtoGKkJpE2EIVPWnmSUzLHNXBVDAl5VKkn2rg6SH5dYZZugqFPVlFce62/T7fsPN6WXFKqttfg4/2RS99iNrR9ZcxLcxQsq+MTHuTDK770FLYzLEn/t2g/Zo2FdO7wAul7ElJt7O2kzihkKFQOiw32NPYcpO4ALzBw09iVyrcNpMSrGCdfHeFXSqEKxIJVhGHYH5KfxbJfOmbp4Cu77I+e5csunHfDq/CbFB+6tfOY08SnxlvY5b7u0jfhx4teXphP3YRxJ0HutUx2u1KzwDgZeydBgBWE/GHmHc1ZHwa0WRYYiDa5cRpF66QZOp/htoWk1bNpODS6NljWbyTEeVdL5bVLnEUR/IphUE3PsrXy2pXH78uv/gR6K3zZztzQ+OfgB25BDrYgeQwK1wTyGLsq41fu0mYVvZtRGNVy/ynSn2Qi/Z/LEARFeZK0CL9Rp1EQ8nvY6yhYLT4wCWWStMSAzNfEoUgzdnmGJ62ew76TzOPXIcyJFJVry3Pr2GU54lKLXZ6phDUW1KG3Tx27Le13CQ0ZR+LhD94CMxfd4nxDm6/crbdfuSt7D9n3Zdm6DsYReE7BuCUViPweT1p/q044s2CGn6zLgWpJSkZtI+GWZhmmrHouH186i7eP3s6jbCLlG3hpfH36ptHasnxxHy8fXbd5VfUrKldmEaQP37duzygsYA99EMtPKA1fyiOVSab+drZvRlHnbILio+UnKmrfM5bisfxST/8UUddlK1QXz3XLR/couu46e7DHmQ3KScS1SKZoxLoxmHbdsgbRR2/zS2rrz2EdHy8/dZhbRU4WPykrq4fUKxr69G6bfcMitGhwCJg9mFmFmDgMTc4imviULJ2FyZYyj/D+/niRe98wTeXcfOSkv2zqr+BpW8msDJRKchoRcgWkWEcmR69VT6a64hgyBrZVq7uoz3i4HLMMWJH6Lr8i6SyZReqn0aTpW0ZeUR4+ujJy0tpQJt+ng1tfZhJhvhjaONWh9+MHjIyjoAmG2zB3fPryE2vbM4vezSjieoYp2xzFbzm5t3y1asyzFaiR7fpnpTOKYn3IARQfuVY9dxC7aYu0r1Eam0EZuLrlkp/PeBZto68uO8Onpy+vVx2XplcReWYDuz0sJR5ZujBGx4BfzoaD4Lu1GMLmd7MjqiJy+kuTepulqcHGlK7kMBtmQBxVB5NUgMrh3u2ADJofzGYxcU1+l5Q1Lj7DV5ZHOZgiap/sqLRcLEvnLDlp9bLqlNOsOHWaLsU5JCllGaq9uGQI2oedzAzi8AduDf0Dhh4dB8vwc9rBc77m/9w4GcisorczCo51534wP8Xn5IEq4+HLvmGSFdmY7Muun005xqUKUrXOrzIgc50EVclzFFUNjW0U/+H815pWX/SC767W+pK1bNklqybIi7TflpdGb9MkhNSQkSa3BtYdFrL0FDkKKQr3KpiiYzj4/ltwPDa81UNaeAksR1399ZdJhURIR1G3k6CQaDM7IdLKoK7xW6ygoyCPeMWIq9q6CIvSMQWvNGSdCmkDskNgR5ofAnlOjV45Cepx2z99rq0OlYi6vV/Ooi08FlQx1nUZ4CqyY8o7ibr0irNNGkyW2w5ClpyYL3F7ZmGo8ZR++EPYq8BUgmVN/E3AUbTwcsXVKT9idOi6F5Jl7VdxR0HR0Q1TwlF0dMZeIRigxbuvjAZ8p1QjZRDQPYoyaMVp/XdxnCaaRURj3qHIn0UkKnSVEb9n6EAG5SzEuNZttLuCJ6Wy6JpS3KNs/6ARR8DQdhoSD5VhKnok2P08/JARnAVdxQQchinD5sVHnvCXwVVf+6WE/ruvflfQK2eREBbLKHRbxWqkJeBc4oM9jVDzcxHgDpde9SPAAdrI2o/g7EH+iojv1lDZzsCOU3Y02yiiSd9oenqTd4tn31AwgvxQ2I6BTkMciP0k3sJsInQnQbATzsKsQLWXoQxdi1vd/ovOov+X3zn2Xw+VaCOgjsJGo1w8a0RHZdY9Lo4hb4nJVaNuoxbNIiI1XZmaHiYE/P3EoRXODaIw0tp2HNEg3PkDjw1/Ozv0GHicaZhZRVQvHuuNs4j0iUurlPKDU4mVVkpDQB1FGjI15MMh8GHOXGWdAyvRQdTrJNx7Sm7Y1rDOKkLwevBv2eWusvQ9UDnBkr0pziKcTdBthK5DHEhYbvyBmU3QP3CXQiYSXIrixvZ1T3hLgr9k1O8s3HEoktyQ2vOSMEzpv/1HQB1FdcwLjV46i6pOorpqaTXjKkdLUPH8tNqaP1wIhM4hPnMIU+28tj02kwd5YkETdmEJyvgHdDvLWvhnAhvb3K9Iu+p3FmmS7HxxKHB7eDtbr8EhoJvZvcNeRnkpCfXOIIqKpqqDcRbD+KReFLXhoIv6zp5FGN1CD2Gi3KuQi9kmNcnnRDgVTC9aTfDJGbF0Fv3d4BadcxSThmnYMwR0RtEdtDKSu+OC2vUvMyVVimYQUVmYV1szIsbdxWpSiGz8rDIcsr9Cd+3JrU2HKX+5xB6CyElEbZY8l5wv3O265rHBjqsvhIPgZjYWoPAGXgOO4yNPTJ9VuHzKp4tCK3R0EPyTdKpE9SSp0NRToDOK7nHkKK48UDMMVveaORyG9HSTo2WdycrdUqcSubzcWRXTRceFmFEuNnEY8r8wHv4rhlYmF3QSoeEFHao06CjCiPx0Ra6+1QmK9odL56YTGuR6kkQNzSiFgDqKUnDVS1zUGNQrNcnNN9Owjdew6JnUvCc5uVapTqk2zlX4ijug8Y+cBDlJM3w2NCyj0+CR2SMfvs3UZS1Sf+TJeLfixuS7FSzv5ir2sp0rgRpRX187XFpN9woBXXrqFbIZfGl4B2F8fQ7Bp6ZrvNy0r47mVUOgrnHQMp/+C3UIl5xoWPONqzHDOPVkrva0I3I+Ybb9bzeb2odveLvNqmC8rVvH8RWspmS1IqAzinrgNPdbGqsbXv0pFMmAT6PqT35RZ9EfbVRKGgJ0zllOJD57oEtIcwocd2FZuOwUpiRO+Twqy9+yIJk5LruW/hJemr6aP9oI6IyiL/07HE6iL00dDSFpVndoWpfuGGjvRf3ISbiKk0KoWEbK0PmwwC5hqV7jjoDOKOobAby71CPUh2fPOfGJvcyyWt5Tfi8ULqOfOwMRN8HZg2v6ZaAyn0+LLRLhf/4aHsOP4gW8tM+Q9/+YbIhsxg+CQeNEE8NK+m8tCOiMohZ1m5ZdAABAAElEQVQYlYkiUD8CZZwEpdv09tKUmSBYnoJW1b74WQ8eeWryXYr2+xTDtfhkKW8rrvG+IaCOog9Q2zewX5zeCB5cXHvmIelvlvvEXpf0OvmGY02OyMY1NNsQ1lALo4QZf3gzG/8jin9AyP8+8vh6P+tR7dQT2xAOhYxPjZNIrx4ioI6iXnCt27AM46GziWWUV9qhQ8AehvGxFdvEFr3hGHZ9P2YVvOgnYJgbIORy1HWPf3OYP5B/7XbAXehnPAbSCxSqjqJ+6OOju37+PeWYP/upT3yGrLh1q09kGU7rsh+//OpPoI1ceAr/c5fuZVbBkBfnHnQeNuDh6hNKQCO/jBdSd/dvteOxkUydUURY9DumjqLfiKu8DgJll1zK0ncElY/Qbtq203DIcGzlJVg1yvJNw4H54Ymn0AtEp58iYcYp0DG0W2c7jl3X4GOBKJgwTgZ1sBaVtVfRzTsVkQPL8seJLogaEo9lMYlTaqoSAnrqqRJs5SvRGKTd4OW5aY1RQaCIk/CNG8njvIGX7RSYZ6cFK3EOkjZh2xZ3TDKcQ8P82BF9BnLNxkWsRpcJ2nRKE4kSprEV+rRyze8HAjqj6AfKKkMRqIiAOIS06nQIXqcAQyz/SV1ZbuqkJWKFDaw7rbXWzJ85AbW6lrlPUWZWEW5m246hzESgDK3VII3WgoA6ilpgTDDxjuoiT48JTn3OyDNMfVanBnHerjB8B9kflJ0ln/1QtS/sFkfx0EDLUpMAa3JB1MlHhP9xb6KFdyrCN7ZxAupJdXxVNtImlG87DdHIDYvQuHU0XTcC6ijqRjSHX5ZxyKk6csX9wWL4DE1eu6s6CBkgdovDOP+NG2k6BmYx5AqT/O18Hk4/GWdBbiFRg8tRpgLzurlszcry6aZuWVlK7yKgexQuIvWleZd5R7cYim4NQn2qRpxEtygn/K0MO63x3iBQx3iw9ywkzkFoBmN7NKbZ/M6A5Q8ZNfD7FKjXwqMkw6xd7WpvanekkbteQ46AziiGvINGVT2fQ+p3W+swzHXp3CtdwoWkUEtxELKpLSHzTRlDkPJHjLiJzbwJOhccfWo217pqavJlO+8zVKoMPRqbCk1fCnRG0ReY/UJsY9krQ+GXvF5zacbKGZhha6nd53XrxhmEICSziVAGc9uxdlSchOQz3aEyTMIPlxsHgkIuP+k1vgjojKK3fc+7S+8wD8ZlHWNIX6+TKGu0y+rsNjtNXrd8bTlEKJxFhMMu7jBsynjcOIR2lvl5CjoOzCRwAMrMKPgp8sFcevsMBve4VHUUcTx6lcp1GGlGpFcKDQPfOg3kMLQnS4d+9S+dROgcQqcauQumoz86Bts5UHeecuJjTWsNHHBMlr+nbeqTNmSX1cSayozENi/GcwXbFWrSQdm4CKijcBHpbTpzUPfLmJRp4jAY82HQoQxmZWjrbJs4CYa0+GEYaZNlcsOlp/bnPOhBzHKTYWMcylU3/XLEyIkduu6FTk48Ge5PZA79dgWhkTBL47gMTfUWAXUUvcXXx13uAl9Z5tl6b4UuMumY5I9sBuGoaCizjGVWWRdN72vVNFx70bbQOYiBjeYWoduQoSezjhAGOgm5zEzDeA3ShvT8oGzVa9dlL2lXtYTEmAlzhqSRv4hIN7IjLAYVk14alPxxlpt25yQw6cag0EhJ/TSDlRBoZUhdK2ukokUxqYpDEf5VeWd1ROgixNSHt7lxCHyJru0AkvU5JBvBofd/wxQ1zFJUWPeqr78sSY6crNlE8qSTj4U4CF9ZmJfjKNSGpUNXW4mCXBuUlRgVdhaVuNdQqRdGrAa1amWRZ8yrYJDH021AFRkuDzdNZyFOIXIc2bf84baTMN95Amn4ol0ruOqml7vsTTrbURSZTYTOKWsvIsNRZDfGq7FmVkFAj8dWQa2+OhzoQ+ssemG86oOuPk6j1k7bQcjwEodB1OLlEY7MN4MR/9BBMMVPjj/3Zr+TiGomY8nvOiVpRLcoFJqhvi1EybEKdY9i8N2tT0WD74NaNSg7m6DwKnXylKZzoOE3xt8itgccl6Pk7+EP3BbSgqCJTNYLOViVrWjWbCIksyVZFTvRtPJQcjEeHWYa6SEC6ih6CG4J1rxj0u6aEmyUdD0jUJezsGcPjHNghWZfXEY01MzmtXX2VQwC384Of7Qooi2KbbQ3kZQX8Qi1Sh/2UlfCqKbG+o+AjIv+S1aJPgR495S/M32ciud5ZY7ackxxOLqjzDL2zQ9iKedD2YYvq36+ZuRNlxDKCGOMh+4ikhzFWNZq//7ErmsuMt92ohwzk7DJmFngipyEEItDkDRDO6+CEJuVxvuCgDqKvsBcWog4C68Rb3MTmqLMbXrhK3k1363Ctqhq65+OBj7LyNsOgnE6jbQri09aHeaHHKP5ROgefH1h57VfqmNtTC/4W9nG2ZiwEVx9s/+0U5YeoSMQCl87fXlCHw8zNrLjhJrqKQK6md1TeLtibt/NdtxmynzedWnlNi3jRenceiXTxQ1BScbrl9yGxI7X2CLbRXA2EXV2FIvEhcPG/IulJ84qOJJkdsH86u9PsHbeJTql0aI1u6/MYiIMsmi0rCYEdEZRE5ADZKM3TAnw5cm/zFO7r45d346nqTJxTbubLLvYi1mFyA+dBmWGckPHwQWl8D/mh5OHkIZ7FYfffwsmFVAQcaazLt9GdnLZyeVgMyUQFhguqaaHCgGdUQxVdwxEmb7drWJQ7f0PySvbcpuHr67wFTpJ27S+PLvcF7frMC78fbRuHp1FlnNw6cvyd+vbaZpo21mwzOxD0CvICGh7B0lGBTanrJfsQilxakm5ZXbajgt9pIXkaDg4BNhDeo03Aok7sozxKwKdbVyL0I8yjc9RdGYbnoZ32xd0DnJxliFpY5rba0v0D4fed4uhlF+yY95VN/n3J/yzCb5cF8kSmVFoJEbJnFjO3gSZ6dVHBHTpqY9gD6GorDu7FnXVScRhNE7BMXM+5xGvVSUVdq2Ikv0Lhp24HIuVUQDvIPR80c53+ZyEjy6Zl8IwSag5Q4iAOooh7JRRUWmcnUTr0KfTu9GxmXAetM9io2P1qmAos4YwjBxDyFiEc48iFHnoA98wG9dMhfsWraC8YRC+MfXbCV/T7Dw77qsfyytFHKupicoIKOiVoRuJiom7u9ulDkGlioGTuus9FCdRYfkk0R+CRV39IvzoRBpwFMZJIJOOgcL5jScuP6Udi/XNKPI3sSmVpia1eSToXBm4qb3qoNTfSPkHh/7qp9IUgVIbxv2Aqyaj3cKSUwvvVIQh4lm698rxci7Dk04ivDdOgi0TCWmtpA/A7Gf3M9IINH+ACOippwGCP2DRiTu3JgOY2yxXjhhBN99mlFYmdYU2jU7Ki4TkWZWPzCYoR+Kpxk8estsh9yqyNraL6G5mCv5VLJjq6GuyFMnZhHEUmE+soWxS9iyKCAJNsZmEzcxpsF1E3bKdBCvrNSAE1FEMCPhRFusab2lrmvFNy5d6WWE3ddP49oKnT9bE83Bclp/0EJcNU9gPZ0FdxOqG8xg4qPY2ifm8uE/ZWvKkoRIKU84kMl+uE0INB4SALj0NCPgBi3Xv1NrUSXMStQkYYkYyg3BVTMs3dHZP2HGXCdJFsA23rsUNJJmwnL85ceh9+HEieImOyFYzaOI3sovuTZSfTSR1iXI6WkRZGhsqBNRRDFV3rG9lsgxZv57S1xuCvqWmrOOyWRhHbfc7isPvu9U4CONMzAyivcVsphWN4Lm35P/uBB1ENSfh14k65yw5GZKobRobBAK69DQI1IdQZreGPMuAdct7COEqrRJnFZkGkXa0tgfrJCPzy3WQYZaWWAxHYX6cCE4iz0HwpFM15+DCJM4iqZ9LaaWlkpWl0X4joDOKfiOu8tY9AllOMatxaUtQZlbh2E77a7NZPIuUHcYyU+gguJnNC04C8jiRuDp/FtHYffW7ajDWbKD8hToYPXQDm2AM/aWOYui7aPgVrGo4h79l/dPQOIsazLGrMT/N0TQGOsn86lv8n+hwebQOXU8LX9MlevCUk25g1wRqz9no0lPPIR46ATXe9PkbrLrsVLz/zSko63cquj0BZTasMXvg06BsW3N/4qrCDuLTVB7jpc4hE/LKXIYLIROPEqb034EioI5ioPAPh/BeGfNe8R0O1KppUXivAvbUt9FNqZzBFcWW1pZOosASU6xB0TJZyCFWWDph8aCfyHcB+RSlddAK3SCgjqIb9NZf3TofDVOPaxY1YusPvlBjti99uc0yihUa6M4qyrOw5bcwe8g/yeTIaMBJWOPEijqExZMRj8aeZxSvppRDg4A6iqHpivWlSLqhXF/tqKpturOIjGIa77xZBWcS8nOpabOKNN6X/dGz0oqK5DtOokiVIjSh89LlpiJYDSeNOorh7Jeh1mrcnURa54ghjJZt0iixHJR3XJb+hvY146qxH+AguGHNc1D2jCRDeKEi4ZX7eQ5yy2ltIYFK1CME9NRTj4AdUrY9vxlHfdmpSL+Kw8ijzXIoZiYBs5328l0NToJjgQ6CTotOoq2uhHnap5Unh1gBPJKV0thr/kAQ0BnFQGAfTaHqJKJ+FeOY5Qwi6oxYTSb0use9qSOEruDqTz8eAZnbjsFNd6qUiNj87Hgqi5pamMpfC2pAQB1FDSCuIxaF7tx11J5UVRuTOBY6PRW08P2i5vJaKl2vC/IcRt4SFDe3u7mue9ybUT3sdv5LbiFH/tur4RDxlvZDmO8KVfGVaN5QIaCOYqi6o+fKRHdwz0UNTsDE5ETQmJ6Ao8Df5FTQ2DIRLJ9YDII1HBTFMjx/2G1iaiKYmpsOJmdwC+BzFnQoi4dPwXb6jWdjgjTxsvQN7WTbXYNpzzTSnEXZjWxKtWd1fNnOdga2Vf7IM74WXPXpxzuKxtvnFJZIFtqTKMFPSQeNgDqKQffAiMi3DVRak4yxhSFuwJC3VpteMpoq26B5ibIyUbkBJ0AHQDmTM5NITwYzcAYrx+Es8JVUvnQ2gbzWWjNYXVgx3BifRL0Wdu2aS+EMZBKOZGbLTDAxCx7wLpOYocwfON6pw4plnIWttus47LIy8Vvf8l/B/IPHTBXqh59BCprANnQSZTjVQ1uiXV11cz3aKpeiCKijKIqU0pVCwDzVw1DziXYCRru5vArD3Apmd2wIZrbOBWtYDlp46ETQXIkchjHIMOhri6ulZMWI4WmmNs6YmQEdU2NCnBL0gHOgJ1hrrmGmMWEM6sQ03QYcx4ZpM9tYehizCutqTE8apzO9eQ68GsG2TTPB4Vv2WRTVnUWMSYnEbX91Y7ByYgkzpslgbWnV4MnqXGKb2ghs6fyga+DMgEqIyCClfffPPNRJZMC2zovUUazzDqxDfZ6gKTIjyJK1YcfGYOFIaGSnYHRpxPhky6Wc1cUVmOIgmN46G8zt2oT8tWAZT/c04hMYgYYO5WaWgbypjTDaqNuEoUubeXh1gRDOImRPYmZm2nwhtQnHsLZAR9V2SrBzNPqTs1Pmz8Sh78rCsnEmXJZaOYU49jnIbwqOjnUbE5hZYDlrdtuGYOnYAlSIjKaNXw0nkrzN++rrPhNMzk0FS4cXgubaWtBYwe/SwflO0ClA10k4yAZ8M9s1txs4o3z5CPWs8/I7iYISCJhe6xAB7bh12Gk1qOy9221jlyWDhvUpr31WguRr134Oz5owqHhqb+BJnQ+eNFZrmE1w+WfDzo3mWXTtFJ54YdiMQQcvsyQEblwyooOZAx1nF6snV4LV+SVT3555JAQjg0tN0zCUTTgmPmVj2gAeYd4q5K/Nr5gyTFiMk2AbKG9qw0wwh1nOBJzK8vEFzGZWgqlZ7F1smjb6ra2sQocVQxNwaQoObOX4UrBw6GR8zwJ8zdIPP8tKf8Snech48h88w6du6byb3/AFgx11PX73ETP74ayIMqYxy+EeC/Vmms7j4Y9/CzIQh1M+de9Rjzx88+nTl3ryy2XpLKIcXuuVWmcU67XneqB30ZmFu6krqkxuwBM6DPYEnnqnYYBX4RBWsInMJ1waMBrwlfnlME1Div+nYdxWJ5Y6T/hcNoLNDQ07DDxpZvAET5nuslBHLmTyWp7nHkToCLhhbWY22KOY4T4Flo6oAx0XZwfTW2aNI5jdvjGYxAyoubQS0IHRQU1vmTOzGnNyCs5hEnmc9Zy8/yj2A45zkmTqc5ZCJ0gHMY29jFW0j8s+dEZG702zRq8q/9zzz98OFrAfcurgibDtRxeCTadvheHHb1ujPcSSenGWw+W8VSzXNaAYVDNOkg6thWU90m1+1C44waVg+SCcG4qpnlHQhNX+KeEgKCAUWU2U1hoCBNRRDEEnDECFtikrJplLMbR+XDIyl7FGybqX/Op3Bfe//3YzK2Dp2uaZYGYnDDSecLlpvHoSxgpLToxzSYcGbhIzjc1nbzdP6vwpThrhJgw5ZfGEEmcITdSj0d+wd0uwAGNniNriOTPg03RondEs/s8lLeTzh3lm4CAmpjBrgROgk5iAkW2tNcw+xgROQ4VP49APMjl7YP2lY6fAY2MwQycCYzyJWU6rCaeH5SjurywemsfJqUaw9dydZj9l+eRisHISS1VYlppqH8mlc5yGo7j9/7k5ePRPXZIEq51zGzajuTTHi7ptOWcHdIcjWIa+0GnDXjgH6D0D50X+NPzbHr0nmN6GPRPUYXoJToTLY3RsxGwFTpX7LpwBTU1ivwbxFujmTttiHPLCvuOeE0/UoCcX1dRrnSOgjmKdd2AX6vMGTph836zCnCCCsV1b5nHT8Kk8TW4DBnLpSHi6iDMBPsUvw5BxmYTGjkbrFJ6UKdosScHg0gkE3NOAIW5yWQqa0chzaWrC7GM0sBy1KcyHfDqLzt4FWwFaGkku9zThlALoyr2Q0LhiAxvX1CzKYGg5M1k+vmJmFTT21M/80hvyZ1GHzox60WhPgr4JA/t/vfNPgw9/9t+D7zz/KcFvXfMKM8PhXsAyaI1DoDOCg+BeCJ3UDGZTG8/YahzF0tFTwT3v+Sac0Fpw/osuNrrY/3CzHOqa5SLqdvL+Y8HysUWz/Mb9CJ62msDSEvvAnODi0tz2ENeTDx7Fstgy2oRmAPdJMOIMY/Hr+4NZyF+FU57ZheU+7mNgtrfzSWcGK+DNJbbW2kZUguMHXA3M6IpeJWYS7Bm9RgQB7cwR6ciKzUg4CpcP9y24eTsFQ7MMo0Sjyg3dS3/tcpfUpO+GUVzBEtBGPAnTOJp1fyyBzGJpZmYLNoFhXI/feSh8hwF8ZrAJzr2FxcPz5j2GFZRz+UdORvFpnnHOIlbhSKiDOb7aHrk0gu0fXDBPy2bfActZdBTc7yA/PrGb2RAMKg07DfA0Nsy5LzEFWVwy4pIY28nlMp7Q2oCnbxrmP/mb1wfv+vd3B/OL88HaGpZxNm4OvvS2zxraBsrXoBNPIJ3EU/os9KS+dDTckOe+inGQePpfwdLQuT/6GC9mt//tTWbWwH2cUzgJRuO95ZztcH6T4fsfaOvMpjk4hDVsuHNmhn6Ag+Nsgh246YwtmLnByWGDm5vcCzfuw4myec4jzMxp+eiimY1sPm+nmRU99pd2o2wRfpWOGx6vhSUs7K00JpbhNbCE1aAjj18lHAQrql2Jw7fuUzqjWPdd2NsGcIZx059+3giZwVLS3J4txqj5pN78+i9gOWkORnYTnoSxLHIEa/54F2Fu96yZifC9hEkY7S3n7AxamC1MbgidQIOP53hy5pHZKTw9b9i72cwQuIlMp8QlIy6vcFnFOAIYVBp+mXXwdNTkDJZZNkIO9xQgh5OFZZxMWsRJLOaZGQLy8dhvjDkNJJ0GRXPzeQrOwywdwcDPnLYZesxi5nLCOJmFZWxyN1fNMtix+ePBRS96QvDxd340uOhRFwansG/B47xzfHKHHrTcXEJbeHgBjhF7FGY5KIATxJJZyvXon740uPVNNwRTmyfgtFYwM5gyjmt682zAP7af+jWbcGqQxbbw2rx3B2YecOJo91377g5ece2vBfv3PRjs3Lg9+KurXgfnPmMc5RLaQYe1ypcOMeNpNDA7Q/vpSJprOGEWcOZC606HAUcxyZNS4cuJE3uehnipS51EKbjWB7E6ivXRTwPV8tLfuCK49S03YDN1m1k3h131Xtsu2A1HAiOP0mU8ZU9uwHHYnVNm9mD2H5A/A8NHA22WsMxsYDL4xOc+Hrzzg38XbJ3bHPz+z77azDDoGLgEs0bDCQNvjqpyWQfLPDSAq4uYWcCAzpzOPYgJ80TPE0urcCazMIrct6BT4VO+ea8CDoHLOCuoxydx7pXQGHLfYwOcglnm4nITdDN7IODDk1Ivf95Lg0995dPBt+6/3TgqNpxbxt/74mcH7/nTfwwuv+g7g9VVzCAwi6E+nMFghwUYwLhjFjaLZaIWVni4uZ91cXOdL/NxiY0zLM56uKTUamHTGu1fxdFdnt7iLIdGn0ttdEQNLElxueyv/+mvg7vuuzOYn58PHjy8P3jNx14f/M8rfxUOZyl42gd+siN6df/N4Mm9IPYiHQMdRHvpCc4COzRsIDKx7LfnSmYUvdRBFEVqHdJp567DTqtZZWMeyvK8573fDB75oxfGqu376D1mX4Dr+vNYSppuv0/BdfsGnvgbsE1LMP6wUlhO4tP/ZHD7XbcHr3nLHwS33XVbcPTkMWPgzzvzvODf/+IDwQJOGC1iVmBOUsHoc7ll6yN3YfIBU423p/kATyfBz3NwyYb7GTSgpJvdgaUnLCtxI52Ogk7k1IETxklwaYgXDfJGLDHRuXHJiPX4xE5HQMex8NBJ46i4hPaiP/u54OZ7+EmM9i1DAwsr+9AXsczDl/Qgl/LpLGjU+Z4FdeXTP4+omnrQd9dT91J04rr5z76I5TroghlCAzOKqY3hMxxnRSsnlnH66aTZsJ7ALIyG3LyUiJAOhXguT64G3/mSp2N5rH0IAOB86NlvDZ5z3YsTspixuu8OsOEyE09p8Y+tBnZwFI0JOLrdT/XW82SqDfGAMmpZ2smj1qPl2wNz07vr3vd9G04CRzixxk4DTQNMw8+nYS4fHXzwoeAnXv0/gnv33RssruBp3DzpYuYxNR38+cv/NLj8tCcbRzCDp36ektp42lYzQ6G9buKU0tKx5eDY3QfNUVBuik9hxsJlGrNxbjxJOMS56cvTVpzZ0LhOca8CexQzeOI3x2hh5HnqifsN3K/gkpWZ+cAR8a1sPt7ff+e9wTN/+7kdsOgo5mZmg2/im0rh50IwC8B/dBZcMuKxWbaRMxjjnKDP3med2akvkW+/42vB/IblYNvebcG2bTswA4FH5aM+NqeJ1zw2uLmBv+XM7WZGZDaw0WvkbdqMpSfq932//rzgvv33hWw5s2rMBMdX0pe8RH7FUG1HReDWYzXt7PXYa/Xq3FNHYau6/5P3mVkEDaF5gscSyiJOBZ1cXAi+76XPCQ4eOWQMrV3ney69Mrj2+a8JNp+13SzjzG6fg8EPHQ6Pj3IJiS+/8Sgq33XgSSXuc3C2csf9dwYnV+eDDVM40rq0aL7jtLi8GHzjjluDmbmZ4GRrMbhz353Bjbd8JViEDrPT2JdYWgiWlnHUFY7jSY96QvD3f/y3xqmRHzeSf+LXfzL47Fc+F6kI9H79x14R/NILXhpMwfnxuC8dBWdRnPksPYyjtJhQ8JitORqMpTTux5j2wwnxxcD/+TfXBtff+p8m769f947g4kddZByFmaHQmd53IJhewPYzluPodLiMde/x+4NvH7gTtBcH3/0j3/smTIYuuvvGbz370h9+iplhiIJ/+d//KHjxe39Dkl2HKw+uXA0P1ppaCq5vnNfg+p1eY4CAOoox6OQCTUw4iwc/dGfwiOedX6BqcZIDcBRcgjGnkGAg+dTNl8L4wtvRh48E1/yfPxjcg5kFN607F6Ivfe6Lg1+8+sXBRrxwNo03puFNgiU8+Zs9DM5SYJg34JQTn/y5t8FlpsOrR4MXv/6lwX0H7jengciPD+msywu22jgDypK/sKT9r6HDHsbchuCOj+AtZ1hi8z4InvAfefX5kY6gm5mcDr70+v8INmCjf2ozNuy5GY3lpwUsv83hVBeXtKgjj/Ryf8G8r8GTqfAT9zx0T/DDv/eTwdIqXkSEczlj9xnB3/3BO4PzzjvfOIT3XvfPwV/87RuD1ZWV4Pdf8Krg8XseGyytLQWv/eDrg8/e+vnjdEzvfec/v/uKJ19+9sJ9x5776B+4ODhxEien2tfebbuDb994x6/PnTP3esmrGi7evfg8LO3NNRsTR/FV3v2rS6ce3nTupn1V+Wm99YMAhqpeikASAW6cctmozotr4ItYz+cSEA3mBCw3ncUU9ge279gWfObv/iP4j//74zDo8eeXt133zuDI6nE4lHDdnp8DpzPgy3KcSYTLWPi0BjZ1eYqJSzIf+uyHg8NHH+6s2dMZcNnJvMDHeQvSXM83m+xcopKL0U4S72wsLgbnfM/5xgHNP3Qc4Sm8xIZTQqIjVF3Gy3hbzttlNp2xU2GWrdjObefvNg6Mx3t5HJd7Jdw34bHXtfay0Re+8WUsuWHTHrqsrK4EDxx8MPjgF/4dTgUvzmEp7A/f8trg3gP3mQ3qn33jLx4/70cu/cOjF6y+41M3XX8Cs6SNJ0+e3PDfXnjNjy/MLzxq4znbv/DYR2LfiPDhD61sHjh2cPX4iZPnSPOqhAv3LPz00r1LP0EnMdmYXMKuyzy2nA5tnNx4tHVLa6b1UGtzFb5aZ/0goI5i/fRVLzWNW2ZIai6HT7+HP38gOPDJ+4N7/7V7p8G3pbmEQyPLJ2yzCY33D07iM9mT2JPgksqFFzw2uP/jd8HOGUtn2kyjfs1rfsQs53BzmC+XmR8lAg86G/LjvgePyZ46cDJYwnLUjz/xB4O5ab4nYDghpPVPNDNyCh3nYES26cP4Kt6feMUf/5r5xtMsXho847QzhKgT8oW8ZTiRE3cfNnscfGubp7O4x8A9hbX2zImzC27kb8QRXG6m/+v17+/ogGYGSytLy0tTK1/cfuGejxxqHvnkkRNHl5GHCcrCEpzahsc943GvuPLyZ8zBScxBrwn+ocaW/7rpv7YBp7kf+7EX3EMHgTjgaMJnrjb/7K/+bGXx3sXfWLh34TVL9y+9evG+xTd2FE+JLN239EPL9y3/POhfRQeBQwMPgPTbK8srN602Vh+gFwpwoCzYFmzBIS+I4/xIr1FFQDt3VHu2RLsW7198nks+g5fEzBMwlkP44hhP4xz63P7g4Gf3d0jvS3Eeh794IDhy48Hg2NePBCe+Ef5WAuN8CY2/78D1el5cKtqCz3dse9QeMyvg5jFpuNH8f1wtRzpDA39i4WRwauUUDC9OTPFYKAwuT1BxeWeNMwKcOlrCBjRfluNJKJ4g+vQbPxpcccl3BbPYcJ7AVINLO/zjjGASbzBPI5zCMtHM9LR5kW7Lhs3B5g2bgu2bt0E7OBX6lbZv+ciXPmZmDNPYUD9t12nR0hMbgusv/+VtOD21yXyCYyPeA+EyUxOzHjqtPU8887f2POns/7X7otN/edfjH/E7Oy854507Lz3jH6fO3fjmW+699cTy2soyPn2+utpcxeneVvCbv/ybH4d7u+HI8SMHwdq4QugP1Sew/z4ziZlHC21YhePAx0hCPa9907U03c2f/CGDGz77BE+xhikUrr/5x7/+ERQ+jBkd3rILLgDdhXAA71m4b+nv4TQ+QRq5MHt4+ql7Vp4GtlOojLf8gnuajcmbcEBqojWBD4FsXF1YW1hbwqGzHUuLS6cj3HbyxMmNwR/C37W4oKfXKCIQzuVHsWXapkIItPa3zsMG7+OX711+w8w5M6+USjsvPv0DeIrYDxu8A4bv1iO3H/q9icnwsfvgpx7A8gr2AvD+wN3/jM9TYCmJG9Q8sLTjor3m6Z6nhyY3cLlnMnj4ywfNWX9+KwmGyiw38X0Bzgp4lJTLP+YILYw/EsboH13GOjvNDm1P2/z8yrW/Grz91W/FV2g34QW3zcHW83eZZaxj334oOHnvkfCpHctYm/G9JH6Blk/of/d77wwe2P8g9j7uCY4fORY84dFPCO548I5gcW05OO+MRwZb9mwLNm7aEBw9ejyYwHLP1pktwYc/d13wO3/7+wKFkQ9jDtWhG2YIV13x7ODLX/tyWN7W7a4H7zJ7LdsfveffUGE/DPi9rdbak7ecv+sUnu+Pon1LK63m/TONqcW11tpis9GY/PO3/e+n4IkfR5bwigcvWOXp6emVbVu2nY9mb33fv71vOxyIKSENncLrfvt1+6YmJw8vryyfBG5b8JLgBGs+fORhfKSktePE/IkNoENXoOdC3RrHTh7bjTnX3ESj9STwuQDlD0HU/ITpzsb9i/ctY4bR3IQ8bm5cjkeD29FUTN3wMkgzODW1htcjW82dE82JxbnW3CMCvEzfbK3tak1MnWw1VudnZmb2B88IjmBmF547BhO9RgsBdRSj1Z+lW7O0unQxXkSbX2mu3NK6f/nvcSan0VpevQDBo2H6H4axeSxM1TfwMt3v4qn2iTBKk3iav/Hk5+56Lc/ecwmJS0H8nhOPiPKFOjoEvkcw28D3hPBeAs/8c09hCieNAnx+nAacG7q/+OpfCj75n58MtuNI6Ot/+0+Cpz7xCvOC2DJeEnvE1tM6SzIwYOb66m1fw3IN3ubeAieA9fxlvDx38r4jeIfipJlh8AU3bh7zb8dj9r4PuqM5wZG1L6/9ws6ZbcHEo/FdJby8tmPbNnM0lvsF5l0L2NRZbKjzFBU3hx911vlmOYuGu3PB6G7CZ0n4CZEXPe3Hgz9627VhO/jNDFzzi6ea287f8y5AsrPVaG5DzSvxgL0NrYU9bp0E84tgoB/G1vsx7KJfD2O84cBD+y6EsQ+FoJAGfse2HfMw8igOgn983z+dj70LdAP33elFg+YPPveH/u3osYfvQnoKDogrAshvNI4cPbIVhnpp+9ZtD0HeTtQzelE3vBAINRrfAvu9EMYPwOP/CXwjpHkHik8H/4vBYhEKHEH+RnitB5oTzSdj5Won8jmz2IglvrOxlPUs6HgcqC62GhN4CaO11Gg275mZnp0/uPcg1/l6dhaX7dBrcAiooxgc9gOXjMWIbWvzy3NYwfhic7LxSDw2PgZPsPfhqfYgHMKmZmv1vInG1Ak4iD1YudkOw/R52KvvwkPunkd893nvOXzk0Im/+ou//Lm7DtwdXHnRFcHyLN6U3j8XfM+j8dkH2LUbvvgVswz04c9cF9xy+y3BQ0cPBlhOMeaXvzJnjqzCa/CzGD/z2y8O3vonb/3iNc/+gc+2mo3/xLsM/xJ6CtrH8OKm8ezOLdgIh6XbNHdgavvsrVsfueO3sBRyAM5uBk/X27F880zshFwIo7YXRu0QbOx1Zzzl3LeuTaxtvuNfv/4Zc2yVp4+w13HuNRf/BtTYA4e3Ac4P51mDz8EA797xpDPOW3vd2suBgRHOPRB+U2rr+bu/Ap2Wtl6wh98IeQo/AohLvAlsJlSbauA8bLADWF0Evpwp8MF9J3g8AEj2oew4Zk0b4R5a7//39z8K8ibhoDibaE1ik/tdb/2HT6LaVtQ8dujwQXwvBc/1NOzQBMtk8K8r8zu273gmvjm18eT8Sa7hQbsgwN4BmSxMT88cB7FRDDJh382Fb7e3+ALIGeAzBzoUtO5tAjOovwtlWNAL/guMvoGWbocu39/A8wB2ks7FQ8JJOL9NyMMYmHiYsxiwXWs0mvsxAbsDK37fCPAJrs1bN2978MFW8xGPaMR/IhBC9Vr/CKijWP99WL0Fa8HGxZWVb2P1mwYJprB11kxj4tRac+VxMCJb4CTOhZFYw+czpvAZ7tNhOTbDwN8O03T2saMnnvibr/2trR/9j48eP7VwauY9H3+vMVpQBrYmwMoKzFVoplo84YMHXFkKob44+DM5CaPTxF7BFIxw89iJY8GvvPpXHv+873vebTCNs4dnjr9xZW31F0ncfprG5zlW5zfs3PBXjbXJy7H0cRTG7f9dXsWHmBrBDth5Lr3MYHnktjUYfji0SVhOfCCqefVqo3UchvuO83/o0h/HaSJ+EQ9GvLG30WxchLnNIbTnEHR4BJT6boj75if+8xM3w3gb4ww62PrQFyDjHXAGO2BYr6L5pV7YBsADtyFo/M0/vX37z7/oJQ9gGW7H8vLS/Fe+8dWd+/bvn3jKE55y4qwzzz4Mg346oIHhb2z99Oc/dQFw22ScEQqMMASPe/Qld0GHyRPHTuATsbhQYGRhj2LL5i2N6anJnwK+++A0DLqoz++FTJxaon1u4buCk2diKWgCatHBsH54oe/QIVuwKIUubTyIM2f/AbxejDo7kD6J9asZONf94Hu01Zw4gtnEU0F4D8ST0QPwPF/DNKeJJs/hq7t8/XsfPtd+d2u2ubK4sDiNejt2BwGmgcGNbYkajBAC6ihGqDPLNAUGZmrlvpUzp6caZ3LNCOlz8bdzrTGxDabpQhgJ3vSLWNw4BoO7GYZ4L5ZEHgPDwTEzcfzkkeXPfelzGw4fObwZ9egWAth+WEz+j41P/IMVbl50HOYRFsYLhKHlQx0UwOJgE5flNLowNgt4kv4CvpO0cPNtN5MvHQ5sGwhwhcspXL5Z+RKeuo9Dxt6p1cnXY21mN6g+3FxpfRE71Y/Ap0LwgaVgAR/02A8h/D75HWBzJuTvhRM6ALm3g/dNCBfe/f53Nx86+NCTvnXHt5586+237f3mHbe9EAZ8A/Si46OV5sY3Xh3A0d6lU5fjvQossTQ+ibZegad7LOPguZsnftCc1/35656NvwZmStPLeGkP8jhxYJtnzz7j7MlbPnPL50HGmdn0/37HG5+EYnCl3YYYMIWc1W07tsFttu54+e++/Ocgfo648KIuO7fvJKI3HXr40J2zs7OPQz080Juy1sICm2u+kkJSnnii7pzUQECrtbS0ODs3O0ua4zD8/wXv9kzEsXneOIkOOsw6YPd8TJIOoJ8Po0FfwlzoBmC5htZNttYmtmAmeV4DL9ljAOyDe3xo08bpQ0uLzU0tdDvOrB3G6ayZ1oHWaY3TGgeohF6jg4A6itHpy1ItOXn7ycfMzcztwOvA2/CUPQ+jAOMwgQ3Y1jlgtBPGBQa2dQSGZhEGDbOJxg7YoQMwIGfA3E8ffPjQZ2Eof4ymCFeDhgnr6nzKRgQmCH+gD3VCYIho02DzwdvMODCTWaYxhdENtm/dvnLt77zueiQxu2kcef6zn//lW2675UWk58Ys5OCN6aVNrbW17wRTPkXzCf0xkIyPJzVugtD/xPIZvoTU3IZtgceBfBU67Xr9X75+85e++qVLrnn28z+6d+/uh6//3PVPu+m2m77rtjtuOw1LNzMwsFuhD7+9gdNT2A/oaMwcWHE4NOTTWrdOzJ+8ZHZ2DjvywVnbNm+bhEOhgzU0rHbw0MEN0zPTYGeayyzjbMh/30P7znrc0y+54qsf+8pbcJT3MTd+7cbN2JA2T/2UMT01vXrm6Wfi5+yCczGzedpHP/3R78DeAnwHDhthVYztf+lP/dJtcFh/s3PnzgPYk/jv4H86/uiIuUDVOPzw4cWtW7YtbN60dW3+1Pw5yIUHBlhYI4OIb6JxcOWNw3BJqLW2A32L42MNfAUQ+xet5tk4EIarhR5sTUHOA0D5cWA8j29CLWMecmhyau1LE8uTm1ZmpuZXVpfmVk7O752Y3XSksbJIO7Iwuzx7MDjH7AuRkV4jhIA6ihHqzDJNwW8xnI8vk+5tNhuzMMTz083pb+JU/hSe2mdhnBbxtgPWiozBwy/5BE/FHGEDHnkfxAe9b0b24Xvuv+9sGLIpHNOEn1mFm2i2YNWwdt1Y5VIVlt65/EHHsQpHsAojzydlpk9haaR5/jnnzZ7/yEfd/7u/+upvb9u6fctZZ5yJ+UNrFgs6F8M0B8+/+vlb/vgtf0wFYAnNUz2fnmHTJh4Lo8aTRGfACB7GQaw3LbfWZvBRCbzaDHOGk7w4nTWDJ+MLUH/7377nbzfvO7Bvw4c/8WEeAabDWcWfuYgXIngeZkthIfmrPxBi5KBM9oNZTke4K3yi34pyvDEIRCwnQV601219yYJJCGAJwFxbmzoxf3zXt+65ffMnP/vxjx98+KEXg7ZDAaeLCdXUSWA68b6P/Gvz2PFjsNdAdbWJo0T4Ou3UVOuKy77r/0O78WMRkxds3LhxATTY08fCGlXHfvWFT73wArKEA6PzYhvRCNOuiV//w1de9KZr33wbpkfnAmjsQTS47MUXQnDwFSeWJho3gDe+Dz+BAwAtvADCpargBNYN4Rin4CmXN06uwp9OYQMbjmFuZmJutTkzM9VY2YNexQ9eYCMb31iETGyI6zVqCKijGLUeLdCe5XuWnwIjhIfFxizWiPD0ODndWmotNDY0HgFDziWnz+Po6iz2FvA519VzsI3Al6224YF7I8rxIaRg9RlXPOMcLK9gYxQbvlh9wX9rFz/m4uu/eN0X/wpG8ZlYUdpy6MghHuNcPOu0s47s37/v6BlnnrFMgzgzhRcWguDRMHDb8VbDaXBYWB9vPYAnWuzINjEmWxdecvElx8CYjkXW4mEC6Uuan5yemP7QQrBwYnp1+jH4OYVzJvGoDAX4jgCXifZAzw2YcrQ+9umPbT3w0IE5c+onNNlQtzUNYwazioV9XMwgX8pCVugkEHKWgwtL9ViRwXXu2eceBfkeUJD8wCLWcpCNWVd0kZPxFcZDwClBddCiSqMFQ7+2d/feU4+94MKJF7z0x58FWj6/h26kzeKOu+84a8djdvzohg0bsE8QbqQLd7QhuPz7L3/lS37qJa03/P4bHo2TRmetrKwYZ0UaKMU3u7kERudjLqMPYsT0nz/43se96Y/e+A7sP+D18GAXkOSJpkUQn0KNY2j40VZj8puYTqA/Jh4BjqvYtzkHbYYvXjuCN7K5wU5B35ybm5vHkeqz0Dp8WqS1xp9/nV+aP2vzeZu/2hatwYghoI5ixDq0SHNgVI9gQQPPmsF+ziJmmhN7WnMTWyfWJs7CevMmGLbtDazRw9DMYCtzFnlTeALFsc5gGU+eO2GI9+zasWsD6LisgdWg8Cjmt+/69qVwLvg5CGyWTs3Mn7Hr9IN4N/h+TE3mzjrnkedDHjZCsVHaaD0KT7pzODmz3Gqs3Q2DegaOj87BuO+A/jtgnHBOPzgK4zqBZR8+HdNB4BBWi5vfn4DdPWeqMXNJMLl6I/aGJ2H8llDnlZgRzBw9fvzU1q2b92IlZss1z/lvJ7544xe5KSzLQ1DZXHj7wCyR0TfQkJu9AvzLWRG/7wS/Zexta9PGTavf+cTvPPwPf/muk7DBm2ArV1Cy4ZKLLjn6mc9fjydw2M6QlmLwQN5Y2LJpyxqMaWvr5q0tvCA3gVNkS8962vd++bW/+Yefu+PeO7bfefedPwuZK6iHD1cB1fCiTE6f+K0m7AvHL9BTzuw7/u4dr/mXD/5LC46DR39jjoY1yAMXo1JmPNup+VOn4YHgR+H6TsduBJascHaZy3fYo0DeUSw4nQnf8N3cAwdYkxgcIJ+EA1/FRjceDvAjhdD0O4DBxXD++zCh4suBh7HLshE/OIV9j4kFCtVrNBFQRzGa/ZrZKqwlP3B06mhzU3PTdhiBvSs4vt9orV0EI3AA6y3fxvLS8/Dm1Nl4lIdRh4HAqgusxwG86vsZpJ8Ao3U2nM2ps854xKGbjx3l0U9eNHjbYax/GDOVm7EJOrs2EezH+djTp5uTF8ChLMKY4FsdwT7sUPwEtl2xsBLsw9nQC1oTk/xcKz4F0cSLFzBbsGCnTp06TucAy8fjpTh62qTjmtp98W48FbfmVtZWZhDym1F4boeFxwoLHBhMJJZcoOx3POk7Tn78PR+983+98dpt2IvgGX9z0YriWgZNEwac7y20Ljjvgnksg5246lnPOXXFZU9tbpibm8by2GEsq+Esb+MEltzOR+UtqMN3FE4hPPGaV/zux5775ef+D/DispLZQyEI733be996+WWXH9q2dRuPlD4d9RZBvx9ubgGtueanX/7T56Fd8KVAA/sPKMfPVayaGQzaiJRRU4y8SfAf6EJY6NAaR45hW2BlxZyKgsiOozLeFPsRyAuX08La1K2FpSq+wfJ9gGoRIGFvAm9d4+cxUHkH+hS+u4n3KNDfmIBAtVNwo3iXpnkvPrK+AIf+PaC/BG3FclSDn/j9T7TthsnW5Cm8cIc1xbXjMxP4+pNeI4uAOoqR7drshs2uzuLZf20L7PXFsE5c98Z5+cbjYZdxRHQNS0OTeJpvzjWwNwEbfAoLJQeC1Yk9fK4HPdY8Gthb2LEdhgdv/fKRnAa7MQ2Lg9MxzT1IY/G88RgYmE3NRvM0GMH9MCjzoHoO7D/XtGlj9+AYzw6sn/BFLTxdN7hmvg8F2Iheuxd1eCJqmpvJJGaLFhYXdkEeLCq0CK8GXIkxUnQSyDKzgS9/9cubn/vCH9jCyQ6WkXiK1dDgcx4rP/OCn/nolZdf+ZlnXv5MvHu3/Upw4tvR+O5GA8turWMwlnizOsAJLDSrQWOKPZEguBOP+8dgqb8JwXe845/e8UTOpDADodHHsVGzRBZc+thLD+IY62PgXJ8AjfGUjflY0NoITo+CN5v9+q1fxwktxCCAddiOTbObVn/v1///9s4DzI6zvPfzzcype/Zs1XbtqnfJcpWxjG1sA8aFZjAETAngkAAXSEJySUJLgBRq7hNCia+dCwRMdSgGY+PgBrZVbLmoa7VN2t5P2VNn5v7eWdnYFCd54MmTaN+RVnv2nJn5vu8/q//7vf0D//e9H37v9czzGeYs+ZzzZQ2ivbF0uXJRnLBW+UwEQYhNa0trH+cEiViiqW+oT4IPuFgMcpaPeaiO03pB53Yu6Aao53NxjufQxBnreT3JeXm+urlvlDuXOSfNpSv5eQP3SXNOiddzyOejTDwUXJwv/pOcYCGv9Tg9EQh/UU/PpemqfhUCwTcCZ9qfbsZButxUiHqx7Scgwl4xRcE5EIeEncLLlp+EZsRMQbhsgNJhUkQY0ewamiC8FNo9jt1edrowpUN2FixSKQeDw4NzIiQQFrgOfMmu44IAU5DdzSkSYTRtXGoOIVTgmt0wcT3cvgw5IM7Tac6hc4+1OpWsvQZylE0y3MSQpw55LWPJ8eR78l3OgyRFIECVSBgqJ+3Zt6dL7sF8ZJ5iVgqjrT75gU+O4ixPkrhGlFEgzohGSJUddpCHOHHGBqNkfoiJ6xsMNsbnJYZLQ+sykT459+ZP3XwAjcQN58FMWFcouMrVymuwP8UIM3qAGR7gXK6xu/i4Zf2F67cwOZEPogWJ8Atn3dHWMfjON73z0VRN6n6ZI2M84+DsYPOGzTPr16zPcZ2s8+mgkFsRCdCAgqM/O9rbt6tvz1uuf8uwOL+fXDvfnWKxKGau46yPLGtrHc+QxEDCYnnY4I6GRdoc2iIrWcmElzN3iQRD+wiWsbJZYGczERzi+d+M9jHFuYYghijrr5FFJFYmBp4xaf3htEJABcVp9Tj//cWY64wHsSSjJNlRpmGLX60QTuo+l11/pGr8H+K0PER4UR77AyYH9pRi7oAk2TCu5GUN/CZ5CFhNnIa2lrYBPhPiDklSCAxSG4JEBrhfmXNW8dkQQuYEZEN1arKgsY3jJG1mP7qCsd4Cx0im7whKwglIaZCv73LN/2ElX2tf1j71iyvicz5mYowon/Ez+W1ic1o8GCN8T8iLlAePsNuQeGVucj7fmAL5B76ph8wl1LWFO1FyA7MK9Y/4oiWfdT+mFNbpXAipRv/lW//S/vY/e/u2+x+6fxtS7wrObXv84OOvZAwGFsEZHuHEljU3i4lnJULlcgY6h09bmG36ngfuSY9PjtOzTjb54RJCQQdGwYH7DnwBjaMNn8aFOLLteCwuvphQqHGmhA5nMKWd2HPnnkcGHx68C61IzEtyn3Bg0XvCwzZnMrflb339W59KegvfZzyen0RRXYHZ782st4PL2RAYqnEFZOqZcb6jObFtMGaar8PceIDbH+KNUV6LOtfL91voKj7n4oBCxcHdTgiE5RT5Pfoln0o4Mf3ntEFATU+nzaP8jy+EDtIlCP8EdSkaUQbaILaDsNxjEEUdWdloGKYdRpMiQ6shkBREn4eMoljUH4Q80AyImiGMlqxo8R3IDl42HMLU1s233Dzx5+96f8517EE+6YSoaBJhneTekgNQz/c1iJ5GmJ7cPjOI0UaIiBrhRN1YQR2vkwRs3mbH7brGhsbNJ0ZPXIVDOOzVICuUMZKJZECEj9jpZewAwbcYSrooC4T8Pc4pv+GVb5jb+9jexompieQpf8AiTwfWSvbRx1nPJczlYKlYXA05SxG8w5/9f5+tfv5Ln79hbHJsNffHZkVc1aISY3311q92dXd2n/n9L992pHVZqwiJkK5ZnyTLhaG1n/zsJ7vf9+73EVVkVRAWhOKipQSm8OP7ftzM+bKEpw7Wa7W3tM8h5yT5ou1Nv/OmE39/49+vlfshcCWCK9i0dtMsEWbTH/vA37HDN2mOIzOHpm5Jrkq9DnxtNAe5HxKdbIdqdSziRAYwPbH75+ahTJK7hRoX/xqEf3CEsW4jSOEc3kVAmijPnwgoq8IJu7jPDLKYMOWA/ApxiQT3og0SKx0mRmakVmAYp+wbBKLbjjqSiy9P3ieT0OP0RUAFxen7bH/tyvgPHq+Q1GZ7pZ8VilCob2di6Vij4wVN7IAv5cJOIpUG4BrIziabGBKxDf0OcIB6fgbSeIJmQ4n1q9Z3c66YQqTktRBTsP/Q/pGIZf8Ui3oz5QK3IyiSEGE7foQ5KKaLa+cRCmXsQVQG8iUE9nLICY3Frw4ND1q3/uDWCy7ZeVHjuWft+HAynnyY+14phIlpxUgpECHQW2+6tXDe2edm8guFLGXBjzKuRGAdxdQ1xjnDTiSKGclDAJrxl//uy2+ABEVAhYeQ+8c+87Fl+w7uS/90989WE+Vaw27bFaLl+2pOEtJdPLhIzFZCtLwh9Z7M0PBQ4orfeeHmvXfsvVNYlHdl085JHPyw9/G9hJjabyCngD7ZXj1aE2a1YPkLL33h+I1fvvEV0m0iPHfxH3/3nbvfxW3OYIie9/3hn0+iLURvuuWmdhzW9vKO5cVdt+8a4voGvqiugo8kwERk23fhw7+OW0R5X+YbhsWSK9KHSa0VwV4VXwzhy7FwmMW1B+9479u/8Q9/89mD0P9laHwdPAdCm6wpFnEWaxGtr4d7tSP9mKOZQ1eb96v2ACFiEwjMRp7Dcga6YdFfbk4gJCbx49/P+p8pAZ+2QH15eiDw9F/a02NFuopnRSDbm22hPHSZ+MrGIBKfjZsSu+EIu1gSu6p2nWeq52LSptYPoaAktElasonYM3iMB4nvaWXv7NqBF/e8yqqtGzZL3aQwRPbUoIZw1GvitfGfFBYKUjfpHEglA5U1QpgupH+fsCqENJBfyJ09NjF22R994I86jg8ej5IUR0hsWNLC+sjff+RVV1x6xdo7vn77Xem1wvEwHf8wr3CYc886dwRne7WmpmYBYsMG4n/H8Z1RhFE6YiIEW5mClNhjjpd/5H9/pPGSl19iEdIp17KBtqyP/sNHN5+6ZWg2Cz/gRvKenCMvZJ7hD/KaBYTCAl4VODK5TPCpL3xackFCjQKSlVM5k2qAdQ3gRA2lspVAyOQpUniQHXnh4vMu9j/4ng8e/MinPrI+X8iLBhE0NzSPp5O127nNaoav5W7173nbe8pveu2bHiZjcYYsa5aCT8OyprHzUMvd38dEhomMxcQX1kt5amAwCAjZFX8C/gXT85bXvKX4uS9+Lsb78nywsgXBHXffcRH+BZImxdRmyIkh+kk2AWKG8n1xZhMya8rIngHGJPTXkDfi7+TiCKoLCXp+7fvb4wAANv9JREFUiSVKWZF9yNtRfFZjiT53t6xdj9MbARUUp/fz/aXV4bTuIhyzTNZbK53LVpogniKgv2AT0URqAVVGnRk4ZwohMch2mlBO04y+sJLgmWMQwwSEArH4L4F/jnS0dz2ItvAeiCl0zEIiVjabTRcXimgJZgsE+jgTWMCRbHY9uuuHf/Anf/C2sfGx1+YWcmIPXwzhhOo4L+Ra+QdakzlH77znjh3Xv/31K+Radvr0zgl37aFvAtK/E1NREcdEE29LlVgJyR2B0I+QOVxL6CwV8+xmPCk9TfVNNmYoyQyX6CO23sK7iwfn/FwYCNlDy+EcAIAjnAg/h4dcIYJAnOKU2ii/9x3/e+Bjn/m7CyDi8P8Q54vW4Y+MjUg9LAqrSrSY1c94HYyzHmjib3/zO4Lnnv/c3f948z9umpyenLz1n2/9DDamsFkR15DcyCDGmmisa2zj+zJ+knpUy8CEKDILf4K9BrVmClNbqb6uvkoPCkkeDNfAGBb1n1o5X/ws5m/f97dHKAOylSQ+4mrxyyDPz9x25rd5vodAGae1tZIpo/dQ3E8CDGwj0W1VhFyWavFSFLGX+0jxw/P5nGQWf4B77yZF+xB2wONoJCVwzZrnaQ8KsDztDxUUp/0j/vkCITJT6stkCbyZLxWsfNSlU2bES0cISw150Q3WkdSWZceIScF/PoZpqRQ6B2mJY7WDDXU3hNIJIeOAtm5vb23dKLZ/dtnhILy28Sucee8D97rDY6Otn//SZ68eOjlUS10i8TF8nJOE1yRCSl6ExCpygevgpjAXgqFC3iOKKTCDJwfqiSwS4QBPhpqI7I79D3/6w8v++k/++h9son08qxTH3NSJxtLOvLGZ290Q/kpOIznOJFuWtdpbNm4p3PfQfeKs5i/0eGoi8h1MQooP34Il+TycA/PDyhN+Km9Jn4qA0t6Fv/mLvxl62VUvH+PnbuZmI7Q4FZbmLHCQulV9LOkJNAG6w9ndSKVLWSlCypoRhWTbpm3BFz7xhQcZj4q35gauOQzJfxMBPk7cMVWYvGs5lwCDYA5ksBBC4iTa8d48pVEOkk6SAouGd//eu3/2V5/8q8tZp8xSTHKmub5BhI5AK7fyHv7xI4cvf8Vl6ydnJp2u9q6Jb974zeP4oHJoI/Ws/CFOTCMOWym028zzL6OxzHHvJLeUiKdrQX0LcxZMSMoL9rFpwPTl11csr74mqBkrFUoEAgR57sP09DidEVBBcTo/3V9Ym/yHzh7N4md2YiknPi1u45ydK1lltwjPTKA5sIv11kEaq6E+OqXZ0otAiCIKcXRxO6KWAsiLGHtjXwhJJbGFS1CqhF6GDI85qfGa111zCWOxP4fdsV0IgUJkYu8Pw2jZhWNjsknhQP6gEnBueC3nPjVj8Uv83vW/N/d3n/146sTwkNQQIvJGzjSGYoE7MTOR/0cXPePMc4994bXGauWe5yN8KKeNLY3cDJQD/7Yv3vboBS++oOvA0QMSpiqczt/FoeQFtww1BZmjEC8O4iqhqmbbxm2lbZu3z730ihfvIUP78LpV61YwjiQFrswXyHRm9qcmLDcM7/jIE49IVViKJ5qNAJNGYyDM2MxC51M4gSm+Z8hZsHq4rlbcOuCwjrle4BmvF6zP5LM1eexykHu1Z3kP4ckyAv4hEh5lXXxO2Y3gsne/9d09m9dvnn/jO99Yh7Zkmhub/WK5Mh2Li5Chwi9lxVlW8bav3LYbwd2EKU+ilnbg7BZ/gwjNKPfE5EhYcOBn+c5+gd+IIKCOFtnbgbWH+ZDHQmg0ZijGnGT+hzkPKeJ2F4PKtkRP/EsyOz1OfwR+/j/z9F/rkl8huz83ezx7HtkJRVrMjVUSkYJTdraxn38+W3ZM0WYzNCq1niRrF2IO6uGyBARCxdGgH8Lr530hR/y6wTF21avXnb/udUQVNYQ7W0iZz8JsaUg03GXzVkig/Cy/a8LLoUiBIBdNQCHDy1vQJadgPvEpgeF/9M8+OnHdNdcVz7ninJZjfcdSp4iYM4yU27Z6H+zN0xv7UWQQuQzWGDR9go9q+DzOvOlras9ZVe9awjhPhHOy7HL/yf79O67c8TpMWXVkTtvbN23P7jx358hZZ5w1TzRTpLOjazbqRmbYSc+gTnQjQqiaKz0trEPEIT2Gz/4F3GslsyW81FQb1tW3ybrlkIXx2oOwi327+g8geMWev4AYlFIbssBJoBjjuvN4T3biRHgRe0QDIcKn7onYZo9nmcbBk4MpBO3vgmnXGZvPeOyOr91x0wO7f7rlln/9+vkPPfxQ17LmZbGR8ZEOBGnkhtfekBHnOFpc5PpXXE81XcxOTIVDYOIvWeWYihiX2ISgidckzJFD4QezfIi/iVqvmAZBfozP5fmIXyLH+Q8h6I6D70/zVW+McC6q8nr1kq+BBlUwRAskl0d3cb4eSwQB+eXQYwkhMHN4ZqdLxhsmkgKEmcR+/dx4NIrpgaQqE1CmwUxAtHQzc3rYsqNV4EuwsZUb57Oc8y7IR4jzJmzUlKAOkjhIt7/2919zHaaqRc1AfqMQBiFxsnXluzCphI+KEhEe4Yecwi7dpGvT5rILL/dff93r57s6OnvbWjvSqBrS/+IwmsLsdW+97rwf/duPehhbbELwmKFeYcQaf2J8CjI7wtySfETilxVDaJD+Yd/NOezcrZ18vglBJS1CC1z6ODfI8HqGNbDDx5Eb+Pgx7AuI/KT/s2g8snZDYybrMOQ9zndRMRIiOCDTKzl/FWto4B7if6i0b2tvxjEt+SEhOzOWn0zU+OMHxr7LmvvQaaTw3nKmJbv3XMQ4w8S8IjgCsrSpdyUVeoPgCCN/F5zC3Iftl29/PTWz3oTQkX4cUXHgC0FzSCiyfAeIRS1Ifm2ZL8vkD3Lq6hdcPXjL524ht2FRGrNmrEUkDAb+IfDkQQQUMgzEd4TWIe1Ppby6GQIL6UmR5Dop4zHOZ4OcQ5IdobG2nSH5MEGwQE/VVFEkgr6km+w1PVolVvBfKoeanpbKkz61TggPvhKDEi0GbNMapaopLobdjiNmaS8HaXRBnnWLu1DqAvmSD2AvkIW7jfJ2LlTlcX2CAoLzEMnyK593Zf3AnsF7tz5v6wX0QEjIDhtSFJWjyv0DTB3wVDBfk6pZaG9tz5+7/dzJs7ednd+0brPV0dp6srtrRZT7S2KahN6uJNrHhT2xKUkiXDB/1aVX/fiHd/3wzRBYKCRkGVJJlXuTyGdBpphY2EmzrgcwBKUIwd2JgLuI+hL0dSZXw9iYVay9UGcH56xkbgf4LklwJImZ5m/869c7aLiTeN0rX8d6QufuWdWqd95D+3bN3PvA3Scp0FfP+C01Nall+EzSjG3L+MxZ2BjTDFG1AMhcRSMCIcqdB/YkAhg3vMkyXgYAGgkbEoIfhbrFTCfVWnuh+wT0fwRs+7i2EWtaO8L7YjCs5yv8vxmORYkQWTfXC7JPHvKG4ADgUD6WuO/c/p2utm1t5dHHRu/mHcxVFHcMQ2utGFfOUXblMNjWS8l4bjfFdWiJ4isJ26MOc+9jYCNCAie3v5XldLI2EbwtbAw2YOY74TneECYwWbseSwgBFRRL6GHLUp0YhUE9a8ZzHS9u4scrpK7hOWiACKSAnRAIpcPJdbAsei/DRWxFMbnITjPle570K5ilB8IW3pYoIjGv5Gtra6NDDw/d/c3vf/Osr3z7KylILtve3j5Lwtrhl7zgJZmXvuilU+xYW+GzVRDa/dwrzTltEFkXZo1V5FYswLZt6DkJ7l1xIk6B3fkQTtbY+WfvWCfT4BBBwcvwEMasRZsYQwjRE8MukshBGQ6rwBxrERAID+hMdvK2neO+5Ar4o/DbNogaYeHhWLGcD378gy3f+v636jCn2F//3tfsufn5VP+J/iQd6ggVrrZDkptZpwwKd6Jw8M+ThxA4bEn/DjHjU+WPTGW0pioC5z4ml3F9W2pVrUSVquN9aicFJ4GM4ouCQ4AgCQZCWWPMvfTSQE56m4kObqFUe7y3v/dJ38fiYheVsqeTs0yEpbMK7FUIrXBi4GNnspn4+p3r1/Y+1HsjADSCxVYc5dIgivEFwGCC0AQc5dbj6EtiYkSwWatYWzfPYpZbPMbzIMoJM5Yh1NY2CF5+C8CTTYIAcWnJy0gordxDjyWCgAqKJfKgn1xmPKDsD+xGT4dCpVSZj6bsFFzTjtlGQlYJfTXjhO73elLXSWgBUw2Ui0AwdZDmz9jaUnLcaoRkNvJzIySJsxY3J36Ba69+xcgrr3nloxBlPVfm+ex7GJw2QEyrIUZ28ZbUgermnveKUYc5XcJ57ZCSx46b5mvBqFzH+3vZvUpeRXFkchSnbCghiNDkDwfkFfo3eDtHVsc84UYIHHsVYyzIfSG8GU6VUuVSUClKLt+ruK+UvYDcgsO8L8Kx/svf+vIGWrm6QvrY/fFtmDh+F4qZ80c260Ks/An/CoDyEywvf/niVqByKtkMR/djf/jWP8q+9trr26HwMgG9DdzmQrzKmHTMSd7DlOefCVCzXEnRQeqZ+9ZC4MaO4i9uBwxqMJkWChYO3nbXbVvQyEJhISMJQRNQJmNKEAC3CcPMkA8SmMVHzFSmJwdvBKxlDV2iEPyBNFkS0xy42JsRAAhssxWMKsieNLOXXBAJkQUyi452Bo0yTFRsQnDRW9WdZyypwbWGc3czkUGuXRFfUyeOcT2WEAIqKJbQwy4OFVcTBDlrHH+eKBs7ICbINcl5r1ISu/xXeQ+HBHzNxhTyuAiC2QnxUK2V3hXsPNlmUjbc+gpxL9Kj+rkQvFSJrbDzxjlqHoDMxGx0BrvmBVhtFPNRpFL1BiFlSnRLRI0/RZxThs9TkOQqGJ9IG0kORjsxfp5x4Ga/BIl1EtV0CMGxOxlNrn6KqMWNwETloJ2pv23TGVSqpbd1yOdWmvl2Mp8F5i9Z32QSmq8jPM7kdKZgT/K51JWSlp9BpVxxKD/uoPWE95N/QtaFdxmCjXj4Y/iZkK98xlSfvqsPTwhJGprmPpte+/LXjrLxFjKew+4Ux3qURoiVWNQMF7YhOEhDsIvcezNTGGJat0pbcs+Oj1Ct+yBj1OJYl8RCEYhocqDFZEQgvPplr75/45qNuWuvunZ3e2vLRL5UfMnA4EBLV0eXs2bHmjM4N5wrgivECFnS7bhuAsOU+Im2cj/8EOZBJi1Z7Di2WaCPIKF1He+VUBdiDCU+Gvw3/gLaXIn5HubaLaxb+m5IiZMVQNMQDqT/LCkEVFAsoccNoWPioZGDHa2rOJVYFF9pvpKX0hgZCFlahOJVMDFI5VXsHs+D0FLsTMuYbqSqLBm7QRk7t1QYzUMmGchEKr/OQyK0VrMPYr66CNIhQxqfh2+tY1veTUbvDhipG6Kkh4H1NTi3g635ekhyhs1xHKJvwyQzihaDYoNJjFLXMF2RLwe5VW5oqGtiXkLKixKC58U8AsJTpW3rGnbhJT6Y4xScttKEB/XE8oZEekDtmxAWI1zcxb1jkCbzIL+BEtqEwJpfKKex+JvACfxh6syW/BGGCkt8gwv3W1RmGFdeMyFmJpPjmJmbiTEXSpOL38KslL6vzPQxMGmHxGk3S2eOiDtEUvUQtXYxm9l30L81HynFnZJDWQ/bGqBASbaprmkHta2kCi5qGm59xqFY4MKNH7/x88xHGggdkRlGUvE127eeKQJZ+nZsZQqLTu2Q/32rd+B4sH71+jKCcphpklMifm0jiX/SF4Nw40AEK94q088iO1FKEghX+o5Y9zLGH6B9fBGBdSXypJHzeQA+AobaLz3Jdy0Cpf8uJQRUUCyhp53P5wN8FAkczLia6StBUSap4BGJRdxStUQbVBzIxl4FeZyNEGCT6Y8SIUX0jzS1sSmiZ9cgIMiFIGMXpzicNMQmW3aqRYTDdknLY/Mbt333QghSkrjiGEwQMBQFFAK1ERyBfT6Qr2UCZ/G6lh02FEblUuPvxyEyhMkJx6s3Vq06ogE0Hjh86F8RcFvYVYu3HZ5btADte/yRth3bd8xw3zhs2gWfSlHBPshaci5SzD2NOW07zm2iknDe0k+Di4e4g/SckPLaI3SyK2N2EsH41G8Br30isYap2Dpzyc5L+j7wxx96qKGhsTo41HdmY12zvWxZ0/706vT7uT/jIM5kUlzDHKUk963Ed1Eiw68V0mXOKxBIuIEqda4bQduw+kjYwL4fSFLbtjIixXeKs+JnIAarH90sPbeQSVCjCYWDP6FmQxMnhCLNnUiU80erJkLob8G2K/a9DP4oGewJBn8dYy1OhdlwpXXwyIHs+lXr7kEfKdEZ6VHK/A3wzHvA5nqeXw9nSY7HvODEtR3MnSJ/5gIehmRtx6kd/xG+A63pQ5Wip7Z1F0rOqsJg/oZET82NTwGmL5YEAioolsRjXlykceJ1uE3rQ+uSbzI0AVpglzsVFINWGpRVEQKt2NQxCVmzmEsIkwxNTgcdE22C2Lt8EzxKAcHnY6JKEfqZoLz0nZB9J7y0goilLhiqCc2gBZKk9Kn0ODBbee8IfHqMuCByuO1XQlC8F3ayS0LS0BuxupaJccV2jO0LEC6Va+3lmKJOIhIuJFGshfBQ0R4WJcSp5/XYwceQMYaGQpKKgB3elkQzC0exdRxnfA8Utxy3Bxtz6hQRUQUhNkCM0oMhBnlyf8v69Ic+3X/Dn9ywQW4JUYp+YNHhbvrOb/z4S5B0F36CHO/RsjXIrF21fpBLNs5nMxdDrBF23fwo14WUblFShOXht7H8Tt6dQASPMkFqKHmUXYyKn6CdKwj7DYh0MpxsCd5U4Q3WMH+XFMa1Qto1iRpJlhNNAuZfnBfOdhc8KLGCtZB7WFSE9yJBD4NPzGXmejg/nIucL0JCfiJ5UgodTjJeBK9SDc+rHnNeP3P6HFh+EA8MUU/+o/wsAQniUwJhbxxMpSLsHO8JN4ggGUbY/sQreXudWLXXsWNaUlxwXmKHCool9MBrXBfbM8YjmB/iyEEK5Rq3Zp7aqsXcVG6E3e845R2kG10B1mQH79GbwVlOYTuKzdl3wG3SwGcvpFLP94dxD1cQCIPs4vPQ7NmYNyh25/dVLX8Lu2SJRpoB3ii7Z/wZQTPj9kLikhRAwUFTYS5iF59mzAMQrvSQlvpGPZhLSB6zhJAK5Hj8kKihl4hQYVwx+YRPrCaR+gnn72eneyZuBbQgT5rviNZANrmNhhMMcD46TtDBe0WExCAsigZkfYvX7SQlBNe88JqO6F9E14opiTVTZs+xDh490AIBv5pBJjgfYRXs4nw61TG05ydd29nCeRJTzPAcqENCzNwDe1ToixCyppie1QBuT0Rsaw9dL4om4m/gzEsREkmeQB/r2CVpDHSKGEf7ItKMsGNCZPlqYL2Szs5d5VaLIU8ve8OLa776T199oMFuKJUiwe8jRciDMNb37vjeTsElBIV/ECZPChjRrJrR+CoIDcn9KIH3RoT7Sk77EYJOkgGzYPMaLka3sW7jHMxUVp8n50tZeWM6kX7SJ30Q7WvB6sThrceSREAFxVJ67BRrIGGq7Jf9QiEozDf6jSVrAYrISPRN6NiUMg4UmnMSREhiN4fCxVltBz+E6HGK2lezG4cPvbuBbTlCoofvHWgLg5bv7ccUsxVfRRbN4zieTzEr9cOkNZD1OHz6A0h9I9dLFjfFBQO0DOt7UOXvQrrSYa4EqcW5ZgryyjEP8ZlQTsLaQolxh111qFEwuNBzcPtPfnDxJ/7yEz8igOsg+QrbYVk229YyduqYx8IeGpQdQXeS3TKEyCrbYXQpINjGTn4/bHoQ279BEwgKBUw5i/2rrYWitMRmZYsRYM3MZSeltPuhbNEI1kxOTTaIA1xUFdYgO39kjzFkes8yPj2kwwZAUuZDopaSVR+fj1sdhPxXcE9KnxBBFjrc/QZ0Ctnti+YlApXbmyeiTrSJ8iEZfB7S6e+pg1pNnX/6/j/90zvuueO5lE2pZb6Ss5IYODHQiRCV0iih0xshJleZFzzvBTnWSySbf5z149C314FLK3iKT2eP5do/QtvZCT4SjTbONftZDo/aJnIaZcSnhhNlXcibOCbBBpZdrKkOB+tcO/EY59LsSI+lhIAKiiX0tPvn+ye6Y91CnCbqRWNFt9gYd+PFyYXJXDqRrsPdSU1vzEL0BgIW2p7Soc3yIUnrcggRsotI/+peCK2Bn9fzvQN2q4GlImTvJSkxuBkDk8+OGZNNMCXCABrdynBCLG/EVv4TDCqP85mE1Z6HieNC6LZAkt0jOH9bEBJUm0UJME4L5wtZjaAZ1GMi4zT4mEF5PzyK5TJOWT9Gpwq28uYI2sxGPkhyYndoYiLck9NbEG/pUBfw/QbknsT+S1QVmdUklcGYUlkWH4A4juX2VF+vBrmF7L/VJGsJ2w3jftcj4DZx3RzXTS7v6qkQTXQWvSZEuwlnJN+JePoi50yiPSHR/DYEGiYrNC2fNrCBsx6zDiYvpxGtap654s8wTahIuyksKD6KatEuOpgArYnszGaisWqYxzP+b970lZv+jPmHfT/A4ske3VJZ96kw2lOakdSq8lOp1DHmkaSclmhvyAj/KPMRjY3z6XPuezcImMzhBPfrZ/2b8Q9hNsPZHfiTjHUIAX0XsODayqcIaUizhaiNdIXPktP0WEoIPOOXcSktfCmudfPmzeVvfCOYfuUFGJsqtP10rVwmk0nUJeokEa4H+wuk4ixgZeELM4NtdrPzxuyCq5UdPvy0gGFDehlQFdXkIRQpbRFBmAi5HBSNAdPTCJoFtaEo/WCCWhSRm7FxV0hZvp18hkvQUMYh+HMhUGL8qajqWNWKVz0Xwvw+EVCYSOx5TDb3soslzNXgCwmk77WHRkH0LbQGu4kEKZVK0Qjb9KrnZ5mDNNu5mo9qIUEpBEiymIXJyc9BzCfZaxPzynqlAquxJ7gv0UKEzRp/WASE/Dl1hNJixwt3XLX//oMPgINoC8dkTKKWZOS2bC4DiVfC0FXWEZI0c/Uefvzh8xEYuyFkj9F+IlIHTCRhr8Fygzob+xLDTOKHySG8KKwIIRt/DrHiTOWnis31zcWyKTe/+i3XvpdoLEmEe8bBfFk3/zAJcED2suJfcXDKYoAT5cllxuGCPB/zmTSeom6VoWCiRf9zMra5HPsZYgoguKqNnwWXNHOek5yL7FzWc2vceuZbjq2O9TPk0V8xpL61BBBQQbEEHvLTl3gdPbODscAZnx53WpOt1XR9uoacAmklKmUw2On6X6HJ6BDW/enyZE0h2Vy6Hp6N4aDGXm3th1CkJPgqdvoJXtLC1KcMtr0WTn0Vu3S25sEwpJqm58UOeJwuaWaD+AswTVE5wqaDnr8SgdRIYOYwbEdyX5jbwFZeEsRkl+9/mUirLIQljnB8H9ZwMpm8nfIgL4If8YGImAj/ive1B4H1NmFwrj3ER2vFAsN3HNpmBn9CD+fic8Hg79AD3PJrGJ/6Sza7fm+EknwvoO+3PTWz2Jqbu0qfJnvg5ED7hp3rnncqz0Kymn1MVBky0OswPTVhelrspXEKWO7p9A/1dzOLPgg5z+k5JIv4b04iRE9S7qQOoRtFBclBy4TwelNoVifjdkIc18VQfytaTVOZqUsHTw71QOSUCZdEuGccQMKqFv0RIgz4y4TDtXOXpx1oFDj5g+/wrsv3LM9LCj12cG071/AYEVricEe7gPzRHnGwU5AQ0YbApcaTFTyKBjTnJt0Y1yZpS5ssDZVSub7Z2tSqBjE96bHEEGCjpcdSQ4CaqBOt21rLc+5comiK+KTDkh39kNxJKoaORKqRCrtIP9awsA7yk3oSFBE0/fIZu02KwwWTEOEGfnmkXtG5xOhsgXFE66AokS+RRQmM/lRhDQ6jIRyAHCXUdQ8kJF9TbGNzxFMR1mlthezXwHZpvqSv9acxzzzEfaTOCHH9wfMZuuH4g8c/Q/e2HzF2FbILsKHbr37p71R4bi/mS3b1J7hmFSYndu1mEEHQi1RySbGmVajMKiTePHUL5ada5tjBfRvZNTt//Pt/jEMX3YPBEG7iewgd28Ojw3Vz83M1CIt6TFON+AxWnBg+0VQsYiIKN/bP+K0xnNeIMJPktb0Y36ZOhQKT/WzREpZKscyM66R1ac6rWLsSxURfMYsBrVROpIN0Paan5sZ0YyGdqpsCBymZUmQEEQRyyHfIffEQwcV85Wd841Sp/fl5LN8Et3z+lk+AEwLcpDAnrWdFY6w7hZDHtIiWFuaS8A7RCcwHYS7hwmE2PQLGzGH8G3UjqRwQviQoV3cQVttpe1UVEqfwX4rfVKNYik9d1vyX1I1+e72Xm8sV7LBiXRDEo/EqTm5kBBb4iFehepE4dfFzuzdBZLVu1ZWyHXuiOGQ5qQrhP5fM42WYd8oQTBmDyBOQ9d3w7R3EOj3hFbxudrcTEBS5FXauQmAS5z6B1/UyePlFwm9oFWyNqS/lBHPs5ofQQpxy1bsIwdODoWmEEyisZ7/xoR88kL/3gftm3/EX/yu2ce0m84kPfBJOtEaQAieheUkGjFFNYwotpxdBsJxby/UxBEKWISrCtDAjadCSeBdECMft4wb9OH3xK/iX8iVE/tRvg8yD+bDEp73Jp2g1TJ3tvGzuf34E52w/Z4bWrE2sFX8AQoukQqCTIkkShjqHMkTfaztTNeV5dIueXCk3Q5fBBV4nTNU0V61qAlIf33f3I2++56f3dF3/tuv/nJara9BeKO1B68FodADN6kQ+l8elY8efc95zdm1et7n56PGj3cs7lyeP9B5pokZUw7XXXPvolZddifD0tyJKxsFiCIGNb8OwXsxOhiqxkqWNCRDRNc5rMcVRskPKp9Du1vNPenb1iFPxWgnuypNKHsNfMplYU7v/58vVV0sNgaf/si+1tet6QSDYS5w9hhH8FfK7EIdaXVqV2qlYKlLySpTjwO9teaPkMhD/HyyHI9ezYxcl4wD/QJfBegh1nn39Y6ZaGV3wqrkap6aZXewOnKtBMp58mB35iyGkPL4GSYQbwjL+PmhWNIhBSJUWoD7lLax6nBBCzJTJNvtcx3kYDWfKq5ATQcMdttAriOKkbYOT51qyuu3P4fs4zPndmJESFd/v4X4d7Lu3c/5G7isaDpt5vOM2pUeMPQCF0/gn6IT6MU/RzQ1fCmT8eNeZXe+AKEWTEG0h/D+Bz4Q9O4GlIkFkn45Eg6AXfQPIE9YsIbF8YIKV3SuHDt57cB/jiWD9MeRMgT1HMqYpcytjWVIuPM37R9GGRhCyc+DtFyvF2YgVKSAIGrmbhLPWcG4ETDOoeZiDgsZQ5XftMrbBeZwTGZ4JGfF2klIr9dx7G9dIkyFplzrMbA3zpiESyoZNCCzSgrFKzHWG5/dizu/n+UlNL5QrfxpTYJpzZJz13OdY1bMOYDosY3YcQffp4PPzOH8u3hP/AufpsYQRUI1iCT98Wbo5x0j+AnnLViJTydhQq5+OpemWVox7tjcStaJx+DFNVdcSWcUkmvkDTsQ8HAncyWwlm4pH4gfyNfm+xhlqCNYEDVEn5RF/eyWVQuiRGhS4zxVc/xz4dBrCkkilV0C8dXDvMGT4kOWQQ4DA4b0TfJ9BgxiCqW3MQM9jLveQa7cPQqbJD329A7eVM2uI2Z2EhK/GJ7wCAfNo1DETdF2bxNR0OUydedKSTx0MKnmQkUdsJxniHoOk+DcC6dMbmnBcnAXlarkR30M5l8vFeB/HLpln+CkSsYQkJEoOgTjRE2BEFC5ikxtSONAnSmy+s71z9Ds3f+fWttY2NCppfWoNIuQk8W8aDSkD0VKLiixtIrfQ0uaZx8qK5y1HsxmpFqpHItFIGWe2u+AuzETdKDksnF8ho9uyexC0InSkm2CWAABxfNci86KRINKIOJKZkJ/iC9ETfoyvx5ghtDeSHQMpbf4A14pWI9Fpnbwf4/thxtrlR31JaqxDQL2I96QPCUX/MHVRBdiN2D1oXEWCENJogERoUR/Lr0qlWD2WOAKqUSzxXwBZfnCAVqcpupvZVnHBW6gnaSFBd9Miu0oPs1Oa4oFtfJfQ0aFcJTfbPNpcKK6pvAF94gIY6zBb9vvnxqYeb1zW8Ck4fgWZFn2Qj4/ZZIYt+MXs4o/RCOg+yEsigl7Od6RKIDWixMmKecgi+sh+EOJqJ2gIM41L5dLgCGb97Zx7IWQmpcYP4WF4gvj/H+D55jr7Kj5biQaxDOJjvkHade1e9v0HMLGcjTrQwBzI+vZn4P5BXpM8SCQXjmfInLBRmvQ4VjNaRuTgkf2dr3/nGzf0DfVJKQvT2dY5cvhnh98PIT9ClkMS0t+Enb52cGTwzGVNyzxCalk6mDF3CPokrymqSGQXwgwzGeVEPNw4ZhjCLhHB1cTuvxshIDWm2khjLLLzP1CxKneTLzFPTFkC7aKKFlcgO57i7842xl3BvQkwswtgsoBZqo91VhFQnWgWLQQXINAQg5RaYRyil8R8hNlosfkQuSfBowg4+mEHEu7ahcCYYow7EbhZmg6VK35lDQLs5ZwjghuY6c1tef2MMRjYboXywEWPzQH44rhxB2pWGCk/oscSRkAFxRJ++M+29GxvtgXntfTJbsPUQZKW6UdTiLJLJpFNemfT5Y1CHRydJIDdTq2oTXgCtmLmORsilmSIOHakEcJBv2tVqnQ0wOrtlYiSje2Emi6QsSFSqSrbiMUfE1RAxI39t7xNirQ9B39lsJe/mZ/OgFyPM540+1kH+ZGPEOZLsJNG/7ANpiuTJMSWjGb7uFiJiOmRMugYd4IFfCKH0DqwEQX7cRgcRzN6hBLr7TDtCtcO6qpVPwkjExpqD+KwTnz7h9+Or12xdvTyiy/fx1g4dAMihYz0qqbOoX8WwakrCAMmQij0XUh01iEIXYi5HvKNMnfajQYVxhdXhjRNKvO9C5JPox2w4/eGK8XK3XbMnsU8lbDpqy0OFhEqYJlBM+qiSGOcedex5qRcj2CZ4b51MgZCEYXEkv6vy1hDB6+lAiz9NoIHOV+CCaQcR00IL2XVGZvaUNaRGBVhFwhQcGNuA9W33sB5RK0Zmbdcm0fryTIfNMCgiHgNI65IP88lViUG5VnpsbQRUEGxtJ//s65+ZO9Isv3s9srCiYVlhHhKxE4LBFbLDneU4M1JXN7VukKlmo/KFtuSJLnLIJ4zYO+fIip+GouXpzNetD7umQhmnGIkHqmnnvhFEOYWdr/1MjikNocdno2yd4zU74cxiYxjkkoSotvmsl/HLo8Vy1tG4jQ9HczbfClsZ9lxPMZzmKCOcT3hrlL/iCQ2234Qc5VUYkXOeDsc1A8SjQdhYRL/gkOYbzL4CHz2/cVIIhKjLmIUEpbub8Ps+Ffx1QbZz0HY0LHXz8/zaAONELf4A9YhgrYzb7QZSpf4wUkEUC+OC1qysnM3VhOegRLjk9FMHop0yyPnnbCiAv4W6SInhL0PXMgtCRYiJjKa9/ItfF/NvMYx4cmuf65QKUTInG+ieVMjQsNIJBZObkqz41Q2VVaGAdB11nEPyX2pQUhRIdY/BuZ7mcNZzH8Vz4DIs7AkiiQ6Fnh9gnsbnmEj51KN1+oEP7oXBuM47SfRejIIogJzl7Ts6cArVWt7ag/I89FDERAE1Eehvwe/FoGOczqEaOQYyfYGLZFIqZUdLSly1lh2Mptvr2NjTsZAUJ9LQE7sdP15iOpHpFfAndbZfrZ8rx/1pnwnvi2ejGwiTIpKrdjUA9znlCZHp8D3gMPaBHfB6SciZadACfRsJVY8C+PKy3BDFxjrHth+AWLbRom/efIv7iNqSRzV2OgDqgoGP0MQVEKzfeBPUxm3yv2kTDkVvWk6YSIn8Dxg1LHbuJc0JYqz767BLEY9JvIGbHuE9dHkiMZMmF4QhGG5DyFkhEg9/0Ok7lGEdYkGJZrVOMIiw3klbFgIqaAODQk/CKXO2d0TliulPgYgbnIBvSZx+HO9R76H1FwivreKwgUGvlkBRmvkUtd2JzDpOaQEem7KpXKrUxuSOuoG1dCztGZNk1tSZscvjZkQnsG9+DIKkDthvtY00WkDCI1zEKtt3DvBlzyHcTAo4YypoxDwNKZDhgskgGCOJoLHEBDiaJevCfDNFqvFOcqHEGEV0IgileW+eigCTyGgGsVTUOiLfw+B6WMBpbunguY0qQH/RKG7D0HZh4PabDAc9d1UqCGwE46SCScEBgeZOBUIidjxieF3MA2RAGbQKCSTusqmPWKegOCyxBIVqEo3C/GeYNdOkx37BdhtMpD/bsxXXYTKpiB0qQArDYDIBof1MMMQVzuNfHoMKqa0CKYrO8C5a0PSYT9sKb/tY+kfZYxcNOomigv+CPW5UxjMJJ6J5DzMZ5Y/SZKItFStQp6Sm0GammvTb2gccpVoIDoAejh76W0h2c706JC14dUWYcjU0CACfAA4Q5iftIoVU5PUTuIkop5sa4r78pqILuPNep49jg+ghI/CqixULEJkGxAUwuKUJfQlOa4BIRRjd4/cwRyFSYgLRZvznagjJE81J2fad/wy/ow6pEx7peJtj7jSUc8i+AsrH0UMZU6CLfc6Sr8LyY2pwzTYQfLcBHn0C2C/EYf1BGuTSrH4+D0pN56i+F+v5NmE89d/FIFTCKig0F+F3woCBw4ciK5wVjRDYA30tyhSYmMZTlnfVOhoZ7Pht6KbIfIryJauw8o+jQnqIEKD2k7WpXwRzYTgsJ0CO3mJNEJzKd9O7sGZkF03woACg6YMEUYgwlrCa9n3WrtQYbiVNYg2QMkQdBLug79jHaPWco9jjFdHxOijVHDtFi2A6/eKeYUwW4pdRWy0CrpVU8Hc9WLs2DtJ8qhBAOCIptZRYFPCxHoOc1wGheOkNq0ETpUgcvwZzEPGk1LcIjDC/uJmQYiaOdFAyTrKeAUERg4hgB7hi1kuzs9ZdvREEgV58iLypUIphnDZwuc5NBBwwhuDc507Ig1oFlViyfGIJNSRKeJT1DBowAwl2dYECaAZ+JVhhJCY/S5DICwHK/qcU3nWqs5gvkNIS3dCI6XCh9Ad9iRSiRJJge0SmYuE6kHjiTCOVE7MIlPTLJzKfzV7zWr8PnooAk9DQAXF08DQl78ZAhCV/D45c/1znU7V2YrjdBZiP26Xi47vxjcQ6joQC4ozVavmHPwDOyA7Ib0keW1J+I06InY/O/iT7G6pF2WkWdFl3JP6TOyw2b3zmnBPNBnf/2YYx2r5dJWLZDDfSKVVAnWs9YwvNaKmq563mS15FNId5TOcs/YAXbkPViuElRrKhSN0SPMmrBWNxyZp0DI9EDUVYPkyph+/xAQmHoSHuwbVQe4pJbtxXlvbsf5I0loqFBYMiC1JtJxpyHqEXfsE4qMGgVRA8o1jgJokqS6G4AnnyA5+NBaLSXVcRi+4lkPYcaVWxJchCc9NRVIV4sCk30ViobLQjKCpcM20PBmEVILIszXkSkitpse4zyh9zxHA5iJwTqJFEGIczDAh/D0ezZLcLWhV9OymEmxAdBYaCiYvxhRXPP0s+AHDYTWxMvXPwd1oacRTmc20RtVDEfgFBFRQ/AIg+uNvhkDQT7VXU3iTT/8IKHS/40aPQKBOMV8k4tafaVjVkC8P5tZiuF9D2aHN0OU6CPgIJ+NcRfuwaF3Kbp09NKYeJwY7SsRTjLLnYn+XmH+aR+DINtZhiJyWrJQt9xAU9LGACOvFN0DoaD9kSdinUCKd+FBpOEeEhiS71UupWFQRqVlFST4c0D5CyFDKgvMQQhTuYzfPOdxPtAJ81NZKhBZ5DPg+qHMFMWPm8RFedN1j3lir0Iyc4ySAx8jw20ikl7QPpf8DEUuWPc2mfVq8ARD+SMyKzSIGsKrxp4j9aY+VNVJ/SxIfm3h/BdkOcgxbHZiZ6AMSFPEdZEpWiQgpu65qV12v6PWlEim8KJZTLFeudmk2hP/nJJauI3Y0QtkOQnDp3Y15rYX5toMFCpGpwWl9JOEk9nH3RqLUtqAhdSdWabe6EG/951kRUEHxrPDoh78JAggNcgcGrKlSKoLJxTTWEXSThdyc4ivYAUujIDbiiAcpBgiDQ9SSzZxHrqzGhCPNfKgCC/FzgmgfmEoykB4cT+gt5T7YMQ9isXo+PEj7TkP/bWz6rqGvQliMb46oIVwUwTJIcrxYqkjZcekT3YhmI8UFE9xTuruJ+aXITp1qhw6+XycjAUO4kXNuJCyUGK94QRdehPCg0hSxWL40JsLpIGG3lMIIqod9O1YylSIBTk4Lid+dpG3Dzk6FUFr6N+FEN868G7F6EQX5+Swii4T0umRd1SzDef5rjvKJ8g6EGIoPeSIQPdFfM7SynUeUGLpwLyA4pGhfI9pCnKXi37Y8xzetErsk2FUpXRU1mLrwiViRKNl6RFWVCvTCTTSi8fSaDi0Z/mug17d/AQGNevoFQPTH3x4CZmVY2M6aOppdiY2ItDLreMktPU924zicKVceTCEwpBwtPE/NIxgNIdHG+3PY/+F7Wo7SE1tmFIaJ2g6ZxF4JB3ISQq6F5J9DYp04ziX34hhO8aPkM59MmMpIrmBmqXm7AU0ijhmKbn5SejYySditCCDJEl9w4y5ZgX4DWoP0icBhTi6yh5kmEqEEiWmmvwZaRkDBK0qCV4MSEVVRSlwRIcWJDnOgdLlIFO7d7ARVDDl2plyNDNY41omy8aRBk5T0JukvqESizmSOvhMp7Fh1vlUYnV6w68+pfzKqTJb4S0ckEzlQqi1dIOAw3wkv5g3h+6k2pBtqECAe+SldlLZtQbMiTYKaXGHehTTowF1t+TSCsvP4P+bLdnku8KKoNVaRoiUmeUby5C8Npm8oAs+CgGoUzwKOfvTbQyB/PH9VNBKlvIa3EZv+SoiPWktGykNIbkAJOp2XXTCk3cIWnHwGfBFhq85gHLKth4VTkJ6U4JCeChdyzhA2ITbb/gJGpD6EzzD3E38E4UF+OeF4JUpD1ZWDStyvutliqWjqN9QPMZ6YYXB1PPOYPTS7Ih6Pr2CHPiZJ6DEnVil75TS+iiSahugAjmNHVzBvBBTqgvg3KHSIVwbTFUnTrlvEuJZJxaNT2YUyTudgFSYgdCZnjvbVJyulbJZSIRbGJg9vyOwzR/+P/xRMBrXcI8bc2sGzR5LzAlMly90psnbyS/xmBG604vnThNWOp1cl9/6q9f7HR9QzFQHNo9Dfgf8CBBAApjJcOYlj9hjmEDYnQYXXlAz0yH7ziex0pyoePTCo2YQ5SApoN+KYJoDJokep3cnOvAb+l2zhPKRHopsvrVkX2JwXLNstBdUS0USRCuVH2HTHPLtUji5EI14yRtWRij2TZD+e2Ngw9mxLbdjYMMDn8vXUMTIykqzz6uoo35GivEYKYRGD+BcQVrMEH0mZ8hqaMUVQiU6yuyermgOmJgU9T1bcNDWxSK5ziYQq0Re2VkxMDkLiWbWIpwb/dS9odVSOlXsQrFHGyqBNzLmkZ4ADVbro0UrJV6K0xqI9cfFF6KEI/FYQUI3itwKj3uQ/gwBNcF7Czn0WkZGkfMWUU/HnY0Flvmjc0MzE7nwdkUkpdshSiE9qFhUJgY3hb6BkuBnEKRwnimga4VHEnOXE3NgUDuJSvpRPR0zQ4FWdXCIW1lZKVFAOot01e/4z8/tV59LsqQU/xlbmNkGewRNPPyf4ELYockqe/t6Tr4MB8jv+i2oliUCmrGKtaTKZJ8fX74rAbwMBFRS/DRT1Hr8xAhKeWe4ub8TsI2U0pGx5hDKv2OKdLKakHAMYcg/GS5VSHbU3Kpl8eT4dTVfxCResLsJfsdEXvEIDWcqS9U192IoTicfSpiNy/288Ob2BIrDEEVBBscR/Af67Lr8wEvT45QXJcvbZxaeqXizvuiXxU5QQDVYimZBUt2ns9WGKWiFbaMA8FEXDcElEi6TSqSnTahYzpP+7LlLnpQj8D0FABcX/kAel08SzIY7cnOga5FO41ixu5Cj9pqulTEkipUqJ1QlxVuuhCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCioAioAgoAoqAIqAIKAKKgCKgCCgCSw+B/w8CzOLimTB/QAAAAABJRU5ErkJggg==" alt="" onerror="this.style.display='none'">
      <h1>우리 반 카트 그랑프리</h1>
      <div class="sub">별명만 있으면 바로 달릴 수 있어요 · 이름·사진·연락처는 받지 않습니다</div>
    </div>

    <div class="card">
      <h2>👋 내 별명 정하기</h2>
      <p class="desc">경기 화면과 순위표에 이 별명이 보여요. 실명 대신 <b>별명</b>이나 <b>출석번호</b>를 써 주세요.</p>
      <div class="row2">
        <div>
          <label class="fld" for="nickIn">별명 (최대 8글자)</label>
          <input class="inp" id="nickIn" maxlength="8" placeholder="예: 번개다람쥐" autocomplete="off" />
        </div>
        <div>
          <label class="fld">내 카트 색</label>
          <div class="karts" id="kartPick"></div>
        </div>
      </div>
    </div>

    <div class="modes">
      <button class="mode" data-mode="solo">
        <div class="ico">🤖</div><div class="t">혼자 달리기</div>
        <div class="d">컴퓨터 카트 7대와 3바퀴 대결. 인터넷 연결이 없어도 됩니다.</div>
      </button>
      <button class="mode" data-mode="online">
        <div class="ico">🌐</div><div class="t">친구들과 함께 달리기</div>
        <div class="d">방 번호를 공유해 최대 8명이 같은 경기장에서 실시간으로 달려요.</div>
      </button>
      <button class="mode" data-mode="split">
        <div class="ico">👥</div><div class="t">둘이 나눠 달리기</div>
        <div class="d">한 대의 노트북·PC를 화면 반씩 나눠 두 명이 대결해요. (키보드 필요)</div>
      </button>
      <button class="mode" data-mode="time">
        <div class="ico">⏱️</div><div class="t">기록 도전</div>
        <div class="d">혼자 최고 기록에 도전! 내 최고 기록이 유령 카트로 함께 달립니다.</div>
      </button>
    </div>

    <div class="card">
      <h2>⌨️ 조작 방법</h2>
      <div class="keys">
        <div class="key"><kbd>↑</kbd><kbd>W</kbd> 달리기</div>
        <div class="key"><kbd>↓</kbd><kbd>S</kbd> 브레이크·후진</div>
        <div class="key"><kbd>←</kbd><kbd>→</kbd> 방향 돌리기</div>
        <div class="key"><kbd>Space</kbd> 드리프트 / 부스터</div>
        <div class="key"><kbd>Shift</kbd><kbd>E</kbd> 아이템 쓰기</div>
        <div class="key"><kbd>C</kbd> 시점 바꾸기</div>
        <div class="key"><kbd>Esc</kbd><kbd>P</kbd> 잠깐 멈춤</div>
        <div class="key"><kbd>R</kbd> 길 위로 되돌리기</div>
      </div>
      <p class="note">패드·휴대폰은 화면 아래 <b>버튼</b>으로 조작합니다. 코너에서 <b>드리프트</b>를 길게 하면
        노란 불꽃이 모이고, 손을 떼는 순간 <b>부스터</b>가 터집니다.</p>
    </div>

    <div class="card">
      <h2>🎁 아이템 7가지</h2>
      <p class="desc">길 위의 상자를 지나가면 아이템이 하나 들어와요. <b>뒤쪽일수록 따라잡는 아이템</b>이,
        <b>앞쪽일수록 지키는 아이템</b>이 잘 나옵니다.</p>
      <div class="items" id="itemGuide"></div>
      <p class="note">아이템을 쓰지 않는 <b>순수 실력전</b>으로도 달릴 수 있어요(경기 준비 화면에서 고릅니다).</p>
    </div>

    <p class="foot">
      🔒 별명 외에는 어떤 개인정보도 저장하지 않습니다. 최고 기록은 이 기기(브라우저)에만 남습니다.<br>
      🐿️ 다람쌤 교실 도구
    </p>
  </section>

  <!-- ── 2. 경기 준비 (트랙·바퀴 수 고르기) ── -->
  <section class="screen" id="scSetup">
    <div class="brand"><h1 id="setupTitle">경기 준비</h1></div>

    <div class="card">
      <h2>🗺️ 경기장 고르기</h2>
      <p class="desc">경기장마다 길이와 코너 모양이 달라요.</p>
      <div class="tracks" id="trackPick"></div>
    </div>

    <div class="card">
      <h2>⚙️ 세부 설정</h2>
      <div style="display:flex;flex-direction:column;gap:14px">
        <div>
          <label class="fld">몇 바퀴 달릴까요?</label>
          <div class="chips" id="lapPick"></div>
        </div>
        <div id="rowAi">
          <label class="fld">컴퓨터 카트 실력</label>
          <div class="chips" id="aiPick"></div>
        </div>
        <div>
          <label class="fld">아이템</label>
          <div class="chips" id="itemPick"></div>
        </div>
        <div>
          <label class="fld">화면 품질 (기기가 느리면 낮춰 주세요)</label>
          <div class="chips" id="qualPick"></div>
        </div>
      </div>
    </div>

    <div id="splitInfo" class="card hidden">
      <h2>👥 둘이 나눠 달리기 조작</h2>
      <div class="keys">
        <div class="key"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> 1번 학생 · 위쪽 화면</div>
        <div class="key"><kbd>왼Shift</kbd> 드리프트 <kbd>Q</kbd> 아이템</div>
        <div class="key"><kbd>↑</kbd><kbd>←</kbd><kbd>↓</kbd><kbd>→</kbd> 2번 학생 · 아래쪽 화면</div>
        <div class="key"><kbd>Enter</kbd> 드리프트 <kbd>/</kbd> 아이템</div>
      </div>
    </div>

    <div class="rowbtn">
      <button class="btn ghost" data-go="scHome">← 뒤로</button>
      <button class="btn primary" id="btnStartRace" style="flex:2">🏁 출발!</button>
    </div>
  </section>

  <!-- ── 3. 온라인 입장 ── -->
  <section class="screen" id="scOnline">
    <div class="brand"><h1>🌐 친구들과 함께 달리기</h1>
      <div class="sub">한 명이 방을 만들고, 나머지는 방 번호를 받아 들어옵니다</div></div>

    <div class="card">
      <h2>🆕 방 만들기 (한 명만)</h2>
      <p class="desc">방을 만든 사람이 경기장을 고르고 출발 신호를 줍니다.</p>
      <button class="btn primary wide" id="btnCreateRoom">방 만들고 번호 받기</button>
    </div>

    <div class="card">
      <h2>🚪 방에 들어가기</h2>
      <p class="desc">친구가 알려준 6자리 방 번호를 넣어 주세요.</p>
      <div class="row2">
        <input class="inp" id="roomIn" inputmode="numeric" maxlength="6" placeholder="000000"
               style="text-align:center;letter-spacing:6px;font-size:22px" autocomplete="off" />
        <button class="btn gold" id="btnJoinRoom">들어가기</button>
      </div>
      <div id="onlineErr" class="err hidden"></div>
    </div>

    <div class="card" id="serverCard">
      <h2>🔧 접속 서버</h2>
      <p class="desc">선생님이 만든 Cloudflare 주소를 넣으면 그 뒤로는 자동으로 기억합니다.</p>
      <input class="inp" id="serverIn" placeholder="https://kart-rooms.계정이름.workers.dev" autocomplete="off" />
      <div class="rowbtn">
        <button class="btn ghost sm" id="btnSaveServer">주소 저장</button>
        <button class="btn ghost sm" id="btnTestServer">연결 확인</button>
      </div>
      <div id="serverMsg" class="note"></div>
    </div>

    <div class="rowbtn"><button class="btn ghost wide" data-go="scHome">← 뒤로</button></div>
  </section>

  <!-- ── 4. 대기실 ── -->
  <section class="screen" id="scLobby">
    <div class="brand"><h1>🏁 출발 대기실</h1></div>

    <div class="card">
      <h2>방 번호</h2>
      <p class="desc">친구들에게 이 번호를 알려 주세요. 모두 나가면 방은 저절로 사라집니다.</p>
      <div class="code" id="lobbyCode">------</div>
      <button class="btn ghost wide sm" id="btnCopyCode">번호 복사하기</button>
    </div>

    <div class="card">
      <h2>지금 들어온 친구 <span id="lobbyCount" style="color:var(--brand)"></span></h2>
      <div class="plist" id="lobbyList"></div>
    </div>

    <div class="card" id="lobbyHostCard">
      <h2>🗺️ 경기장 · 바퀴 수 (방장만)</h2>
      <div class="tracks" id="lobbyTrackPick" style="margin-bottom:14px"></div>
      <label class="fld">몇 바퀴 달릴까요?</label>
      <div class="chips" id="lobbyLapPick"></div>
    </div>
    <div class="card hidden" id="lobbyGuestCard">
      <h2>🗺️ 오늘의 경기장</h2>
      <p class="desc" id="lobbyGuestInfo">방장이 고르는 중입니다…</p>
    </div>

    <div id="lobbyErr" class="err hidden"></div>
    <div class="rowbtn">
      <button class="btn danger" id="btnLeaveRoom">방 나가기</button>
      <button class="btn primary" id="btnHostStart" style="flex:2">🏁 모두 출발!</button>
    </div>
    <p class="note" id="lobbyWaitNote">방장이 출발 버튼을 누르면 함께 시작합니다.</p>
  </section>

  <!-- ── 5. 결과 ── -->
  <section class="screen" id="scResult">
    <div class="brand"><h1 id="resultTitle">🏁 경기 끝!</h1></div>
    <div class="card">
      <div class="podium" id="podium"></div>
      <table class="tbl">
        <thead><tr><th style="width:34px">순위</th><th>선수</th><th style="text-align:right">기록</th></tr></thead>
        <tbody id="resultRows"></tbody>
      </table>
      <div id="resultExtra" class="note"></div>
    </div>
    <div class="rowbtn">
      <button class="btn ghost" id="btnResultHome">처음 화면</button>
      <button class="btn primary" id="btnAgain" style="flex:2">🔁 한 번 더!</button>
    </div>
  </section>

</div>
</div>

<!-- ═══════════ 로딩 ═══════════ -->
<div id="load"><div class="sp"></div><div class="t" id="loadTxt">경기장을 만드는 중…</div></div>

<!-- ═══════════ WebGL 미지원 안내 ═══════════ -->
<div id="nogl" class="hidden">
  <h2>😢 이 기기에서는 3D 화면을 열 수 없어요</h2>
  <p>브라우저가 <b>WebGL</b>을 지원하지 않습니다.<br>
     크롬(Chrome) 최신 버전으로 열거나, 브라우저 설정에서
     <b>하드웨어 가속</b>을 켠 뒤 다시 들어와 주세요.</p>
</div>
<script>
/* ══════════════════════════════════════════════════════════════════
   우리 반 카트 그랑프리
   ──────────────────────────────────────────────────────────────────
   · 외부 라이브러리를 하나도 쓰지 않는 순수 WebGL 3D 레이싱 게임입니다.
     (학교 인터넷이 CDN을 막아도 파일 하나만 있으면 그대로 작동합니다.)
   · 학생 개인정보는 저장하지 않습니다. 별명만 사용합니다.
   ══════════════════════════════════════════════════════════════════ */
'use strict';

/* ═════════ 0. 자잘한 도우미 ═════════ */
const $  = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp  = (a, b, t) => a + (b - a) * t;
const TAU = Math.PI * 2;

/** 각도를 -π ~ +π 범위로 접어 넣음 */
function wrapAngle(a) {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
}
/** 프레임 시간에 영향받지 않는 부드러운 접근(감쇠) */
function damp(a, b, rate, dt) { return lerp(a, b, 1 - Math.exp(-rate * dt)); }

/** 시드가 있는 난수 — 같은 경기장은 언제나 똑같은 모양으로 만들어짐 */
function makeRng(seed) {
  let s = seed >>> 0 || 1;
  return function () {
    s ^= s << 13; s >>>= 0;
    s ^= s >> 17;
    s ^= s << 5;  s >>>= 0;
    return s / 4294967296;
  };
}

/** 1:23.456 꼴로 시간 표시 */
function fmtTime(ms) {
  if (ms == null || !isFinite(ms) || ms < 0) return '--:--.---';
  const t = Math.floor(ms);
  const m = Math.floor(t / 60000);
  const s = Math.floor((t % 60000) / 1000);
  const f = t % 1000;
  return m + ':' + String(s).padStart(2, '0') + '.' + String(f).padStart(3, '0');
}
function fmtDelta(ms) {
  const sign = ms >= 0 ? '+' : '-';
  const a = Math.abs(ms);
  return sign + (a / 1000).toFixed(3) + '초';
}

/* ═════════ 1. 행렬·벡터 수학 (열 우선, WebGL 표준) ═════════ */
const M4 = {
  create() {
    return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]);
  },
  identity(o) {
    o[0]=1;o[1]=0;o[2]=0;o[3]=0; o[4]=0;o[5]=1;o[6]=0;o[7]=0;
    o[8]=0;o[9]=0;o[10]=1;o[11]=0; o[12]=0;o[13]=0;o[14]=0;o[15]=1; return o;
  },
  /** o = a * b */
  mul(o, a, b) {
    const a00=a[0],a01=a[1],a02=a[2],a03=a[3], a10=a[4],a11=a[5],a12=a[6],a13=a[7],
          a20=a[8],a21=a[9],a22=a[10],a23=a[11], a30=a[12],a31=a[13],a32=a[14],a33=a[15];
    for (let i = 0; i < 4; i++) {
      const b0=b[i*4], b1=b[i*4+1], b2=b[i*4+2], b3=b[i*4+3];
      o[i*4]   = b0*a00 + b1*a10 + b2*a20 + b3*a30;
      o[i*4+1] = b0*a01 + b1*a11 + b2*a21 + b3*a31;
      o[i*4+2] = b0*a02 + b1*a12 + b2*a22 + b3*a32;
      o[i*4+3] = b0*a03 + b1*a13 + b2*a23 + b3*a33;
    }
    return o;
  },
  perspective(o, fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    o[0]=f/aspect;o[1]=0;o[2]=0;o[3]=0;
    o[4]=0;o[5]=f;o[6]=0;o[7]=0;
    o[8]=0;o[9]=0;o[10]=(far+near)*nf;o[11]=-1;
    o[12]=0;o[13]=0;o[14]=2*far*near*nf;o[15]=0;
    return o;
  },
  lookAt(o, ex, ey, ez, cx, cy, cz, ux, uy, uz) {
    let zx=ex-cx, zy=ey-cy, zz=ez-cz;
    let l = Math.hypot(zx, zy, zz) || 1; zx/=l; zy/=l; zz/=l;
    let xx=uy*zz-uz*zy, xy=uz*zx-ux*zz, xz=ux*zy-uy*zx;
    l = Math.hypot(xx, xy, xz);
    if (l < 1e-6) { xx=1; xy=0; xz=0; } else { xx/=l; xy/=l; xz/=l; }
    const yx=zy*xz-zz*xy, yy=zz*xx-zx*xz, yz=zx*xy-zy*xx;
    o[0]=xx;o[1]=yx;o[2]=zx;o[3]=0;
    o[4]=xy;o[5]=yy;o[6]=zy;o[7]=0;
    o[8]=xz;o[9]=yz;o[10]=zz;o[11]=0;
    o[12]=-(xx*ex+xy*ey+xz*ez);
    o[13]=-(yx*ex+yy*ey+yz*ez);
    o[14]=-(zx*ex+zy*ey+zz*ez);
    o[15]=1;
    return o;
  },
  /** 이동 → Y회전 → Z회전(기울기) → 크기 순으로 합친 모델 행렬 */
  compose(o, x, y, z, yaw, roll, pitch, sx, sy, sz) {
    const cy=Math.cos(yaw), sy0=Math.sin(yaw);
    const cr=Math.cos(roll), sr=Math.sin(roll);
    const cp=Math.cos(pitch), sp=Math.sin(pitch);
    // R = Ry(yaw) * Rx(pitch) * Rz(roll)  — 모형의 +Z가 진행 방향, +X가 오른쪽
    const m00 = cy*cr + sy0*sp*sr, m01 = -cy*sr + sy0*sp*cr, m02 = sy0*cp;
    const m10 = cp*sr,             m11 = cp*cr,              m12 = -sp;
    const m20 = -sy0*cr + cy*sp*sr, m21 = sy0*sr + cy*sp*cr, m22 = cy*cp;
    o[0]=m00*sx; o[1]=m10*sx; o[2]=m20*sx; o[3]=0;
    o[4]=m01*sy; o[5]=m11*sy; o[6]=m21*sy; o[7]=0;
    o[8]=m02*sz; o[9]=m12*sz; o[10]=m22*sz; o[11]=0;
    o[12]=x; o[13]=y; o[14]=z; o[15]=1;
    return o;
  },
  /** 회전+균일배율 모델 행렬에서 법선 행렬(3x3) 뽑기 */
  normal3(o, m) {
    for (let c = 0; c < 3; c++) {
      const x=m[c*4], y=m[c*4+1], z=m[c*4+2];
      const l = Math.hypot(x, y, z) || 1;
      o[c*3]=x/l; o[c*3+1]=y/l; o[c*3+2]=z/l;
    }
    return o;
  },
};

/* ═════════ 2. WebGL 렌더러 ═════════ */

/* 물체용 셰이더 — 정점 색 + 방향광 + 반구 환경광 + 거리 안개 */
const VS_MAIN = \`
attribute vec3 aPos;
attribute vec3 aNrm;
attribute vec3 aCol;
uniform mat4 uMVP;
uniform mat4 uModel;
uniform mat3 uNrmMat;
uniform vec3 uCam;
uniform vec2 uFog;          /* x=시작 거리, y=끝 거리 */
varying vec3 vNrm;
varying vec3 vCol;
varying float vFog;
varying float vHeight;
void main(){
  vec4 world = uModel * vec4(aPos, 1.0);
  gl_Position = uMVP * vec4(aPos, 1.0);
  vNrm = uNrmMat * aNrm;
  vCol = aCol;
  vHeight = world.y;
  float d = distance(world.xyz, uCam);
  vFog = clamp((d - uFog.x) / max(uFog.y - uFog.x, 1.0), 0.0, 1.0);
}\`;

const FS_MAIN = \`
precision mediump float;
varying vec3 vNrm;
varying vec3 vCol;
varying float vFog;
varying float vHeight;
uniform vec3 uLightDir;     /* 빛이 오는 방향(정규화) */
uniform vec3 uSun;
uniform vec3 uAmbSky;       /* 위쪽에서 오는 환경광 */
uniform vec3 uAmbGround;    /* 아래쪽에서 반사되는 환경광 */
uniform vec3 uFogCol;
uniform vec4 uTint;         /* rgb=색 곱하기, a=투명도 */
void main(){
  vec3 n = normalize(vNrm);
  float diff = max(dot(n, uLightDir), 0.0);
  /* 위를 향한 면일수록 하늘빛, 아래를 향할수록 땅빛 (반구 조명) */
  float hemi = n.y * 0.5 + 0.5;
  vec3 amb = mix(uAmbGround, uAmbSky, hemi);
  /* 살짝의 림 라이트로 저폴리 모양의 윤곽을 살림 */
  vec3 col = vCol * uTint.rgb * (amb + uSun * diff);
  col = mix(col, uFogCol, vFog);
  gl_FragColor = vec4(col, uTint.a);
}\`;

/* 하늘 셰이더 — 화면을 덮는 삼각형에 위아래 그라데이션 + 해 무리 */
const VS_SKY = \`
attribute vec2 aPos;
varying vec2 vUv;
void main(){ vUv = aPos; gl_Position = vec4(aPos, 0.999, 1.0); }\`;

const FS_SKY = \`
precision mediump float;
varying vec2 vUv;
uniform vec3 uTop;
uniform vec3 uMid;
uniform vec3 uBottom;
uniform vec2 uSunPos;       /* 화면상의 해 위치(-1~1) */
uniform vec3 uSunCol;
void main(){
  float t = vUv.y * 0.5 + 0.5;               /* 0=아래, 1=위 */
  vec3 c = t > 0.42
    ? mix(uMid, uTop, clamp((t - 0.42) / 0.58, 0.0, 1.0))
    : mix(uBottom, uMid, clamp(t / 0.42, 0.0, 1.0));
  float d = distance(vUv, uSunPos);
  c += uSunCol * (exp(-d * d * 5.0) * 0.55 + exp(-d * 22.0) * 0.85);
  gl_FragColor = vec4(c, 1.0);
}\`;

/** 정점을 모아 하나의 메시로 굽는 도구 */
class MeshBuilder {
  constructor() {
    this.v = [];        // pos(3) nrm(3) col(3)
    this.i = [];
    this.n = 0;
    this.stack = [];
    this.m = M4.create();
  }
  push(mat) { this.stack.push(this.m); const o = M4.create(); this.m = M4.mul(o, this.m, mat); return this; }
  pop() { this.m = this.stack.pop(); return this; }
  /** 현재 행렬을 적용해 정점 하나 추가 → 인덱스 반환 */
  vert(x, y, z, nx, ny, nz, r, g, b) {
    const m = this.m;
    const wx = m[0]*x + m[4]*y + m[8]*z + m[12];
    const wy = m[1]*x + m[5]*y + m[9]*z + m[13];
    const wz = m[2]*x + m[6]*y + m[10]*z + m[14];
    // 법선은 이동을 뺀 회전/배율만 적용 후 정규화
    let ax = m[0]*nx + m[4]*ny + m[8]*nz;
    let ay = m[1]*nx + m[5]*ny + m[9]*nz;
    let az = m[2]*nx + m[6]*ny + m[10]*nz;
    const l = Math.hypot(ax, ay, az) || 1; ax/=l; ay/=l; az/=l;
    this.v.push(wx, wy, wz, ax, ay, az, r, g, b);
    return this.n++;
  }
  tri(a, b, c) { this.i.push(a, b, c); return this; }
  /** 네 점으로 사각면 하나. 법선은 자동 계산 */
  quad(p0, p1, p2, p3, col, nrm) {
    let n = nrm;
    if (!n) {
      const ux=p1[0]-p0[0], uy=p1[1]-p0[1], uz=p1[2]-p0[2];
      const vx=p3[0]-p0[0], vy=p3[1]-p0[1], vz=p3[2]-p0[2];
      let nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
      const l = Math.hypot(nx, ny, nz) || 1;
      n = [nx/l, ny/l, nz/l];
    }
    const a = this.vert(p0[0],p0[1],p0[2], n[0],n[1],n[2], col[0],col[1],col[2]);
    const b = this.vert(p1[0],p1[1],p1[2], n[0],n[1],n[2], col[0],col[1],col[2]);
    const c = this.vert(p2[0],p2[1],p2[2], n[0],n[1],n[2], col[0],col[1],col[2]);
    const d = this.vert(p3[0],p3[1],p3[2], n[0],n[1],n[2], col[0],col[1],col[2]);
    this.i.push(a, b, c, a, c, d);
    return this;
  }
  /** 삼각면 하나 */
  tri3(p0, p1, p2, col) {
    const ux=p1[0]-p0[0], uy=p1[1]-p0[1], uz=p1[2]-p0[2];
    const vx=p2[0]-p0[0], vy=p2[1]-p0[1], vz=p2[2]-p0[2];
    let nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
    const l = Math.hypot(nx, ny, nz) || 1; nx/=l; ny/=l; nz/=l;
    const a = this.vert(p0[0],p0[1],p0[2], nx,ny,nz, col[0],col[1],col[2]);
    const b = this.vert(p1[0],p1[1],p1[2], nx,ny,nz, col[0],col[1],col[2]);
    const c = this.vert(p2[0],p2[1],p2[2], nx,ny,nz, col[0],col[1],col[2]);
    this.i.push(a, b, c);
    return this;
  }
  /** 축에 정렬된 상자 (중심 cx,cy,cz / 반크기 hx,hy,hz) */
  box(cx, cy, cz, hx, hy, hz, col, colTop) {
    const x0=cx-hx, x1=cx+hx, y0=cy-hy, y1=cy+hy, z0=cz-hz, z1=cz+hz;
    const top = colTop || col;
    this.quad([x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0], top,  [0,1,0]);   // 윗면
    this.quad([x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1], col,  [0,-1,0]);  // 아랫면
    this.quad([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1], col,  [0,0,1]);   // 앞
    this.quad([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0], col,  [0,0,-1]);  // 뒤
    this.quad([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1], col,  [1,0,0]);   // 오른
    this.quad([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0], col,  [-1,0,0]);  // 왼
    return this;
  }
  /** Y축을 축으로 하는 원기둥(바퀴는 눕혀서 씀) */
  cyl(cx, cy, cz, r, h, seg, col, colCap) {
    const cap = colCap || col;
    const y0 = cy - h/2, y1 = cy + h/2;
    const topC = this.vert(cx, y1, cz, 0,1,0, cap[0],cap[1],cap[2]);
    const botC = this.vert(cx, y0, cz, 0,-1,0, cap[0],cap[1],cap[2]);
    const ring = [];
    for (let i = 0; i < seg; i++) {
      const a = i / seg * TAU;
      const dx = Math.cos(a), dz = Math.sin(a);
      const x = cx + dx*r, z = cz + dz*r;
      ring.push({
        st: this.vert(x, y1, z, dx,0,dz, col[0],col[1],col[2]),
        sb: this.vert(x, y0, z, dx,0,dz, col[0],col[1],col[2]),
        ct: this.vert(x, y1, z, 0,1,0, cap[0],cap[1],cap[2]),
        cb: this.vert(x, y0, z, 0,-1,0, cap[0],cap[1],cap[2]),
      });
    }
    for (let i = 0; i < seg; i++) {
      const a = ring[i], b = ring[(i+1)%seg];
      this.i.push(a.st, b.sb, a.sb,  a.st, b.st, b.sb);   // 옆면
      this.i.push(topC, b.ct, a.ct);                       // 윗뚜껑
      this.i.push(botC, a.cb, b.cb);                       // 아랫뚜껑
    }
    return this;
  }
  /** 아래가 넓고 위가 좁은 사각뿔대 — 산·나무 밑동에 씀 */
  frustum(cx, cy, cz, rb, rt, h, seg, colSide, colTop) {
    const y0 = cy, y1 = cy + h;
    const idxB = [], idxT = [];
    for (let i = 0; i < seg; i++) {
      const a = i / seg * TAU;
      const dx = Math.cos(a), dz = Math.sin(a);
      const slope = Math.atan2(rb - rt, h);
      const ny = Math.sin(slope), s = Math.cos(slope);
      idxB.push(this.vert(cx+dx*rb, y0, cz+dz*rb, dx*s, ny, dz*s, colSide[0],colSide[1],colSide[2]));
      idxT.push(this.vert(cx+dx*rt, y1, cz+dz*rt, dx*s, ny, dz*s, colTop[0],colTop[1],colTop[2]));
    }
    for (let i = 0; i < seg; i++) {
      const j = (i+1)%seg;
      this.i.push(idxB[i], idxT[i], idxT[j],  idxB[i], idxT[j], idxB[j]);
    }
    if (rt > 0.01) {
      const c = this.vert(cx, y1, cz, 0,1,0, colTop[0],colTop[1],colTop[2]);
      const cap = [];
      for (let i = 0; i < seg; i++) {
        const a = i / seg * TAU;
        cap.push(this.vert(cx+Math.cos(a)*rt, y1, cz+Math.sin(a)*rt, 0,1,0, colTop[0],colTop[1],colTop[2]));
      }
      for (let i = 0; i < seg; i++) this.i.push(c, cap[(i+1)%seg], cap[i]);
    }
    return this;
  }
  get count() { return this.i.length; }
}

/** GPU에 올라간 메시 하나 */
class Mesh {
  constructor(gl, builder) {
    this.gl = gl;
    this.count = builder.i.length;
    this.vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(builder.v), gl.STATIC_DRAW);
    this.ibo = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo);
    // 정점이 6만5천 개를 넘으면 32비트 인덱스가 필요함
    this.big = builder.n > 65535;
    const arr = this.big ? new Uint32Array(builder.i) : new Uint16Array(builder.i);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, arr, gl.STATIC_DRAW);
  }
  dispose() {
    this.gl.deleteBuffer(this.vbo);
    this.gl.deleteBuffer(this.ibo);
    this.count = 0;
  }
}

/** 렌더러 — 셰이더·상태·그리기 담당 */
class Renderer {
  constructor(canvas) {
    const opts = { antialias:true, alpha:false, depth:true, stencil:false,
                   powerPreference:'high-performance', failIfMajorPerformanceCaveat:false };
    let gl = canvas.getContext('webgl', opts) || canvas.getContext('experimental-webgl', opts);
    if (!gl) { this.ok = false; return; }
    this.ok = true;
    this.gl = gl;
    this.canvas = canvas;
    this.uintExt = gl.getExtension('OES_element_index_uint');

    this.prog = this._program(VS_MAIN, FS_MAIN);
    this.aPos = gl.getAttribLocation(this.prog, 'aPos');
    this.aNrm = gl.getAttribLocation(this.prog, 'aNrm');
    this.aCol = gl.getAttribLocation(this.prog, 'aCol');
    this.u = {};
    ['uMVP','uModel','uNrmMat','uCam','uFog','uLightDir','uSun','uAmbSky','uAmbGround','uFogCol','uTint']
      .forEach(k => this.u[k] = gl.getUniformLocation(this.prog, k));

    this.sky = this._program(VS_SKY, FS_SKY);
    this.skyA = gl.getAttribLocation(this.sky, 'aPos');
    this.skyU = {};
    ['uTop','uMid','uBottom','uSunPos','uSunCol'].forEach(k => this.skyU[k] = gl.getUniformLocation(this.sky, k));
    this.skyBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);

    this.proj = M4.create();
    this.view = M4.create();
    this.vp   = M4.create();
    this.mvp  = M4.create();
    this.model = M4.create();
    this.nrm3 = new Float32Array(9);
    this.tint = new Float32Array([1,1,1,1]);
    this.camPos = [0,0,0];

    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);
    gl.clearColor(0.5, 0.7, 0.9, 1);
  }

  _shader(type, src) {
    const gl = this.gl, s = gl.createShader(type);
    gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
      console.error('셰이더 오류:', gl.getShaderInfoLog(s), src);
      throw new Error('shader');
    }
    return s;
  }
  _program(vs, fs) {
    const gl = this.gl, p = gl.createProgram();
    gl.attachShader(p, this._shader(gl.VERTEX_SHADER, vs));
    gl.attachShader(p, this._shader(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      console.error('프로그램 연결 오류:', gl.getProgramInfoLog(p));
      throw new Error('program');
    }
    return p;
  }

  /** 캔버스 크기를 화면(및 픽셀 비율)에 맞춤 */
  resize(dprCap) {
    const dpr = Math.min(window.devicePixelRatio || 1, dprCap || 2);
    const w = Math.max(1, Math.round(this.canvas.clientWidth  * dpr));
    const h = Math.max(1, Math.round(this.canvas.clientHeight * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w; this.canvas.height = h;
    }
    this.w = w; this.h = h;
    return this;
  }

  /** 화면 전체를 지우고 하늘을 칠함 */
  clearAll() {
    const gl = this.gl;
    gl.viewport(0, 0, this.w, this.h);
    gl.disable(gl.SCISSOR_TEST);
    gl.depthMask(true);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  }

  /** 화면의 일부만 쓰도록 지정 (분할 화면용, 픽셀 단위) */
  viewport(x, y, w, h) {
    const gl = this.gl;
    gl.viewport(x, y, w, h);
    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(x, y, w, h);
    this.vw = w; this.vh = h;
  }

  drawSky(env, sunScreen) {
    const gl = this.gl;
    gl.useProgram(this.sky);
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyBuf);
    gl.enableVertexAttribArray(this.skyA);
    gl.vertexAttribPointer(this.skyA, 2, gl.FLOAT, false, 0, 0);
    gl.uniform3fv(this.skyU.uTop, env.skyTop);
    gl.uniform3fv(this.skyU.uMid, env.skyMid);
    gl.uniform3fv(this.skyU.uBottom, env.skyBottom);
    gl.uniform2f(this.skyU.uSunPos, sunScreen[0], sunScreen[1]);
    gl.uniform3fv(this.skyU.uSunCol, env.sunGlow);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.disableVertexAttribArray(this.skyA);
    gl.enable(gl.DEPTH_TEST);
    gl.depthMask(true);
    gl.clear(gl.DEPTH_BUFFER_BIT);
  }

  /** 이번 시야의 카메라와 조명 환경을 설정 */
  setCamera(fov, aspect, near, far, eye, target, up) {
    M4.perspective(this.proj, fov, aspect, near, far);
    M4.lookAt(this.view, eye[0],eye[1],eye[2], target[0],target[1],target[2], up[0],up[1],up[2]);
    M4.mul(this.vp, this.proj, this.view);
    this.camPos = eye;
  }
  setEnv(env) {
    const gl = this.gl;
    gl.useProgram(this.prog);
    gl.uniform3fv(this.u.uLightDir, env.lightDir);
    gl.uniform3fv(this.u.uSun, env.sun);
    gl.uniform3fv(this.u.uAmbSky, env.ambSky);
    gl.uniform3fv(this.u.uAmbGround, env.ambGround);
    gl.uniform3fv(this.u.uFogCol, env.fogCol);
    gl.uniform2f(this.u.uFog, env.fogNear, env.fogFar);
    gl.uniform3fv(this.u.uCam, this.camPos);
  }

  /** 메시 하나 그리기. model이 없으면 이미 월드 좌표로 구워진 메시 */
  draw(mesh, model, tint) {
    if (!mesh || !mesh.count) return;
    const gl = this.gl;
    const m = model || M4.identity(this.model);
    M4.mul(this.mvp, this.vp, m);
    M4.normal3(this.nrm3, m);
    gl.useProgram(this.prog);
    gl.uniformMatrix4fv(this.u.uMVP, false, this.mvp);
    gl.uniformMatrix4fv(this.u.uModel, false, m);
    gl.uniformMatrix3fv(this.u.uNrmMat, false, this.nrm3);
    gl.uniform4fv(this.u.uTint, tint || this.tint);
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vbo);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.ibo);
    const S = 36;
    gl.enableVertexAttribArray(this.aPos); gl.vertexAttribPointer(this.aPos, 3, gl.FLOAT, false, S, 0);
    gl.enableVertexAttribArray(this.aNrm); gl.vertexAttribPointer(this.aNrm, 3, gl.FLOAT, false, S, 12);
    gl.enableVertexAttribArray(this.aCol); gl.vertexAttribPointer(this.aCol, 3, gl.FLOAT, false, S, 24);
    gl.drawElements(gl.TRIANGLES, mesh.count, mesh.big ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT, 0);
  }

  blend(on, depthWrite) {
    const gl = this.gl;
    if (on) { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); }
    else gl.disable(gl.BLEND);
    gl.depthMask(depthWrite !== false);
  }
  additive() {
    const gl = this.gl;
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    gl.depthMask(false);
  }
  /** 월드 좌표를 현재 시야의 화면 좌표(0~1)로 투영. 뒤에 있으면 null */
  project(x, y, z) {
    const v = this.vp;
    const cx = v[0]*x + v[4]*y + v[8]*z + v[12];
    const cy = v[1]*x + v[5]*y + v[9]*z + v[13];
    const cw = v[3]*x + v[7]*y + v[11]*z + v[15];
    if (cw <= 0.02) return null;
    return [(cx / cw) * 0.5 + 0.5, 1 - ((cy / cw) * 0.5 + 0.5)];
  }
}
/* ══════════════════════════════════════════════════════════════════
   3. 경기장(트랙) 만들기
   중심선 조종점 → 스플라인 → 일정 간격 표본 → 도로·연석·관중석·풍경 메시
   ══════════════════════════════════════════════════════════════════ */

/** 경기장 3종. pts는 [x, z] 조종점이며 닫힌 고리를 이룸 */
const TRACKS = [
  {
    id: 'snow',
    name: '눈꽃 스타디움',
    desc: '넓고 시원한 타원 코스. 처음 달리기에 딱 좋아요.',
    tag: '난이도 ★☆☆ · 초보 추천',
    scale: 0.86, width: 12.6, hills: 0.9, seed: 1207,
    pts: [
      [   0, 190], [  70, 183], [ 118, 150], [ 132,  95],
      [ 135,  20], [ 128, -60], [ 105,-128], [  55,-172],
      [ -15,-186], [ -85,-170], [-128,-120], [-140, -45],
      [-138,  35], [-128, 108], [ -95, 163], [ -45, 190],
    ],
    env: {
      ground: [0.90, 0.93, 0.98], groundAlt: [0.82, 0.87, 0.95],
      road:   [0.27, 0.29, 0.34], roadAlt: [0.24, 0.26, 0.31],
      curbA:  [0.86, 0.24, 0.28], curbB: [0.95, 0.96, 0.98],
      wall:   [0.30, 0.44, 0.70], wallTop: [0.94, 0.96, 1.0],
      skyTop: [0.29, 0.52, 0.83], skyMid: [0.60, 0.78, 0.94], skyBottom: [0.86, 0.92, 0.97],
      sunGlow:[0.16, 0.15, 0.11], sunAngle: 2.3,
      lightDir:[0.42, 0.78, 0.46], sun: [0.62, 0.62, 0.60],
      ambSky: [0.56, 0.61, 0.72], ambGround: [0.35, 0.38, 0.44],
      fogCol: [0.78, 0.86, 0.94], fogNear: 260, fogFar: 900,
      mountain: [0.55, 0.60, 0.72], mountainTop: [0.97, 0.98, 1.0], mountainCount: 26,
      tree: 'pine', treeCount: 150,
      treeLeaf: [0.14, 0.32, 0.26], treeLeaf2: [0.19, 0.40, 0.31], treeTrunk: [0.30, 0.23, 0.18],
      stands: 7,
    },
  },
  {
    id: 'hill',
    name: '초록 언덕 서킷',
    desc: '헤어핀과 오르막이 섞인 코스. 드리프트 연습에 좋아요.',
    tag: '난이도 ★★☆ · 코너 많음',
    scale: 0.85, width: 11.6, hills: 2.2, seed: 8842,
    // 위아래 두 덩어리가 가운데서 잘록해지는 '땅콩' 모양
    pts: [
      [   0, 180], [  70, 165], [ 105, 120], [ 108,  60],
      [  78,  14], [  46, -22], [  44, -70], [  72,-118],
      [  96,-172], [  50,-215], [ -20,-220], [ -88,-196],
      [-116,-146], [-100, -92], [ -62, -58], [ -44, -18],
      [ -60,  30], [ -96,  76], [-104, 130], [ -62, 170],
    ],
    env: {
      ground: [0.42, 0.62, 0.32], groundAlt: [0.34, 0.54, 0.27],
      road:   [0.29, 0.30, 0.33], roadAlt: [0.26, 0.27, 0.30],
      curbA:  [0.88, 0.26, 0.26], curbB: [0.96, 0.96, 0.96],
      wall:   [0.90, 0.92, 0.95], wallTop: [0.85, 0.30, 0.32],
      skyTop: [0.24, 0.48, 0.86], skyMid: [0.56, 0.76, 0.96], skyBottom: [0.83, 0.91, 0.98],
      sunGlow:[0.22, 0.20, 0.13], sunAngle: 1.1,
      lightDir:[-0.36, 0.84, 0.40], sun: [0.66, 0.64, 0.56],
      ambSky: [0.52, 0.58, 0.66], ambGround: [0.34, 0.38, 0.30],
      fogCol: [0.76, 0.86, 0.95], fogNear: 300, fogFar: 1000,
      mountain: [0.38, 0.50, 0.38], mountainTop: [0.52, 0.64, 0.46], mountainCount: 22,
      tree: 'round', treeCount: 190,
      treeLeaf: [0.26, 0.55, 0.24], treeLeaf2: [0.34, 0.63, 0.28], treeTrunk: [0.36, 0.26, 0.17],
      stands: 6,
    },
  },
  {
    id: 'dusk',
    name: '노을 사막 협곡',
    desc: '해 질 녘 좁고 구불구불한 길. 가장 어려워요.',
    tag: '난이도 ★★★ · 도전 코스',
    scale: 0.72, width: 10.6, hills: 1.7, seed: 3391,
    pts: [
      [   0, 170], [  75, 165], [ 130, 128], [ 150,  68],
      [ 128,  14], [  70,  -8], [  14, -32], [ -12, -82],
      [  36,-126], [ 112,-142], [ 162,-182], [ 146,-238],
      [  74,-258], [ -12,-250], [ -86,-216], [-142,-160],
      [-170, -86], [-174,   6], [-152,  86], [-100, 146],
      [ -45, 172],
    ],
    env: {
      ground: [0.76, 0.55, 0.34], groundAlt: [0.66, 0.45, 0.28],
      road:   [0.31, 0.27, 0.27], roadAlt: [0.28, 0.24, 0.24],
      curbA:  [0.92, 0.72, 0.20], curbB: [0.35, 0.20, 0.18],
      wall:   [0.58, 0.36, 0.26], wallTop: [0.90, 0.72, 0.36],
      skyTop: [0.20, 0.20, 0.48], skyMid: [0.86, 0.45, 0.36], skyBottom: [0.99, 0.74, 0.42],
      sunGlow:[0.42, 0.24, 0.08], sunAngle: -0.5,
      lightDir:[0.72, 0.30, -0.62], sun: [0.86, 0.56, 0.34],
      ambSky: [0.48, 0.40, 0.46], ambGround: [0.40, 0.28, 0.22],
      fogCol: [0.88, 0.60, 0.42], fogNear: 200, fogFar: 780,
      mountain: [0.52, 0.32, 0.26], mountainTop: [0.68, 0.44, 0.32], mountainCount: 24,
      tree: 'cactus', treeCount: 130,
      treeLeaf: [0.30, 0.46, 0.26], treeLeaf2: [0.36, 0.52, 0.30], treeTrunk: [0.42, 0.30, 0.20],
      stands: 5,
    },
  },
  {
    id: 'beach',
    name: '바닷가 코코넛 서킷',
    desc: '넓고 평평한 해변 길. 길게 밟을 수 있어 가장 빨라요.',
    tag: '난이도 ★★☆ · 넓고 빠름',
    scale: 0.88, width: 12.6, hills: 0.9, seed: 5517,
    // 오른쪽 아래에 헤어핀 하나, 나머지는 길게 이어지는 큰 곡선
    pts: [
      [   0, 186], [  84, 176], [ 142, 138], [ 160,  74],
      [ 142,  16], [ 116, -32], [ 130, -88], [ 170,-128],
      [ 158,-188], [  88,-216], [   6,-214], [ -76,-192],
      [-138,-148], [-168, -78], [-170,   6], [-148,  82],
      [-110, 146], [ -56, 180],
    ],
    env: {
      ground: [0.93, 0.86, 0.64], groundAlt: [0.87, 0.79, 0.57],
      road:   [0.30, 0.30, 0.33], roadAlt: [0.27, 0.27, 0.30],
      curbA:  [0.96, 0.54, 0.18], curbB: [0.98, 0.98, 0.96],
      wall:   [0.18, 0.62, 0.68], wallTop: [0.98, 0.98, 0.96],
      skyTop: [0.16, 0.48, 0.88], skyMid: [0.46, 0.76, 0.96], skyBottom: [0.86, 0.95, 0.99],
      sunGlow:[0.26, 0.22, 0.12], sunAngle: 0.4,
      lightDir:[0.30, 0.86, 0.42], sun: [0.78, 0.74, 0.62],
      ambSky: [0.56, 0.66, 0.76], ambGround: [0.50, 0.46, 0.34],
      fogCol: [0.70, 0.88, 0.94], fogNear: 320, fogFar: 1100,
      // 멀리 보이는 것은 산이 아니라 바다 건너 섬이다
      mountain: [0.28, 0.54, 0.50], mountainTop: [0.48, 0.70, 0.58], mountainCount: 18,
      tree: 'palm', treeCount: 150,
      treeLeaf: [0.20, 0.58, 0.32], treeLeaf2: [0.32, 0.72, 0.40], treeTrunk: [0.56, 0.44, 0.28],
      stands: 6,
    },
  },
  {
    id: 'volcano',
    name: '불타는 화산 지대',
    desc: '가장 길고 가파른 길. 좁은 오르내리막이 끝없이 이어져요.',
    tag: '난이도 ★★★★ · 가장 어려움',
    // 폭 10.0 으로 해 보니 컴퓨터 카트가 코스 밖에서 보내는 시간이 21% 나 됐다
    // (가장 어려운 기존 코스인 노을 사막이 14%). 10.8 로 넓혀 17% 로 맞췄다.
    scale: 0.88, width: 10.8, hills: 3.0, seed: 7731,
    // 바깥 고리 안쪽으로 두 번 파고드는 모양 — 오르내리막이 특히 심하다
    pts: [
      [   0, 166], [  74, 158], [ 122, 126], [ 136,  76],
      [ 118,  32], [  90,   8], [  76, -36], [ 104, -78],
      [ 142, -94], [ 176,-126], [ 180,-180], [ 118,-212],
      [  44,-206], [ -30,-178], [-100,-122], [-100, -56],
      [ -74, -12], [ -86,  36], [-134,  54], [-172,  98],
      [-150, 154], [ -80, 172],
    ],
    env: {
      // 도로(0.22)와 너무 비슷하면 길 끝이 안 보인다 — 땅을 조금 밝게 둔다
      ground: [0.34, 0.26, 0.24], groundAlt: [0.28, 0.21, 0.20],
      road:   [0.22, 0.20, 0.21], roadAlt: [0.19, 0.17, 0.18],
      curbA:  [0.94, 0.36, 0.12], curbB: [0.16, 0.14, 0.15],
      wall:   [0.36, 0.24, 0.22], wallTop: [0.96, 0.46, 0.16],
      skyTop: [0.10, 0.06, 0.16], skyMid: [0.44, 0.15, 0.20], skyBottom: [0.94, 0.42, 0.14],
      sunGlow:[0.55, 0.22, 0.05], sunAngle: -1.2,
      lightDir:[-0.50, 0.58, -0.64], sun: [0.95, 0.50, 0.22],
      ambSky: [0.40, 0.24, 0.26], ambGround: [0.34, 0.18, 0.14],
      fogCol: [0.44, 0.18, 0.14], fogNear: 190, fogFar: 820,
      // 봉우리가 붉게 달아오른 화산들
      mountain: [0.24, 0.16, 0.16], mountainTop: [0.96, 0.42, 0.12], mountainCount: 20,
      tree: 'rock', treeCount: 150,
      treeLeaf: [0.26, 0.22, 0.22], treeLeaf2: [0.36, 0.31, 0.30], treeTrunk: [0.20, 0.17, 0.17],
      stands: 4,
    },
  },
];

/** Catmull-Rom 보간 (한 축) */
function crom(p0, p1, p2, p3, t) {
  const t2 = t * t, t3 = t2 * t;
  return 0.5 * ((2*p1) + (-p0 + p2) * t
    + (2*p0 - 5*p1 + 4*p2 - p3) * t2
    + (-p0 + 3*p1 - 3*p2 + p3) * t3);
}

/** 부드러운 값 잡음 — 지형 높이에 씀 */
function makeNoise(seed) {
  const rng = makeRng(seed);
  const G = 256, tab = new Float32Array(G * G);
  for (let i = 0; i < G * G; i++) tab[i] = rng();
  const sm = (t) => t * t * (3 - 2 * t);
  return function (x, y) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const a = (i, j) => tab[(((i % G) + G) % G) * G + (((j % G) + G) % G)];
    const u = sm(xf), v = sm(yf);
    return lerp(lerp(a(xi, yi), a(xi + 1, yi), u),
                lerp(a(xi, yi + 1), a(xi + 1, yi + 1), u), v);
  };
}

/** 경기장 하나를 통째로 만들어 반환 */
function buildTrack(def, gl, quality) {
  const env = def.env;
  const rng = makeRng(def.seed);
  const noise = makeNoise(def.seed);
  const SCALE = def.scale;
  const STEP = 3.2;                       // 표본 간격(m)
  const HW = def.width / 2;               // 도로 반폭(m)

  /* ── 1) 조종점 → 촘촘한 점 → 등간격 재표본 ── */
  const cp = def.pts.map(p => [p[0] * SCALE, p[1] * SCALE]);
  const n = cp.length;
  const dense = [];
  for (let i = 0; i < n; i++) {
    const p0 = cp[(i - 1 + n) % n], p1 = cp[i], p2 = cp[(i + 1) % n], p3 = cp[(i + 2) % n];
    const sub = 26;
    for (let k = 0; k < sub; k++) {
      const t = k / sub;
      dense.push([crom(p0[0], p1[0], p2[0], p3[0], t), crom(p0[1], p1[1], p2[1], p3[1], t)]);
    }
  }
  // 누적 거리
  const acc = [0];
  for (let i = 1; i <= dense.length; i++) {
    const a = dense[i - 1], b = dense[i % dense.length];
    acc.push(acc[i - 1] + Math.hypot(b[0] - a[0], b[1] - a[1]));
  }
  const total = acc[dense.length];
  const count = Math.max(120, Math.round(total / STEP));
  const spacing = total / count;

  const pos = new Float32Array(count * 3);
  let di = 0;
  for (let i = 0; i < count; i++) {
    const target = i * spacing;
    while (di < dense.length - 1 && acc[di + 1] < target) di++;
    const seg = acc[di + 1] - acc[di] || 1;
    const t = (target - acc[di]) / seg;
    const a = dense[di], b = dense[(di + 1) % dense.length];
    pos[i * 3]     = lerp(a[0], b[0], t);
    pos[i * 3 + 2] = lerp(a[1], b[1], t);
  }

  /* ── 2) 높낮이: 코스를 한 바퀴 돌면 원래 높이로 돌아오는 주기 함수 ── */
  for (let i = 0; i < count; i++) {
    const u = i / count;
    pos[i * 3 + 1] = def.hills * (
      3.4 * Math.sin(u * TAU * 2 + 0.7) +
      2.1 * Math.sin(u * TAU * 3 + 2.1) +
      1.2 * Math.sin(u * TAU * 5 + 4.3)
    );
  }

  /* ── 3) 진행 방향·오른쪽 벡터·곡률·경사(뱅크) ── */
  const fwd = new Float32Array(count * 3);
  const rgt = new Float32Array(count * 3);
  const bank = new Float32Array(count);
  const curv = new Float32Array(count);
  const at = (i, k) => pos[(((i % count) + count) % count) * 3 + k];

  for (let i = 0; i < count; i++) {
    let dx = at(i + 1, 0) - at(i - 1, 0);
    let dy = at(i + 1, 1) - at(i - 1, 1);
    let dz = at(i + 1, 2) - at(i - 1, 2);
    const l = Math.hypot(dx, dy, dz) || 1;
    fwd[i*3] = dx/l; fwd[i*3+1] = dy/l; fwd[i*3+2] = dz/l;
    // 오른쪽 = forward × up  (수평면 기준)
    let rx = fwd[i*3+2], rz = -fwd[i*3];
    const rl = Math.hypot(rx, rz) || 1;
    rgt[i*3] = rx/rl; rgt[i*3+1] = 0; rgt[i*3+2] = rz/rl;
  }
  for (let i = 0; i < count; i++) {
    const h0 = Math.atan2(fwd[(((i-1)+count)%count)*3], fwd[(((i-1)+count)%count)*3+2]);
    const h1 = Math.atan2(fwd[((i+1)%count)*3], fwd[((i+1)%count)*3+2]);
    curv[i] = wrapAngle(h1 - h0) / (2 * spacing);
  }
  // 곡률을 부드럽게 다듬은 뒤 경사각으로 변환
  const cs = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    let s = 0;
    for (let k = -6; k <= 6; k++) s += curv[(((i + k) % count) + count) % count];
    cs[i] = s / 13;
  }
  // 부호가 음수인 이유: 각도(h)가 커지는 쪽이 화면에서는 왼쪽이라,
  // 그대로 두면 코너 안쪽이 높아지는 역뱅크가 된다.
  for (let i = 0; i < count; i++) bank[i] = clamp(cs[i] * -55, -0.16, 0.16);

  /* ── 4) 빠른 위치 찾기용 격자 ── */
  let minX = 1e9, maxX = -1e9, minZ = 1e9, maxZ = -1e9;
  for (let i = 0; i < count; i++) {
    minX = Math.min(minX, pos[i*3]); maxX = Math.max(maxX, pos[i*3]);
    minZ = Math.min(minZ, pos[i*3+2]); maxZ = Math.max(maxZ, pos[i*3+2]);
  }
  const CELL = 24;
  const gx0 = minX - 60, gz0 = minZ - 60;
  const gw = Math.ceil((maxX - minX + 120) / CELL), gh = Math.ceil((maxZ - minZ + 120) / CELL);
  const grid = new Array(gw * gh);
  for (let i = 0; i < count; i++) {
    const cxi = clamp(Math.floor((pos[i*3] - gx0) / CELL), 0, gw - 1);
    const czi = clamp(Math.floor((pos[i*3+2] - gz0) / CELL), 0, gh - 1);
    for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) {
      const k = (czi + b) * gw + (cxi + a);
      if (k < 0 || k >= grid.length) continue;
      (grid[k] || (grid[k] = [])).push(i);
    }
  }

  const T = {
    def, env, count, spacing, length: count * spacing,
    pos, fwd, rgt, bank, curv, halfWidth: HW,
    bounds: { minX, maxX, minZ, maxZ },
    _grid: grid, _gx0: gx0, _gz0: gz0, _gw: gw, _gh: gh, _cell: CELL,
  };

  /** i번 표본에서 lateral(오른쪽 +, m) 만큼 떨어진 노면의 3차원 좌표 */
  T.surface = function (i, lateral, out) {
    const k = (((i % count) + count) % count) * 3;
    const b = bank[(((i % count) + count) % count)];
    const o = out || [0, 0, 0];
    o[0] = pos[k]     + rgt[k]     * lateral;
    o[1] = pos[k + 1] + Math.sin(b) * lateral;
    o[2] = pos[k + 2] + rgt[k + 2] * lateral;
    return o;
  };
  /** 실수 위치(부드럽게 보간)에서의 노면 좌표 */
  T.surfaceF = function (fi, lateral, out) {
    const i0 = Math.floor(fi), t = fi - i0;
    const a = T.surface(i0, lateral, [0,0,0]);
    const b = T.surface(i0 + 1, lateral, [0,0,0]);
    const o = out || [0, 0, 0];
    o[0] = lerp(a[0], b[0], t); o[1] = lerp(a[1], b[1], t); o[2] = lerp(a[2], b[2], t);
    return o;
  };
  /** 표본 i의 진행 방향 각도(yaw) */
  T.headingAt = function (i) {
    const k = (((i % count) + count) % count) * 3;
    return Math.atan2(fwd[k], fwd[k + 2]);
  };
  /** (x,z)에 가장 가까운 표본을 hint 주변에서 국소 탐색 */
  T.locate = function (x, z, hint) {
    let best = -1, bestD = Infinity;
    if (hint != null) {
      for (let k = -14; k <= 14; k++) {
        const i = (((hint + k) % count) + count) % count;
        const dx = x - pos[i*3], dz = z - pos[i*3+2];
        const d = dx*dx + dz*dz;
        if (d < bestD) { bestD = d; best = i; }
      }
      if (bestD < 900) return T._refine(x, z, best);
    }
    return T._refine(x, z, T.locateGlobal(x, z));
  };
  /** 전체에서 가장 가까운 표본 (격자 이용) */
  T.locateGlobal = function (x, z) {
    const cxi = clamp(Math.floor((x - gx0) / CELL), 0, gw - 1);
    const czi = clamp(Math.floor((z - gz0) / CELL), 0, gh - 1);
    const cand = grid[czi * gw + cxi];
    let best = 0, bestD = Infinity;
    if (cand) {
      for (const i of cand) {
        const dx = x - pos[i*3], dz = z - pos[i*3+2];
        const d = dx*dx + dz*dz;
        if (d < bestD) { bestD = d; best = i; }
      }
      return best;
    }
    for (let i = 0; i < count; i += 2) {
      const dx = x - pos[i*3], dz = z - pos[i*3+2];
      const d = dx*dx + dz*dz;
      if (d < bestD) { bestD = d; best = i; }
    }
    return best;
  };
  /** 가장 가까운 표본을 실수 위치·가로 오프셋으로 정밀화 */
  T._refine = function (x, z, i) {
    const k = i * 3;
    const dx = x - pos[k], dz = z - pos[k+2];
    const along = dx * fwd[k] + dz * fwd[k+2];          // 진행 방향 성분
    const lat   = dx * rgt[k] + dz * rgt[k+2];          // 오른쪽 성분
    const fi = i + clamp(along / spacing, -1.5, 1.5);
    return { i, fi: (fi + count) % count, lat, along };
  };

  buildTrackMeshes(T, gl, rng, noise, quality);
  return T;
}
/* ══════════════════════════════════════════════════════════════════
   4. 경기장 메시 굽기 — 도로·연석·방호벽·지형·관중석·풍경
   모두 월드 좌표로 미리 구워 두고 한 번의 그리기 호출로 처리함
   ══════════════════════════════════════════════════════════════════ */
function buildTrackMeshes(T, gl, rng, noise, quality) {
  const env = T.env, count = T.count, HW = T.halfWidth;
  const P = (i, lat) => T.surface(i, lat, [0, 0, 0]);
  const mix = (a, b, t) => [lerp(a[0],b[0],t), lerp(a[1],b[1],t), lerp(a[2],b[2],t)];
  const shade = (c, k) => [clamp(c[0]*k,0,1), clamp(c[1]*k,0,1), clamp(c[2]*k,0,1)];

  /* ─────────── 도로면 · 차선 · 연석 ─────────── */
  const road = new MeshBuilder();
  const LINE = HW * 0.075;               // 흰 선 두께
  const CURB = HW * 0.20;                // 연석 폭
  const startLen = 2;                    // 결승선 길이(표본 수)
  const SHOULDER = 4.0;                  // 갓길 폭
  const DIP_ROAD = 0.55;                 // 갓길이 내려가는 높이

  /* 도로 주변 지형의 높이 — 지형 격자와 나무·산 배치가 같은 공식을 씀 */
  const FLAT = HW + CURB + SHOULDER + 2;   // 이 안쪽은 평평함
  function groundH(x, z) {
    const kk = T.locateGlobal(x, z);
    const k3 = kk * 3;
    const ddx = x - T.pos[k3], ddz = z - T.pos[k3 + 2];
    const d = Math.hypot(ddx, ddz);
    const lat = ddx * T.rgt[k3] + ddz * T.rgt[k3 + 2];
    // 코너 경사(뱅크)를 이어받아 도로 가장자리와 높이를 맞춤
    const baseY = T.pos[k3 + 1] + Math.sin(T.bank[kk]) * clamp(lat, -34, 34);
    const dip = (DIP_ROAD + 0.07) * (1 - clamp((d - FLAT) / 16, 0, 1));
    const t = clamp((d - 34) / 80, 0, 1);
    const rise = t * t * (3 - 2 * t);
    const nh = (noise(x * 0.006, z * 0.006) - 0.5) * 26
             + (noise(x * 0.018, z * 0.018) - 0.5) * 7;
    const far = clamp((d - 230) / 520, 0, 1);
    return { y: baseY - dip + rise * nh + far * far * 42 * noise(x * 0.0025 + 9, z * 0.0025 + 4), d };
  }
  T.groundH = (x, z) => groundH(x, z).y;

  // 가로 방향 띠 구성: [안쪽offset, 바깥쪽offset, 종류]
  const bands = [
    [-HW - CURB, -HW,          'curb'],
    [-HW,        -HW + LINE,   'line'],
    [-HW + LINE, -HW * 0.34,   'road'],
    [-HW * 0.34, -HW * 0.028,  'road'],
    [-HW * 0.028, HW * 0.028,  'dash'],
    [ HW * 0.028, HW * 0.34,   'road'],
    [ HW * 0.34,  HW - LINE,   'road'],
    [ HW - LINE,  HW,          'line'],
    [ HW,         HW + CURB,   'curb'],
  ];

  for (let i = 0; i < count; i++) {
    const j = i + 1;
    const inStart = (i < startLen);                     // 결승선 구간
    for (let b = 0; b < bands.length; b++) {
      const [o0, o1, kind] = bands[b];
      let col;
      if (kind === 'curb') {
        col = (Math.floor(i / 3) % 2) ? env.curbA : env.curbB;
      } else if (kind === 'line') {
        col = [0.93, 0.94, 0.96];
      } else if (kind === 'dash') {
        // 가운데 점선: 6칸마다 흰색
        col = (i % 8 < 4) ? [0.86, 0.87, 0.90] : ((i % 2) ? env.road : env.roadAlt);
      } else {
        col = (i % 2) ? env.road : env.roadAlt;
        // 코너 진입 표시로 살짝 어둡게 얼룩을 줌
        if ((i * 7 + b * 13) % 29 === 0) col = shade(col, 0.93);
      }
      if (inStart && kind !== 'curb') {
        // 결승선: 검정·흰색 바둑판
        const cell = Math.floor((o0 + HW) / (HW * 2) * 10);
        col = ((cell + i) % 2) ? [0.95, 0.96, 0.97] : [0.12, 0.13, 0.16];
      }
      road.quad(P(i, o0), P(j, o0), P(j, o1), P(i, o1), col);
    }
    // 연석 바깥 갓길 — 지형으로 자연스럽게 이어짐
    const sh = HW + CURB, sh2 = HW + CURB + SHOULDER;
    const gcol = shade(env.ground, 0.94);
    const l0 = P(i, -sh), l1 = P(j, -sh);
    const l2 = P(j, -sh2), l3 = P(i, -sh2);
    l2[1] -= DIP_ROAD; l3[1] -= DIP_ROAD;
    road.quad(l3, l2, l1, l0, gcol);
    const r0 = P(i, sh), r1 = P(j, sh);
    const r2 = P(j, sh2), r3 = P(i, sh2);
    r2[1] -= DIP_ROAD; r3[1] -= DIP_ROAD;
    road.quad(r0, r1, r2, r3, gcol);
  }
  T.roadMesh = new Mesh(gl, road);

  /* ─────────── 방호벽 (양쪽) ─────────── */
  const wall = new MeshBuilder();
  const WOFF = HW + CURB + 2.4, WH = 1.15;
  for (let side = -1; side <= 1; side += 2) {
    for (let i = 0; i < count; i++) {
      const j = i + 1;
      const o = WOFF * side;
      const a0 = P(i, o), a1 = P(j, o);
      const b0 = [a0[0], a0[1] + WH, a0[2]], b1 = [a1[0], a1[1] + WH, a1[2]];
      // 안쪽 면(도로를 향함): 광고판처럼 색을 번갈아
      const panel = Math.floor(i / 4) % 3;
      const face = panel === 0 ? env.wall : panel === 1 ? [0.95,0.96,0.97] : shade(env.wall, 1.25);
      if (side > 0) wall.quad(a0, a1, b1, b0, face);
      else          wall.quad(a1, a0, b0, b1, face);
      // 윗면 레일
      const t0 = [b0[0], b0[1] + 0.16, b0[2]], t1 = [b1[0], b1[1] + 0.16, b1[2]];
      const io = (WOFF - 0.34) * side;
      const c0 = P(i, io), c1 = P(j, io);
      c0[1] += WH + 0.16; c1[1] += WH + 0.16;
      if (side > 0) wall.quad(c0, c1, t1, t0, env.wallTop, [0,1,0]);
      else          wall.quad(t0, t1, c1, c0, env.wallTop, [0,1,0]);
    }
  }
  T.wallMesh = new Mesh(gl, wall);
  T.wallOffset = WOFF - 0.5;

  /* ─────────── 지형 ─────────── */
  const terr = new MeshBuilder();
  const pad = 340;
  const x0 = T.bounds.minX - pad, x1 = T.bounds.maxX + pad;
  const z0 = T.bounds.minZ - pad, z1 = T.bounds.maxZ + pad;
  const cell = quality.terrain;                       // 8 / 11 / 15 m
  const nx = Math.min(190, Math.ceil((x1 - x0) / cell));
  const nz = Math.min(190, Math.ceil((z1 - z0) / cell));
  const dx = (x1 - x0) / nx, dz = (z1 - z0) / nz;

  const hs = new Float32Array((nx + 1) * (nz + 1));
  const ds = new Float32Array((nx + 1) * (nz + 1));
  for (let a = 0; a <= nx; a++) {
    for (let b = 0; b <= nz; b++) {
      const g = groundH(x0 + a * dx, z0 + b * dz);
      hs[a * (nz + 1) + b] = g.y;
      ds[a * (nz + 1) + b] = g.d;
    }
  }
  for (let a = 0; a < nx; a++) {
    for (let b = 0; b < nz; b++) {
      const xa = x0 + a * dx, xb = xa + dx;
      const za = z0 + b * dz, zb = za + dz;
      const h00 = hs[a*(nz+1)+b], h10 = hs[(a+1)*(nz+1)+b];
      const h11 = hs[(a+1)*(nz+1)+b+1], h01 = hs[a*(nz+1)+b+1];
      const dd = (ds[a*(nz+1)+b] + ds[(a+1)*(nz+1)+b+1]) * 0.5;
      // 도로 바로 옆은 살짝 다른 색, 멀리는 얼룩덜룩하게
      const nv = noise(xa * 0.011 + 3, za * 0.011 + 7);
      let col = mix(env.ground, env.groundAlt, nv);
      if (dd < FLAT + 14) col = mix(col, shade(env.ground, 0.9), 0.5);
      const slope = Math.max(Math.abs(h10 - h00), Math.abs(h01 - h00)) / cell;
      if (slope > 0.45) col = mix(col, env.mountain, clamp((slope - 0.45) * 1.5, 0, 0.8));
      terr.quad([xa,h00,za], [xa,h01,zb], [xb,h11,zb], [xb,h10,za], col);
    }
  }
  T.terrainMesh = new Mesh(gl, terr);

  /* ─────────── 관중석 + 관중 + 지붕 ─────────── */
  const stand = new MeshBuilder();
  const standSpots = [];
  const nStands = Math.min(env.stands, Math.floor(count / 26));
  for (let s = 0; s < nStands; s++) {
    // 첫 관중석은 결승선 바로 옆, 나머지는 고르게 배치
    const at = s === 0 ? 4 : Math.floor((s / nStands) * count + count * 0.08) % count;
    for (let side = -1; side <= 1; side += 2) {
      if (s !== 0 && ((s + (side > 0 ? 1 : 0)) % 2)) continue;    // 한쪽만 있는 곳도 둠
      standSpots.push({ at, side });
      buildStand(stand, T, at, side, env, rng, quality, s === 0);
    }
  }
  T.standMesh = new Mesh(gl, stand);
  T.standSpots = standSpots;

  /* ─────────── 결승선 아치 · 깃발 · 나무 · 산 ─────────── */
  const scene = new MeshBuilder();
  buildGantry(scene, T, env);
  buildMountains(scene, T, env, rng);
  buildTrees(scene, T, env, rng, standSpots, quality);
  T.sceneMesh = new Mesh(gl, scene);

  /* ─────────── 출발 그리드 (최대 8칸) ─────────── */
  T.startGrid = [];
  for (let k = 0; k < 8; k++) {
    const row = Math.floor(k / 2);
    const sideL = (k % 2 === 0) ? -1 : 1;
    const idx = (count - (7 + row * 7)) % count;
    const lat = sideL * HW * 0.42;
    const p = T.surface(idx, lat, [0,0,0]);
    T.startGrid.push({ x: p[0], y: p[1], z: p[2], yaw: T.headingAt(idx), i: idx, lat, prog: idx / count });
  }

  /* ─────────── 아이템 상자 위치 ─────────── */
  T.itemSpots = [];
  const groups = 5;
  for (let g = 0; g < groups; g++) {
    const at = Math.floor(((g + 0.55) / groups) * count) % count;
    for (let c = -1; c <= 1; c++) {
      const lat = c * HW * 0.45;
      const p = T.surface(at, lat, [0,0,0]);
      T.itemSpots.push({ x: p[0], y: p[1] + 1.5, z: p[2], i: at, lat, taken: 0 });
    }
  }

  /* ─────────── 미니맵용 외곽선 ─────────── */
  T.mapPath = [];
  for (let i = 0; i < count; i += 2) T.mapPath.push([T.pos[i*3], T.pos[i*3+2]]);
}

/** 관중석 한 채 — 계단식 좌석 + 관중 + 지붕 */
function buildStand(mb, T, at, side, env, rng, quality, roofed) {
  const HW = T.halfWidth;
  const LEN = 22;                       // 표본 수 (약 70m)
  const rows = 6;
  const rowD = 2.35, rowH = 1.42;
  const base = HW + HW * 0.20 + 6.4;    // 방호벽 바깥쪽에 자리 잡음
  const cShade = [
    [0.93,0.30,0.32],[0.30,0.52,0.92],[0.98,0.80,0.24],[0.28,0.76,0.55],
    [0.94,0.52,0.20],[0.70,0.38,0.86],[0.96,0.96,0.97],[0.20,0.24,0.34],
    [0.98,0.45,0.62],[0.40,0.82,0.86],
  ];
  const concrete = [0.62,0.63,0.67], concreteDark = [0.44,0.45,0.50];

  const at0 = at, at1 = at + LEN;
  // 아래 받침 — 지형과 좌석 사이가 비어 보이지 않게 함
  for (let i = at0; i < at1; i++) {
    const j = i + 1;
    const o = base * side;
    const a = T.surface(i, o, [0,0,0]); a[1] -= 2.2;
    const b = T.surface(j, o, [0,0,0]); b[1] -= 2.2;
    const c = [b[0], b[1] + 2.2, b[2]], d = [a[0], a[1] + 2.2, a[2]];
    if (side > 0) mb.quad(a, b, c, d, concreteDark);
    else          mb.quad(b, a, d, c, concreteDark);
  }
  for (let i = at0; i < at1; i++) {
    const j = i + 1;
    for (let r = 0; r < rows; r++) {
      const o0 = (base + r * rowD) * side;
      const o1 = (base + (r + 1) * rowD) * side;
      const y0 = r * rowH, y1 = (r + 1) * rowH;
      // 좌석 바닥(수평면)
      const a = T.surface(i, o0, [0,0,0]); a[1] += y0;
      const b = T.surface(j, o0, [0,0,0]); b[1] += y0;
      const c = T.surface(j, o1, [0,0,0]); c[1] += y0;
      const d = T.surface(i, o1, [0,0,0]); d[1] += y0;
      if (side > 0) mb.quad(a, b, c, d, concrete, [0,1,0]);
      else          mb.quad(d, c, b, a, concrete, [0,1,0]);
      // 계단 앞면(수직)
      const e = [c[0], c[1] + rowH, c[2]], f = [d[0], d[1] + rowH, d[2]];
      if (side > 0) mb.quad(d, c, e, f, concreteDark);
      else          mb.quad(f, e, c, d, concreteDark);
    }
  }
  // 관중 — 도로 쪽을 향한 작은 판. 사진 속 알록달록한 픽셀 느낌
  if (quality.crowd > 0) {
    const seatGap = quality.crowd;                    // 좌석 사이 거리(m)
    const step = seatGap / T.spacing;                 // 표본 단위로 환산
    const subs = seatGap < 1.8 ? 2 : 1;               // 한 단에 앞뒤로 두 줄
    for (let i = at0 + 0.6; i < at1 - 0.6; i += step) {
      for (let r = 0; r < rows; r++) {
        for (let sub = 0; sub < subs; sub++) {
          if (rng() < 0.10) continue;                 // 군데군데 빈자리
          const o = (base + r * rowD + 0.7 + sub * 1.0) * side;
          const along = i + sub * 0.5 * step;
          const p = T.surfaceF(along, o, [0,0,0]);
          const y = p[1] + r * rowH + 0.1;
          const h = 0.9 + rng() * 0.4;
          const w = seatGap * 0.32;
          const col = cShade[(rng() * cShade.length) | 0];
          // 도로 쪽을 바라보는 납작한 판 (앞뒤 방향으로 폭을 줌)
          const ci = ((((i | 0) % T.count) + T.count) % T.count) * 3;
          const fw = T.fwd[ci], fz = T.fwd[ci + 2];
          const ax = fw * w, az = fz * w;
          const tilt = 0.22 * h;                       // 도로 쪽으로 살짝 기울임
          const lx = -side * fz * tilt, lz = side * fw * tilt;
          const q0 = [p[0] - ax, y, p[2] - az];
          const q1 = [p[0] + ax, y, p[2] + az];
          const q2 = [p[0] + ax + lx, y + h, p[2] + az + lz];
          const q3 = [p[0] - ax + lx, y + h, p[2] - az + lz];
          if (side > 0) mb.quad(q0, q1, q2, q3, col);
          else          mb.quad(q1, q0, q3, q2, col);
          // 머리
          const hc = [0.86, 0.72, 0.60];
          const hx = ax * 0.55, hz = az * 0.55;
          const h0 = [p[0] - hx + lx, y + h, p[2] - hz + lz];
          const h1 = [p[0] + hx + lx, y + h, p[2] + hz + lz];
          const h2 = [p[0] + hx + lx*1.3, y + h + 0.34, p[2] + hz + lz*1.3];
          const h3 = [p[0] - hx + lx*1.3, y + h + 0.34, p[2] - hz + lz*1.3];
          if (side > 0) mb.quad(h0, h1, h2, h3, hc);
          else          mb.quad(h1, h0, h3, h2, hc);
        }
      }
    }
  }
  // 지붕 — 메인 관중석에만 씌움 (도로 쪽으로 뻗은 캐노피와 기둥)
  if (!roofed) return;
  const roofY = rows * rowH + 4.6;
  const inner = (base - 2.4) * side, outer = (base + rows * rowD + 1.2) * side;
  const roofCol = [0.34, 0.38, 0.50], roofUnder = [0.23, 0.26, 0.36];
  for (let i = at0; i < at1; i++) {
    const j = i + 1;
    const a = T.surface(i, inner, [0,0,0]); a[1] += roofY - 1.1;
    const b = T.surface(j, inner, [0,0,0]); b[1] += roofY - 1.1;
    const c = T.surface(j, outer, [0,0,0]); c[1] += roofY + 1.4;
    const d = T.surface(i, outer, [0,0,0]); d[1] += roofY + 1.4;
    if (side > 0) { mb.quad(a, b, c, d, roofCol); mb.quad(d, c, b, a, roofUnder); }
    else          { mb.quad(d, c, b, a, roofCol); mb.quad(a, b, c, d, roofUnder); }
  }
  for (let i = at0 + 2; i < at1; i += 6) {
    const p = T.surface(i, outer, [0,0,0]);
    mb.box(p[0], p[1] + (roofY + 1.4) / 2, p[2], 0.34, (roofY + 1.4) / 2, 0.34, concreteDark);
  }
}

/** 결승선 위 아치 + 깃발 */
function buildGantry(mb, T, env) {
  const HW = T.halfWidth;
  const at = 2;
  const off = HW + HW * 0.20 + 3.2;
  const H = 8.2;
  const pillar = [0.86, 0.88, 0.92];
  for (let side = -1; side <= 1; side += 2) {
    const p = T.surface(at, off * side, [0,0,0]);
    mb.box(p[0], p[1] + H / 2, p[2], 0.62, H / 2, 0.62, pillar, [0.95,0.96,0.98]);
  }
  // 가로 보 — 바둑판 무늬 띠
  const cells = 18;
  for (let c = 0; c < cells; c++) {
    const t0 = -off + (2 * off) * (c / cells);
    const t1 = -off + (2 * off) * ((c + 1) / cells);
    const a = T.surface(at, t0, [0,0,0]), b = T.surface(at, t1, [0,0,0]);
    const cy = a[1] + H;
    const fw = T.fwd[at*3], fz = T.fwd[at*3+2];
    const d = 0.75;
    for (let r = 0; r < 2; r++) {
      const col = ((c + r) % 2) ? [0.96,0.97,0.98] : [0.10,0.11,0.14];
      const y0 = cy + r * 0.85, y1 = cy + (r + 1) * 0.85;
      // 다가오는 쪽 면
      mb.quad([b[0]-fw*d, y0, b[2]-fz*d], [a[0]-fw*d, y0, a[2]-fz*d],
              [a[0]-fw*d, y1, a[2]-fz*d], [b[0]-fw*d, y1, b[2]-fz*d], col);
      // 지나간 쪽 면
      mb.quad([a[0]+fw*d, y0, a[2]+fz*d], [b[0]+fw*d, y0, b[2]+fz*d],
              [b[0]+fw*d, y1, b[2]+fz*d], [a[0]+fw*d, y1, a[2]+fz*d], col);
      // 윗면
      mb.quad([a[0]+fw*d, y1, a[2]+fz*d], [b[0]+fw*d, y1, b[2]+fz*d],
              [b[0]-fw*d, y1, b[2]-fz*d], [a[0]-fw*d, y1, a[2]-fz*d], col, [0,1,0]);
    }
  }
  // 코스 곳곳의 깃대
  for (let i = 6; i < T.count; i += 34) {
    for (let side = -1; side <= 1; side += 2) {
      const p = T.surface(i, (off + 1.6) * side, [0,0,0]);
      mb.box(p[0], p[1] + 2.4, p[2], 0.1, 2.4, 0.1, [0.8,0.82,0.86]);
      const fw = T.fwd[i*3], fz = T.fwd[i*3+2];
      const col = ((i / 34) | 0) % 2 ? [0.92,0.28,0.32] : [0.24,0.52,0.92];
      mb.quad([p[0], p[1]+4.0, p[2]], [p[0]+fw*1.9, p[1]+4.0, p[2]+fz*1.9],
              [p[0]+fw*1.9, p[1]+4.7, p[2]+fz*1.9], [p[0], p[1]+4.7, p[2]], col);
      mb.quad([p[0]+fw*1.9, p[1]+4.0, p[2]+fz*1.9], [p[0], p[1]+4.0, p[2]],
              [p[0], p[1]+4.7, p[2]], [p[0]+fw*1.9, p[1]+4.7, p[2]+fz*1.9], col);
    }
  }
}

/** 멀리 보이는 산맥 */
function buildMountains(mb, T, env, rng) {
  const cx = (T.bounds.minX + T.bounds.maxX) / 2;
  const cz = (T.bounds.minZ + T.bounds.maxZ) / 2;
  const rad = Math.max(T.bounds.maxX - T.bounds.minX, T.bounds.maxZ - T.bounds.minZ) * 0.72;
  const N = env.mountainCount;
  for (let i = 0; i < N; i++) {
    const a = (i / N) * TAU + rng() * 0.16;
    const d = rad + 330 + rng() * 420;
    const x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
    const h = 110 + rng() * 190;
    const r = h * (0.75 + rng() * 0.55);
    const y = (T.groundH ? T.groundH(x, z) : 0) - 16;
    mb.frustum(x, y, z, r, r * 0.10, h * 0.76, 7, env.mountain, mix3(env.mountain, env.mountainTop, 0.45));
    // 눈 덮인 봉우리
    mb.frustum(x, y + h * 0.76, z, r * 0.16, 0, h * 0.30, 7, env.mountainTop, env.mountainTop);
  }
  function mix3(a, b, t) { return [lerp(a[0],b[0],t), lerp(a[1],b[1],t), lerp(a[2],b[2],t)]; }
}

/** 코스 주변의 나무·선인장·바위 */
function buildTrees(mb, T, env, rng, standSpots, quality) {
  const HW = T.halfWidth;
  const N = Math.round(env.treeCount * quality.trees);
  let placed = 0, guard = 0;
  while (placed < N && guard++ < N * 12) {
    const i = (rng() * T.count) | 0;
    // 관중석 근처는 피함
    let blocked = false;
    for (const s of standSpots) {
      const d = Math.abs(wrapIdx(i - s.at, T.count));
      if (d < 26) { blocked = true; break; }
    }
    if (blocked) continue;
    const side = rng() < 0.5 ? -1 : 1;
    const off = (HW * 2.8 + rng() * HW * 8) * side;
    const p = T.surfaceF(i + rng(), off, [0,0,0]);
    // 다른 구간의 도로 위에 심어지지 않도록 확인
    const k = T.locateGlobal(p[0], p[2]);
    const dd = Math.hypot(p[0] - T.pos[k*3], p[2] - T.pos[k*3+2]);
    if (dd < HW * 2.4) continue;
    // 실제 지형 높이에 맞춰 심음
    p[1] = T.groundH(p[0], p[2]) - 0.35;
    const s = 0.75 + rng() * 0.9;
    if (env.tree === 'pine') {
      mb.cyl(p[0], p[1] + 0.9*s, p[2], 0.28*s, 1.8*s, 5, env.treeTrunk);
      mb.frustum(p[0], p[1] + 1.3*s, p[2], 2.1*s, 1.2*s, 2.6*s, 6, env.treeLeaf, env.treeLeaf2);
      mb.frustum(p[0], p[1] + 3.5*s, p[2], 1.5*s, 0.55*s, 2.4*s, 6, env.treeLeaf, env.treeLeaf2);
      mb.frustum(p[0], p[1] + 5.4*s, p[2], 0.85*s, 0.0,     2.1*s, 6, env.treeLeaf2, [0.95,0.96,0.98]);
    } else if (env.tree === 'round') {
      mb.cyl(p[0], p[1] + 1.4*s, p[2], 0.32*s, 2.8*s, 5, env.treeTrunk);
      mb.frustum(p[0], p[1] + 2.4*s, p[2], 1.1*s, 2.2*s, 1.5*s, 7, env.treeLeaf, env.treeLeaf2);
      mb.frustum(p[0], p[1] + 3.9*s, p[2], 2.2*s, 0.5*s, 2.0*s, 7, env.treeLeaf2, env.treeLeaf2);
    } else if (env.tree === 'palm') {
      // 야자수 — 살짝 기운 줄기 세 토막 + 잎 여섯 장 + 코코넛
      const H = (4.6 + rng() * 1.8) * s;
      const ang = rng() * TAU;
      const lean = (0.10 + rng() * 0.16) * H;          // 꼭대기가 옆으로 밀리는 정도
      const lx = Math.cos(ang) * lean, lz = Math.sin(ang) * lean;
      for (let t = 0; t < 3; t++) {
        const f0 = t / 3, f1 = (t + 1) / 3;
        // 위로 갈수록 더 휘도록 f를 제곱해서 옆으로 민다
        mb.frustum(p[0] + lx * f0 * f0, p[1] + H * f0, p[2] + lz * f0 * f0,
                   0.30 * s * (1 - f0 * 0.45), 0.30 * s * (1 - f1 * 0.45),
                   H / 3 + 0.06, 6, env.treeTrunk, env.treeTrunk);
      }
      const tx = p[0] + lx, ty = p[1] + H, tz = p[2] + lz;
      for (let t = 0; t < 6; t++) {
        // 잎 한 장 = 납작하게 눌러(sz 0.42) 바깥으로 뉘인(pitch 1.25) 원뿔
        mb.push(M4.compose(M4.create(), tx, ty, tz, ang + t / 6 * TAU, 0, 1.25, 1, 1, 0.42));
        mb.frustum(0, 0, 0, 0.36 * s, 0.05 * s, 2.5 * s, 5,
                   (t % 2) ? env.treeLeaf : env.treeLeaf2, env.treeLeaf2);
        mb.pop();
      }
      mb.frustum(tx, ty - 0.3 * s, tz, 0.30 * s, 0.16 * s, 0.40 * s, 6, env.treeTrunk, env.treeLeaf);
    } else if (env.tree === 'rock') {
      // 검은 바위 — 다섯에 하나쯤은 붉게 달아올라 있다
      const hot = rng() < 0.22;
      const top = hot ? env.mountainTop : env.treeLeaf2;
      mb.frustum(p[0], p[1], p[2], 2.2 * s, 1.2 * s, 1.7 * s, 6, env.treeLeaf, top);
      if (rng() < 0.6) {
        mb.frustum(p[0] + 1.3 * s, p[1], p[2] - 0.9 * s, 1.1 * s, 0.45 * s, 1.2 * s, 5,
                   env.treeLeaf, hot ? env.mountainTop : env.treeLeaf2);
      }
    } else {
      // 선인장 · 바위
      if (rng() < 0.55) {
        mb.cyl(p[0], p[1] + 1.7*s, p[2], 0.42*s, 3.4*s, 7, env.treeLeaf, env.treeLeaf2);
        mb.cyl(p[0] + 0.9*s, p[1] + 2.3*s, p[2], 0.26*s, 1.5*s, 6, env.treeLeaf);
        mb.cyl(p[0] + 0.9*s, p[1] + 2.9*s, p[2], 0.26*s, 0.9*s, 6, env.treeLeaf);
      } else {
        mb.frustum(p[0], p[1], p[2], 1.9*s, 1.1*s, 1.7*s, 6, env.mountain, env.mountainTop);
      }
    }
    placed++;
  }
  function wrapIdx(d, n) { d = ((d % n) + n) % n; return d > n / 2 ? d - n : d; }
}
/* ══════════════════════════════════════════════════════════════════
   5. 카트 — 모양 · 주행 물리 · 컴퓨터 운전수(AI)
   ══════════════════════════════════════════════════════════════════ */

/** 고를 수 있는 카트 색 (별명과 함께 학생을 구분하는 유일한 표시) */
const KART_COLORS = [
  { id:0, name:'빨강',   body:[0.92,0.22,0.26], trim:[0.62,0.10,0.14], css:'#ea3842' },
  { id:1, name:'파랑',   body:[0.20,0.46,0.94], trim:[0.10,0.26,0.62], css:'#3475f0' },
  { id:2, name:'초록',   body:[0.20,0.72,0.42], trim:[0.10,0.44,0.26], css:'#33b86b' },
  { id:3, name:'노랑',   body:[0.98,0.78,0.16], trim:[0.72,0.52,0.06], css:'#f8c72a' },
  { id:4, name:'분홍',   body:[0.96,0.36,0.66], trim:[0.68,0.18,0.44], css:'#f45ca8' },
  { id:5, name:'보라',   body:[0.60,0.36,0.92], trim:[0.36,0.18,0.62], css:'#9a5cea' },
  { id:6, name:'주황',   body:[0.98,0.52,0.14], trim:[0.68,0.32,0.06], css:'#f8862a' },
  { id:7, name:'하늘',   body:[0.32,0.80,0.92], trim:[0.14,0.50,0.62], css:'#52ccea' },
];

/** 카트 몸통 메시 (색깔별로 한 번만 구움). 앞쪽이 +Z */
const kartMeshCache = {};
function getKartMesh(gl, colorId) {
  if (kartMeshCache[colorId]) return kartMeshCache[colorId];
  const C = KART_COLORS[colorId % KART_COLORS.length];
  const mb = new MeshBuilder();
  const body = C.body, trim = C.trim;
  const dark = [0.14,0.15,0.19], metal = [0.62,0.65,0.72], glass = [0.30,0.44,0.56];

  // 바닥 판
  mb.box(0, 0.20, 0, 0.62, 0.09, 1.18, trim, body);
  // 몸통 (앞이 좁고 뒤가 넓음)
  mb.quad([-0.40,0.29, 1.15], [0.40,0.29, 1.15], [0.62,0.29,-0.10], [-0.62,0.29,-0.10], body, [0,1,0]);
  mb.box(0, 0.42, -0.62, 0.60, 0.22, 0.56, body, [body[0]*1.1, body[1]*1.1, body[2]*1.1]);
  // 앞 코
  mb.tri3([-0.40,0.29,1.15], [0,0.29,1.62], [0.40,0.29,1.15], body);
  mb.quad([-0.40,0.16,1.15], [0.40,0.16,1.15], [0.40,0.29,1.15], [-0.40,0.29,1.15], trim);
  mb.tri3([0,0.29,1.62], [-0.40,0.16,1.15], [0.40,0.16,1.15], trim);
  mb.tri3([0,0.29,1.62], [0.40,0.16,1.15], [0.40,0.29,1.15], trim);
  mb.tri3([0,0.29,1.62], [-0.40,0.29,1.15], [-0.40,0.16,1.15], trim);
  // 앞 범퍼
  mb.box(0, 0.24, 1.34, 0.34, 0.08, 0.16, dark);
  // 옆 사이드 포드
  mb.box(-0.66, 0.32, 0.10, 0.14, 0.16, 0.62, trim);
  mb.box( 0.66, 0.32, 0.10, 0.14, 0.16, 0.62, trim);
  // 좌석
  mb.box(0, 0.44, -0.22, 0.30, 0.16, 0.34, dark);
  mb.box(0, 0.70, -0.48, 0.32, 0.26, 0.10, dark);
  // 운전자 — 몸통 · 팔 · 머리 · 헬멧
  mb.box(0, 0.74, -0.20, 0.24, 0.24, 0.19, [0.94,0.95,0.97]);
  mb.box(-0.28, 0.70, 0.06, 0.07, 0.07, 0.30, [0.94,0.95,0.97]);
  mb.box( 0.28, 0.70, 0.06, 0.07, 0.07, 0.30, [0.94,0.95,0.97]);
  mb.box(0, 1.06, -0.20, 0.19, 0.16, 0.18, body, [body[0]*1.15, body[1]*1.15, body[2]*1.15]);
  mb.box(0, 1.03, -0.03, 0.15, 0.09, 0.03, glass);           // 헬멧 앞창
  // 핸들
  mb.push(M4.compose(M4.create(), 0, 0.66, 0.28, 0, 0, -0.55, 1, 1, 1));
  mb.cyl(0, 0, 0, 0.20, 0.05, 8, dark);
  mb.pop();
  // 뒤 날개
  mb.box(0, 0.86, -1.06, 0.56, 0.05, 0.20, body, [1,1,1]);
  mb.box(-0.48, 0.66, -1.06, 0.05, 0.22, 0.06, metal);
  mb.box( 0.48, 0.66, -1.06, 0.05, 0.22, 0.06, metal);
  // 배기구
  mb.box(-0.22, 0.36, -1.14, 0.07, 0.07, 0.14, metal);
  mb.box( 0.22, 0.36, -1.14, 0.07, 0.07, 0.14, metal);

  const m = new Mesh(gl, mb);
  kartMeshCache[colorId] = m;
  return m;
}

/** 바퀴 하나 (축이 X 방향) */
let wheelMeshCache = null;
function getWheelMesh(gl) {
  if (wheelMeshCache) return wheelMeshCache;
  const mb = new MeshBuilder();
  mb.push(M4.compose(M4.create(), 0, 0, 0, 0, Math.PI / 2, 0, 1, 1, 1));
  mb.cyl(0, 0, 0, 0.34, 0.26, 10, [0.11,0.12,0.15], [0.20,0.21,0.25]);
  mb.cyl(0, 0, 0, 0.17, 0.28, 8, [0.78,0.80,0.86], [0.86,0.88,0.92]);
  mb.pop();
  wheelMeshCache = new Mesh(gl, mb);
  return wheelMeshCache;
}

/** 그림자·불꽃 등에 쓰는 납작한 원판 */
let discMeshCache = null;
function getDiscMesh(gl) {
  if (discMeshCache) return discMeshCache;
  const mb = new MeshBuilder();
  const c = mb.vert(0, 0, 0, 0, 1, 0, 1, 1, 1);
  const seg = 14, ring = [];
  for (let i = 0; i < seg; i++) {
    const a = i / seg * TAU;
    ring.push(mb.vert(Math.cos(a), 0, Math.sin(a), 0, 1, 0, 1, 1, 1));
  }
  for (let i = 0; i < seg; i++) mb.tri(c, ring[(i + 1) % seg], ring[i]);
  discMeshCache = new Mesh(gl, mb);
  return discMeshCache;
}

/** 아이템 상자 · 바나나 · 미사일 메시 */
const propMeshCache = {};
function getPropMesh(gl, kind) {
  if (propMeshCache[kind]) return propMeshCache[kind];
  const mb = new MeshBuilder();
  if (kind === 'itembox') {
    mb.box(0, 0, 0, 0.62, 0.62, 0.62, [0.98, 0.84, 0.26], [1, 0.94, 0.5]);
    mb.box(0, 0, 0, 0.66, 0.20, 0.20, [0.24, 0.30, 0.46]);
    mb.box(0, 0, 0, 0.20, 0.66, 0.20, [0.24, 0.30, 0.46]);
    mb.box(0, 0, 0, 0.20, 0.20, 0.66, [0.24, 0.30, 0.46]);
  } else if (kind === 'banana') {
    mb.frustum(0, 0, 0, 0.30, 0.16, 0.42, 6, [0.96, 0.84, 0.20], [0.98, 0.90, 0.34]);
    mb.box(0, 0.48, 0, 0.05, 0.10, 0.05, [0.44, 0.32, 0.12]);
  } else if (kind === 'missile') {
    mb.push(M4.compose(M4.create(), 0, 0, 0, 0, 0, Math.PI / 2, 1, 1, 1));
    mb.cyl(0, 0, 0, 0.20, 0.72, 8, [0.90, 0.26, 0.30], [0.96, 0.96, 0.98]);
    mb.pop();
    mb.tri3([0, 0.20, 0.36], [-0.18, -0.10, 0.36], [0.18, -0.10, 0.36], [0.96,0.96,0.98]);
    mb.frustum(0, 0.36, 0, 0.20, 0.02, 0.38, 8, [0.96,0.96,0.98], [0.96,0.96,0.98]);
  } else if (kind === 'ice') {
    // 얼음 웅덩이 — 납작한 육각 얼음판
    mb.frustum(0, 0, 0, 0.62, 0.46, 0.16, 6, [0.62, 0.86, 1.0], [0.86, 0.96, 1.0]);
    mb.frustum(0, 0.16, 0, 0.30, 0.16, 0.22, 6, [0.78, 0.93, 1.0], [0.95, 0.99, 1.0]);
  } else if (kind === 'shield') {
    mb.frustum(0, -1.1, 0, 1.35, 1.35, 2.2, 12, [0.45, 0.78, 1.0], [0.65, 0.90, 1.0]);
  }
  propMeshCache[kind] = new Mesh(gl, mb);
  return propMeshCache[kind];
}

/* ═════════ 아이템 정의 ═════════
   hint 는 아이템 칸 아래에 뜨는 한 줄 설명이다. 조작 키가 아니라 '무엇을 하는지'를 적는다
   (아이템 쓰기는 어느 것이든 Shift·E, 패드에서는 [아이템] 단추다). */
const ITEMS = {
  boost:  { icon:'⚡',  name:'부스터', hint:'잠깐 아주 빨라져요' },
  banana: { icon:'🍌', name:'바나나', hint:'뒤에 놓아 두어요' },
  missile:{ icon:'🚀', name:'미사일', hint:'앞차를 쫓아가 맞혀요' },
  shield: { icon:'🛡️', name:'방패',   hint:'한 번 막아 줘요 (6초)' },
  ice:    { icon:'🧊', name:'얼음',   hint:'뒤에 깔아 미끄러뜨려요' },
  thunder:{ icon:'🌩️', name:'번개',   hint:'나보다 앞선 카트가 모두 휘청' },
  star:   { icon:'🌟', name:'별',     hint:'6초 동안 무적 · 조금 빨라져요' },
};
/** 순위가 낮을수록 좋은 아이템이 잘 나옴 (초등 수업용으로 완만하게)
    선두는 지키는 아이템(바나나·얼음·방패), 뒤쪽은 따라잡는 아이템(미사일·번개·별)이 잘 나온다 */
function rollItem(rank, total) {
  const behind = total > 1 ? (rank - 1) / (total - 1) : 0;   // 0=1위, 1=꼴찌
  const w = {
    banana:  0.22 - behind * 0.10,
    ice:     0.14 - behind * 0.05,
    shield:  0.15,
    boost:   0.18 + behind * 0.06,
    missile: 0.14 + behind * 0.10,
    thunder: 0.04 + behind * 0.14,
    star:    0.05 + behind * 0.09,
  };
  let sum = 0; for (const k in w) sum += w[k];
  let r = Math.random() * sum;
  for (const k in w) { r -= w[k]; if (r <= 0) return k; }
  return 'boost';
}

/* ═════════ 카트 한 대 ═════════ */
class Kart {
  constructor(opts) {
    this.id = opts.id;
    this.name = opts.name || '카트';
    this.colorId = opts.colorId || 0;
    this.isPlayer = !!opts.isPlayer;
    this.isRemote = !!opts.isRemote;
    this.isAI = !!opts.isAI;
    this.skill = opts.skill != null ? opts.skill : 0.8;

    this.x = 0; this.y = 0; this.z = 0;
    this.h = 0;                 // 향하고 있는 방향
    this.vx = 0; this.vz = 0;   // 속도 벡터
    this.speed = 0;             // 앞쪽 속도(m/s)
    this.steer = 0;
    this.roll = 0; this.pitch = 0;
    this.wheelSpin = 0;

    this.drifting = false; this.driftDir = 0; this.driftCharge = 0;
    this.boost = 0;             // 남은 부스터 시간
    this.spin = 0;              // 아이템에 맞아 도는 시간
    this.shield = 0;
    this.star = 0;              // 별 — 남은 무적 시간
    this.slip = 0;              // 얼음 — 남은 미끄러짐 시간
    this.item = null;
    this.itemRolling = 0;
    this.itemHeld = false;      // 아이템 버튼을 계속 누르고 있는지

    this.trackI = 0; this.lat = 0; this.lap = 0; this.prog = 0;
    this.rank = 1; this.finished = false; this.finishTime = null;
    this.lapTimes = []; this.lastLapStart = 0;
    this.bestLap = null;
    this.offRoad = false; this.wrongWay = false;
    this.respawnT = 0;
    this.aiSeed = Math.random() * 100;
    this.aiLine = (Math.random() - 0.5) * 0.5;
    this.netT = 0; this.tx = 0; this.tz = 0; this.ty = 0; this.th = 0;   // 통신 보간용
  }

  /** 출발선에 배치 */
  placeAt(g) {
    this.x = g.x; this.y = g.y; this.z = g.z; this.h = g.yaw;
    this.vx = 0; this.vz = 0; this.speed = 0;
    this.trackI = g.i; this.lat = g.lat;
    this.tx = this.x; this.tz = this.z; this.ty = this.y; this.th = this.h;
    // 출발선 뒤에서 시작하므로 결승선을 처음 지날 때 1바퀴째가 시작됨
    this.lap = -1; this.prog = g.prog != null ? g.prog : 0;
    this.finished = false; this.finishTime = null;
    this.lapTimes = []; this.bestLap = null; this.lastLapStart = 0;
    this.boost = 0; this.spin = 0; this.shield = 0; this.item = null;
    this.star = 0; this.slip = 0; this.itemHeld = false;
    this.driftCharge = 0; this.drifting = false; this.roll = 0; this.pitch = 0;
  }

  get kmh() { return Math.max(0, this.speed) * 3.6; }

  /** 한 프레임 물리 갱신. input = {gas, brake, steer, drift, useItem} */
  update(dt, input, track, race) {
    const wasLap = this.lap;

    // ── 아이템에 맞아 도는 중 ──
    if (this.spin > 0) {
      this.spin -= dt;
      this.h += dt * 9.5;
      this.speed = damp(this.speed, 2, 5, dt);
      input = { gas: 0, brake: 0, steer: 0, drift: false };
    }
    // ── 되돌리기(리스폰) 중 ──
    if (this.respawnT > 0) {
      this.respawnT -= dt;
      const loc = track.locate(this.x, this.z, this.trackI);
      const p = track.surface(loc.i, 0, [0,0,0]);
      this.x = damp(this.x, p[0], 9, dt);
      this.z = damp(this.z, p[2], 9, dt);
      this.y = damp(this.y, p[1], 9, dt);
      this.h = this.h + wrapAngle(track.headingAt(loc.i) - this.h) * clamp(dt * 9, 0, 1);
      this.speed = 0; this.vx = 0; this.vz = 0;
      this.trackI = loc.i;
      return;
    }

    const fx = Math.sin(this.h), fz = Math.cos(this.h);

    // ── 노면 상태 ──
    const loc = track.locate(this.x, this.z, this.trackI);
    this.trackI = loc.i; this.lat = loc.lat;
    const edge = track.halfWidth * 1.36;          // 연석 위까지는 코스 안으로 봄
    this.offRoad = Math.abs(loc.lat) > edge;
    const surfaceGrip = this.offRoad ? 0.55 : 1;
    const surfaceTop  = this.offRoad ? 0.52 : 1;

    // ── 얼음에 미끄러지는 중 ──
    if (this.slip > 0) this.slip -= dt;
    const slipping = this.slip > 0;

    // ── 엔진 ──
    const boosting = this.boost > 0;
    if (boosting) this.boost -= dt;
    const topSpeed = (boosting ? 46 : 33.5) * surfaceTop * (this.isAI ? (0.90 + this.skill * 0.14) : 1)
                   * (this.star > 0 ? 1.12 : 1);            // 별을 쓰면 조금 더 빨라짐
    let accel = boosting ? 30 : 15.5;
    // 속도가 붙을수록 가속이 둔해짐
    accel *= clamp(1 - this.speed / (topSpeed + 8), 0.12, 1);

    if (input.gas) this.speed += accel * dt;
    if (input.brake) {
      if (this.speed > 0.4) this.speed -= 26 * dt;
      else this.speed -= 9 * dt;               // 후진
    }
    if (!input.gas && !input.brake) this.speed -= 6.5 * dt * Math.sign(this.speed);
    // 공기 저항 + 최고 속도 제한
    this.speed -= this.speed * Math.abs(this.speed) * 0.0016 * dt * 60 / 60;
    if (this.speed > topSpeed) this.speed = damp(this.speed, topSpeed, 3.2, dt);
    this.speed = clamp(this.speed, -7, 52);
    if (this.offRoad && this.speed > topSpeed) this.speed = damp(this.speed, topSpeed, 6, dt);

    // ── 조향 ──
    const st = clamp(input.steer, -1, 1);
    this.steer = damp(this.steer, st, 13, dt);
    const sAbs = Math.abs(this.speed);
    // 아주 느릴 때와 아주 빠를 때는 덜 꺾임
    const speedTurn = clamp(sAbs / 7, 0, 1) * clamp(1 - (sAbs - 26) / 46, 0.62, 1);
    // 얼음 위에서는 핸들이 잘 안 먹는다(넘어지지는 않고 쭉 미끄러진다)
    let turn = this.steer * 2.35 * speedTurn * surfaceGrip * (slipping ? 0.55 : 1);

    // ── 드리프트 ──
    const wantDrift = input.drift && sAbs > 11 && !this.offRoad;
    if (wantDrift && !this.drifting && Math.abs(this.steer) > 0.18) {
      this.drifting = true;
      this.driftDir = Math.sign(this.steer);
      this.driftCharge = 0;
    }
    if (this.drifting) {
      if (!input.drift || sAbs < 7) {
        // 손을 떼는 순간 모은 만큼 부스터
        if (this.driftCharge > 0.85) this.boost = Math.max(this.boost, 0.55 + Math.min(this.driftCharge, 2.6) * 0.52);
        this.drifting = false; this.driftCharge = 0;
      } else {
        this.driftCharge += dt;
        // 드리프트 방향으로 더 잘 꺾임
        turn += this.driftDir * 0.95 * clamp(0.35 + Math.abs(this.steer), 0, 1.35) * speedTurn;
      }
    }
    if (this.speed < 0) turn = -turn;                 // 후진 중에는 반대로
    this.h += turn * dt;

    // ── 속도 벡터: 앞 성분은 유지하고 옆 미끄러짐만 서서히 잡음 ──
    const nfx = Math.sin(this.h), nfz = Math.cos(this.h);
    const fwdSpeed = this.vx * nfx + this.vz * nfz;
    let latx = this.vx - nfx * fwdSpeed, latz = this.vz - nfz * fwdSpeed;
    // 회전으로 생기는 옆 미끄러짐을 더해 줌
    const slideAdd = turn * this.speed * (this.drifting ? 0.46 : 0.12);
    latx += nfz * slideAdd; latz += -nfx * slideAdd;
    const grip = (this.drifting ? 2.0 : 9.5) * surfaceGrip * (slipping ? 0.32 : 1);
    const keep = Math.exp(-grip * dt);
    latx *= keep; latz *= keep;
    const latLen = Math.hypot(latx, latz);
    const latMax = 15;
    if (latLen > latMax) { latx *= latMax / latLen; latz *= latMax / latLen; }
    this.vx = nfx * this.speed + latx;
    this.vz = nfz * this.speed + latz;

    // ── 위치 이동 ──
    this.x += this.vx * dt;
    this.z += this.vz * dt;

    // ── 방호벽 ──
    const loc2 = track.locate(this.x, this.z, this.trackI);
    this.trackI = loc2.i; this.lat = loc2.lat;
    const wallAt = track.wallOffset;
    if (Math.abs(loc2.lat) > wallAt) {
      const sign = Math.sign(loc2.lat);
      const p = track.surface(loc2.i, wallAt * sign, [0,0,0]);
      this.x = p[0]; this.z = p[2];
      this.speed *= 0.62;
      const rx = track.rgt[loc2.i*3], rz = track.rgt[loc2.i*3+2];
      const into = this.vx * rx + this.vz * rz;
      this.vx -= rx * into * 1.5; this.vz -= rz * into * 1.5;
      // 벽을 따라 미끄러지도록 방향을 살짝 되돌림
      const along = track.headingAt(loc2.i);
      this.h += wrapAngle(along - this.h) * clamp(dt * 4.5, 0, 0.5);
      if (this.isPlayer && Math.abs(into) > 6) race.shake = Math.min(1, race.shake + 0.35);
    }

    // ── 노면 높이 · 기울기 ──
    const surf = track.surfaceF(loc2.fi, clamp(loc2.lat, -track.wallOffset, track.wallOffset), [0,0,0]);
    let targetY = surf[1];
    if (this.offRoad) {
      // 코스 밖은 살짝 낮음
      targetY -= 0.3;
    }
    this.y = damp(this.y, targetY, 12, dt);
    const bankHere = track.bank[loc2.i];
    const targetRoll = -this.steer * clamp(sAbs / 26, 0, 1) * 0.14
                     + (this.drifting ? this.driftDir * 0.14 : 0) + bankHere * 0.9;
    this.roll = damp(this.roll, targetRoll, 8, dt);
    const slope = Math.asin(clamp(track.fwd[loc2.i*3+1], -1, 1));
    this.pitch = damp(this.pitch, -slope, 6, dt);
    this.wheelSpin += (this.speed / 0.34) * dt;

    // ── 오래 갇혀 있으면 자동으로 길 위로 ──
    if (this.offRoad && sAbs < 2.5) {
      this.stuckT = (this.stuckT || 0) + dt;
      if (this.stuckT > 3.2) { this.stuckT = 0; this.respawn(track); }
    } else this.stuckT = 0;

    // ── 바퀴 수 세기 ──
    const prog = loc2.fi / track.count;
    const dp = prog - this.prog;
    if (dp < -0.6) this.lap++;                    // 결승선 통과
    else if (dp > 0.6) this.lap--;                // 뒤로 넘어감
    this.prog = prog;
    // 역주행 판정
    const along = track.headingAt(loc2.i);
    this.wrongWay = sAbs > 4 && Math.abs(wrapAngle(along - this.h)) > 2.1;

    if (this.lap !== wasLap && this.lap > wasLap && race) {
      const t = race.clock;
      if (this.lap >= 1) {
        const lt = t - this.lastLapStart;
        if (this.lastLapStart > 0 || this.lap === 1) {
          this.lapTimes.push(lt);
          if (this.bestLap == null || lt < this.bestLap) this.bestLap = lt;
        }
      }
      this.lastLapStart = t;
    }
  }

  /** 코스 위 안전한 곳으로 되돌리기 */
  respawn(track) {
    this.respawnT = 0.9;
    this.speed = 0; this.vx = 0; this.vz = 0;
    this.drifting = false; this.driftCharge = 0; this.spin = 0;
  }
  /** 아이템에 맞음 */
  hit(dur) {
    if (this.star > 0) return false;                        // 별을 쓰는 동안은 무적
    if (this.shield > 0) { this.shield = 0; return false; }
    if (this.spin > 0) return false;
    this.spin = dur || 1.3;
    this.boost = 0;
    this.speed *= 0.4;
    this.drifting = false; this.driftCharge = 0;
    return true;
  }
  /** 전체 진행도 (순위 계산용) */
  get total() { return this.lap + this.prog; }
}

/* ═════════ 컴퓨터 운전수 ═════════ */
/** AI가 다음에 갈 지점을 보고 조작값을 만들어 냄 */
function aiControl(k, track, race, dt) {
  const count = track.count;
  const i = k.trackI;
  const sAbs = Math.abs(k.speed);
  // 속도가 빠를수록 더 멀리 봄
  const look = Math.round(4 + sAbs * 0.55);
  const j = (i + look) % count;

  // 레이싱 라인: 코너 안쪽을 파고듦
  let curveAhead = 0;
  for (let s = 2; s < look + 10; s++) {
    const w = 1 - s / (look + 12);
    curveAhead += track.curv[(i + s) % count] * w;
  }
  curveAhead /= (look + 8) * 0.5;
  const lineLat = clamp(-curveAhead * 260, -1, 1) * track.halfWidth * 0.48
                + k.aiLine * track.halfWidth * 0.35;

  const target = track.surface(j, lineLat, [0,0,0]);
  const want = Math.atan2(target[0] - k.x, target[2] - k.z);
  const diff = wrapAngle(want - k.h);
  let steer = clamp(diff * 3.1, -1, 1);

  // 앞차와 부딪히지 않게 살짝 비켜감
  for (const o of race.karts) {
    if (o === k || o.finished) continue;
    const dx = o.x - k.x, dz = o.z - k.z;
    const d = Math.hypot(dx, dz);
    if (d > 7 || d < 0.1) continue;
    const ahead = (dx * Math.sin(k.h) + dz * Math.cos(k.h)) / d;
    if (ahead < 0.55) continue;
    const side = (dx * Math.cos(k.h) - dz * Math.sin(k.h));
    steer += (side > 0 ? -1 : 1) * (7 - d) / 7 * 0.5;
  }
  // 길 가장자리에 너무 붙으면 안쪽으로 되돌림
  const edgeT = (Math.abs(k.lat) - track.halfWidth * 0.78) / (track.halfWidth * 0.5);
  if (edgeT > 0) steer -= Math.sign(k.lat) * clamp(edgeT, 0, 1) * 0.85;
  steer = clamp(steer, -1, 1);

  // 코너가 급하면 미리 속도를 줄임
  const curveMag = Math.abs(curveAhead);
  const safeSpeed = clamp(41 - curveMag * 820, 15, 43) * (0.84 + k.skill * 0.22);
  let gas = 1, brake = 0;
  if (sAbs > safeSpeed * 1.04) { gas = 0; brake = sAbs > safeSpeed * 1.22 ? 1 : 0; }
  // 코스를 벗어났으면 속도를 줄이고 길 안쪽으로 되돌아옴
  if (k.offRoad) {
    gas = 1; brake = 0;
    const back = track.surface(i + 6, 0, [0,0,0]);
    steer = clamp(wrapAngle(Math.atan2(back[0] - k.x, back[2] - k.z) - k.h) * 3.0, -1, 1);
  }
  if (k.wrongWay) { gas = 1; brake = 0; }

  const drift = k.skill > 0.55 && Math.abs(steer) > 0.52 && sAbs > 17 && curveMag > 0.0035;

  // 아이템 사용
  let useItem = false;
  if (k.item) {
    k.aiSeed += dt;
    if (k.item === 'boost') useItem = sAbs > 12 && curveMag < 0.004;
    else if (k.item === 'shield') useItem = k.rank > 1;
    else if (k.item === 'star') useItem = true;                       // 받으면 바로 쓴다
    else if (k.item === 'banana') useItem = Math.sin(k.aiSeed * 1.7) > 0.9;
    else if (k.item === 'ice') useItem = Math.sin(k.aiSeed * 1.9) > 0.9;
    else if (k.item === 'thunder') useItem = k.rank > 1 && Math.sin(k.aiSeed * 1.3) > 0.5;
    else if (k.item === 'missile') {
      // 앞에 누군가 있으면 발사
      useItem = k.rank > 1 && Math.sin(k.aiSeed * 2.3) > 0.55;
    }
  }
  return { gas, brake, steer, drift, useItem };
}
/* ══════════════════════════════════════════════════════════════════
   6. 경기 진행 · 카메라 · 화면 그리기 · HUD
   ══════════════════════════════════════════════════════════════════ */

/* crowd = 관중 좌석 사이 거리(m). 0이면 관중을 그리지 않음 */
const QUALITY = {
  high:   { name:'높음', dpr:2,    terrain:8,  crowd:1.25, trees:1.0, fog:1.0 },
  mid:    { name:'보통', dpr:1.5,  terrain:11, crowd:2.2,  trees:0.7, fog:0.85 },
  low:    { name:'낮음', dpr:1,    terrain:15, crowd:0,    trees:0.4, fog:0.7 },
};

/** 한 명의 시점(분할 화면이면 두 개) */
class ViewCam {
  constructor(kart) {
    this.kart = kart;
    this.pos = [0, 5, -10];
    this.look = [0, 0, 0];
    this.fov = 1.08;
    this.mode = 0;          // 0=뒤쪽, 1=멀리, 2=1인칭
    this.ready = false;
  }
  update(dt, race, snap) {
    const k = this.kart;
    const fx = Math.sin(k.h), fz = Math.cos(k.h);
    let back, up, ahead, fovT;
    if (this.mode === 2) { back = -0.35; up = 1.15; ahead = 16; fovT = 1.12; }
    else if (this.mode === 1) { back = 11.5; up = 5.0; ahead = 9; fovT = 1.02; }
    else { back = 7.4; up = 3.15; ahead = 8; fovT = 1.05; }

    // 속도가 빠를수록 시야각을 넓혀 속도감을 줌
    const sp = clamp(Math.abs(k.speed) / 42, 0, 1.2);
    fovT += sp * 0.20 + (k.boost > 0 ? 0.07 : 0);

    const tx = k.x - fx * back, tz = k.z - fz * back;
    const ty = k.y + up;
    if (!this.ready || snap) {
      this.pos[0] = tx; this.pos[1] = ty; this.pos[2] = tz;
      this.ready = true;
    } else {
      const rate = this.mode === 2 ? 40 : 7.5;
      this.pos[0] = damp(this.pos[0], tx, rate, dt);
      this.pos[1] = damp(this.pos[1], ty, rate * 0.9, dt);
      this.pos[2] = damp(this.pos[2], tz, rate, dt);
    }
    this.look[0] = k.x + fx * ahead;
    this.look[1] = k.y + 1.1;
    this.look[2] = k.z + fz * ahead;
    this.fov = damp(this.fov, fovT, 4, dt);

    // 흔들림 (벽 충돌 · 아이템 피격 · 코스 밖)
    const sh = race.shake + (k.offRoad ? 0.13 : 0) + (k.spin > 0 ? 0.3 : 0);
    if (sh > 0.001) {
      const t = race.time * 47;
      this.pos[0] += Math.sin(t) * sh * 0.42;
      this.pos[1] += Math.sin(t * 1.7) * sh * 0.30;
      this.pos[2] += Math.cos(t * 1.3) * sh * 0.42;
    }
  }
}

/** 경기 한 판 */
class Race {
  constructor(cfg) {
    this.cfg = cfg;                      // {mode, track, laps, items, ai, quality}
    this.track = cfg.track;
    this.laps = cfg.laps;
    this.karts = [];
    this.state = 'ready';                // ready → racing → over
    this.count = 3.6;                    // 카운트다운 남은 시간
    this.clock = 0;                      // 출발 후 경과(ms)
    this.time = 0;                       // 전체 경과(초)
    this.shake = 0;
    this.bananas = [];
    this.missiles = [];
    this.effects = [];
    this.itemTimers = new Map();
    this.overAt = null;
    this.ghost = null;
    this.ghostRec = cfg.recordGhost ? [] : null;
    this.ghostT = 0;
  }

  add(k) { this.karts.push(k); return k; }

  start() {
    const grid = this.track.startGrid;
    this.karts.forEach((k, idx) => k.placeAt(grid[idx % grid.length]));
    this.updateRanks();
  }

  /** 진행도에 따라 순위 매기기
      경기가 끝나면 finish()가 못 들어온 카트도 finished 로 표시하면서 finishTime 을 null 로 둔다.
      그래서 '완주했는지'는 finished 가 아니라 finishTime 이 있는지로 따져야 한다.
      (예전에는 null - 62000 = -62000 이 되어 미완주 카트가 1등으로 올라갔다) */
  updateRanks() {
    const arr = this.karts.slice();
    const done = (k) => (k.finished && k.finishTime != null) ? k.finishTime : null;
    arr.sort((a, b) => {
      const at = done(a), bt = done(b);
      if (at != null && bt != null) return at - bt;   // 둘 다 완주 → 빨리 들어온 쪽이 앞
      if (at != null) return -1;                      // 완주한 쪽이 언제나 앞
      if (bt != null) return 1;
      return b.total - a.total;                       // 둘 다 미완주 → 많이 간 쪽이 앞
    });
    arr.forEach((k, i) => k.rank = i + 1);
    this.order = arr;
  }

  update(dt, inputs) {
    this.time += dt;
    this.shake = Math.max(0, this.shake - dt * 2.2);

    if (this.state === 'ready') {
      this.count -= dt;
      if (this.count <= 0) { this.state = 'racing'; this.clock = 0; }
    } else if (this.state === 'racing') {
      this.clock += dt * 1000;
    }

    const racing = this.state !== 'ready';
    for (const k of this.karts) {
      if (k.isRemote) { this.stepRemote(k, dt); continue; }
      let inp;
      if (k.finished) {
        inp = k.isAI || k.isPlayer ? aiControl(k, this.track, this, dt) : { gas:0, brake:0, steer:0, drift:false };
        inp.useItem = false;
      } else if (!racing) {
        inp = { gas: 0, brake: 0, steer: 0, drift: false, useItem: false };
      } else if (k.isAI) {
        inp = aiControl(k, this.track, this, dt);
      } else {
        inp = inputs.get(k.id) || { gas:0, brake:0, steer:0, drift:false, useItem:false };
      }
      k.update(dt, inp, this.track, this);
      if (k.shield > 0) k.shield -= dt;
      if (k.star > 0) k.star -= dt;
      if (k.itemRolling > 0) {
        k.itemRolling -= dt;
        if (k.itemRolling <= 0) {
          k.item = rollItem(k.rank, this.karts.length);
          if (k.isPlayer) sfx('item');
        }
      }
      // 사람이 모는 카트는 '새로 누른 순간'에만 아이템을 쓴다.
      // 누르고 있는 동안에도 썼더니, 상자를 먹자마자 아이템이 그대로 사라져 버렸다.
      // (컴퓨터 운전수는 스스로 때를 고르므로 그대로 둔다)
      const pressed = !!inp.useItem;
      if (racing && k.item && (k.isAI ? pressed : (pressed && !k.itemHeld))) this.useItem(k);
      k.itemHeld = pressed;
    }

    if (racing) {
      this.collide(dt);
      this.checkItems(dt);
      this.stepProps(dt);
      this.recordGhost(dt);
    }
    this.updateRanks();

    // 완주 판정
    for (const k of this.karts) {
      if (!k.finished && k.lap >= this.laps) {
        k.finished = true;
        k.finishTime = this.clock;
        k.finishRank = this.karts.filter(o => o.finished).length;
        if (k.isPlayer) sfx('finish');
      }
    }
    // 경기 종료 조건
    if (this.state === 'racing') {
      const humans = this.karts.filter(k => k.isPlayer);
      const allHuman = humans.length > 0 && humans.every(k => k.finished);
      const all = this.karts.every(k => k.finished);
      if (all) this.finish();
      else if (allHuman) {
        if (this.overAt == null) this.overAt = this.time + 4.0;
        else if (this.time > this.overAt) this.finish();
      }
    }
  }

  finish() {
    if (this.state === 'over') return;
    this.state = 'over';
    // 아직 못 들어온 카트는 진행도 순으로 뒤에 붙임
    this.updateRanks();
    for (const k of this.order) {
      if (!k.finished) { k.finished = true; k.finishTime = null; }
    }
    if (this.onFinish) this.onFinish();
  }

  /* ── 카트끼리 부딪히기 ── */
  collide() {
    const ks = this.karts, R = 1.30;
    for (let a = 0; a < ks.length; a++) {
      for (let b = a + 1; b < ks.length; b++) {
        const A = ks[a], B = ks[b];
        if (A.respawnT > 0 || B.respawnT > 0) continue;
        let dx = B.x - A.x, dz = B.z - A.z;
        let d = Math.hypot(dx, dz);
        if (d > R * 2 || d < 0.0001) continue;
        const push = (R * 2 - d) * 0.5;
        dx /= d; dz /= d;
        if (!A.isRemote) { A.x -= dx * push; A.z -= dz * push; }
        if (!B.isRemote) { B.x += dx * push; B.z += dz * push; }
        // 빠른 쪽이 느린 쪽을 밀어냄
        const rel = (B.vx - A.vx) * dx + (B.vz - A.vz) * dz;
        if (rel < 0) {
          const j = rel * 0.42;
          if (!A.isRemote) { A.vx += dx * j; A.vz += dz * j; A.speed *= 0.985; }
          if (!B.isRemote) { B.vx -= dx * j; B.vz -= dz * j; B.speed *= 0.985; }
          if ((A.isPlayer || B.isPlayer) && Math.abs(rel) > 7) {
            this.shake = Math.min(1, this.shake + 0.22);
            sfx('bump');
          }
        }
      }
    }
  }

  /* ── 아이템 상자 먹기 ── */
  checkItems(dt) {
    if (!this.cfg.items) return;
    for (const s of this.track.itemSpots) {
      if (s.taken > 0) { s.taken -= dt; continue; }
      for (const k of this.karts) {
        if (k.isRemote || k.item || k.itemRolling > 0 || k.finished) continue;
        const d = Math.hypot(k.x - s.x, k.z - s.z);
        if (d < 2.2) {
          s.taken = 4.0;
          k.itemRolling = 0.7;
          this.effects.push({ kind:'pop', x:s.x, y:s.y, z:s.z, t:0, life:0.45 });
          break;
        }
      }
    }
  }

  /** 아이템 쓰기 */
  useItem(k, forced) {
    const it = forced || k.item;
    if (!it) return;
    k.item = null;
    if (it === 'boost') {
      k.boost = Math.max(k.boost, 2.3);
      if (k.isPlayer) sfx('boost');
    } else if (it === 'shield') {
      k.shield = 6.5;
      if (k.isPlayer) sfx('shield');
    } else if (it === 'star') {
      k.star = 6;
      k.spin = 0;                                   // 맞아 돌던 중이었다면 바로 풀림
      if (k.isPlayer) sfx('star');
    } else if (it === 'banana' || it === 'ice') {
      // 얼음도 바나나와 같은 목록에 넣고 kind 로만 구분한다(움직임·수명이 같다)
      const fx = Math.sin(k.h), fz = Math.cos(k.h);
      this.bananas.push({ kind: it, x: k.x - fx * 3.2, y: k.y + 0.3, z: k.z - fz * 3.2,
                          t: 0, owner: k.id });
      if (this.bananas.length > 24) this.bananas.shift();
      if (k.isPlayer) sfx(it === 'ice' ? 'ice' : 'drop');
    } else if (it === 'thunder') {
      // 나보다 앞선 카트를 모두 잠깐 휘청이게 함 (통신 카트는 각자의 기기에서 처리)
      for (const o of this.karts) {
        if (o === k || o.finished || o.isRemote) continue;
        if (o.total <= k.total) continue;
        if (o.hit(0.9)) {
          this.effects.push({ kind:'burst', x:o.x, y:o.y + 0.9, z:o.z, t:0, life:0.55, col:[0.7,0.86,1] });
          if (o.isPlayer) { this.shake = 1; flashHit(); }
        }
      }
      this.effects.push({ kind:'burst', x:k.x, y:k.y + 1.4, z:k.z, t:0, life:0.6, col:[0.8,0.92,1] });
      if (k.isPlayer) sfx('thunder');
    } else if (it === 'missile') {
      // 바로 앞 순위의 카트를 겨냥
      let target = null, bestGap = Infinity;
      for (const o of this.karts) {
        if (o === k || o.finished) continue;
        const gap = o.total - k.total;
        if (gap > 0 && gap < bestGap) { bestGap = gap; target = o; }
      }
      const fx = Math.sin(k.h), fz = Math.cos(k.h);
      this.missiles.push({
        x: k.x + fx * 2.6, y: k.y + 0.7, z: k.z + fz * 2.6,
        h: k.h, sp: 30, t: 0, owner: k.id, target,
        i: k.trackI, lat: k.lat,
      });
      if (k.isPlayer) sfx('shoot');
    }
    if (k.isPlayer && net.active) net.sendItem(it, k);
  }

  /* ── 바나나 · 얼음 · 미사일 움직이기 ── */
  stepProps(dt) {
    const T = this.track;
    // 길에 놓인 것들 (바나나 = 뒤집힘, 얼음 = 한동안 미끄러짐)
    for (let n = this.bananas.length - 1; n >= 0; n--) {
      const b = this.bananas[n];
      b.t += dt;
      if (b.t > 40) { this.bananas.splice(n, 1); continue; }
      const isIce = b.kind === 'ice';
      for (const k of this.karts) {
        if (k.isRemote || k.finished || k.respawnT > 0) continue;
        if (!isIce && k.spin > 0) continue;
        if (b.t < 0.5 && k.id === b.owner) continue;
        if (Math.hypot(k.x - b.x, k.z - b.z) < (isIce ? 2.1 : 1.7)) {
          if (isIce) {
            // 얼음은 뒤집지 않는다 — 대신 잠깐 핸들이 말을 안 듣는다. 별을 쓰는 중이면 안 미끄러짐
            if (k.star <= 0) {
              k.slip = Math.max(k.slip, 2.6);
              k.speed *= 0.86;
              this.effects.push({ kind:'burst', x:k.x, y:k.y+0.35, z:k.z, t:0, life:0.5, col:[0.65,0.9,1] });
              if (k.isPlayer) { this.shake = Math.min(1, this.shake + 0.4); sfx('ice'); }
            }
          } else if (k.hit(1.25)) {
            this.effects.push({ kind:'burst', x:k.x, y:k.y+0.6, z:k.z, t:0, life:0.5, col:[1,0.85,0.3] });
            if (k.isPlayer) { this.shake = 1; sfx('hit'); flashHit(); }
          }
          this.bananas.splice(n, 1);
          break;
        }
      }
    }
    // 미사일 — 코스를 따라 날아가 목표를 쫓음
    for (let n = this.missiles.length - 1; n >= 0; n--) {
      const m = this.missiles[n];
      m.t += dt;
      if (m.t > 7) { this.missiles.splice(n, 1); continue; }
      let wantH;
      if (m.target && !m.target.finished) {
        const dx = m.target.x - m.x, dz = m.target.z - m.z;
        if (Math.hypot(dx, dz) < 44) wantH = Math.atan2(dx, dz);
      }
      if (wantH == null) {
        // 목표가 멀면 코스 앞쪽을 따라감
        const loc = T.locate(m.x, m.z, m.i);
        m.i = loc.i;
        const aim = T.surface(loc.i + 7, clamp(loc.lat, -T.halfWidth, T.halfWidth) * 0.7, [0,0,0]);
        wantH = Math.atan2(aim[0] - m.x, aim[2] - m.z);
      }
      m.h += wrapAngle(wantH - m.h) * clamp(dt * 5.5, 0, 1);
      m.sp = Math.min(46, m.sp + 16 * dt);
      m.x += Math.sin(m.h) * m.sp * dt;
      m.z += Math.cos(m.h) * m.sp * dt;
      const loc2 = T.locate(m.x, m.z, m.i);
      m.i = loc2.i;
      const su = T.surfaceF(loc2.fi, clamp(loc2.lat, -T.wallOffset, T.wallOffset), [0,0,0]);
      m.y = damp(m.y, su[1] + 0.75, 8, dt);
      let gone = false;
      for (const k of this.karts) {
        if (k.finished || k.respawnT > 0) continue;
        if (m.t < 0.35 && k.id === m.owner) continue;
        if (Math.hypot(k.x - m.x, k.z - m.z) < 2.1) {
          if (!k.isRemote) k.hit(1.5);
          this.effects.push({ kind:'burst', x:k.x, y:k.y+0.7, z:k.z, t:0, life:0.55, col:[1,0.5,0.25] });
          if (k.isPlayer) { this.shake = 1; sfx('hit'); flashHit(); }
          gone = true; break;
        }
      }
      if (gone) this.missiles.splice(n, 1);
    }
    // 효과
    for (let n = this.effects.length - 1; n >= 0; n--) {
      const e = this.effects[n];
      e.t += dt;
      if (e.t > e.life) this.effects.splice(n, 1);
    }
  }

  /* ── 통신으로 받은 카트를 부드럽게 따라가게 함 ── */
  stepRemote(k, dt) {
    k.x = damp(k.x, k.tx, 11, dt);
    k.z = damp(k.z, k.tz, 11, dt);
    k.y = damp(k.y, k.ty, 11, dt);
    k.h = k.h + wrapAngle(k.th - k.h) * clamp(dt * 11, 0, 1);
    k.wheelSpin += (k.speed / 0.34) * dt;
    k.roll = damp(k.roll, k.troll || 0, 8, dt);
    if (k.spin > 0) k.spin -= dt;
    if (k.shield > 0) k.shield -= dt;
    if (k.boost > 0) k.boost -= dt;
    if (k.star > 0) k.star -= dt;
    if (k.slip > 0) k.slip -= dt;
    const loc = this.track.locate(k.x, k.z, k.trackI);
    k.trackI = loc.i; k.lat = loc.lat;
  }

  /* ── 기록 도전용 유령 카트 ── */
  recordGhost(dt) {
    if (!this.ghostRec) return;
    this.ghostT += dt;
    if (this.ghostT >= 0.1) {
      // 0 으로 되돌리지 않고 0.1 만 덜어 낸다. 되돌리면 한 프레임이 긴 기기(30fps)에서
      // 남는 시간이 매번 버려져, 유령 카트가 실제 기록보다 빠르게 달리는 것처럼 보였다.
      this.ghostT -= 0.1;
      const p = this.karts.find(k => k.isPlayer);
      if (p) this.ghostRec.push([Math.round(p.x*10)/10, Math.round(p.y*10)/10,
                                Math.round(p.z*10)/10, Math.round(p.h*100)/100]);
    }
  }
}

/* ═════════ 화면 그리기 ═════════ */
const TMP_M = M4.create();
const TMP_M2 = M4.create();
const TINT = new Float32Array([1,1,1,1]);

function drawScene(R, race, cam, aspect, showSelf) {
  const T = race.track, env = T.env, Q = race.cfg.quality;
  const far = 2600;
  R.setCamera(cam.fov, aspect, 0.55, far, cam.pos, cam.look, [0,1,0]);

  // 해 위치를 화면 좌표로 (하늘의 빛무리)
  const sunDir = env.lightDir;
  const sp = R.project(cam.pos[0] + sunDir[0]*900, cam.pos[1] + sunDir[1]*900, cam.pos[2] + sunDir[2]*900);
  const sunScr = sp ? [sp[0]*2-1, (1-sp[1])*2-1] : [0, 2.2];
  R.drawSky(env, sunScr);

  const fogFar = env.fogFar * Q.fog;
  R.setEnv({
    lightDir: env.lightDir, sun: env.sun, ambSky: env.ambSky, ambGround: env.ambGround,
    fogCol: env.fogCol, fogNear: env.fogNear * Q.fog, fogFar,
  });

  R.blend(false, true);
  R.draw(T.terrainMesh, null, TINT);
  R.draw(T.roadMesh, null, TINT);
  R.draw(T.wallMesh, null, TINT);
  if (T.standMesh) R.draw(T.standMesh, null, TINT);
  R.draw(T.sceneMesh, null, TINT);

  // ── 카트 ──
  const wheel = getWheelMesh(R.gl);
  for (const k of race.karts) {
    if (k === cam.kart && !showSelf) continue;
    const dx = k.x - cam.pos[0], dz = k.z - cam.pos[2];
    if (dx*dx + dz*dz > 640*640) continue;
    drawKart(R, k, wheel, false);
  }
  if (race.ghost && race.ghost.on) drawKart(R, race.ghost.kart, wheel, true);

  // ── 아이템 상자 · 바나나 · 미사일 ──
  if (race.cfg.items) {
    const boxM = getPropMesh(R.gl, 'itembox');
    const spin = race.time * 1.6;
    for (const s of T.itemSpots) {
      if (s.taken > 0) continue;
      const dx = s.x - cam.pos[0], dz = s.z - cam.pos[2];
      if (dx*dx + dz*dz > 340*340) continue;
      const bob = Math.sin(race.time * 2.2 + s.i) * 0.22;
      M4.compose(TMP_M, s.x, s.y + bob, s.z, spin + s.i, 0, 0.4, 1, 1, 1);
      R.draw(boxM, TMP_M, TINT);
    }
    const banM = getPropMesh(R.gl, 'banana');
    const iceM = getPropMesh(R.gl, 'ice');
    for (const b of race.bananas) {
      const isIce = b.kind === 'ice';
      // 얼음은 굴러가지 않으므로 천천히만 돌린다
      M4.compose(TMP_M, b.x, b.y, b.z, b.t * (isIce ? 0.25 : 0.7), 0, 0, 1, 1, 1);
      R.draw(isIce ? iceM : banM, TMP_M, TINT);
    }
    const misM = getPropMesh(R.gl, 'missile');
    for (const m of race.missiles) {
      M4.compose(TMP_M, m.x, m.y, m.z, m.h, race.time * 9, 0, 1, 1, 1);
      R.draw(misM, TMP_M, TINT);
    }
  }

  /* ── 반투명한 것들 ── */
  const disc = getDiscMesh(R.gl);
  R.blend(true, false);
  // 그림자
  TINT[0] = 0; TINT[1] = 0; TINT[2] = 0.03; TINT[3] = 0.30;
  for (const k of race.karts) {
    const dx = k.x - cam.pos[0], dz = k.z - cam.pos[2];
    if (dx*dx + dz*dz > 340*340) continue;
    M4.compose(TMP_M, k.x, k.y + 0.045, k.z, k.h, 0, 0, 1.55, 1, 1.95);
    R.draw(disc, TMP_M, TINT);
  }
  TINT[0] = TINT[1] = TINT[2] = TINT[3] = 1;

  // 방패 거품 · 별 거품(같은 거품 모양을 색만 바꿔 쓴다)
  const shieldM = getPropMesh(R.gl, 'shield');
  for (const k of race.karts) {
    const starOn = k.star > 0;
    if (!starOn && k.shield <= 0) continue;
    const a = 0.24 + Math.sin(race.time * (starOn ? 14 : 8)) * 0.08;
    if (starOn) { TINT[0] = 1; TINT[1] = 0.86; TINT[2] = 0.35; }
    else        { TINT[0] = 0.55; TINT[1] = 0.85; TINT[2] = 1; }
    TINT[3] = a;
    M4.compose(TMP_M, k.x, k.y + 0.6, k.z, race.time * (starOn ? 5 : 2), 0, 0, 1, 1, 1);
    R.draw(shieldM, TMP_M, TINT);
  }
  TINT[0] = TINT[1] = TINT[2] = TINT[3] = 1;

  // 부스터 불꽃 · 드리프트 불꽃 (더하기 합성)
  R.additive();
  for (const k of race.karts) {
    const fx = Math.sin(k.h), fz = Math.cos(k.h);
    const rx = fz, rz = -fx;
    if (k.boost > 0) {
      for (let s = -1; s <= 1; s += 2) {
        const px = k.x - fx*1.35 + rx*0.24*s, pz = k.z - fz*1.35 + rz*0.24*s;
        const f = 0.55 + Math.random() * 0.6;
        TINT[0] = 1; TINT[1] = 0.72; TINT[2] = 0.3; TINT[3] = 0.75;
        M4.compose(TMP_M, px, k.y + 0.42, pz, k.h, 0, 0, 0.42*f, 1, 0.42*f);
        R.draw(disc, TMP_M, TINT);
      }
    }
    if (k.drifting && k.driftCharge > 0.35) {
      const lvl = clamp(k.driftCharge / 2.2, 0, 1);
      const col = lvl < 0.4 ? [0.4,0.7,1] : lvl < 0.78 ? [1,0.8,0.3] : [1,0.4,0.5];
      for (let s = -1; s <= 1; s += 2) {
        const px = k.x - fx*1.0 + rx*0.62*s, pz = k.z - fz*1.0 + rz*0.62*s;
        const f = (0.4 + Math.random()*0.5) * (0.5 + lvl);
        TINT[0] = col[0]; TINT[1] = col[1]; TINT[2] = col[2]; TINT[3] = 0.6;
        M4.compose(TMP_M, px, k.y + 0.14, pz, 0, 0, 0, f, 1, f);
        R.draw(disc, TMP_M, TINT);
      }
    }
  }
  // 터짐 효과
  for (const e of race.effects) {
    const t = e.t / e.life;
    const s = (e.kind === 'pop' ? 1.2 : 3.2) * (0.4 + t * 1.4);
    const c = e.col || [1, 0.9, 0.4];
    TINT[0] = c[0]; TINT[1] = c[1]; TINT[2] = c[2]; TINT[3] = (1 - t) * 0.8;
    M4.compose(TMP_M, e.x, e.y, e.z, 0, 0, 0, s, 1, s);
    R.draw(disc, TMP_M, TINT);
  }
  TINT[0] = TINT[1] = TINT[2] = TINT[3] = 1;
  R.blend(false, true);
}

/** 카트 한 대 (몸통 + 바퀴 4개) */
function drawKart(R, k, wheelMesh, ghost) {
  const body = getKartMesh(R.gl, k.colorId);
  if (ghost) { TINT[0] = 0.7; TINT[1] = 0.85; TINT[2] = 1; TINT[3] = 0.42; R.blend(true, false); }
  const squash = k.spin > 0 ? 1 + Math.sin(k.spin * 22) * 0.06 : 1;
  M4.compose(TMP_M, k.x, k.y, k.z, k.h, k.roll, k.pitch, 1, squash, 1);
  R.draw(body, TMP_M, TINT);
  // 바퀴: 앞 두 개는 조향각을 반영
  const st = k.steer * 0.5;
  const W = [[-0.72, 0.34, 0.86, st], [0.72, 0.34, 0.86, st],
             [-0.76, 0.36, -0.82, 0], [0.76, 0.36, -0.82, 0]];
  for (const w of W) {
    M4.compose(TMP_M2, w[0], w[1], w[2], w[3], 0, k.wheelSpin, 1, 1, 1);
    M4.mul(TMP_M2, TMP_M, TMP_M2);
    R.draw(wheelMesh, TMP_M2, TINT);
  }
  if (ghost) { TINT[0] = TINT[1] = TINT[2] = TINT[3] = 1; R.blend(false, true); }
}
/* ══════════════════════════════════════════════════════════════════
   7. 조작 입력 · HUD · 미니맵 · 소리
   ══════════════════════════════════════════════════════════════════ */

/* ─────────── 키보드 ─────────── */
const keys = Object.create(null);
window.addEventListener('keydown', (e) => {
  keys[e.code] = true;
  if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)) e.preventDefault();
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });
window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });

const KEYSETS = {
  solo: {
    gas:['ArrowUp','KeyW'], brake:['ArrowDown','KeyS'],
    left:['ArrowLeft','KeyA'], right:['ArrowRight','KeyD'],
    drift:['Space'], item:['ShiftLeft','ShiftRight','KeyE'],
  },
  p1: {
    gas:['KeyW'], brake:['KeyS'], left:['KeyA'], right:['KeyD'],
    drift:['ShiftLeft'], item:['KeyQ'],
  },
  p2: {
    gas:['ArrowUp'], brake:['ArrowDown'], left:['ArrowLeft'], right:['ArrowRight'],
    drift:['Enter'], item:['Slash','ShiftRight'],
  },
};
const anyKey = (list) => list.some(c => keys[c]);

/* ─────────── 터치 ─────────── */
const touch = { left:false, right:false, gas:false, brake:false, drift:false, item:false };
function bindTouch() {
  const map = [['#tLeft','left'], ['#tRight','right'], ['#tGas','gas'], ['#tBrake','brake'],
               ['#tDrift','drift'], ['#tItem','item']];
  for (const [sel, key] of map) {
    const el = $(sel);
    if (!el) continue;
    const on = (e) => { e.preventDefault(); touch[key] = true; el.classList.add('on'); };
    const off = (e) => { e.preventDefault(); touch[key] = false; el.classList.remove('on'); };
    el.addEventListener('touchstart', on, { passive:false });
    el.addEventListener('touchend', off, { passive:false });
    el.addEventListener('touchcancel', off, { passive:false });
    el.addEventListener('mousedown', on);
    el.addEventListener('mouseup', off);
    el.addEventListener('mouseleave', off);
  }
}

/** 키보드 + 터치를 합쳐 조작값 하나로 */
function readInput(set, useTouch) {
  const K = KEYSETS[set];
  let steer = 0;
  // 방향 각도(h)가 커지는 쪽이 화면에서는 '왼쪽'이라, 화살표를 뒤집어 맞춘다.
  // (이렇게 해야 → 를 누를 때 화면에서도 오른쪽으로 돈다)
  if (anyKey(K.left)  || (useTouch && touch.left))  steer += 1;
  if (anyKey(K.right) || (useTouch && touch.right)) steer -= 1;
  return {
    gas:   anyKey(K.gas)   || (useTouch && touch.gas),
    brake: anyKey(K.brake) || (useTouch && touch.brake),
    steer,
    drift: anyKey(K.drift) || (useTouch && touch.drift),
    useItem: anyKey(K.item) || (useTouch && touch.item),
  };
}

/* ─────────── 소리 (파일 없이 직접 만들어 냄) ─────────── */
const audio = { ctx:null, on:true, engine:null, gain:null, master:null };
function audioInit() {
  if (audio.ctx || !audio.on) return;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) { audio.on = false; return; }
  try {
    audio.ctx = new AC();
    audio.master = audio.ctx.createGain();
    audio.master.gain.value = 0.32;
    audio.master.connect(audio.ctx.destination);
    // 엔진 소리: 톱니파 두 개를 겹쳐 속도에 따라 음을 올림
    const o1 = audio.ctx.createOscillator(); o1.type = 'sawtooth';
    const o2 = audio.ctx.createOscillator(); o2.type = 'square';
    const g = audio.ctx.createGain(); g.gain.value = 0;
    const f = audio.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900;
    o1.connect(g); o2.connect(g); g.connect(f); f.connect(audio.master);
    o1.start(); o2.start();
    audio.engine = { o1, o2, gain: g, filt: f };
  } catch (e) { audio.on = false; }
}
function audioEngine(kmh, boosting) {
  if (!audio.ctx || !audio.engine) return;
  const e = audio.engine;
  const t = audio.ctx.currentTime;
  const base = 46 + kmh * 1.55 + (boosting ? 60 : 0);
  e.o1.frequency.setTargetAtTime(base, t, 0.06);
  e.o2.frequency.setTargetAtTime(base * 0.5, t, 0.06);
  e.filt.frequency.setTargetAtTime(500 + kmh * 12, t, 0.1);
  e.gain.gain.setTargetAtTime(0.055 + Math.min(kmh, 150) / 150 * 0.05, t, 0.15);
}
function audioEngineOff() {
  if (audio.engine) audio.engine.gain.gain.setTargetAtTime(0, audio.ctx.currentTime, 0.1);
}
const SFX = {
  item:  { f:660, to:990, d:0.16, type:'square', v:0.16 },
  boost: { f:180, to:840, d:0.35, type:'sawtooth', v:0.20 },
  shield:{ f:440, to:880, d:0.30, type:'sine',   v:0.18 },
  drop:  { f:300, to:180, d:0.14, type:'triangle', v:0.14 },
  shoot: { f:820, to:260, d:0.28, type:'sawtooth', v:0.18 },
  hit:   { f:220, to:60,  d:0.40, type:'square', v:0.22 },
  bump:  { f:130, to:80,  d:0.10, type:'square', v:0.12 },
  count: { f:520, to:520, d:0.14, type:'sine',   v:0.22 },
  go:    { f:880, to:880, d:0.40, type:'sine',   v:0.26 },
  finish:{ f:520, to:1320,d:0.55, type:'sine',   v:0.24 },
  ice:   { f:1400, to:420, d:0.26, type:'sine',   v:0.16 },
  thunder:{f:1200, to:110, d:0.50, type:'sawtooth', v:0.24 },
  star:  { f:520, to:1568,d:0.45, type:'triangle', v:0.22 },
};
function sfx(name) {
  if (!audio.on || !audio.ctx) return;
  const s = SFX[name]; if (!s) return;
  const t = audio.ctx.currentTime;
  const o = audio.ctx.createOscillator(); o.type = s.type;
  const g = audio.ctx.createGain();
  o.frequency.setValueAtTime(s.f, t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, s.to), t + s.d);
  g.gain.setValueAtTime(s.v, t);
  g.gain.exponentialRampToValueAtTime(0.0008, t + s.d);
  o.connect(g); g.connect(audio.master);
  o.start(t); o.stop(t + s.d + 0.02);
}

/* ─────────── 화면 효과 ─────────── */
let hitFxT = 0;
function flashHit() { hitFxT = 0.5; $('#hitfx').classList.add('on'); }

/* ─────────── HUD 갱신 ─────────── */
const hudEls = {};
function hudInit() {
  hudEls.lap = $('#lapv'); hudEls.time = $('#timev'); hudEls.split = $('#splitv');
  hudEls.posn = $('#posn'); hudEls.posof = $('#posof'); hudEls.posbox = $('#posbox');
  hudEls.spdv = $('#spdv'); hudEls.arc = $('#spdarc');
  hudEls.boost = $('#boostfill'); hudEls.boostbar = $('#boostbar');
  hudEls.item = $('#itembox'); hudEls.itemhint = $('#itemhint');
  hudEls.board = $('#board'); hudEls.count = $('#count'); hudEls.toast = $('#toast');
  hudEls.warn = $('#warn'); hudEls.speedfx = $('#speedfx');
  hudEls.arcLen = hudEls.arc.getTotalLength();
  hudEls.mini = $('#minimap'); hudEls.miniCtx = hudEls.mini.getContext('2d');
}

const hudState = { lap:-1, pos:-1, spd:-1, item:'', count:'', warn:false, boostFull:false,
                   lapsDone:0, splitUntil:0 };

/* 경기장별 '한 바퀴 최고 기록' — 기록 도전뿐 아니라 어느 모드에서 달려도 쌓인다.
   기록 도전의 전체 기록(kart.best.…)과는 다른 값이라 열쇠도 따로 쓴다. */
function lapBestKey(trackId) { return 'kart.lapbest.' + trackId; }
function loadLapBest(trackId) {
  try { const v = +localStorage.getItem(lapBestKey(trackId)); return v > 0 ? v : null; }
  catch (e) { return null; }
}
function saveLapBest(trackId, ms) {
  try { localStorage.setItem(lapBestKey(trackId), String(Math.round(ms))); } catch (e) {}
}

/** 한 바퀴를 돌 때마다 그 바퀴 기록과 내 최고 기록과의 차이를 잠깐 띄움 */
function showLapSplit(race, ms) {
  const id = race.track.def.id;
  const prev = loadLapBest(id);
  const el = hudEls.split;
  let txt = '이번 바퀴 ' + fmtTime(ms);
  let faster = true;
  if (prev != null) { txt += ' · ' + fmtDelta(ms - prev); faster = ms < prev; }
  if (prev == null || ms < prev) { saveLapBest(id, ms); if (prev != null) txt += ' 🎉'; }
  el.textContent = txt;
  el.classList.toggle('neg', faster);
  el.classList.remove('hidden');
  hudState.splitUntil = race.time + 2.8;
}

function hudUpdate(race, player) {
  // 바퀴
  const lap = clamp(player.lap + 1, 1, race.laps);
  if (lap !== hudState.lap) {
    hudState.lap = lap;
    hudEls.lap.innerHTML = lap + '<small>/' + race.laps + '</small>';
  }
  // 시간
  hudEls.time.textContent = fmtTime(race.state === 'ready' ? 0 : race.clock);

  // 한 바퀴 기록 — 바퀴를 마칠 때마다 잠깐 떴다 사라짐
  if (player.lapTimes.length !== hudState.lapsDone) {
    hudState.lapsDone = player.lapTimes.length;
    const lt = player.lapTimes[player.lapTimes.length - 1];
    if (lt != null && lt > 0) showLapSplit(race, lt);
  }
  if (hudState.splitUntil && race.time > hudState.splitUntil) {
    hudState.splitUntil = 0;
    hudEls.split.classList.add('hidden');
  }

  // 순위
  if (player.rank !== hudState.pos) {
    hudState.pos = player.rank;
    hudEls.posn.textContent = player.rank;
    hudEls.posof.textContent = '/ ' + race.karts.length;
    hudEls.posbox.className = player.rank <= 3 ? 'p' + player.rank : '';
  }
  // 속도계
  const kmh = Math.round(player.kmh);
  if (kmh !== hudState.spd) {
    hudState.spd = kmh;
    hudEls.spdv.textContent = kmh;
    const t = clamp(kmh / 170, 0, 1);
    hudEls.arc.setAttribute('stroke-dasharray', (hudEls.arcLen * t) + ' ' + hudEls.arcLen);
  }
  // 드리프트 충전 막대
  const chg = player.drifting ? clamp(player.driftCharge / 2.2, 0, 1)
            : (player.boost > 0 ? clamp(player.boost / 2.3, 0, 1) : 0);
  hudEls.boost.style.width = (chg * 100) + '%';
  const full = chg > 0.85;
  if (full !== hudState.boostFull) {
    hudState.boostFull = full;
    hudEls.boostbar.classList.toggle('full', full);
  }
  // 아이템 칸
  const ikey = player.itemRolling > 0 ? '?' : (player.item || '');
  if (ikey !== hudState.item) {
    hudState.item = ikey;
    hudEls.item.classList.toggle('spin', player.itemRolling > 0);
    if (player.itemRolling > 0) {
      hudEls.item.textContent = '🎁';
      hudEls.itemhint.classList.add('hidden');
    } else if (player.item) {
      hudEls.item.textContent = ITEMS[player.item].icon;
      hudEls.item.classList.add('pop');
      setTimeout(() => hudEls.item.classList.remove('pop'), 140);
      hudEls.itemhint.textContent = ITEMS[player.item].name + ' · ' + ITEMS[player.item].hint;
      hudEls.itemhint.classList.remove('hidden');
    } else {
      hudEls.item.innerHTML = '<span class="none">아이템<br>없음</span>';
      hudEls.itemhint.classList.add('hidden');
    }
  }
  // 순위표
  hudBoard(race, player);
  // 역주행 경고
  const warn = player.wrongWay && race.state === 'racing';
  if (warn !== hudState.warn) {
    hudState.warn = warn;
    hudEls.warn.classList.toggle('hidden', !warn);
  }
  // 부스터 화면 효과
  hudEls.speedfx.classList.toggle('on', player.boost > 0 || player.kmh > 128);
}

let boardKey = '';
function hudBoard(race, player) {
  const list = race.order || race.karts;
  const key = list.map(k => k.id + (k.finished ? 'F' : '') + k.rank).join(',');
  if (key === boardKey) return;
  boardKey = key;
  let html = '';
  const lead = list[0];
  for (let i = 0; i < list.length && i < 8; i++) {
    const k = list[i];
    const c = KART_COLORS[k.colorId % KART_COLORS.length].css;
    let gap = '';
    if (k.finished) gap = '완주';
    else if (k === lead) gap = '선두';
    else {
      const d = (lead.total - k.total) * race.track.length;
      gap = d > 999 ? '-' : '-' + Math.round(d) + 'm';
    }
    html += '<div class="row' + (k === player ? ' me' : '') + (k.finished ? ' fin' : '') + '">'
          + '<span class="r">' + (i + 1) + '</span>'
          + '<span class="c" style="background:' + c + '"></span>'
          + '<span class="n">' + escapeHtml(k.name) + '</span>'
          + '<span class="g">' + gap + '</span></div>';
  }
  hudEls.board.innerHTML = html;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
}

/* ─────────── 미니맵 ─────────── */
function miniSetup(race) {
  const T = race.track, cv = hudEls.mini;
  const pad = 14;
  const w = cv.width, h = cv.height;
  const bx = T.bounds.maxX - T.bounds.minX, bz = T.bounds.maxZ - T.bounds.minZ;
  const s = Math.min((w - pad*2) / bx, (h - pad*2) / bz);
  race.map = {
    s,
    ox: w/2 - (T.bounds.minX + bx/2) * s,
    oy: h/2 - (T.bounds.minZ + bz/2) * s,
  };
}
function miniDraw(race, player) {
  const ctx = hudEls.miniCtx, T = race.track, m = race.map;
  const cv = hudEls.mini;
  ctx.clearRect(0, 0, cv.width, cv.height);
  // 코스 외곽선
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.beginPath();
  const P = T.mapPath;
  for (let i = 0; i < P.length; i++) {
    const x = P[i][0] * m.s + m.ox, y = P[i][1] * m.s + m.oy;
    i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  }
  ctx.closePath();
  ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.lineWidth = 13; ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.92)'; ctx.lineWidth = 3.4; ctx.stroke();
  // 결승선
  const s0 = T.pos[0] * m.s + m.ox, s1 = T.pos[2] * m.s + m.oy;
  ctx.fillStyle = '#ffd85e';
  ctx.fillRect(s0 - 4, s1 - 4, 8, 8);
  // 카트 위치
  for (const k of race.karts) {
    const x = k.x * m.s + m.ox, y = k.z * m.s + m.oy;
    const me = k === player;
    ctx.beginPath();
    ctx.arc(x, y, me ? 8 : 6, 0, TAU);
    ctx.fillStyle = me ? '#ff4d7d' : KART_COLORS[k.colorId % KART_COLORS.length].css;
    ctx.fill();
    ctx.lineWidth = me ? 3 : 2;
    ctx.strokeStyle = 'rgba(6,10,22,.85)';
    ctx.stroke();
  }
}

/* ─────────── 이름표 (친구 별명을 카트 위에 띄움) ─────────── */
let plateWrap = null, platePool = [];
function plateInit() {
  plateWrap = document.createElement('div');
  plateWrap.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:8;overflow:hidden';
  document.body.appendChild(plateWrap);
}
function plateUpdate(R, race, player, enabled) {
  let n = 0;
  if (enabled) {
    for (const k of race.karts) {
      if (k === player) continue;
      const d = Math.hypot(k.x - player.x, k.z - player.z);
      if (d > 95) continue;
      const p = R.project(k.x, k.y + 2.35, k.z);
      if (!p || p[0] < -0.1 || p[0] > 1.1 || p[1] < -0.1 || p[1] > 1.1) continue;
      let el = platePool[n];
      if (!el) {
        el = document.createElement('div');
        el.style.cssText = 'position:absolute;transform:translate(-50%,-100%);white-space:nowrap;'
          + 'font-size:12px;font-weight:800;padding:2px 8px;border-radius:9px;'
          + 'background:rgba(9,14,28,.7);border:1px solid rgba(255,255,255,.2);color:#fff;'
          + 'text-shadow:0 2px 6px rgba(0,0,0,.6)';
        plateWrap.appendChild(el);
        platePool[n] = el;
      }
      const c = KART_COLORS[k.colorId % KART_COLORS.length].css;
      el.style.display = 'block';
      el.style.left = (p[0] * 100) + '%';
      el.style.top = (p[1] * 100) + '%';
      el.style.opacity = String(clamp(1 - (d - 60) / 40, 0.35, 1));
      el.style.borderColor = c;
      el.textContent = k.name;
      n++;
    }
  }
  for (let i = n; i < platePool.length; i++) platePool[i].style.display = 'none';
}
/* ══════════════════════════════════════════════════════════════════
   8. 온라인 방 (Cloudflare Worker + Durable Object 웹소켓)
   서버를 두지 않아도 '혼자 달리기'는 그대로 작동합니다.
   ══════════════════════════════════════════════════════════════════ */

/** 선생님이 워커를 배포한 뒤 이 값을 바꾸면 학생은 주소를 입력할 필요가 없습니다. */
const DEFAULT_SERVER = 'https://kart.dasooni.workers.dev';   // 다람쌤 교실 방 서버

const net = {
  base: '',
  ws: null,
  active: false,
  room: '',
  me: '',
  host: false,
  players: [],       // [{id, name, color, host}]
  onEvent: null,
  lastSend: 0,
  closedByUs: false,

  /** 저장된 서버 주소 불러오기 */
  loadBase() {
    let b = '';
    try { b = localStorage.getItem('kart.server') || ''; } catch (e) {}
    this.base = (b || DEFAULT_SERVER).replace(/\\/+$/, '');
    return this.base;
  },
  saveBase(url) {
    this.base = String(url || '').trim().replace(/\\/+$/, '');
    try { localStorage.setItem('kart.server', this.base); } catch (e) {}
    return this.base;
  },
  get ready() { return !!this.base; },

  /** 서버가 살아 있는지 확인 */
  async ping() {
    if (!this.base) throw new Error('주소가 비어 있습니다.');
    const r = await fetch(this.base + '/api/health', { method:'GET' });
    if (!r.ok) throw new Error('서버가 응답하지 않습니다 (' + r.status + ')');
    return r.json();
  },

  /** 새 방 번호 받기 */
  async newRoom() {
    const r = await fetch(this.base + '/api/new', { method:'POST' });
    if (!r.ok) throw new Error('방을 만들지 못했습니다 (' + r.status + ')');
    const j = await r.json();
    if (!j.room) throw new Error('방 번호를 받지 못했습니다.');
    return j.room;
  },

  /** 방에 접속 (웹소켓) */
  connect(room, name, color, onEvent) {
    return new Promise((resolve, reject) => {
      this.disconnect(true);
      this.onEvent = onEvent;
      this.closedByUs = false;
      const wsBase = this.base.replace(/^http/, 'ws');
      const url = wsBase + '/api/ws?room=' + encodeURIComponent(room)
        + '&name=' + encodeURIComponent(name) + '&color=' + color;
      let ws;
      try { ws = new WebSocket(url); } catch (e) { reject(new Error('접속할 수 없습니다.')); return; }
      this.ws = ws;
      let settled = false;
      const fail = (msg) => { if (!settled) { settled = true; reject(new Error(msg)); } };
      const timer = setTimeout(() => { fail('서버가 응답하지 않습니다. 주소를 확인해 주세요.'); ws.close(); }, 9000);

      ws.onopen = () => { /* 서버의 room 메시지를 기다림 */ };
      ws.onmessage = (ev) => {
        let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === 'room' && !settled) {
          settled = true; clearTimeout(timer);
          this.active = true; this.room = room;
          this.me = m.you; this.host = m.host === m.you;
          this.players = m.players || [];
          resolve(m);
        }
        if (m.t === 'full' && !settled) {
          settled = true; clearTimeout(timer);
          reject(new Error('이 방은 이미 8명이 차 있습니다.'));
          ws.close(); return;
        }
        if (m.t === 'players') { this.players = m.players || []; this.host = m.host === this.me; }
        if (this.onEvent) this.onEvent(m);
      };
      ws.onerror = () => { clearTimeout(timer); fail('접속에 실패했습니다. 주소가 맞는지 확인해 주세요.'); };
      ws.onclose = () => {
        clearTimeout(timer);
        const was = this.active;
        this.active = false;
        fail('서버와의 연결이 끊어졌습니다.');
        if (was && !this.closedByUs && this.onEvent) this.onEvent({ t:'closed' });
      };
    });
  },

  disconnect(silent) {
    this.closedByUs = true;
    if (this.ws) { try { this.ws.close(); } catch (e) {} }
    this.ws = null; this.active = false;
    if (!silent) { this.room = ''; this.players = []; }
  },

  send(obj) {
    if (this.ws && this.ws.readyState === 1) {
      try { this.ws.send(JSON.stringify(obj)); } catch (e) {}
    }
  },

  /** 내 카트 위치를 초당 약 15번 알림 */
  sendState(k, now) {
    if (!this.active || now - this.lastSend < 66) return;
    this.lastSend = now;
    let fl = 0;
    if (k.drifting) fl |= 1;
    if (k.boost > 0) fl |= 2;
    if (k.spin > 0) fl |= 4;
    if (k.shield > 0) fl |= 8;
    if (k.star > 0) fl |= 16;
    this.send({
      t:'s',
      x: Math.round(k.x * 20) / 20, y: Math.round(k.y * 20) / 20, z: Math.round(k.z * 20) / 20,
      h: Math.round(k.h * 200) / 200, v: Math.round(k.speed * 10) / 10,
      r: Math.round(k.roll * 100) / 100,
      l: k.lap, p: Math.round(k.prog * 1000) / 1000, f: fl,
    });
  },
  sendItem(kind, k) {
    this.send({ t:'i', k: kind, x: Math.round(k.x*10)/10, y: Math.round(k.y*10)/10,
                z: Math.round(k.z*10)/10, h: Math.round(k.h*100)/100 });
  },
  sendHitBy(targetId) { this.send({ t:'hit', to: targetId }); },
  sendFinish(ms, best) { this.send({ t:'fin', ms: Math.round(ms), best: best ? Math.round(best) : null }); },
  sendSetup(trackId, laps) { this.send({ t:'setup', track: trackId, laps }); },
  sendGo(trackId, laps, seed) { this.send({ t:'go', track: trackId, laps, seed }); },
  sendBack() { this.send({ t:'back' }); },
};
/* ══════════════════════════════════════════════════════════════════
   9. 앱 전체 흐름 — 메뉴 · 경기 시작 · 매 프레임 갱신
   ══════════════════════════════════════════════════════════════════ */

const app = {
  R: null,
  race: null,
  cams: [],
  player: null,
  player2: null,
  mode: 'solo',
  paused: false,
  running: false,
  trackCache: {},
  lastTs: 0,
  screen: 'scHome',
  prefs: {
    nick: '', colorId: 1, trackId: 'snow', laps: 3,
    ai: 'normal', items: true, quality: 'high', sound: true,
  },
};

const AI_LEVELS = {
  easy:   { name:'쉬움', skill:0.42 },
  normal: { name:'보통', skill:0.72 },
  hard:   { name:'어려움', skill:0.95 },
};
const AI_NAMES = ['빠른곰','민트여우','파랑상어','노랑벌','초코토끼','번개다람쥐','하늘고래','붕붕이'];

/* ─────────── 설정 저장 ─────────── */
function loadPrefs() {
  try {
    const raw = localStorage.getItem('kart.prefs');
    if (raw) Object.assign(app.prefs, JSON.parse(raw));
  } catch (e) {}
  audio.on = app.prefs.sound !== false;
}
function savePrefs() {
  try { localStorage.setItem('kart.prefs', JSON.stringify(app.prefs)); } catch (e) {}
}
function bestKey(trackId, laps) { return 'kart.best.' + trackId + '.' + laps; }
function loadBest(trackId, laps) {
  try { const r = localStorage.getItem(bestKey(trackId, laps)); return r ? JSON.parse(r) : null; }
  catch (e) { return null; }
}
function saveBest(trackId, laps, data) {
  try { localStorage.setItem(bestKey(trackId, laps), JSON.stringify(data)); } catch (e) {}
}

/* ─────────── 화면 전환 ─────────── */
function showScreen(id) {
  app.screen = id;
  $$('#ui .screen').forEach(s => s.classList.toggle('on', s.id === id));
  $('#ui').classList.remove('off');
  $('#hud').classList.add('off');
  $('#touch').classList.add('off');
  $('#pauseBtn').classList.add('off');
  $('#ui').scrollTop = 0;
}
function hideMenu() {
  $('#ui').classList.add('off');
  $('#hud').classList.remove('off');
  if (isTouchDevice() && app.mode !== 'split') $('#touch').classList.remove('off');
  // 온라인 경기는 멈출 수 없으므로 단추도 감춘다
  $('#pauseBtn').classList.toggle('off', net.active);
}
function isTouchDevice() {
  return ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
}

/* ─────────── 경기장 미리보기 그림 ─────────── */
function previewPath(def) {
  const cp = def.pts.map(p => [p[0] * def.scale, p[1] * def.scale]);
  const n = cp.length, out = [];
  for (let i = 0; i < n; i++) {
    const p0 = cp[(i-1+n)%n], p1 = cp[i], p2 = cp[(i+1)%n], p3 = cp[(i+2)%n];
    for (let k = 0; k < 10; k++) {
      const t = k / 10;
      out.push([crom(p0[0],p1[0],p2[0],p3[0],t), crom(p0[1],p1[1],p2[1],p3[1],t)]);
    }
  }
  return out;
}
function drawPreview(cv, def) {
  const ctx = cv.getContext('2d');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = cv.clientWidth || 190, h = 96;
  cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const g = ctx.createLinearGradient(0, 0, 0, h);
  const e = def.env;
  const rgb = (c, a) => 'rgba(' + Math.round(c[0]*255) + ',' + Math.round(c[1]*255) + ',' + Math.round(c[2]*255) + ',' + a + ')';
  g.addColorStop(0, rgb(e.skyMid, 1));
  g.addColorStop(1, rgb(e.ground, 1));
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

  const P = previewPath(def);
  let minX=1e9, maxX=-1e9, minY=1e9, maxY=-1e9;
  for (const p of P) { minX=Math.min(minX,p[0]); maxX=Math.max(maxX,p[0]); minY=Math.min(minY,p[1]); maxY=Math.max(maxY,p[1]); }
  const pad = 12;
  const s = Math.min((w-pad*2)/(maxX-minX), (h-pad*2)/(maxY-minY));
  const ox = w/2 - (minX+maxX)/2*s, oy = h/2 - (minY+maxY)/2*s;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.beginPath();
  P.forEach((p, i) => { const x=p[0]*s+ox, y=p[1]*s+oy; i?ctx.lineTo(x,y):ctx.moveTo(x,y); });
  ctx.closePath();
  ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 11; ctx.stroke();
  ctx.strokeStyle = rgb(e.road, 1); ctx.lineWidth = 8; ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 1.4;
  ctx.setLineDash([5, 5]); ctx.stroke(); ctx.setLineDash([]);
  // 출발선 표시
  const st = P[0];
  ctx.fillStyle = '#ffd85e';
  ctx.beginPath(); ctx.arc(st[0]*s+ox, st[1]*s+oy, 4.5, 0, TAU); ctx.fill();
}

/* ─────────── 메뉴 위젯 만들기 ─────────── */
function buildPickers() {
  // 카트 색
  const kp = $('#kartPick');
  kp.innerHTML = '';
  KART_COLORS.forEach(c => {
    const b = document.createElement('button');
    b.className = 'kt' + (c.id === app.prefs.colorId ? ' on' : '');
    b.innerHTML = '<div class="sw" style="background:' + c.css + '"></div><div class="nm">' + c.name + '</div>';
    b.onclick = () => {
      app.prefs.colorId = c.id; savePrefs();
      $$('#kartPick .kt').forEach((x, i) => x.classList.toggle('on', i === c.id));
    };
    kp.appendChild(b);
  });

  // 경기장 (준비 화면 + 대기실)
  ['#trackPick', '#lobbyTrackPick'].forEach(sel => {
    const tp = $(sel);
    tp.innerHTML = '';
    TRACKS.forEach(def => {
      const b = document.createElement('button');
      b.className = 'trk' + (def.id === app.prefs.trackId ? ' on' : '');
      b.dataset.track = def.id;
      b.innerHTML = '<canvas></canvas><div class="info"><div class="t">' + def.name + '</div>'
        + '<div class="d">' + def.desc + '</div><div class="m">' + def.tag + '</div></div>';
      b.onclick = () => {
        app.prefs.trackId = def.id; savePrefs();
        $$(sel + ' .trk').forEach(x => x.classList.toggle('on', x.dataset.track === def.id));
        if (sel === '#lobbyTrackPick' && net.active && net.host) net.sendSetup(def.id, app.prefs.laps);
      };
      tp.appendChild(b);
      requestAnimationFrame(() => drawPreview(b.querySelector('canvas'), def));
    });
  });

  // 바퀴 수
  ['#lapPick', '#lobbyLapPick'].forEach(sel => {
    const lp = $(sel); lp.innerHTML = '';
    [1, 2, 3, 5].forEach(n => {
      const b = document.createElement('button');
      b.className = 'chip' + (n === app.prefs.laps ? ' on' : '');
      b.textContent = n + '바퀴';
      b.dataset.laps = n;
      b.onclick = () => {
        app.prefs.laps = n; savePrefs();
        $$('#lapPick .chip, #lobbyLapPick .chip').forEach(x => x.classList.toggle('on', +x.dataset.laps === n));
        if (sel === '#lobbyLapPick' && net.active && net.host) net.sendSetup(app.prefs.trackId, n);
      };
      lp.appendChild(b);
    });
  });

  // 컴퓨터 실력
  const ap = $('#aiPick'); ap.innerHTML = '';
  Object.keys(AI_LEVELS).forEach(k => {
    const b = document.createElement('button');
    b.className = 'chip' + (k === app.prefs.ai ? ' on' : '');
    b.textContent = AI_LEVELS[k].name;
    b.onclick = () => {
      app.prefs.ai = k; savePrefs();
      $$('#aiPick .chip').forEach((x, i) => x.classList.toggle('on', Object.keys(AI_LEVELS)[i] === k));
    };
    ap.appendChild(b);
  });

  // 아이템 켜기/끄기
  const ip = $('#itemPick'); ip.innerHTML = '';
  [[true, '아이템 사용'], [false, '순수 실력전']].forEach(([v, label]) => {
    const b = document.createElement('button');
    b.className = 'chip' + (v === app.prefs.items ? ' on' : '');
    b.textContent = label;
    b.onclick = () => {
      app.prefs.items = v; savePrefs();
      $$('#itemPick .chip').forEach((x, i) => x.classList.toggle('on', (i === 0) === v));
    };
    ip.appendChild(b);
  });

  // 아이템 안내 — ITEMS 를 그대로 옮겨 적어 두 곳이 어긋나지 않게 한다
  const ig = $('#itemGuide');
  if (ig) {
    ig.innerHTML = Object.keys(ITEMS).map(id => {
      const it = ITEMS[id];
      return '<div class="itm"><span class="ic">' + it.icon + '</span>'
           + '<span><b>' + it.name + '</b> · ' + it.hint + '</span></div>';
    }).join('');
  }

  // 화면 품질
  const qp = $('#qualPick'); qp.innerHTML = '';
  Object.keys(QUALITY).forEach(k => {
    const b = document.createElement('button');
    b.className = 'chip' + (k === app.prefs.quality ? ' on' : '');
    b.textContent = QUALITY[k].name;
    b.onclick = () => {
      app.prefs.quality = k; savePrefs();
      $$('#qualPick .chip').forEach((x, i) => x.classList.toggle('on', Object.keys(QUALITY)[i] === k));
    };
    qp.appendChild(b);
  });
}

/* ─────────── 경기장 만들기 (무거우므로 로딩 화면과 함께) ─────────── */
function ensureTrack(trackId, qualityKey) {
  const key = trackId + '|' + qualityKey;
  if (app.trackCache[key]) return Promise.resolve(app.trackCache[key]);
  const def = TRACKS.find(t => t.id === trackId) || TRACKS[0];
  $('#loadTxt').textContent = def.name + ' 을(를) 만드는 중…';
  $('#load').classList.remove('hidden');
  return new Promise(resolve => {
    // 로딩 화면이 먼저 그려지도록 두 프레임 양보
    requestAnimationFrame(() => requestAnimationFrame(() => {
      const t0 = performance.now();
      const T = buildTrack(def, app.R.gl, QUALITY[qualityKey]);
      app.trackCache[key] = T;
      console.log('[카트] ' + def.name + ' 준비 완료 · '
        + Math.round(T.length) + 'm · ' + Math.round(performance.now() - t0) + 'ms');
      $('#load').classList.add('hidden');
      resolve(T);
    }));
  });
}

/* ─────────── 경기 시작 ─────────── */
async function startRace(opts) {
  const mode = opts.mode;
  app.mode = mode;
  const qk = app.prefs.quality;
  const T = await ensureTrack(opts.trackId || app.prefs.trackId, qk);
  // 아이템 상자 상태 초기화
  T.itemSpots.forEach(s => s.taken = 0);

  const laps = opts.laps || app.prefs.laps;
  const race = new Race({
    mode, track: T, laps,
    items: mode === 'time' ? false : app.prefs.items,
    quality: QUALITY[qk],
    recordGhost: mode === 'time',
  });
  app.race = race;
  app.cams = [];
  app.player2 = null;

  const nick = (app.prefs.nick || '나').slice(0, 8);

  if (mode === 'online') {
    // 서버가 알려 준 순서대로 배치 (모든 기기에서 같은 자리)
    const list = net.players;
    list.forEach((p) => {
      const isMe = p.id === net.me;
      const k = new Kart({
        id: p.id, name: p.name, colorId: p.color,
        isPlayer: isMe, isRemote: !isMe,
      });
      race.add(k);
      if (isMe) app.player = k;
    });
    if (!app.player) { app.player = race.karts[0]; app.player.isPlayer = true; app.player.isRemote = false; }
  } else if (mode === 'split') {
    const p1 = race.add(new Kart({ id:'p1', name: nick, colorId: app.prefs.colorId, isPlayer:true }));
    const c2 = (app.prefs.colorId + 4) % KART_COLORS.length;
    const p2 = race.add(new Kart({ id:'p2', name:'2번', colorId: c2, isPlayer:true }));
    app.player = p1; app.player2 = p2;
    addAI(race, 4, [app.prefs.colorId, c2]);
  } else if (mode === 'time') {
    const p = race.add(new Kart({ id:'p1', name: nick, colorId: app.prefs.colorId, isPlayer:true }));
    app.player = p;
    setupGhost(race, opts.trackId || app.prefs.trackId, laps);
  } else {
    const p = race.add(new Kart({ id:'p1', name: nick, colorId: app.prefs.colorId, isPlayer:true }));
    app.player = p;
    addAI(race, 7, [app.prefs.colorId]);
  }

  race.start();
  app.cams.push(new ViewCam(app.player));
  if (app.player2) app.cams.push(new ViewCam(app.player2));
  app.cams.forEach(c => c.update(0.016, race, true));

  miniSetup(race);
  boardKey = '';
  hudState.lap = -1; hudState.pos = -1; hudState.spd = -1; hudState.item = ''; hudState.warn = false;
  hudState.lapsDone = 0; hudState.splitUntil = 0;
  $('#splitv').classList.add('hidden');
  race.onFinish = onRaceFinish;

  $('#splitHud').classList.toggle('hidden', mode !== 'split');
  $('#hud').classList.toggle('slim', mode === 'split');
  hideMenu();
  app.paused = false;
  app.running = true;
  app.lastTs = 0;
  if (audio.on) { audioInit(); if (audio.ctx && audio.ctx.state === 'suspended') audio.ctx.resume(); }
}

function addAI(race, n, avoidColors) {
  const skill = AI_LEVELS[app.prefs.ai].skill;
  const pool = KART_COLORS.map(c => c.id).filter(c => !avoidColors.includes(c));
  const names = AI_NAMES.slice().sort(() => Math.random() - 0.5);
  for (let i = 0; i < n; i++) {
    race.add(new Kart({
      id: 'ai' + i, name: names[i % names.length], colorId: pool[i % pool.length],
      isAI: true, skill: clamp(skill + (Math.random() - 0.5) * 0.14, 0.25, 1),
    }));
  }
}

/** 기록 도전 — 저장된 최고 기록을 유령 카트로 되살림 */
function setupGhost(race, trackId, laps) {
  const best = loadBest(trackId, laps);
  if (!best || !best.ghost || best.ghost.length < 4) { race.ghost = null; return; }
  const gk = new Kart({ id:'ghost', name:'내 최고 기록', colorId: app.prefs.colorId });
  gk.placeAt(race.track.startGrid[0]);
  race.ghost = { kart: gk, data: best.ghost, on:false, ms: best.ms };
}
function stepGhost(race, dt) {
  const g = race.ghost;
  if (!g) return;
  if (race.state !== 'racing') { g.on = false; return; }
  g.on = true;
  const t = race.clock / 1000;
  const fi = t / 0.1;
  const i = Math.floor(fi);
  const d = g.data;
  if (i >= d.length - 1) { g.on = i < d.length; if (!g.on) return; }
  const a = d[Math.min(i, d.length - 1)], b = d[Math.min(i + 1, d.length - 1)];
  const u = clamp(fi - i, 0, 1);
  const k = g.kart;
  k.x = lerp(a[0], b[0], u); k.y = lerp(a[1], b[1], u); k.z = lerp(a[2], b[2], u);
  k.h = a[3] + wrapAngle(b[3] - a[3]) * u;
  k.wheelSpin += dt * 40;
}

/* ─────────── 경기 종료 ─────────── */
function onRaceFinish() {
  const race = app.race;
  audioEngineOff();
  if (net.active && app.player) net.sendFinish(app.player.finishTime || race.clock, app.player.bestLap);
  // 기록 도전: 최고 기록 갱신 확인
  let newRecord = false;
  if (race.cfg.mode === 'time' && app.player.finishTime != null) {
    const prev = loadBest(race.track.def.id, race.laps);
    if (!prev || app.player.finishTime < prev.ms) {
      newRecord = true;
      saveBest(race.track.def.id, race.laps, {
        ms: Math.round(app.player.finishTime),
        best: app.player.bestLap ? Math.round(app.player.bestLap) : null,
        ghost: (race.ghostRec || []).slice(0, 6000),
        at: new Date().toISOString().slice(0, 10),
      });
    }
  }
  setTimeout(() => showResult(newRecord), 900);
}

function showResult(newRecord) {
  const race = app.race;
  app.running = false;
  race.updateRanks();
  const list = race.order;
  $('#resultTitle').textContent = race.cfg.mode === 'time' ? '⏱️ 기록 도전 끝!' : '🏁 경기 끝!';

  // 시상대 (2위 · 1위 · 3위 순서로 세움)
  const pod = $('#podium'); pod.innerHTML = '';
  [[1, 'g2'], [0, 'g1'], [2, 'g3']].forEach(([idx, cls]) => {
    const k = list[idx];
    if (!k) return;
    const d = document.createElement('div');
    d.className = 'pod ' + cls;
    d.innerHTML = '<div class="who" style="color:' + KART_COLORS[k.colorId % 8].css + '">'
      + escapeHtml(k.name) + '</div><div class="bar">' + (idx + 1) + '</div>';
    pod.appendChild(d);
  });

  // 순위표
  let html = '';
  list.forEach((k, i) => {
    const c = KART_COLORS[k.colorId % 8].css;
    const t = k.finishTime != null ? fmtTime(k.finishTime) : '미완주';
    html += '<tr' + (k === app.player ? ' class="me"' : '') + '>'
      + '<td class="r">' + (i + 1) + '</td>'
      + '<td><span class="c" style="background:' + c + '"></span>' + escapeHtml(k.name) + '</td>'
      + '<td class="t">' + t + '</td></tr>';
  });
  $('#resultRows').innerHTML = html;

  // 아래쪽 부가 정보
  const p = app.player;
  let extra = '';
  if (race.cfg.mode !== 'time') {
    const myRank = list.indexOf(p) + 1;
    extra += '내 순위: <b>' + myRank + '위</b> / ' + list.length + '명'
           + (p.finishTime != null ? ' · 기록 <b>' + fmtTime(p.finishTime) + '</b>' : ' · 미완주') + '<br>';
  }
  if (p.bestLap) extra += '이번 경기 한 바퀴 최고: <b>' + fmtTime(p.bestLap) + '</b><br>';
  const lapBest = loadLapBest(race.track.def.id);
  if (lapBest) extra += '이 경기장 한 바퀴 내 최고 기록: <b>' + fmtTime(lapBest) + '</b><br>';
  if (race.cfg.mode === 'time') {
    const best = loadBest(race.track.def.id, race.laps);
    if (newRecord) extra += '🎉 <b>새 최고 기록</b>을 세웠어요! 다음에는 유령 카트와 함께 달립니다.<br>';
    else if (best) extra += '이 경기장 최고 기록: <b>' + fmtTime(best.ms) + '</b> (' + (best.at || '') + ')<br>';
  }
  extra += '경기장: ' + race.track.def.name + ' · ' + race.laps + '바퀴';
  $('#resultExtra').innerHTML = extra;

  $('#btnAgain').textContent = race.cfg.mode === 'online' ? '🏠 대기실로' : '🔁 한 번 더!';
  showScreen('scResult');
  $('#splitHud').classList.add('hidden');
}

/* ─────────── 매 프레임 ─────────── */
function frame(ts) {
  requestAnimationFrame(frame);
  if (!app.R) return;
  const race = app.race;
  if (!race || !app.running || app.paused) { app.lastTs = ts; return; }
  let dt = app.lastTs ? (ts - app.lastTs) / 1000 : 0.016;
  app.lastTs = ts;
  if (dt > 0.06) dt = 0.06;               // 창을 잠깐 벗어나도 튀지 않게

  // 조작 모으기
  const inputs = new Map();
  if (app.mode === 'split') {
    inputs.set('p1', readInput('p1', false));
    inputs.set('p2', readInput('p2', false));
  } else {
    inputs.set(app.player.id, readInput('solo', true));
  }

  const before = race.state;
  race.update(dt, inputs);
  stepGhost(race, dt);

  // 카운트다운 소리
  if (before === 'ready') {
    const n = Math.ceil(race.count - 0.6);
    if (n !== app._lastCount) {
      app._lastCount = n;
      if (n >= 1 && n <= 3) sfx('count');
    }
  }
  if (before === 'ready' && race.state === 'racing') sfx('go');

  // 통신
  if (net.active && app.player) net.sendState(app.player, ts);

  // 화면 그리기
  const R = app.R;
  R.resize(race.cfg.quality.dpr);
  R.clearAll();
  if (app.mode === 'split') {
    const halfH = Math.floor(R.h / 2);
    // 마지막 인자는 '내 카트를 그릴지'다. 1인칭(mode 2)일 때만 숨긴다.
    // (예전에는 둘 다 false 로 넘겨서 나눠 달리기에서 자기 카트가 보이지 않았다)
    app.cams[0].update(dt, race, false);
    R.viewport(0, halfH, R.w, R.h - halfH);
    drawScene(R, race, app.cams[0], R.w / (R.h - halfH), app.cams[0].mode !== 2);
    app.cams[1].update(dt, race, false);
    R.viewport(0, 0, R.w, halfH);
    drawScene(R, race, app.cams[1], R.w / halfH, app.cams[1].mode !== 2);
    R.gl.disable(R.gl.SCISSOR_TEST);
    splitHudUpdate(race);
  } else {
    const cam = app.cams[0];
    cam.update(dt, race, false);
    R.viewport(0, 0, R.w, R.h);
    drawScene(R, race, cam, R.w / R.h, cam.mode === 2 ? false : true);
    R.gl.disable(R.gl.SCISSOR_TEST);
    plateUpdate(R, race, app.player, race.karts.length > 1);
  }

  // HUD
  if (app.mode !== 'split') {
    hudUpdate(race, app.player);
    miniDraw(race, app.player);
  }
  countdownUI(race);

  // 소리
  if (audio.on && audio.ctx) audioEngine(app.player.kmh, app.player.boost > 0);
  if (hitFxT > 0) { hitFxT -= dt; if (hitFxT <= 0) $('#hitfx').classList.remove('on'); }
}

/** 3 · 2 · 1 · 출발! 표시 */
let countdownShown = '';
function countdownUI(race) {
  const el = $('#count'), toast = $('#toast');
  let txt = '';
  if (race.state === 'ready') {
    const n = Math.ceil(race.count - 0.6);
    txt = n >= 1 ? String(Math.min(n, 3)) : '출발!';
  } else if (race.time - (race.startShown || 0) < 0) txt = '';
  if (race.state === 'racing' && race.clock < 900) txt = '출발!';
  if (txt !== countdownShown) {
    countdownShown = txt;
    if (txt) {
      el.textContent = txt;
      el.classList.remove('hidden', 'pulse');
      el.classList.toggle('go', txt === '출발!');
      void el.offsetWidth;
      el.classList.add('pulse');
    } else el.classList.add('hidden');
  }
  // 안내 문구
  const p = app.player;
  let msg = '';
  if (p.finished && race.state !== 'over') msg = '🏁 완주! ' + p.rank + '위';
  else if (race.state === 'racing' && p.lap >= race.laps - 1 && race.laps > 1 && !p.finished) msg = '마지막 바퀴!';
  if (msg !== (toast._msg || '')) {
    toast._msg = msg;
    toast.textContent = msg;
    toast.classList.toggle('hidden', !msg);
    if (msg) { toast.classList.remove('pulse'); void toast.offsetWidth; toast.classList.add('pulse'); }
  }
}

/** 분할 화면용 간단 HUD */
function splitHudUpdate(race) {
  for (let i = 0; i < 2; i++) {
    const k = i === 0 ? app.player : app.player2;
    const box = $('#sh' + (i + 1));
    if (!box || !k) continue;
    box.querySelector('.p').textContent = k.rank + '위';
    box.querySelector('.l').textContent = 'LAP ' + clamp(k.lap + 1, 1, race.laps) + '/' + race.laps;
    box.querySelector('.s').textContent = Math.round(k.kmh) + ' km/h';
    box.querySelector('.i').textContent = k.itemRolling > 0 ? '🎁' : (k.item ? ITEMS[k.item].icon : '');
  }
}

/* ─────────── 일시정지 ─────────── */
function setPaused(on) {
  if (!app.race || !app.running) return;
  if (net.active && on) return;              // 온라인 경기는 멈출 수 없음
  app.paused = on;
  $('#pause').classList.toggle('hidden', !on);
  if (on) audioEngineOff();
  else app.lastTs = 0;
}
function quitRace() {
  app.running = false; app.paused = false;
  $('#pause').classList.add('hidden');
  $('#splitHud').classList.add('hidden');
  audioEngineOff();
  plateUpdate(app.R, app.race, app.player, false);
  if (net.active) { net.sendBack(); showScreen('scLobby'); }
  else showScreen('scHome');
}
/* ══════════════════════════════════════════════════════════════════
   10. 버튼 연결 · 온라인 대기실 · 시작
   ══════════════════════════════════════════════════════════════════ */

/* ─────────── 온라인 대기실 ─────────── */
const lobby = { trackId:'snow', laps:3, starting:false };

function lobbyRender() {
  $('#lobbyCode').textContent = net.room || '------';
  const list = net.players;
  $('#lobbyCount').textContent = '(' + list.length + '/8)';
  const wrap = $('#lobbyList');
  wrap.innerHTML = '';
  if (!list.length) {
    wrap.innerHTML = '<div class="pl empty">아직 아무도 없어요</div>';
  } else {
    list.forEach(p => {
      const d = document.createElement('div');
      d.className = 'pl';
      const c = KART_COLORS[p.color % 8].css;
      d.innerHTML = '<span class="c" style="background:' + c + '"></span>'
        + '<span class="n">' + escapeHtml(p.name) + '</span>'
        + (p.id === net.me ? '<span class="tag me">나</span>' : '')
        + (p.host ? '<span class="tag">방장</span>' : '');
      wrap.appendChild(d);
    });
  }
  // 방장만 경기장을 고를 수 있음
  $('#lobbyHostCard').classList.toggle('hidden', !net.host);
  $('#lobbyGuestCard').classList.toggle('hidden', net.host);
  $('#btnHostStart').classList.toggle('hidden', !net.host);
  $('#lobbyWaitNote').textContent = net.host
    ? '모두 들어오면 출발 버튼을 눌러 주세요. 혼자여도 시작할 수 있습니다.'
    : '방장이 출발 버튼을 누르면 함께 시작합니다.';
  const def = TRACKS.find(t => t.id === lobby.trackId) || TRACKS[0];
  $('#lobbyGuestInfo').textContent = def.name + ' · ' + lobby.laps + '바퀴';
  $$('#lobbyTrackPick .trk').forEach(x => x.classList.toggle('on', x.dataset.track === lobby.trackId));
  $$('#lobbyLapPick .chip').forEach(x => x.classList.toggle('on', +x.dataset.laps === lobby.laps));
}

function lobbyError(msg) {
  const el = $('#lobbyErr');
  el.textContent = msg;
  el.classList.toggle('hidden', !msg);
}

/** 서버에서 오는 소식 처리 */
function onNetEvent(m) {
  if (m.t === 'room' || m.t === 'players') {
    net.players = m.players || net.players;
    if (m.track) lobby.trackId = m.track;
    if (m.laps) lobby.laps = m.laps;
    if (app.screen === 'scLobby') lobbyRender();
    // 경기 중 나간 사람의 카트를 치움
    if (app.race && app.running && app.mode === 'online') {
      const ids = new Set(net.players.map(p => p.id));
      app.race.karts = app.race.karts.filter(k => k.isPlayer || ids.has(k.id));
    }
  } else if (m.t === 'setup') {
    lobby.trackId = m.track; lobby.laps = m.laps;
    if (app.screen === 'scLobby') lobbyRender();
  } else if (m.t === 'go') {
    lobby.trackId = m.track; lobby.laps = m.laps;
    // 모든 기기가 같은 순서로 카트를 놓도록 선수 목록을 함께 맞춤
    if (m.players && m.players.length) net.players = m.players;
    startRace({ mode:'online', trackId: m.track, laps: m.laps });
  } else if (m.t === 's') {
    const k = app.race && app.race.karts.find(x => x.id === m.id);
    if (k && k.isRemote) {
      k.tx = m.x; k.ty = m.y; k.tz = m.z; k.th = m.h;
      k.speed = m.v; k.lap = m.l; k.prog = m.p; k.troll = m.r || 0;
      k.drifting = !!(m.f & 1);
      k.boost = (m.f & 2) ? 0.3 : 0;
      k.spin = (m.f & 4) ? 0.3 : 0;
      k.shield = (m.f & 8) ? 0.3 : 0;
      k.star = (m.f & 16) ? 0.3 : 0;
    }
  } else if (m.t === 'i') {
    // 친구가 아이템을 썼음 — 내 화면에도 똑같이 보이게
    const race = app.race;
    if (!race || !app.running) return;
    if (m.k === 'banana' || m.k === 'ice') {
      race.bananas.push({ kind:m.k, x:m.x, y:m.y + 0.3, z:m.z, t:0, owner:m.id });
    } else if (m.k === 'thunder') {
      // 번개는 쏜 친구보다 앞서 있을 때만 맞는다 (각 기기가 스스로 판정)
      const src = race.karts.find(x => x.id === m.id);
      const me = app.player;
      if (src && me && !me.finished && me.total > src.total && me.hit(0.9)) {
        race.shake = 1; sfx('hit'); flashHit();
      }
      race.effects.push({ kind:'burst', x:m.x, y:m.y + 1.4, z:m.z, t:0, life:0.6, col:[0.8,0.92,1] });
    } else if (m.k === 'missile') {
      race.missiles.push({
        x:m.x + Math.sin(m.h) * 2.6, y:m.y + 0.7, z:m.z + Math.cos(m.h) * 2.6,
        h:m.h, sp:30, t:0, owner:m.id, target:null,
        i: race.track.locateGlobal(m.x, m.z), lat:0,
      });
    }
  } else if (m.t === 'fin') {
    const k = app.race && app.race.karts.find(x => x.id === m.id);
    if (k && !k.finished) { k.finished = true; k.finishTime = m.ms; k.lap = app.race.laps; }
  } else if (m.t === 'back') {
    // 누군가 대기실로 돌아감 — 알림만
  } else if (m.t === 'closed') {
    net.active = false;
    if (app.running) { app.running = false; audioEngineOff(); }
    lobbyError('서버와의 연결이 끊어졌습니다. 다시 들어와 주세요.');
    showScreen('scOnline');
    $('#onlineErr').textContent = '연결이 끊어졌습니다. 방 번호로 다시 들어가 주세요.';
    $('#onlineErr').classList.remove('hidden');
  }
}

/* ─────────── 버튼 연결 ─────────── */
function wireUI() {
  // 별명
  const nickIn = $('#nickIn');
  nickIn.value = app.prefs.nick || '';
  nickIn.addEventListener('input', () => {
    app.prefs.nick = nickIn.value.trim().slice(0, 8);
    savePrefs();
  });

  // 모드 고르기
  $$('.mode').forEach(b => {
    b.onclick = () => {
      const mode = b.dataset.mode;
      if (!app.prefs.nick) {
        nickIn.focus();
        nickIn.style.borderColor = 'var(--red)';
        setTimeout(() => nickIn.style.borderColor = '', 1200);
        app.prefs.nick = '이름없음';
        nickIn.value = '이름없음';
        savePrefs();
      }
      if (mode === 'online') { openOnline(); return; }
      app.mode = mode;
      $('#setupTitle').textContent =
        mode === 'split' ? '👥 둘이 나눠 달리기' : mode === 'time' ? '⏱️ 기록 도전' : '🤖 혼자 달리기';
      $('#rowAi').classList.toggle('hidden', mode === 'time');
      $('#splitInfo').classList.toggle('hidden', mode !== 'split');
      showScreen('scSetup');
    };
  });
  $$('[data-go]').forEach(b => b.onclick = () => showScreen(b.dataset.go));

  // 출발
  $('#btnStartRace').onclick = () => startRace({ mode: app.mode });

  // 일시정지 화면
  $('#pauseBtn').onclick = () => setPaused(!app.paused);
  $('#btnResume').onclick = () => setPaused(false);
  $('#btnRestart').onclick = () => { setPaused(false); startRace({ mode: app.mode }); };
  $('#btnQuit').onclick = quitRace;
  $('#btnResultHome').onclick = () => {
    if (net.active) { net.disconnect(); }
    showScreen('scHome');
  };
  $('#btnAgain').onclick = () => {
    if (app.race && app.race.cfg.mode === 'online') { showScreen('scLobby'); lobbyRender(); }
    else startRace({ mode: app.race ? app.race.cfg.mode : 'solo' });
  };

  /* ── 온라인 ── */
  $('#serverIn').value = net.loadBase();
  $('#btnSaveServer').onclick = () => {
    const v = net.saveBase($('#serverIn').value);
    $('#serverMsg').innerHTML = v ? '저장했습니다: <b>' + escapeHtml(v) + '</b>' : '주소를 지웠습니다.';
  };
  $('#btnTestServer').onclick = async () => {
    net.saveBase($('#serverIn').value);
    $('#serverMsg').textContent = '확인하는 중…';
    try { await net.ping(); $('#serverMsg').innerHTML = '✅ 서버가 잘 응답합니다. 방을 만들어 보세요.'; }
    catch (e) { $('#serverMsg').innerHTML = '❌ ' + escapeHtml(e.message); }
  };
  $('#btnCreateRoom').onclick = () => joinFlow(null);
  $('#btnJoinRoom').onclick = () => joinFlow($('#roomIn').value.trim());
  $('#roomIn').addEventListener('keydown', e => { if (e.key === 'Enter') joinFlow($('#roomIn').value.trim()); });
  $('#btnCopyCode').onclick = async () => {
    try {
      await navigator.clipboard.writeText(net.room);
      $('#btnCopyCode').textContent = '✅ 복사했어요!';
    } catch (e) { $('#btnCopyCode').textContent = '방 번호: ' + net.room; }
    setTimeout(() => $('#btnCopyCode').textContent = '번호 복사하기', 1600);
  };
  $('#btnLeaveRoom').onclick = () => { net.disconnect(); showScreen('scOnline'); };
  $('#btnHostStart').onclick = () => {
    if (!net.host) return;
    lobbyError('');
    net.sendGo(lobby.trackId, lobby.laps, Date.now() & 0xffff);
  };

  // 키보드 단축키
  window.addEventListener('keydown', (e) => {
    if (!app.running) return;
    if (e.code === 'Escape' || e.code === 'KeyP') { setPaused(!app.paused); e.preventDefault(); }
    if (e.code === 'KeyC' && app.cams[0]) {
      app.cams.forEach(c => { c.mode = (c.mode + 1) % 3; c.ready = false; });
    }
    if (e.code === 'KeyR' && app.player && !app.paused) app.player.respawn(app.race.track);
  });

  // 소리 켜기/끄기
  const sndBtn = document.createElement('button');
  sndBtn.className = 'btn ghost sm';
  sndBtn.style.cssText = 'position:fixed;right:14px;top:14px;z-index:31';
  const paint = () => sndBtn.textContent = audio.on ? '🔊 소리 켜짐' : '🔇 소리 꺼짐';
  paint();
  sndBtn.onclick = () => {
    audio.on = !audio.on;
    app.prefs.sound = audio.on; savePrefs();
    if (audio.on) { audioInit(); if (audio.ctx && audio.ctx.state === 'suspended') audio.ctx.resume(); }
    else audioEngineOff();
    paint();
  };
  $('#ui').appendChild(sndBtn);

  window.addEventListener('resize', () => {
    if (app.R) app.R.resize(QUALITY[app.prefs.quality].dpr);
    $$('.trk canvas').forEach((cv, i) => drawPreview(cv, TRACKS[i % TRACKS.length]));
  });
  // 첫 조작 때 소리 장치를 깨움 (브라우저 정책)
  const wake = () => {
    if (audio.on) { audioInit(); if (audio.ctx && audio.ctx.state === 'suspended') audio.ctx.resume(); }
    window.removeEventListener('pointerdown', wake);
    window.removeEventListener('keydown', wake);
  };
  window.addEventListener('pointerdown', wake);
  window.addEventListener('keydown', wake);
}

function openOnline() {
  $('#serverIn').value = net.loadBase();
  $('#onlineErr').classList.add('hidden');
  if (!net.ready) {
    $('#onlineErr').innerHTML =
      '아직 <b>접속 서버 주소</b>가 없습니다. 아래 칸에 선생님이 알려 주신 주소를 넣고 <b>주소 저장</b>을 눌러 주세요.<br>'
      + '(서버 없이도 <b>혼자 달리기</b>와 <b>둘이 나눠 달리기</b>는 그대로 됩니다.)';
    $('#onlineErr').classList.remove('hidden');
  }
  showScreen('scOnline');
}

/** 방 만들기(code=null) 또는 들어가기 */
async function joinFlow(code) {
  const err = $('#onlineErr');
  err.classList.add('hidden');
  if (!net.ready) {
    err.textContent = '먼저 접속 서버 주소를 저장해 주세요.';
    err.classList.remove('hidden'); return;
  }
  const btn = code ? $('#btnJoinRoom') : $('#btnCreateRoom');
  const label = btn.textContent;
  btn.disabled = true; btn.textContent = '연결하는 중…';
  try {
    let room = code;
    if (!room) room = await net.newRoom();
    if (!/^\\d{4,8}$/.test(room)) throw new Error('방 번호는 숫자 6자리입니다.');
    const m = await net.connect(room, app.prefs.nick || '이름없음', app.prefs.colorId, onNetEvent);
    lobby.trackId = m.track || app.prefs.trackId;
    lobby.laps = m.laps || app.prefs.laps;
    lobbyError('');
    showScreen('scLobby');
    lobbyRender();
  } catch (e) {
    err.textContent = e.message || '접속하지 못했습니다.';
    err.classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = label;
  }
}

/* ─────────── 시작 ─────────── */
function boot() {
  const canvas = $('#gl');
  let R;
  try { R = new Renderer(canvas); } catch (e) { R = null; console.error(e); }
  if (!R || !R.ok) {
    $('#load').classList.add('hidden');
    $('#nogl').classList.remove('hidden');
    $('#ui').classList.add('off');
    return;
  }
  app.R = R;
  R.resize(2);

  loadPrefs();
  net.loadBase();
  hudInit();
  plateInit();
  bindTouch();
  buildPickers();
  wireUI();

  $('#load').classList.add('hidden');
  showScreen('scHome');
  requestAnimationFrame(frame);
  console.log('[카트] 준비 완료 — 즐겁게 달리세요! 🏎️');
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
</script>
</body>
</html>
`;

export default {
  fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/favicon.ico') return new Response(null, { status: 204 });
    if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method Not Allowed', { status: 405 });
    return new Response(APP_HTML, {
      headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff' }
    });
  }
};
